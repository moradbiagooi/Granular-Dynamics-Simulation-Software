//page 39
#ifndef _Sheath_h
#define _Sheath_h

#include <iostream>
#include <math.h>

#include "properties.h"

#ifdef TwoDimensional
#include "Vector.h"
#endif


#include "Particle.h"

using namespace std;
/*
inline double abs(double dx){
return dx < 0 ? -dx : dx;
}
*/

inline double normalize(double dx, double L){
  while(dx<-L/2) dx+=L;
  while(dx>=L/2) dx-=L;
  return dx;
}

//class Particle;

class Sheath {
  friend istream & operator >> (istream & is, Sheath & p);
  friend ostream & operator << (ostream & os, const Sheath & p);


#ifdef OneDimensional
  friend double Distance(const Sheath & p1, const Sheath & p2, double lx){
//    double dx=normalize(p1.rtd0.x()-p2.rtd0.x(),lx);
    double dx=normalize(p1.rtd0-p2.rtd0,lx);
    return sqrt(dx*dx);
  }

  friend void force(Sheath & p1, Sheath & p2, double lx);
//  friend void force3(Sheath & p1, Particle & p2, double lx); void internal_force();
#endif

#ifdef TwoDimensional
  friend double Distance(const Sheath & p1, const Sheath & p2, double lx, double ly){
    double dx=normalize(p1.rtd0.x()-p2.rtd0.x(),lx);
    double dy=normalize(p1.rtd0.y()-p2.rtd0.y(),ly);
    return sqrt(dx*dx+dy*dy);
  }

  friend void force(Sheath & p1, Sheath & p2, double lx, double ly);
  friend void force3(Sheath & p1, Particle & p2, double lx, double ly);
#endif


public:
#ifdef OneDimensional
  Sheath(): rtd0(0), rtd1(0), rtd2(0), rtd3(0), rtd4(0)
  {}
#endif
#ifdef TwoDimensional
  Sheath(): rtd0(null), rtd1(null), rtd2(null), rtd3(null), rtd4(null)
  {}
#endif
//  Vector & pos() {return rtd0;}
//  Vector pos() const {return rtd0;}


#ifdef ParticlesExist
  double & P_x() {return P.x();}
  double P_x() const {return P.x();}
 
  double & P_vx() {return P.vx();}
  double P_vx() const {return P.vx();}
 
  double & P_r() {return P.r();}
  double P_r() const {return P.r();}

//  double & P_r_mid() {return P.r_mid();}
//  double P_r_mid() const {return P.r_mid();}

  double P_m() const {return P.m();}
  double & P_m() {return P.m();}

  double & P_Y() {return P.Y();}
  double P_Y () const {return P.Y();}

  double & P_A() {return P.A();}
  double P_A() const {return P.A();}

  double & P_mu() {return P.mu();}
  double P_mu() const {return P.mu();}
#endif

// ----------------- 
#ifdef OneDimensional
  double & x() {return rtd0;}
  double x() const {return rtd0;}
  double & vx() {return rtd1;}
  double vx() const {return rtd1;}
#else
  double & x() {return rtd0.x();}
  double x() const {return rtd0.x();}
  double & vx() {return rtd1.x();}
  double vx() const {return rtd1.x();}
#endif

#ifdef TwoDimensional
  double & y() {return rtd0.y();}
  double y() const {return rtd0.y();}
  double & vy() {return rtd1.y();}
  double vy() const {return rtd1.y();}


  double & phi() {return rtd0.phi();}
  double phi() const {return rtd0.phi();}
  double & omega() {return rtd1.phi();}
  double omega() const {return rtd1.phi();}
#endif

//  const Vector & velocity() const {return rtd1;}

  double & r() {return _r;}
  double r() const {return _r;}

  double & r_mid() {return _r_mid;}
  double r_mid() const {return _r_mid;}

  double m() const {return _m;}
  double & m() {return _m;}

  double & Y() {return _Y;}
  double Y () const {return _Y;}

  double & A() {return _A;}
  double A() const {return _A;}

  double & mu() {return _mu;}
  double mu() const {return _mu;}



  int ptype() const {return _ptype;}//Returns the type of the Sheath. Sheaths of type 0 are subject to Newton’s equationof motion, Sheaths of other types belong to walls.
  int & ptype() {return _ptype;}
  void predict(double dt);//First step of the Gear algorithm

#ifdef OneDimensional
  void add_force(const double & f){_force+=f;} //Adds a value to the total force _force of the Sheath
#endif
#ifdef TwoDimensional
  void add_force(const vector & f){_force+=f;} //Adds a value to the total force _force of the Sheath
#endif

  void correct(double dt);//Second step of the Gear algorithm
  double kinetic_energy() const;//Computes the kinetic energy of the Sheath

#ifdef ParticlesExist
  bool P_slipped_out();
#endif

  void set_force_to_zero(){
#ifdef OneDimensional
    _force=0;
#else
    _force=null;
#endif
#ifdef ParticlesExist
    P.set_force_to_zero();
#endif
  }
  void boundary_conditions(int n, double timestep, double Time);//Computes the positions and velocities of Sheaths of type other than 0

#ifdef OneDimensional
  void periodic_bc(double x_0, double lx);//Enforces the periodic boundary conditions
#endif

#ifdef TwoDimensional
  void periodic_bc(double x_0, double y_0, double lx, double ly);//Enforces the periodic boundary conditions
#endif

#ifdef ParticlesExist
  void internal_force(double lx);
#endif

private:

  double _r, _m, _J, _r_mid;
  int _ptype;
  double _Y,_A,_mu,_gamma;

#ifdef OneDimensional
  double rtd0,rtd1,rtd2,rtd3,rtd4;
  double _force;
#endif  

#ifdef TwoDimensional
  Vector rtd0,rtd1,rtd2,rtd3,rtd4;
  Vector _force;
#endif  

#ifdef ParticlesExist
  Particle P;
#endif  
};

#endif
