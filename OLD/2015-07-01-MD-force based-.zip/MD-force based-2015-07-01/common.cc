
/* //==========================
   // Developed by Morad Biagooi
   // m.biagooi@gmail.com
   // m.biagooi@iasbs.ac.ir
*/ //==========================

#include <stdlib.h>
#include <stdio.h>
#include "common.h"
#include "Sphere.h"   
#include "Sphere2.h"
#include <math.h>
#include "force3.h"
#include "properties.h"
#include <string>
#include <sys/stat.h> // used for mkdir()
#include <time.h>
#include <iomanip> 

using namespace std;

double Time=0, timestep;

int nstep, nprint, nenergy;
int Atom=0,XYZscale=200;

int Num_of_type1=0; // used for XYZ visualization
                    // - number of type1 particles

#ifdef OneDimensional
double lx, x_0;// *** if these are extern 
               //why we re-define them and
               // use them in the function arguments?
#endif
#ifdef TwoDimensional
double lx, ly, x_0, y_0;// *** above
#endif
#ifdef ThreeDimensional
double lx, ly, lz, 
       x_0, y_0, z_0;// *** above argument?
#endif


double Density1=1.0,Density2=1.0;

double Pi=3.14159265;

double mass_in,mass_out;
double radius_in,radius_mid,radius_out;
double A_in,A_out;   //Dissipation
double Y_in,Y_out;   //Young modulus
double mu_in,mu_out; //friction


Vector G; // gravity 

vector< Sphere > particle;   // outer particles //

#ifdef InnerParticlesExist
vector< Sphere2 > particle2; // inner particles//
#endif


unsigned int no_of_particles;


int mkdir(const char *path, mode_t mode);

ofstream ftemperature;
ofstream fparameters_out;

#ifdef XYZOutputMaker
ofstream xyzfile;  // only outer particles
ofstream xyzfile2; // with inner particles
#endif

string str_folder_output;

void output_file_maker();


void init_system(char * fname_is);
void init_parameters(char * fname_ip);

double total_kinetic_energy1(),
       total_kinetic_energy2();// for particles type one and two




//==================================================  main
//==================================================  main
//==================================================  main

int main (int argc, char ** argv)
{


  if (argc!=3){
    cerr << "Needs 2 input files, for example: \n\t \
             /a.out init_particles.dat init_parameters.dat";
    exit(0);
    return 0; 
  }

  clock_t t1,t2;
  t1=clock();


  ftemperature.precision(10); 

  init_parameters(argv[2]);

  init_system(argv[1]);
  
  output_file_maker();


#ifdef InnerParticlesExist
  init_inner_particles();
#endif




  init_algorithm();
  phase_plot();

#ifdef InnerParticlesExist
  // *** not sure about this in case of having outer dissipations ***
  double _m_eff = mass_out * mass_in / (mass_out+mass_in); 
//  in case of force fn=Y*sqrt(reff)*(xi+A*xidot);
//  double _Y     = Y_out * sqrt(radius_out/2);
//  double _gamma = Y_out * sqrt(radius_out/2) * A_in;
//  in case of force fn=Y*xi+A*xidot;
  double _Y     = Y_out;
  double _gamma = A_in;
#else
  double _m_eff = mass_out * mass_out / (mass_out+mass_out);
//  in case of force fn=Y*sqrt(reff)*(xi+A*xidot);
//  double _Y     = Y_out * sqrt(radius_out/2);
//  double _gamma = Y_out * sqrt(radius_out/2) * A_out;
//  in case of force fn=Y*xi+A*xidot;
  double _Y     = Y_out;
  double _gamma = A_out;
#endif

  double _epsilon; // coefficient of restitution, in Hookean case
  _epsilon      = exp( -((Pi*_gamma)/(2*_m_eff)) / 
                  sqrt((_Y/_m_eff)-(_gamma/(2*_m_eff))*(_gamma/(2*_m_eff))) );

  cout            << "epsilon : " << _epsilon << "\n";
  fparameters_out << "epsilon : " << _epsilon << "\n";

  cout<<"======================time loop()\n";
  for (int i=0;i<nstep;i++){

    step();

#ifdef XYZOutputMaker
    if ((i+1)%nprint==0){
//      cout << "phase_plot: " << i+1 << "  " << particle.size() << " particles\n";
      phase_plot();
    }
#endif

    if ((i+1)%nenergy==0){
//      cout << "temperature_plot: " << i+1 << "  " << particle.size() << " particles\n";
      double Tmp1=total_kinetic_energy1()/particle.size();

#ifdef InnerParticlesExist
      double Tmp2=total_kinetic_energy2()/particle2.size();
      ftemperature << Time << "\t" << Tmp1 << "\t"<< Tmp2 << "\t"<< Tmp1+Tmp2 << endl;
#else
      ftemperature << Time << "\t" << Tmp1 << "\t"<< "0.0" << "\t"<< Tmp1 << endl;
#endif


    }

  }

  phase_plot();


  t2=clock();
  float diff ((float)t2-(float)t1);
  cout            << "\n  execution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n\n" ;
  fparameters_out <<"\nexecution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n" ;

  return 0;

}

//==================================================  output_file_maker
//==================================================  output_file_maker
//==================================================  output_file_maker

void output_file_maker(){



  str_folder_output.append("outputs/"); 

  const char* char_folder_output=str_folder_output.c_str();
  mkdir(char_folder_output,0777);

  // what if outputs already existed with files within it


  time_t rawtime;
  struct tm * timeinfo;
  char char_buffer [40];
  time (&rawtime);
  timeinfo = localtime (&rawtime);
  cout << asctime(timeinfo)<<"\n";


  time (&rawtime);
  timeinfo = localtime (&rawtime);

//  strftime (buffer,80,"Now it's %I:%M%p.",timeinfo);
//  strftime (buffer,80,"Now it's %F_%T",timeinfo);

  strftime (char_buffer,80,"  %F  %T",timeinfo);


  char_folder_output = str_folder_output.c_str();
  mkdir(char_folder_output,0777);

//  string str_fname=str_folder_output;
  string str_fname;



// ------------------



#ifdef OneDimensional    //(1) 
  str_fname.append("_1D");
#endif
#ifdef TwoDimensional    //(2)
  str_fname.append("_2D");
#endif
#ifdef ThreeDimensional    //(3)
  str_fname.append("_3D");
#endif

#ifdef InnerParticlesExist //ON or OFF//
  str_fname.append("_i:On");
#ifdef HookeanInnerForce    //(1)
  str_fname.append("_i:Hook");
#endif
#ifdef HertzianInnerForce    //(2)
  str_fname.append("_i:Hertz");
#endif
#else
  str_fname.append("_i:Off");
#endif


#ifdef HookeanOuterForce   //(1)
  str_fname.append("_o:Hook");
#endif

#ifdef HertzianOuterForce    //(2)
  str_fname.append("_o:Hertz");
#endif






  char buffer[50]="";

  sprintf(buffer,"_nP:%lu",particle.size());
  str_fname.append(buffer);
  sprintf(buffer,"_dt:%g",timestep);
  str_fname.append(buffer);
  sprintf(buffer,"_nt:%u",nstep);
  str_fname.append(buffer);
//  sprintf(buffer,"_t-%g",nstep*timestep);
#ifdef InnerParticlesExist
  sprintf(buffer,"_Ai:%g",A_in);
  str_fname.append(buffer);
#endif
  sprintf(buffer,"_Ao:%g",A_out);
  str_fname.append(buffer);
#ifdef InnerParticlesExist
  sprintf(buffer,"_Mi:%g",mass_in);
  str_fname.append(buffer);
#endif
  sprintf(buffer,"_Mo:%g",mass_out);
  str_fname.append(buffer);

//----


  string str_fname_T=str_folder_output;
  str_fname_T.append("/T");
  str_fname_T.append(str_fname);
  str_fname_T.append(".dat");
  const char * char_ftemperature=str_fname_T.c_str();
  ftemperature.open(char_ftemperature);



  string str_fname_P=str_folder_output;
  str_fname_P.append("/P");
  str_fname_P.append(str_fname);
  str_fname_P.append(".dat");
  const char * char_fparameters_out=str_fname_P.c_str();
  fparameters_out.open(char_fparameters_out);
//----

#ifdef XYZOutputMaker
  string str_xyzfile=str_folder_output;
  str_xyzfile.append("/XYZ");
  str_xyzfile.append(str_fname);
  str_xyzfile.append(".xyz");
  const char * char_xyzfile=str_xyzfile.c_str();
  xyzfile.open(char_xyzfile);
#ifdef InnerParticlesExist
  string str_xyzfile2=str_folder_output;
  str_xyzfile2.append("/XYZ2");
  str_xyzfile2.append(str_fname);
  str_xyzfile2.append(".xyz");
  const char * char_xyzfile2=str_xyzfile2.c_str();
  xyzfile2.open(char_xyzfile2);
#endif
#endif



  fparameters_out << "==================Date and time"     << "\n\n";
  fparameters_out << char_buffer                           << "\n\n";
  fparameters_out << "==================system properties" << "\n\n";
#ifdef OneDimensional    //(1) 
  fparameters_out << "OneDimensional"       << "\n";
#endif
#ifdef TwoDimensional    //(2)
  fparameters_out << "TwoDimensional"       << "\n";
#endif
#ifdef ThreeDimensional    //(3)
  fparameters_out << "ThreeDimensional"     << "\n";
#endif

#ifdef InnerParticlesExist //ON or OFF//
  fparameters_out << "InnerParticlesON"     << "\n";
#ifdef HookeanInnerForce    //(1)
  fparameters_out << "HookeanInnerForce"    << "\n";
#endif
#ifdef HertzianInnerForce    //(2)
  fparameters_out << "HertzianInnerForce"   << "\n";
#endif
#else
  fparameters_out << "InnerParticlesOFF"    << "\n";
#endif

#ifdef HookeanOuterForce   //(1)
  fparameters_out << "HookeanOuterForce"    << "\n";
#endif
#ifdef HertzianOuterForce    //(2)
  fparameters_out << "HertzianOuterForce"   << "\n";
#endif

  fparameters_out << "\n==================init_parameters\n\n";
#ifdef InnerParticlesExist //ON or OFF//
  fparameters_out << "radius_in: "  << radius_in  << "\n";
  fparameters_out << "radius_mid: " << radius_mid << "\n";
#endif
  fparameters_out << "radius_out: " << radius_out << "\n";
#ifdef InnerParticlesExist //ON or OFF//
  fparameters_out << "mass_in: "    << mass_in    << "\n";
#endif
  fparameters_out << "mass_out: "   << mass_out   << "\n";
#ifdef InnerParticlesExist //ON or OFF//
  fparameters_out << "A_in: "       << A_in       << "\n";
#endif
  fparameters_out << "A_out: "      << A_out      << "\n";
#ifdef InnerParticlesExist //ON or OFF//
  fparameters_out << "Y_in: "       << Y_in       << "\n";
#endif
  fparameters_out << "Y_out: "      << Y_out      << "\n";
#ifdef InnerParticlesExist //ON or OFF//
  fparameters_out << "mu_in: "      << mu_in      << "\n";
#endif
  fparameters_out << "mu_out: "     << mu_out     << "\n";
  fparameters_out << "dt: "         << timestep   << "\n";
  fparameters_out << "nsteps: "     << nstep      << "\n";
  fparameters_out << "time: "  
                  << nstep*timestep               << "\n";

  fparameters_out << "\n==================\n\n";
  fparameters_out << "Number of particles: " 
                  << particle.size()              << "\n";

#ifdef InnerParticlesExist
  fparameters_out << "Number of inner particles: "
                  <<particle2.size()              << "\n";
#endif


}



//==================================================  integrate
//==================================================  integrate
//==================================================  integrate

void integrate()
{

  for(unsigned int i=0;i<particle.size();i++){
    if(particle[i].ptype()==0) {
      particle[i].set_force_to_zero();
      particle[i].predict(timestep);
#ifdef InnerParticlesExist
      particle2[i].set_force_to_zero();
      particle2[i].predict(timestep); 
#endif

    } else {
      particle[i].boundary_conditions(i,timestep,Time);
    }
  }



    make_forces();

  
  for(unsigned int i=0;i<particle.size();i++){

    if(particle[i].ptype()==0) {
      particle[i].correct(timestep);
#ifdef InnerParticlesExist
      particle2[i].correct(timestep);
#endif
    }

  }


  for(unsigned int i=0;i<particle.size();i++){

#ifdef OneDimensional
    particle[i].periodic_bc (x_0, lx);
#ifdef InnerParticlesExist
    particle2[i].periodic_bc(x_0, lx);
#endif
#endif

#ifdef TwoDimensional
    particle[i].periodic_bc (x_0, y_0, lx, ly);
#ifdef InnerParticlesExist
    particle2[i].periodic_bc(x_0, y_0, lx, ly);
#endif
#endif

#ifdef ThreeDimensional
    particle[i].periodic_bc (x_0, y_0, z_0, lx, ly, lz);
#ifdef InnerParticlesExist
    particle2[i].periodic_bc(x_0, y_0, z_0, lx, ly, lz);
#endif
#endif

  }
  Time+=timestep;
}

//==================================================  init_parameters
//==================================================  init_parameters
//==================================================  init_parameters

void init_parameters(char * fname_ip)
{
  cout<<"======================init_parameters()\n";
  ifstream fparameters(fname_ip);
  while(fparameters.peek()=='#'){
    string type;
    fparameters >> type;
    if(type=="#radius_in:"){
      fparameters >> radius_in;
      fparameters.ignore(100,'\n');
      cout << "radius_in: " << radius_in << endl;
    }
      else if(type=="#radius_mid:"){
      fparameters >> radius_mid;
      fparameters.ignore(100,'\n');
      cout << "radius_mid: " << radius_mid << endl;
    }
      else if(type=="#radius_out:"){
      fparameters >> radius_out;
      fparameters.ignore(100,'\n');
      cout << "radius_out: " << radius_out << endl;
    }
      else if(type=="#mass_in:"){
      fparameters >> mass_in;
      fparameters.ignore(100,'\n');
      cout << "mass_in: " << mass_in << endl;
    }
      else if(type=="#mass_out:"){
      fparameters >> mass_out;
      fparameters.ignore(100,'\n');
      cout << "mass_out: " << mass_out << endl;
    }
      else if(type=="#A_in:"){
      fparameters >> A_in;
      fparameters.ignore(100,'\n');
      cout << "A_in: " << A_in << endl;
    }
      else if(type=="#A_out:"){
      fparameters >> A_out;
      fparameters.ignore(100,'\n');
      cout << "A_out: " << A_out << endl;
    }
      else if(type=="#Y_in:"){
      fparameters >> Y_in;
      fparameters.ignore(100,'\n');
      cout << "Y_in: " << Y_in << endl;
    }
      else if(type=="#Y_out:"){
      fparameters >> Y_out;
      fparameters.ignore(100,'\n');
      cout << "Y_out: " << Y_out << endl;
    } else if(type=="#mu_in:"){
      fparameters >> mu_in;
      fparameters.ignore(100,'\n');
      cout << "mu_in: " << mu_in << endl;
    }
      else if(type=="#mu_out:"){
      fparameters >> mu_out;
      fparameters.ignore(100,'\n');
      cout << "mu_out: " << mu_out << endl;
    }


      else {
      cerr << "init_parameters(): unknown global property: " << type << endl;
//      abort(); what's this
    }
  }
}

//==================================================  init_system 
//==================================================  init_system 
//==================================================  init_system 

void init_system(char * fname_is)
{
  cout<<"======================init_system()\n";
  fparameters_out<<"==================init_system"<<"\n";
  ifstream fparticle(fname_is);
  while(fparticle.peek()=='#'){
    string type;
    fparticle >> type;
    if(type=="#gravity:"){

#ifdef OneDimensional
      fparticle >> G.x();
#endif

#ifdef TwoDimensional
      fparticle >> G.x() >> G.y() >> G.phi();
#endif

#ifdef ThreeDimensional
      fparticle >> G.x() >> G.y() >> G.z();
#endif

      fparticle.ignore(100,'\n');
      cout << "gravity: " << G << endl;
      fparameters_out << "gravity: " << G << endl;
    } else if(type=="#Time:"){
      fparticle >> Time;
      fparticle.ignore(100,'\n');
      cout << "Time: " << Time << endl;
      fparameters_out << "Time: " << Time << endl;
    } else if(type=="#nstep:"){
      fparticle >> nstep;
      fparticle.ignore(100,'\n');
      cout << "nstep: " << nstep << endl;
      fparameters_out << "nstep: " << nstep << endl;
    } else if(type=="#timestep:"){
      fparticle >> timestep;
      fparticle.ignore(100,'\n');
      cout << "timestep: " << timestep << endl;
      fparameters_out << "timestep: " << timestep << endl;
    } else if(type=="#nprint:"){
      fparticle >> nprint;
      fparticle.ignore(100,'\n');
      cout << "nprint: " << nprint << endl;
    } else if(type=="#nenergy:"){
      fparticle >> nenergy;
      fparticle.ignore(100,'\n');
      cout << "nenergy: " << nenergy << endl;
      fparameters_out << "nenergy: " << nenergy << endl;
    } else if(type=="#lx:"){
      fparticle >> lx;
      fparticle.ignore(100,'\n');
      cout << "lx: " << lx << endl;
      fparameters_out << "lx: " << lx << endl;
    } 
#ifdef TwoDimensional
      else if(type=="#ly:"){
      fparticle >> ly;
      cout << "ly: " << ly << endl;
      fparameters_out << "ly: " << ly << endl;
      fparticle.ignore(100,'\n'); // ?????????????
    } 
#endif

#ifdef ThreeDimensional
      else if(type=="#ly:"){
      fparticle >> ly;
      cout << "ly: " << ly << endl;
      fparameters_out << "ly: " << ly << endl;
      fparticle.ignore(100,'\n'); // ?????????????
    } 
      else if(type=="#lz:"){
      fparticle >> lz;
      cout << "lz: " << lz << endl;
      fparameters_out << "lz: " << lz << endl;
      fparticle.ignore(100,'\n'); // ?????????????
    } 
#endif

      else if(type=="#x_0:"){
      fparticle >> x_0;
      fparticle.ignore(100,'\n');
      cout << "x_0: " << x_0 << endl;
      fparameters_out << "x_0: " << x_0 << endl;
    } 
#ifdef TwoDimensional
      else if(type=="#y_0:"){
      fparticle >> y_0;
      cout << "y_0: " << y_0 << endl;
      fparameters_out << "y_0: " << y_0 << endl;
      fparticle.ignore(100,'\n');
    } 
#endif

#ifdef ThreeDimensional
      else if(type=="#y_0:"){
      fparticle >> y_0;
      cout << "y_0: " << y_0 << endl;
      fparameters_out << "y_0: " << y_0 << endl;
      fparticle.ignore(100,'\n');
    } 
      else if(type=="#z_0:"){
      fparticle >> z_0;
      cout << "z_0: " << z_0 << endl;
      fparameters_out << "z_0: " << z_0 << endl;
      fparticle.ignore(100,'\n');
    } 
#endif

      else {
      cerr << "init_system(): unknown global property: " << type << endl;
//      abort(); what's this
    }
  }
  while(fparticle){
    Sphere pp;
    fparticle >> pp;

    pp.m()=mass_out;
    pp.r()=radius_out;;
    pp.r_mid()=radius_mid;
    pp.A()=A_out;
    pp.Y()=Y_out;
    pp.mu()=mu_out;


    if(fparticle){
      particle.push_back(pp);
    }
  }
  no_of_particles=particle.size();
  cout << no_of_particles << " particles read\n" << flush;
}

//==================================================  init_inner_particles
//==================================================  init_inner_particles
//==================================================  init_inner_particles

#ifdef InnerParticlesExist
void init_inner_particles(){
//int size_i=particle.size();

  for (unsigned int i=0;i<particle.size();i++){
#ifdef OneDimensional
    Sphere2 pp2(particle[i].x(),particle[i].vx());

    if (particle[i].ptype()==1) {
    Num_of_type1++;
    }

#endif
#ifdef TwoDimensional
    Sphere2 pp2(particle[i].x() ,particle[i].y()
               ,particle[i].vx(),particle[i].vy());

    if (particle[i].ptype()==1) {
    Num_of_type1++;
    }

#endif
#ifdef ThreeDimensional
    Sphere2 pp2(particle[i].x() ,particle[i].y() ,particle[i].z()
               ,particle[i].vx(),particle[i].vy(),particle[i].vz());

    if (particle[i].ptype()==1) {
    Num_of_type1++;
    }

#endif

    pp2.m()=mass_in;
    pp2.r()=radius_in;
    pp2.A()=A_in;
    pp2.Y()=Y_in;
    pp2.mu()=mu_in;

    particle2.push_back(pp2);

  }
}
#endif




//==================================================  total_kinetic_eneregy
//==================================================  total_kinetic_eneregy
//==================================================  total_kinetic_eneregy

double total_kinetic_energy1()
{
  double sum=0;
  for(unsigned int i=0;i<particle.size();i++){
    if(particle[i].ptype()==0){
      sum+=particle[i].kinetic_energy();
    }
  }
  return sum;
}

double total_kinetic_energy2()
{
  double sum=0;
#ifdef InnerParticlesExist
  for(unsigned int i=0;i<particle2.size();i++){
    if(particle2[i].ptype()==0){
      sum+=particle2[i].kinetic_energy();
    }
  }
#endif
  return sum;
}


//==================================================  phase_plot
//==================================================  phase_plot
//==================================================  phase_plot

void phase_plot()
{
/*
  os << "#NewFrame\n";
  os << "#no_of_particles: " << no_of_particles << endl;
  os << "#compressed: no\n";
  os << "#type: SphereXYPhiVxVyOmegaRMFixed25\n";
  os << "#gravity: " << G.x() << " " << G.y() << " " << G.phi() << endl;
  os << "#Time: " << Time << endl;
  os << "#timestep: " << timestep << endl;
  os << "#EndOfHeader\n";
*/
#ifdef XYZOutputMaker
  xyzfile  << particle.size() << "\nAtom\n";

#ifdef InnerParticlesExist
  xyzfile2 << particle.size()+particle2.size()-Num_of_type1
           << "\nAtom\n";
#else
  xyzfile2 << particle.size() << "\nAtom\n";
#endif

  for(unsigned int i=0;i<particle.size();i++){

//    os << particle[i];
#ifdef OneDimensional
    xyzfile  << particle[i].ptype()+1    << "\t"
             << XYZscale*particle[i].x() << "\t0.0\t0.0\n";

    xyzfile2 << particle[i].ptype()+1    << "\t"
             << XYZscale*particle[i].x() << "\t0.0\t0.0\n";
#ifdef InnerParticlesExist
    if (particle[i].ptype()!=1){
      xyzfile2 << 3                        << "\t"
               << XYZscale*particle2[i].x()<< "\t0.0\t0.0\n";
    }
#endif
#endif


#ifdef TwoDimensional
    xyzfile  << particle[i].ptype()+1    << "\t"
             << XYZscale*particle[i].x() << "\t"
             << XYZscale*particle[i].y() << "\t0.0\n";

    xyzfile2 << particle[i].ptype()+1    << "\t"
             << XYZscale*particle[i].x() << "\t"
             << XYZscale*particle[i].y() << "\t0.0\n";
#ifdef InnerParticlesExist
    if (particle[i].ptype()!=1){
      xyzfile2 << 3                         << "\t"
               << XYZscale*particle2[i].x() << "\t"
               << XYZscale*particle2[i].y() << "\t0.0\n";
    }
#endif
#endif

#ifdef ThreeDimensional
    xyzfile  << particle[i].ptype()+1    << "\t"
             << XYZscale*particle[i].x() << "\t"
             << XYZscale*particle[i].y() << "\t"
             << XYZscale*particle[i].z() << "\n";


    xyzfile2 << particle[i].ptype()+1    << "\t"
             << XYZscale*particle[i].x() << "\t"
             << XYZscale*particle[i].y() << "\t"
             << XYZscale*particle[i].z() << "\n";

#ifdef InnerParticlesExist
    if (particle[i].ptype()!=1){
      xyzfile2 << 3                         << "\t"
               << XYZscale*particle2[i].x() << "\t"
               << XYZscale*particle2[i].y() << "\t"
               << XYZscale*particle2[i].z() << "\n";

    }
//    xyzfile2 << flush;
#endif
#endif
//    xyzfile  << flush;

  }

#endif
}
