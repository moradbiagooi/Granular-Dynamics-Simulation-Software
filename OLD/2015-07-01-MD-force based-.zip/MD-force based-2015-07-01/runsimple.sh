#reset
#rm simple_box.out
#g++ -o simple_box.out common.cc Sphere.cc Sphere2.cc verlet.cc
g++ -std=c++11 -o simple_box.out common.cc Sphere.cc Sphere2.cc simple.cc
#./simple_box.out input_box_1D.dat input_parameters.dat
#gnuplot outputs/fit_code
#vmd output2.xyz
#rm phase.dat lastframe.dat
