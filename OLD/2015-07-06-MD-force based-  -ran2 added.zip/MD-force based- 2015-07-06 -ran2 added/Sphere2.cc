//part 1 page 41

#include "Sphere2.h"
#include <assert.h>
#include "properties.h"

extern Vector G;


void Sphere2::predict(double dt)
{
  double a1=dt;
  double a2=a1*dt/2;
  double a3=a2*dt/3;
  double a4=a3*dt/4;

  rtd0+=a1*rtd1 + a2*rtd2 + a3*rtd3 + a4*rtd4;
  rtd1+=a1*rtd2 + a2*rtd3 + a3*rtd4;
  rtd2+=a1*rtd3 + a2*rtd4;
  rtd3+=a1*rtd4;
}


void Sphere2::correct(double dt)
{
  static Vector accel,corr;
  double dtrez = 1/dt;
  const double coeff0=double(19)/double(90)*(dt*dt/double(2));
  const double coeff1=double(3)/double(4)*(dt/double(2));
  const double coeff3=double(1)/double(2)*(double(3)*dtrez);
  const double coeff4=double(1)/double(12)*(double(12)*(dtrez*dtrez));

#ifdef GravityInnerForce

#ifdef OneDimensional
  accel=Vector((1/_m)*_force.x()+G.x());
#endif
#ifdef TwoDimensional
  accel=Vector((1/_m)*_force.x()+G.x(),
    (1/_m)*_force.y()+G.y(),
    (1/_J)*_force.phi()+G.phi()); // *** in this case_ is that rotational gravity??
#endif
#ifdef ThreeDimensional
  accel=Vector((1/_m)*_force.x()+G.x(),
    (1/_m)*_force.y()+G.y(),
    (1/_m)*_force.z()+G.z());
#endif

#else

#ifdef OneDimensional
  accel=Vector((1/_m)*_force.x());
#endif
#ifdef TwoDimensional
  accel=Vector((1/_m)*_force.x(),
    (1/_m)*_force.y(),
    (1/_J)*_force.phi());
#endif
#ifdef ThreeDimensional
  accel=Vector((1/_m)*_force.x(),
    (1/_m)*_force.y(),
    (1/_m)*_force.z());
#endif

#endif

  corr=accel-rtd2;

  rtd0 += coeff0*corr;
  rtd1 += coeff1*corr;
  rtd2  = accel;
  rtd3 += coeff3*corr;
  rtd4 += coeff4*corr;
}


#ifdef OneDimensional
void Sphere2::periodic_bc(double x_0, double lx)
{
  while(rtd0.x()<x_0) rtd0.x()+=lx;
  while(rtd0.x()>x_0+lx) rtd0.x()-=lx;
}
#endif

#ifdef TwoDimensional
void Sphere2::periodic_bc(double x_0, double y_0, double lx, double ly)
{
  while(rtd0.x()<x_0) rtd0.x()+=lx;
  while(rtd0.x()>x_0+lx) rtd0.x()-=lx;
  while(rtd0.y()<y_0) rtd0.y()+=ly;
  while(rtd0.y()>y_0+ly) rtd0.y()-=ly;
}
#endif

#ifdef ThreeDimensional
void Sphere2::periodic_bc(double x_0, double y_0, double z_0, double lx, double ly, double lz)
{
  while(rtd0.x()<x_0) rtd0.x()+=lx;
  while(rtd0.x()>x_0+lx) rtd0.x()-=lx;
  while(rtd0.y()<y_0) rtd0.y()+=ly;
  while(rtd0.y()>y_0+ly) rtd0.y()-=ly;
  while(rtd0.z()<z_0) rtd0.z()+=lz;
  while(rtd0.z()>z_0+lz) rtd0.z()-=lz;
}
#endif



//part  5 page 45
double Sphere2::kinetic_energy() const
{
#ifdef OneDimensional
  return _m*(rtd1.x()*rtd1.x())/2;
#endif

#ifdef TwoDimensional
  return _m*(rtd1.x()*rtd1.x()/2 + rtd1.y()*rtd1.y()/2)
    + _J*rtd1.phi()*rtd1.phi()/2;
#endif

#ifdef ThreeDimensional
  return _m*(rtd1.x()*rtd1.x() + rtd1.y()*rtd1.y()
    + rtd1.z()*rtd1.z())/2; // which is faster "*0.5" or "/2"
//    + _J*rtd1.phi()*rtd1.phi()/2; // rotational Energy???
#endif

}


