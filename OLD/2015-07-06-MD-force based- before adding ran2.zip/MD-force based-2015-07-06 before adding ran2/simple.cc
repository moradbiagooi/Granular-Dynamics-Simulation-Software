//part 1 page 36
#include "common.h"
#include "Sphere.h"
#include "Sphere2.h"   /* <==== replace this line if necessary */
#include "properties.h"

using namespace std;

extern vector<Sphere> particle;
extern vector<Sphere2> particle2;

void init_algorithm()
{
}

void step()
{
  integrate();
}


void make_forces()
{


  for(unsigned int i=0;i<particle.size();i++){

#ifdef OneDimensional

#ifdef InnerParticlesExist
    force3(particle[i], particle2[i], lx); // between inner and outer particles
#endif

#ifdef OneDimLinForce
    if (i+1 == particle.size()){
      force(particle[i],particle[0], lx); // Periodic B.C
    }
    else
    {
      force(particle[i],particle[i+1], lx); // LINEAR NEIGHBORS FORCE
    }
#else

    for(unsigned int j=i+1;j<particle.size();j++){
    force(particle[i],particle[j], lx); // between outer particles
    }
#endif
#endif



#ifdef TwoDimensional

#ifdef InnerParticlesExist
    force3(particle[i], particle2[i], lx, ly); // between inner and outer particles
#endif




    for(unsigned int j=i+1;j<particle.size();j++){
    force(particle[i],particle[j], lx, ly); // between outer particles
    }

#endif

#ifdef ThreeDimensional

#ifdef InnerParticlesExist
    force3(particle[i], particle2[i], lx, ly, lz); // between inner and outer particles
#endif




    for(unsigned int j=i+1;j<particle.size();j++){
    force(particle[i],particle[j], lx, ly, lz); // between outer particles
    }

#endif




  }

}


