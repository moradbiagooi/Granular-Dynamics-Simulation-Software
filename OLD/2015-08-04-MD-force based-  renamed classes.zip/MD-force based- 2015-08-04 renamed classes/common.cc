
/* //==========================
   // Developed by Morad Biagooi
   // m.biagooi@gmail.com
   // m.biagooi@iasbs.ac.ir
*/ //==========================

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <sys/stat.h> // used for mkdir()
#include <time.h>
#include <iomanip> 

#include "common.h"
#include "Sheath.h"   
#include "Particle.h"
#include "force3.h"
#include "random.h"
#include "properties.h"

#define Pi 3.14159265

using namespace std;

double Time=0, timestep;

int nstep, nprint, nenergy;
int Atom=0,XYZscale=200;

int Num_of_type0=0; // - number of active outer Sheaths
int Num_of_type1=0; // - number of wall Sheaths

unsigned int int_output_index=0;

#ifdef OneDimensional
double lx, x_0;// *** if these are extern 
               //why we re-define them and
               // use them in the function arguments?
#endif
#ifdef TwoDimensional
double lx, ly, x_0, y_0;// *** above
#endif
#ifdef ThreeDimensional
double lx, ly, lz, 
       x_0, y_0, z_0;// *** above argument?
#endif


double Density1=1.0,Density2=1.0;

//double Pi=3.14159265;

double mass_in,mass_out;
double radius_in,radius_mid,radius_out;
double A_in,A_out;   //Dissipation
double Y_in,Y_out;   //Young modulus
double mu_in,mu_out; //friction


Vector G; // gravity 

vector< Sheath > Sheaths;   // outer Sheaths //

#ifdef ParticlesExist
vector< Particle > Particles; // inner Sheaths//
#endif


unsigned int no_of_Sheaths;


int mkdir(const char *path, mode_t mode);

ofstream ftemperature;
ofstream fparameters_out;

#ifdef XYZOutputMaker
ofstream xyzfile;  // only outer Sheaths
ofstream xyzfile2; // with inner Sheaths
#endif

//string str_folder_output;

void output_file_maker();

void temperature_normalizer(double);

void init_system(char * fname_is);
void init_parameters(char * fname_ip);

double total_kinetic_energy1(),
       total_kinetic_energy2();// for Sheaths type one and two




//==================================================  main
//==================================================  main
//==================================================  main


Random Ranni; // makes a R of class Random

long seed ;
long *iseed=&seed; //used in random seeding


int main (int argc, char ** argv)
{

  if (argc!=3){
    cerr << "Needs 2 input files, for example: \n\t \
             /a.out init_Sheaths.dat init_parameters.dat";
    exit(0);
    return 0; 
  }

//======ran(2)
  time_t utime;
  time(&utime);

  long seed = (long)utime;
  iseed=&seed;
  for (int i=0;i< 100000;i++)
    Ranni.ran2(iseed); // to forget first few numbers



  clock_t t1,t2,t3;
  t3=clock();

  for (int j=0;j<1;j++){ // number of files to be created

    t1=clock();

    Sheaths.clear();
#ifdef ParticlesExist
    Particles.clear();
#endif

    ftemperature.precision(10); 

    init_parameters(argv[2]);

    init_system(argv[1]);
  
    output_file_maker();


#ifdef ParticlesExist
    init_inner_Sheaths();
#endif




    init_algorithm();
    phase_plot();

#ifdef ParticlesExist
    double _m_eff = mass_out * mass_in / (mass_out+mass_in); 
    double _Y     = Y_out;
    double _gamma = A_in;
#else
    double _m_eff = mass_out * mass_out / (mass_out+mass_out);
    double _Y     = Y_out;
    double _gamma = A_out;
#endif

    double _epsilon; // coefficient of restitution, in Hookean case
    _epsilon      = exp( -((Pi*_gamma)/(2*_m_eff)) / 
                    sqrt((_Y/_m_eff)-(_gamma/(2*_m_eff))*(_gamma/(2*_m_eff))) );

    cout            << "epsilon : " << _epsilon << "\n";
    fparameters_out << "epsilon : " << _epsilon << "\n";

    cout<<"======================time loop()\n";

    temperature_normalizer(10.0); 

    for (int i=0;i<nstep;i++){

      step();

#ifdef XYZOutputMaker
      if ((i+1)%nprint==0){

        phase_plot();
      }
#endif


      if ((i+1)%nenergy==0){

        double Tmp1=total_kinetic_energy1()/Num_of_type0;

#ifdef ParticlesExist
        double Tmp2=total_kinetic_energy2()/Num_of_type0;
        ftemperature << Time << "\t" << Tmp1 << "\t"<< Tmp2 << "\t"<< Tmp1+Tmp2 << endl;
#else
        ftemperature << Time << "\t" << Tmp1 << "\t"<< "0.0" << "\t"<< Tmp1 << endl;
#endif


      }

    }

    phase_plot();

    cout            << "\n  : Num_of_type0: " << Num_of_type0;
    cout            << "\n  : Num_of_type1: " << Num_of_type1; 
    cout            << "\n  : Sheath.size: "<< Sheaths.size(); 
    t2=clock();
    float diff ((float)t2-(float)t1);
    cout            << "\n  execution time: " 
                    << diff / CLOCKS_PER_SEC << " seconds\n\n" ;
    fparameters_out <<"\nexecution time: " 
                    << diff / CLOCKS_PER_SEC << " seconds\n" ;

    ftemperature.close();
    fparameters_out.close();

#ifdef XYZOutputMaker
    xyzfile.close();
#ifdef ParticlesExist
    xyzfile2.close();
#endif
#endif

  }

  float diff_tot ((float)t2-(float)t3);
  cout            << "\n  Total execution time: " 
                  << diff_tot / CLOCKS_PER_SEC << " seconds\n\n" ;

  return 0;

}

//==================================================  temperature normalizer
//==================================================  temperature normalizer
//==================================================  temperature normalizer



void temperature_normalizer(double temp_0){
#ifdef OneDimensional
#ifdef ParticlesExist
  double temp_1 = total_kinetic_energy1()+total_kinetic_energy2();
#else
  double temp_1 = total_kinetic_energy1();
#endif
  double temp_r = Num_of_type0*temp_0/temp_1;
  double vel_r  = sqrt(temp_r);

  for(unsigned int i=0;i<Sheaths.size();i++){
    if(Sheaths[i].ptype()==0){
      Sheaths[i].vx()  = vel_r * Sheaths[i].vx() ;
#ifdef ParticlesExist
      Particles[i].vx() = vel_r * Particles[i].vx();
#endif
    }
  }
#endif
}


//==================================================  output_file_maker
//==================================================  output_file_maker
//==================================================  output_file_maker

void output_file_maker(){


  int_output_index++;

  string str_folder_output;

  str_folder_output.append("outputs/"); 
  
  if(int_output_index==1){
   // what if outputs already existed with files within it
    const char* char_folder_output=str_folder_output.c_str();
    mkdir(char_folder_output,0777);
  }
  


  time_t rawtime;
  struct tm * timeinfo;
  char char_buffer [40];
  time (&rawtime);
  timeinfo = localtime (&rawtime);
  cout << asctime(timeinfo)<<"\n";


  time (&rawtime);
  timeinfo = localtime (&rawtime);

//  strftime (buffer,80,"Now it's %I:%M%p.",timeinfo);
//  strftime (buffer,80,"Now it's %F_%T",timeinfo);

  strftime (char_buffer,80,"  %F  %T",timeinfo);


//  char_folder_output = str_folder_output.c_str();
//  mkdir(char_folder_output,0777);

//  string str_fname=str_folder_output;
  string str_fname;



// ------------------



#ifdef OneDimensional    //(1) 
  str_fname.append("_1D");
#endif
#ifdef TwoDimensional    //(2)
  str_fname.append("_2D");
#endif
#ifdef ThreeDimensional    //(3)
  str_fname.append("_3D");
#endif

#ifdef ParticlesExist //ON or OFF//
  str_fname.append("_i:On");
#ifdef HookeanInnerForce    //(1)
  str_fname.append("_i:Hook");
#endif
#ifdef HertzianInnerForce    //(2)
  str_fname.append("_i:Hertz");
#endif
#else
  str_fname.append("_i:Off");
#endif


#ifdef HookeanOuterForce   //(1)
  str_fname.append("_o:Hook");
#endif

#ifdef HertzianOuterForce    //(2)
  str_fname.append("_o:Hertz");
#endif






  char buffer[50]="";

  sprintf(buffer,"_nP:%lu",Sheaths.size());
  str_fname.append(buffer);
  sprintf(buffer,"_dt:%g",timestep);
  str_fname.append(buffer);
//  sprintf(buffer,"_nt:%u",nstep);
  sprintf(buffer,"_t:%g",nstep*timestep);
  str_fname.append(buffer);
#ifdef ParticlesExist
  sprintf(buffer,"_Ai:%g",A_in);
  str_fname.append(buffer);
#endif
  sprintf(buffer,"_Ao:%g",A_out);
  str_fname.append(buffer);
#ifdef ParticlesExist
  sprintf(buffer,"_Mi:%g",mass_in);
  str_fname.append(buffer);
#endif
  sprintf(buffer,"_Mo:%g",mass_out);
  str_fname.append(buffer);

//----

  cout <<"\nOutput File number: "<<int_output_index<<"\n";
  sprintf(buffer,"_%u",int_output_index);
  str_fname.append(buffer);


  string str_fname_T=str_folder_output;
  str_fname_T.append("/T");
  str_fname_T.append(str_fname);
  str_fname_T.append(".dat");
  const char * char_ftemperature=str_fname_T.c_str();
  ftemperature.open(char_ftemperature);



  string str_fname_P=str_folder_output;
  str_fname_P.append("/P");
  str_fname_P.append(str_fname);
  str_fname_P.append(".dat");
  const char * char_fparameters_out=str_fname_P.c_str();
  fparameters_out.open(char_fparameters_out);
//----

#ifdef XYZOutputMaker
  string str_xyzfile=str_folder_output;
  str_xyzfile.append("/XYZ");
  str_xyzfile.append(str_fname);
  str_xyzfile.append(".xyz");
  const char * char_xyzfile=str_xyzfile.c_str();
  xyzfile.open(char_xyzfile);
#ifdef ParticlesExist
  string str_xyzfile2=str_folder_output;
  str_xyzfile2.append("/XYZ2");
  str_xyzfile2.append(str_fname);
  str_xyzfile2.append(".xyz");
  const char * char_xyzfile2=str_xyzfile2.c_str();
  xyzfile2.open(char_xyzfile2);
#endif
#endif



  fparameters_out << "==================Date and time"     << "\n\n";
  fparameters_out << char_buffer                           << "\n\n";
  fparameters_out << "==================system properties" << "\n\n";
#ifdef OneDimensional    //(1) 
  fparameters_out << "OneDimensional"       << "\n";
#endif
#ifdef TwoDimensional    //(2)
  fparameters_out << "TwoDimensional"       << "\n";
#endif
#ifdef ThreeDimensional    //(3)
  fparameters_out << "ThreeDimensional"     << "\n";
#endif

#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "InnerSheathsON"     << "\n";
#ifdef HookeanInnerForce    //(1)
  fparameters_out << "HookeanInnerForce"    << "\n";
#endif
#ifdef HertzianInnerForce    //(2)
  fparameters_out << "HertzianInnerForce"   << "\n";
#endif
#else
  fparameters_out << "InnerSheathsOFF"    << "\n";
#endif

#ifdef HookeanOuterForce   //(1)
  fparameters_out << "HookeanOuterForce"    << "\n";
#endif
#ifdef HertzianOuterForce    //(2)
  fparameters_out << "HertzianOuterForce"   << "\n";
#endif

  fparameters_out << "\n==================init_parameters\n\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "radius_in: "  << radius_in  << "\n";
  fparameters_out << "radius_mid: " << radius_mid << "\n";
#endif
  fparameters_out << "radius_out: " << radius_out << "\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "mass_in: "    << mass_in    << "\n";
#endif
  fparameters_out << "mass_out: "   << mass_out   << "\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "A_in: "       << A_in       << "\n";
#endif
  fparameters_out << "A_out: "      << A_out      << "\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "Y_in: "       << Y_in       << "\n";
#endif
  fparameters_out << "Y_out: "      << Y_out      << "\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "mu_in: "      << mu_in      << "\n";
#endif
  fparameters_out << "mu_out: "     << mu_out     << "\n";
  fparameters_out << "dt: "         << timestep   << "\n";
  fparameters_out << "nsteps: "     << nstep      << "\n";
  fparameters_out << "time: "  
                  << nstep*timestep               << "\n";

  fparameters_out << "\n==================\n\n";
  fparameters_out << "Number of Sheaths: " 
                  << Sheaths.size()              << "\n";

#ifdef ParticlesExist
  fparameters_out << "Number of inner Sheaths: "
                  <<Particles.size()              << "\n";
#endif


}



//==================================================  integrate
//==================================================  integrate
//==================================================  integrate

void integrate()
{

  for(unsigned int i=0;i<Sheaths.size();i++){
    if(Sheaths[i].ptype()==0) {
      Sheaths[i].set_force_to_zero();
      Sheaths[i].predict(timestep);
#ifdef ParticlesExist
      Particles[i].set_force_to_zero();
      Particles[i].predict(timestep); 
#endif

    } else {
      Sheaths[i].boundary_conditions(i,timestep,Time);
    }
  }



    make_forces();

  
  for(unsigned int i=0;i<Sheaths.size();i++){

    if(Sheaths[i].ptype()==0) {
      Sheaths[i].correct(timestep);
#ifdef ParticlesExist
      Particles[i].correct(timestep);
#endif
    }

  }


  for(unsigned int i=0;i<Sheaths.size();i++){

#ifdef OneDimensional
    Sheaths[i].periodic_bc (x_0, lx);
#ifdef ParticlesExist
    Particles[i].periodic_bc(x_0, lx);
#endif
#endif

#ifdef TwoDimensional
    Sheaths[i].periodic_bc (x_0, y_0, lx, ly);
#ifdef ParticlesExist
    Particles[i].periodic_bc(x_0, y_0, lx, ly);
#endif
#endif

#ifdef ThreeDimensional
    Sheaths[i].periodic_bc (x_0, y_0, z_0, lx, ly, lz);
#ifdef ParticlesExist
    Particles[i].periodic_bc(x_0, y_0, z_0, lx, ly, lz);
#endif
#endif

  }
  Time+=timestep;
}

//==================================================  init_parameters
//==================================================  init_parameters
//==================================================  init_parameters

void init_parameters(char * fname_ip)
{
  cout<<"======================init_parameters()\n";
  ifstream fparameters(fname_ip);
  while(fparameters.peek()=='#'){
    string type;
    fparameters >> type;
    if(type=="#radius_in:"){
      fparameters >> radius_in;
      fparameters.ignore(100,'\n');
      cout << "radius_in: " << radius_in << endl;
    }
      else if(type=="#radius_mid:"){
      fparameters >> radius_mid;
      fparameters.ignore(100,'\n');
      cout << "radius_mid: " << radius_mid << endl;
    }
      else if(type=="#radius_out:"){
      fparameters >> radius_out;
      fparameters.ignore(100,'\n');
      cout << "radius_out: " << radius_out << endl;
    }
      else if(type=="#mass_in:"){
      fparameters >> mass_in;
      fparameters.ignore(100,'\n');
      cout << "mass_in: " << mass_in << endl;
    }
      else if(type=="#mass_out:"){
      fparameters >> mass_out;
      fparameters.ignore(100,'\n');
      cout << "mass_out: " << mass_out << endl;
    }
      else if(type=="#A_in:"){
      fparameters >> A_in;
      fparameters.ignore(100,'\n');
      cout << "A_in: " << A_in << endl;
    }
      else if(type=="#A_out:"){
      fparameters >> A_out;
      fparameters.ignore(100,'\n');
      cout << "A_out: " << A_out << endl;
    }
      else if(type=="#Y_in:"){
      fparameters >> Y_in;
      fparameters.ignore(100,'\n');
      cout << "Y_in: " << Y_in << endl;
    }
      else if(type=="#Y_out:"){
      fparameters >> Y_out;
      fparameters.ignore(100,'\n');
      cout << "Y_out: " << Y_out << endl;
    } else if(type=="#mu_in:"){
      fparameters >> mu_in;
      fparameters.ignore(100,'\n');
      cout << "mu_in: " << mu_in << endl;
    }
      else if(type=="#mu_out:"){
      fparameters >> mu_out;
      fparameters.ignore(100,'\n');
      cout << "mu_out: " << mu_out << endl;
    }


      else {
      cerr << "init_parameters(): unknown global property: " << type << endl;
//      abort(); what's this
    }
  }
}

//==================================================  init_system 
//==================================================  init_system 
//==================================================  init_system 

void init_system(char * fname_is)
{
  cout<<"======================init_system()\n";
  fparameters_out<<"==================init_system"<<"\n";
  ifstream fSheath(fname_is);
  while(fSheath.peek()=='#'){
    string type;
    fSheath >> type;
    if(type=="#gravity:"){

#ifdef OneDimensional
      fSheath >> G.x();
#endif

#ifdef TwoDimensional
      fSheath >> G.x() >> G.y() >> G.phi();
#endif

#ifdef ThreeDimensional
      fSheath >> G.x() >> G.y() >> G.z();
#endif

      fSheath.ignore(100,'\n');
      cout << "gravity: " << G << endl;
      fparameters_out << "gravity: " << G << endl;
    } else if(type=="#Time:"){
      fSheath >> Time;
      fSheath.ignore(100,'\n');
      cout << "Time: " << Time << endl;
      fparameters_out << "Time: " << Time << endl;
    } else if(type=="#nstep:"){
      fSheath >> nstep;
      fSheath.ignore(100,'\n');
      cout << "nstep: " << nstep << endl;
      fparameters_out << "nstep: " << nstep << endl;
    } else if(type=="#timestep:"){
      fSheath >> timestep;
      fSheath.ignore(100,'\n');
      cout << "timestep: " << timestep << endl;
      fparameters_out << "timestep: " << timestep << endl;
    } else if(type=="#nprint:"){
      fSheath >> nprint;
      fSheath.ignore(100,'\n');
      cout << "nprint: " << nprint << endl;
    } else if(type=="#nenergy:"){
      fSheath >> nenergy;
      fSheath.ignore(100,'\n');
      cout << "nenergy: " << nenergy << endl;
      fparameters_out << "nenergy: " << nenergy << endl;
    } else if(type=="#lx:"){
      fSheath >> lx;
      fSheath.ignore(100,'\n');
      cout << "lx: " << lx << endl;
      fparameters_out << "lx: " << lx << endl;
    } 
#ifdef TwoDimensional
      else if(type=="#ly:"){
      fSheath >> ly;
      cout << "ly: " << ly << endl;
      fparameters_out << "ly: " << ly << endl;
      fSheath.ignore(100,'\n'); // ?????????????
    } 
#endif

#ifdef ThreeDimensional
      else if(type=="#ly:"){
      fSheath >> ly;
      cout << "ly: " << ly << endl;
      fparameters_out << "ly: " << ly << endl;
      fSheath.ignore(100,'\n'); // ?????????????
    } 
      else if(type=="#lz:"){
      fSheath >> lz;
      cout << "lz: " << lz << endl;
      fparameters_out << "lz: " << lz << endl;
      fSheath.ignore(100,'\n'); // ?????????????
    } 
#endif

      else if(type=="#x_0:"){
      fSheath >> x_0;
      fSheath.ignore(100,'\n');
      cout << "x_0: " << x_0 << endl;
      fparameters_out << "x_0: " << x_0 << endl;
    } 
#ifdef TwoDimensional
      else if(type=="#y_0:"){
      fSheath >> y_0;
      cout << "y_0: " << y_0 << endl;
      fparameters_out << "y_0: " << y_0 << endl;
      fSheath.ignore(100,'\n');
    } 
#endif

#ifdef ThreeDimensional
      else if(type=="#y_0:"){
      fSheath >> y_0;
      cout << "y_0: " << y_0 << endl;
      fparameters_out << "y_0: " << y_0 << endl;
      fSheath.ignore(100,'\n');
    } 
      else if(type=="#z_0:"){
      fSheath >> z_0;
      cout << "z_0: " << z_0 << endl;
      fparameters_out << "z_0: " << z_0 << endl;
      fSheath.ignore(100,'\n');
    } 
#endif

      else {
      cerr << "init_system(): unknown global property: " << type << endl;
//      abort(); what's this
    }
  }
  while(fSheath){
    Sheath pp;
    fSheath >> pp;

    pp.m()=mass_out;
    pp.r()=radius_out;;
    pp.r_mid()=radius_mid;
    pp.A()=A_out;
    pp.Y()=Y_out;
    pp.mu()=mu_out;


    if(fSheath){

      if (pp.ptype()==0) {

        Num_of_type0++;

        pp.vx() =  ( 0.5 - ( ( Ranni.ran2(iseed)
                   + Ranni.ran2(iseed) + Ranni.ran2(iseed)
                   + Ranni.ran2(iseed) + Ranni.ran2(iseed) ) / (5)) );
#ifdef TwoDimensional
        pp.vy() =  ( 0.5 - ( ( Ranni.ran2(iseed)
                   + Ranni.ran2(iseed) + Ranni.ran2(iseed)
                   + Ranni.ran2(iseed) + Ranni.ran2(iseed) ) / (5)) );
#endif
#ifdef ThreeDimensional
        pp.vy() =  ( 0.5 - ( ( Ranni.ran2(iseed)
                   + Ranni.ran2(iseed) + Ranni.ran2(iseed)
                   + Ranni.ran2(iseed) + Ranni.ran2(iseed) ) / (5)) );
        pp.vz() =  ( 0.5 - ( ( Ranni.ran2(iseed)
                   + Ranni.ran2(iseed) + Ranni.ran2(iseed)
                   + Ranni.ran2(iseed) + Ranni.ran2(iseed) ) / (5)) );
#endif
      }

      if (pp.ptype()==1) 
        Num_of_type1++;

      Sheaths.push_back(pp);
    }
    
  }

    
  
  no_of_Sheaths=Sheaths.size();
  cout << no_of_Sheaths << " Sheaths read\n" << flush;
}

//==================================================  init_inner_Sheaths
//==================================================  init_inner_Sheaths
//==================================================  init_inner_Sheaths

#ifdef ParticlesExist
void init_inner_Sheaths(){
//int size_i=Sheath.size();

  for (unsigned int i=0;i<Sheaths.size();i++){


#ifdef OneDimensional
    Particle pp2(Sheaths[i].x(),Sheaths[i].vx());
#endif
#ifdef TwoDimensional
    Particle pp2(Sheaths[i].x() ,Sheaths[i].y()
               ,Sheaths[i].vx(),Sheaths[i].vy());
#endif
#ifdef ThreeDimensional
    Particle pp2(Sheaths[i].x() ,Sheaths[i].y() ,Sheaths[i].z()
               ,Sheaths[i].vx(),Sheaths[i].vy(),Sheaths[i].vz());
#endif

    pp2.m()=mass_in;
    pp2.r()=radius_in;
    pp2.A()=A_in;
    pp2.Y()=Y_in;
    pp2.mu()=mu_in;

    Particles.push_back(pp2);

  }
}
#endif




//==================================================  total_kinetic_eneregy
//==================================================  total_kinetic_eneregy
//==================================================  total_kinetic_eneregy

double total_kinetic_energy1()
{
  double sum=0;
  for(unsigned int i=0;i<Sheaths.size();i++){
    if(Sheaths[i].ptype()==0){
      sum+=Sheaths[i].kinetic_energy();
    }
  }
  return sum;
}

double total_kinetic_energy2()
{
  double sum=0;
#ifdef ParticlesExist
  for(unsigned int i=0;i<Particles.size();i++){
    if(Particles[i].ptype()==0){
      sum+=Particles[i].kinetic_energy();
    }
  }
#endif
  return sum;
}


//==================================================  phase_plot
//==================================================  phase_plot
//==================================================  phase_plot

void phase_plot()
{
/*
  os << "#NewFrame\n";
  os << "#no_of_Sheaths: " << no_of_Sheaths << endl;
  os << "#compressed: no\n";
  os << "#type: SheathXYPhiVxVyOmegaRMFixed25\n";
  os << "#gravity: " << G.x() << " " << G.y() << " " << G.phi() << endl;
  os << "#Time: " << Time << endl;
  os << "#timestep: " << timestep << endl;
  os << "#EndOfHeader\n";
*/
#ifdef XYZOutputMaker
  xyzfile  << Sheaths.size() << "\nAtom\n";

#ifdef ParticlesExist
  xyzfile2 << Sheaths.size()+Particles.size()-Num_of_type1
           << "\nAtom\n";
#else
  xyzfile2 << Sheaths.size() << "\nAtom\n";
#endif

  for(unsigned int i=0;i<Sheaths.size();i++){

//    os << Sheath[i];
#ifdef OneDimensional
    xyzfile  << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t0.0\t0.0\n";

    xyzfile2 << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t0.0\t0.0\n";
#ifdef ParticlesExist
    if (Sheaths[i].ptype()!=1){
      xyzfile2 << 3                        << "\t"
               << XYZscale*Particles[i].x()<< "\t0.0\t0.0\n";
    }
#endif
#endif


#ifdef TwoDimensional
    xyzfile  << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t"
             << XYZscale*Sheaths[i].y() << "\t0.0\n";

    xyzfile2 << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t"
             << XYZscale*Sheaths[i].y() << "\t0.0\n";
#ifdef ParticlesExist
    if (Sheaths[i].ptype()!=1){
      xyzfile2 << 3                         << "\t"
               << XYZscale*Particles[i].x() << "\t"
               << XYZscale*Particles[i].y() << "\t0.0\n";
    }
#endif
#endif

#ifdef ThreeDimensional
    xyzfile  << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t"
             << XYZscale*Sheaths[i].y() << "\t"
             << XYZscale*Sheaths[i].z() << "\n";


    xyzfile2 << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t"
             << XYZscale*Sheaths[i].y() << "\t"
             << XYZscale*Sheaths[i].z() << "\n";

#ifdef ParticlesExist
    if (Sheaths[i].ptype()!=1){
      xyzfile2 << 3                         << "\t"
               << XYZscale*Particles[i].x() << "\t"
               << XYZscale*Particles[i].y() << "\t"
               << XYZscale*Particles[i].z() << "\n";

    }
//    xyzfile2 << flush;
#endif
#endif
//    xyzfile  << flush;

  }

#endif
}
