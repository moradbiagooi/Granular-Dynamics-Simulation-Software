//page 33
#ifndef _common_h
#define _common_h

#include <math.h>
#include <fstream>
#include <vector> // an array class template. a good one of STL
#include <set>
#include <string>
#include "properties.h"

using namespace std;

extern double lx,x_0 ;  // horizontal system size ,lower left corner

#ifdef TwoDimensional
extern double ly,y_0;  // vertical system size,lower down corner
#endif

#ifdef ThreeDimensional
extern double ly,y_0;  // vertical system size,lower down corner
extern double lz,z_0;  // ... , ...
#endif

extern int inner_work; // functioning of inner Sheaths

extern unsigned int no_of_Sheaths;  // number of Sheaths
extern double Time; // elapsed real time
extern ofstream fphase; // output file : phase space
extern ofstream fenergy; //outpud file : energy of system

void step();//Performs one time step of the simulation[simple.cc]
void make_forces();//Computes the total forces acting on each Sheath[simple.cc]
void integrate();//Integrates Newton’s equation of motion using the Gear algorithm[common.cc]
void init_algorithm();//Initializes all data specific to the force summation algorithm[simple.cc]
//void phase_plot(ostream & os);//Dumps the current positions, velocities, and further values into the output file[common.cc]
void phase_plot();//Dumps the current positions, velocities, and further values into the output fil
void  init_inner_Sheaths(); 

#endif
