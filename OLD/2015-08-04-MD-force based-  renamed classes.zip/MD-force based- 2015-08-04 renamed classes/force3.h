#include "properties.h"

// This calculates the force between inner and outer Sheaths
//double Young=1e9,friction=0.5,damping=0.01,tang_damp=10.0,density=8e3;




//===========================

#ifdef OneDimensional
void force3(Sheath & p1, Particle & p2, double lx) // Sheath and Particle friend
#endif

#ifdef TwoDimensional
void force3(Sheath & p1, Particle & p2, double lx, double ly) // Sheath and Particle friend
#endif

#ifdef ThreeDimensional
void force3(Sheath & p1, Particle & p2, double lx, double ly, double lz) // Sheath and Particle friend
#endif
{



  double Y=p2.Y(),mu=p2.mu(),A=p2.A(); // What about defining these in macro

  double dx=normalize2(p1.x()-p2.x(),lx);// X_1 - X_2

#ifdef OneDimensional
  double rr=sqrt(dx*dx);// distance between two Sheaths
#endif

#ifdef TwoDimensional
  double dy=normalize2(p1.y()-p2.y(),ly);// Y_1 - Y_2
  double rr=sqrt(dx*dx+dy*dy);// distance between two Sheaths
#endif

#ifdef ThreeDimensional
  double dy=normalize2(p1.y()-p2.y(),ly);// Y_1 - Y_2
  double dz=normalize2(p1.z()-p2.z(),lz);// Z_1 - Z_2
  double rr=sqrt(dx*dx+dy*dy+dz*dz);// distance between two Sheaths
#endif

  double r1=p1.r();
  double r2=p2.r();
  double r3=p1.r_mid();

  double xi=rr+r2-r3;


  if (xi>0) {



    double dvx=p1.vx()-p2.vx();// relative velocity component x: (V_x)_1 -(V_x)_2 
#ifdef TwoDimensional
    double dvy=p1.vy()-p2.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
#endif
#ifdef ThreeDimensional
    double dvy=p1.vy()-p2.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
    double dvz=p1.vz()-p2.vz();// relative velocity component z: (V_z)_1 -(V_z)_2 
#endif

    double rr_rez=1/rr;// distance^(-1)

    double ex=dx*rr_rez;// dX/rr

#ifdef OneDimensional
    double xidot=(ex*dvx);// -(dX*dV_x)/rr = - e_ij . dV_ij
#endif

#ifdef TwoDimensional
    double ey=dy*rr_rez;;//dy*rr_rez;// dX/rr
    double xidot=(ex*dvx+ey*dvy);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij
#endif

#ifdef ThreeDimensional
    double ey=dy*rr_rez;;//dy*rr_rez;// dY/rr
    double ez=dz*rr_rez;;//dz*rr_rez;// dZ/rr
    double xidot=(ex*dvx+ey*dvy+ez*dvz);// -(dX*dV_x+dY*dV_y+dZ*dV_z)/rr = - e_ij . dV_ij // **** check
#endif





#ifdef HertzianInnerForce
    double reff = (r1*r2)/(r1+r2);// effective radius // **** r1 or r3??
    double fn=sqrt(xi)*Y*sqrt(reff)*(xi+A*xidot);// normal force: Y * (x_i^(3/2) + A * x_i^(1/2) * d(xi)/dt)
#endif

#ifdef HookeanInnerForce
    double fn=Y*xi+A*xidot;// normal force: Y * (x_i + A * d(xi)/dt) 
#endif

    double ft=0.0;// *** no ft for inner Sheaths?? //-gamma*vtrel;// tangential force; almost: (eq 2.18)

#ifdef NoAdhesiveForce
    if(fn<0) fn=0;// non-negative force condition : fn = max ( 0 , fn) // *** THIS MAY NEED CHANGE IN THIS CASE
#endif

//    if (dx>0 && fn<0) fn=0.0;
//    if (dx<0 && fn>0) fn=0.0;

#ifdef OneDimensional
    p1.add_force(Vector(-fn*ex));
    p2.add_force(Vector( fn*ex));
#endif

#ifdef TwoDimensional
    p1.add_force(Vector(-fn*ex,-fn*ey, 0)); 
    p2.add_force(Vector( fn*ex, fn*ey, 0)); 
// *** no ft for inner Sheaths??
#endif

#ifdef ThreeDimensional
    p1.add_force(Vector(-fn*ex, -fn*ey, -fn*ez));
    p2.add_force(Vector( fn*ex,  fn*ey,  fn*ez));
#endif

  }


}


//=================

