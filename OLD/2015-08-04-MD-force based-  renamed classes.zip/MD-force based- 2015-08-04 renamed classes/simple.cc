//part 1 page 36
#include "common.h"
#include "Sheath.h"
#include "Particle.h"   /* <==== replace this line if necessary */
#include "properties.h"

using namespace std;

extern vector<Sheath> Sheaths;
extern vector<Particle> Particles;

void init_algorithm()
{
}

void step()
{
  integrate();
}


void make_forces()
{


  for(unsigned int i=0;i<Sheaths.size();i++){

#ifdef OneDimensional

#ifdef ParticlesExist
    force3(Sheaths[i], Particles[i], lx); // between inner and outer Sheaths
#endif

#ifdef OneDimLinForce
    if (i+1 == Sheaths.size()){
      force(Sheaths[i],Sheaths[0], lx); // Periodic B.C
    }
    else
    {
      force(Sheaths[i],Sheaths[i+1], lx); // LINEAR NEIGHBORS FORCE
    }
#else

    for(unsigned int j=i+1;j<Sheaths.size();j++){
    force(Sheaths[i],Sheaths[j], lx); // between outer Sheaths
    }
#endif
#endif



#ifdef TwoDimensional

#ifdef ParticlesExist
    force3(Sheaths[i], Particles[i], lx, ly); // between inner and outer Sheaths
#endif




    for(unsigned int j=i+1;j<Sheaths.size();j++){
    force(Sheaths[i],Sheaths[j], lx, ly); // between outer Sheaths
    }

#endif

#ifdef ThreeDimensional

#ifdef ParticlesExist
    force3(Sheaths[i], Particles[i], lx, ly, lz); // between inner and outer Sheaths
#endif




    for(unsigned int j=i+1;j<Sheaths.size();j++){
    force(Sheaths[i],Sheaths[j], lx, ly, lz); // between outer Sheaths
    }

#endif




  }

}


