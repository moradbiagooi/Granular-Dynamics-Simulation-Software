#ifndef _variable_h
#define _variable_h

double A_o=0.0; //dissipation coefficient
double A_i=0.0; //dissipation coefficient

double mass_in;
#endif
