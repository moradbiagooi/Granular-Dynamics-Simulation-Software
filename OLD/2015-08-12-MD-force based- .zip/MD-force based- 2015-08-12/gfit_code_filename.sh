 
FILENAME="temperature.dat"
set logscale
f1(x)=a1*x**(-b1)
fit [1.0:] f1(x) FILENAME using 1:4 via a1,b1
plot [:][:2]f1(x) title sprintf("y= %1.2fx+%1.2f",b1,a1),FILENAME using 1:4 w l
set term png
set terminal png size 640,480 enhanced font "Helvetica,10"             
set output "f1.png"
rep
