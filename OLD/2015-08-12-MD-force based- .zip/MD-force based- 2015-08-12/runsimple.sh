#reset
rm simple_box
clear
g++ -std=c++11 -o simple_box common.cc Sheath.cc Particle.cc simple.cc
./simple_box input_box_1D.dat input_parameters.dat
rm simple_box
#rm *~
