//page 33
#ifndef _common_h
#define _common_h

#include <math.h>
#include <fstream>
#include <vector>      
#include <string>
#include "properties.h"

using namespace std;

extern double lx, x_0; // horizontal system size ,lower left corner

#ifdef TwoDimensional
extern double ly, y_0; // vertical system size,lower down corner
#endif


extern double Time;    // elapsed real time


void step();           // Performs one time step of the simulation[simple.cpp]
void make_forces();    // Computes the total forces acting on each Sheath[simple.cpp]
void integrate();      // Integrates Newton’s equation of motion using the Gear algorithm[common.cpp]

void phase_plot_XYZ(); // Dumps the current positions into the file (xyz format)
void phase_plot_XT();  // Dumps the current positions into the file (xt format)

#ifdef TwoDimensional
void init_algorithm(); //
#endif

#endif
