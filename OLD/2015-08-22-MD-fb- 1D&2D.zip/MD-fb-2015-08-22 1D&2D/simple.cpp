//part 1 page 36
#include "common.h"
#include "Sheath.h"
#include "properties.h"

using namespace std;

extern vector<Sheath> Sheaths;

/*
void init_algorithm()
{
}
*/

void step()
{
  integrate();
}


void make_forces()
{


  for(unsigned int i=0;i<Sheaths.size();i++){

#ifdef OneDimensional

#ifdef ParticlesExist

    Sheaths[i].internal_force(lx);
#endif

#ifdef OneDimLinForce
    if (i+1 == Sheaths.size()){
      force(Sheaths[i],Sheaths[0], lx); // Periodic B.C
    }
    else
    {
      force(Sheaths[i],Sheaths[i+1], lx); // LINEAR NEIGHBORS FORCE
    }
#else

    for(unsigned int j=i+1;j<Sheaths.size();j++){
    force(Sheaths[i],Sheaths[j], lx); // between outer Sheaths
    }
#endif
#endif



#ifdef TwoDimensional

#ifdef ParticlesExist
    force3(Sheaths[i], Particles[i], lx, ly); // between inner and outer Sheaths
#endif


    for(unsigned int j=i+1;j<Sheaths.size();j++){
    force(Sheaths[i],Sheaths[j], lx, ly); // between outer Sheaths
    }

#endif

  }

}


