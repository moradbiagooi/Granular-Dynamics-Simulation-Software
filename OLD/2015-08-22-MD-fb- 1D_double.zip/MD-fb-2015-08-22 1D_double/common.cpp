
/* //==========================
   // Developed by Morad Biagooi
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
*/ //==========================

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <sys/stat.h> // used for mkdir()
#include <time.h>
#include <iomanip> 

#include "common.h"
#include "Sheath.h"   
#include "MersenneTwister.h"
#include "properties.h"

#define Pi 3.14159265
#define GSmallNumber 1e-4

using namespace std;

double Time=0, timestep;

int nstep, nprint, nenergy;
int Atom=0,XYZscale=1.0;

int number_of_grains;
double average_free_space;

int Num_of_type0=0; // - number of active grains
int Num_of_type1=0; // - number of walls

//unsigned int int_output_index=0;

#ifdef OneDimensional
double lx, x_0=0;
#endif

#ifdef TwoDimensional
double lx, ly,
       x_0=0, y_0=0;
#endif

double Density;
double Alpha; //               Particle.r / Sheath.r_out
double Beta;  // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 

double radius_S_out;     //Sheath:radius_out
double A_S, Y_S, mu_S;   //Sheath:   Dissip. coef., Young modulus, friction coef.

#ifdef ParticlesExist
double A_P, Y_P, mu_P;   //Particle: Dissip. coef., Young modulus, friction coef.
#endif

#ifdef OneDimensional
double G; // gravity 
#endif

#ifdef TwoDimensional
Vector G; // gravity 
#endif

vector< Sheath > Sheaths;   // outer Sheaths //

int mkdir(const char *path, mode_t mode);

ofstream ftemperature;
ofstream fparameters_out;

#ifdef XYZOutputMaker
ofstream xyzfile;  // only outer Sheaths
ofstream xyzfile2; // with inner Sheaths
#endif
#ifdef XTOutputMaker
ofstream xtfile;
#endif



void output_file_maker();

void temperature_normalizer(double);

void v_COM_zero(); // set COM velocity to zero.

void v_COM();      // COM velocity.

// void init_system     (char * fname_is);

void make_1D_gas(int);

void init_parameters (char * fname_ip);

double total_kinetic_energy();




//==================================================  main
//==================================================  main
//==================================================  main



int main (int argc, char ** argv)
{


  if (argc!=2){
    cerr << "Needs 1 input file, for example: \n\t \
             $ /a.out init_parameters.dat\n";
    exit(0);
    return 0; 
  }

/*
  if (argc!=3){
    cerr << "Needs 2 input files, for example: \n\t \
             $ /a.out init_system.dat init_parameters.dat";
    exit(0);
    return 0; 
  }
*/



  clock_t t1,t2,t3;
  t3 = clock();


  t1=clock();

  Sheaths.clear();


  ftemperature.precision(10); 

  init_parameters(argv[1]);

//    init_system(argv[1]); // input the system from a file.

  make_1D_gas(number_of_grains);  

  output_file_maker();




  init_algorithm();
#ifdef XYZOutputMaker
  phase_plot_XYZ();
#endif
#ifdef XTOutputMaker
  phase_plot_XT();
#endif

#ifdef ParticlesExist
  double _m_eff = Sheaths[1].m() * Sheaths[1].P_m() / (Sheaths[1].m() + Sheaths[1].P_m()); 
  double _Y     = Sheaths[1].Y();
  double _gamma = Sheaths[1].P_A();
#else
  double _m_eff = Sheaths[1].m() * Sheaths[1].m() / (Sheaths[1].m() + Sheaths[1].m()); ±
  double _Y     = Sheaths[1].Y();
  double _gamma = Sheaths[1].A();
#endif

  double _epsilon; // coefficient of restitution, in Hookean case
  _epsilon      = exp( -((Pi*_gamma)/(2*_m_eff)) / 
                  sqrt((_Y/_m_eff)-(_gamma/(2*_m_eff))*(_gamma/(2*_m_eff))) );

  cout            << "epsilon : " << _epsilon << "\n";
  fparameters_out << "epsilon : " << _epsilon << "\n";



  cout<<"======================\n";
  v_COM_zero();

  v_COM();

  temperature_normalizer(1.0); 
  cout<<"======================time loop()\n";
  for (int i=0;i<nstep;i++){

    step();
#ifdef ParticlesExist
    for (unsigned j=0; j<Sheaths.size(); j++)
        if (Sheaths[j].P_slipped_out()){
          cerr << "Error: Particle " << j
               << " slipped out of its sheath at the step "
               << i << "\n";
          return 0;
        }
#endif
#ifdef XYZOutputMaker
    if ((i+1)%nprint==0){
      phase_plot_XYZ();
    }
#endif
#ifdef XTOutputMaker
    if ((i+1)%nprint==0){
      phase_plot_XT();
    }
#endif


    if ((i+1)%nenergy==0){
      ftemperature << Time << "\t" 
                   << total_kinetic_energy()/Num_of_type0 
                   << endl;
    }

  }

#ifdef XYZOutputMaker
  phase_plot_XYZ();
#endif
#ifdef XTOutputMaker
  phase_plot_XT();
#endif

  cout            << "\n  : Num. of active grains: " << Num_of_type0;
  cout            << "\n  : Num. of wall grains: "   << Num_of_type1; 

  t2=clock();
  float diff ((float)t2-(float)t1);
  cout            << "\n\n  execution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n\n" ;
  fparameters_out << "\nexecution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n" ;

  ftemperature.close();
  fparameters_out.close();

#ifdef XYZOutputMaker
  xyzfile.close();
#ifdef ParticlesExist
  xyzfile2.close();
#endif
#endif

  


  return 0;

}

//==================================================  make_1D_gas
//==================================================  make_1D_gas
//==================================================  make_1D_gas

void make_1D_gas(int grains_num){

  cout<<"======================make_1D_gas()\n";

// MersenneTwister random number generator
  long rng_seed = (long) 2;
  class MTRand *RandNumb = new MTRand (rng_seed);


// -------- making grain_x[]

  lx = ((2.0 * radius_S_out) + average_free_space) * grains_num; 

  double grain_x [grains_num];

  int grains_counter = 0;

  while (grains_counter < grains_num) {
 
    double temp_x = lx * RandNumb -> randDblExc();


    bool flag_freeSpace = true;
    int i = 0;

    while (flag_freeSpace && i < grains_counter){

      if (   temp_x < grain_x[i] + 2.0 * radius_S_out + GSmallNumber
          && temp_x > grain_x[i] - 2.0 * radius_S_out - GSmallNumber)
        flag_freeSpace = false;

        i++;
    }

    if (flag_freeSpace){
      grain_x[grains_counter] = temp_x;
      grains_counter++;
    }
  }

// -------- ordering grain_x[]

  bool flag_disorder = true;

  while (flag_disorder){

    flag_disorder = false;

    for (int i=0;i<grains_num;i++){
      for (int j=0;j<grains_num;j++){

        if (grain_x[i] > grain_x[j] && i < j){
          flag_disorder = true;
          double temp_x = grain_x[i];
          grain_x[i]    = grain_x[j];
          grain_x[j]    = temp_x;
        }

      }
    }
  }
// check grain_x

//for (int i=0; i<grains_num -1; i++)
//  cout << grain_x[i+1] - grain_x[i] << "\n" ;

  cout << "lx = " << lx << endl;
// -------- making grains (Sheaths and particles)

  for (int i=0; i<grains_num ; i++){

    Sheath pp;

    pp.x()     = grain_x[i];

    pp.r()     = radius_S_out;

#ifdef ParticlesExist
    pp.r_mid() = radius_S_out * ( 1.0 - 2 * Beta) ;
    pp.m()     = Density * 2 * (pp.r() - pp.r_mid());
#else
    pp.r_mid() = radius_S_out;
    pp.m()     = Density * 2 * pp.r();
#endif

    pp.A()     = A_S;
    pp.Y()     = Y_S;
    pp.mu()    = mu_S;

#ifdef ParticlesExist
    pp.P_x()  = pp.x() 
              + (0.5 - RandNumb -> randDblExc()) 
              * (pp.r_mid() - GSmallNumber);

    pp.P_r()  = pp.r() * Alpha ;
    pp.P_m()  = Density * 2 * pp.P_r();
    pp.P_A()  = A_P;
    pp.P_Y()  = Y_P;
    pp.P_mu() = mu_P;
#endif

    
    pp.ptype() = 0;

    Num_of_type0++;

    pp.vx() = 0.5 - RandNumb -> randDblExc();
#ifdef ParticlesExist
    pp.P_vx()=0.5 - RandNumb -> randDblExc();
#endif
    
    Sheaths.push_back(pp);
  }
  
  cout << number_of_grains << " grains are made\n" << flush;

}


//==================================================  v_COM_zero 
//==================================================  v_COM_zero
//==================================================  v_COM_zero
void v_COM(){

  double v_COM_x=0;


  for(unsigned int i=0;i<Sheaths.size();i++){
    if(Sheaths[i].ptype()==0){
      v_COM_x += Sheaths[i].vx();
#ifdef ParticlesExist
      v_COM_x += Sheaths[i].P_vx();
#endif
    }
  }

#ifdef ParticlesExist
  v_COM_x /= (2 * Num_of_type0);
#else
  v_COM_x /= ( Num_of_type0);
#endif

  cout << "center of mass velocity: " << v_COM_x << "\n";

}



void v_COM_zero(){

  double v_COM_x=0;

  for(unsigned int i=0;i<Sheaths.size();i++){
    if(Sheaths[i].ptype()==0){
      v_COM_x += Sheaths[i].vx();
#ifdef ParticlesExist
      v_COM_x += Sheaths[i].P_vx();
#endif
    }
  }
#ifdef ParticlesExist
  v_COM_x /= (2 * Num_of_type0);
#else
  v_COM_x /= ( Num_of_type0);
#endif

  for(unsigned int i=0;i<Sheaths.size();i++){
    if(Sheaths[i].ptype()==0){
      Sheaths[i].vx()   -= v_COM_x;
#ifdef ParticlesExist
      Sheaths[i].P_vx() -= v_COM_x;
#endif
    }
  }

}


//==================================================  temperature_normalizer
//==================================================  temperature_normalizer
//==================================================  temperature_normalizer



void temperature_normalizer(double temp_0){

  double temp_1 = total_kinetic_energy();
  double temp_r = Num_of_type0*temp_0/temp_1;
  double vel_r  = sqrt(temp_r);

//  cout << "total kinetic energy : " << temp_1 << "\n";

  for(unsigned int i=0;i<Sheaths.size();i++){
    if(Sheaths[i].ptype()==0){
#ifdef OneDimensional
      Sheaths[i].vx()   = vel_r * Sheaths[i].vx() ;
#ifdef ParticlesExist
      Sheaths[i].P_vx() = vel_r * Sheaths[i].P_vx();
#endif

#endif
    }
  }
  cout << "initial kinetic energy : "
       <<  total_kinetic_energy() << "\n";
  cout << "initial granular temperature : "
       <<  total_kinetic_energy()/Num_of_type0  << "\n";

}


//==================================================  output_file_maker
//==================================================  output_file_maker
//==================================================  output_file_maker

void output_file_maker(){


//  int_output_index++;

  string str_folder_output;

  str_folder_output.append("outputs/"); 
  
//  if(int_output_index==1){
   // what if outputs already existed with files within it
    const char* char_folder_output=str_folder_output.c_str();
    mkdir(char_folder_output,0777);
//  }
  


  time_t rawtime;
  struct tm * timeinfo;
  char char_buffer [40];
  time (&rawtime);
  timeinfo = localtime (&rawtime);
  cout << asctime(timeinfo)<<"\n";


  time (&rawtime);
  timeinfo = localtime (&rawtime);

//  strftime (buffer,80,"Now it's %I:%M%p.",timeinfo);
//  strftime (buffer,80,"Now it's %F_%T",timeinfo);

  strftime (char_buffer,80,"  %F  %T",timeinfo);


//  char_folder_output = str_folder_output.c_str();
//  mkdir(char_folder_output,0777);

//  string str_fname=str_folder_output;
  string str_fname;



// ------------------



#ifdef OneDimensional    //(1) 
  str_fname.append("_1D");
#endif
#ifdef TwoDimensional    //(2)
  str_fname.append("_2D");
#endif
#ifdef ParticlesExist //ON or OFF//
  str_fname.append("_P:On");
#endif


#ifdef HookeanForce   //(1)
  str_fname.append("_Hook");
#endif

#ifdef HertzianForce    //(2)
  str_fname.append("_Hertz");
#endif






  char buffer[50]="";

  sprintf(buffer,"_nP:%lu",Sheaths.size());
  str_fname.append(buffer);
//  sprintf(buffer,"_dt:%g",timestep);
//  str_fname.append(buffer);
//  sprintf(buffer,"_nt:%u",nstep);
  sprintf(buffer,"_t:%g",nstep*timestep);
  str_fname.append(buffer);
#ifdef ParticlesExist
  sprintf(buffer,"_AP:%g",A_P);
  str_fname.append(buffer);
#else
  sprintf(buffer,"_AS:%g",A_S);
  str_fname.append(buffer);
#endif

#ifdef ParticlesExist
  sprintf(buffer,"_Alpha:%g",Alpha);
  str_fname.append(buffer);
  sprintf(buffer,"_Beta:%g",Beta);
  str_fname.append(buffer);
#endif
//----

//  cout <<"\nOutput File number: "<<int_output_index<<"\n";
//  sprintf(buffer,"_%u",int_output_index);
//  str_fname.append(buffer);


  string str_fname_T=str_folder_output;
  str_fname_T.append("/T");
  str_fname_T.append(str_fname);
  str_fname_T.append(".dat");
  const char * char_ftemperature=str_fname_T.c_str();
  ftemperature.open(char_ftemperature);



  string str_fname_P=str_folder_output;
  str_fname_P.append("/P");
  str_fname_P.append(str_fname);
  str_fname_P.append(".dat");
  const char * char_fparameters_out=str_fname_P.c_str();
  fparameters_out.open(char_fparameters_out);
//----

#ifdef XYZOutputMaker
  string str_xyzfile=str_folder_output;
  str_xyzfile.append("/XYZ");
  str_xyzfile.append(str_fname);
  str_xyzfile.append(".xyz");
  const char * char_xyzfile=str_xyzfile.c_str();
  xyzfile.open(char_xyzfile);
#ifdef ParticlesExist
  string str_xyzfile2=str_folder_output;
  str_xyzfile2.append("/XYZ2");
  str_xyzfile2.append(str_fname);
  str_xyzfile2.append(".xyz");
  const char * char_xyzfile2=str_xyzfile2.c_str();
  xyzfile2.open(char_xyzfile2);
#endif
#endif
#ifdef XTOutputMaker
  string str_xtfile=str_folder_output;
  str_xtfile.append("/xt");
  str_xtfile.append(str_fname);
  str_xtfile.append(".dat");
  const char * char_xtfile=str_xtfile.c_str();
  xtfile.open(char_xtfile);
#endif


  fparameters_out << "==================Date and time"     << "\n\n";
  fparameters_out << char_buffer                           << "\n\n";
  fparameters_out << "==================system properties" << "\n\n";
#ifdef OneDimensional    //(1) 
  fparameters_out << "OneDimensional"       << "\n";
#endif
#ifdef TwoDimensional    //(2)
  fparameters_out << "TwoDimensional"       << "\n";
#endif
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "ParticlesExists"     << "\n";
#endif

#ifdef HookeanForce   //(1)
  fparameters_out << "HookeanForce"    << "\n";
#endif
#ifdef HertzianForce  //(2)
  fparameters_out << "HertzianForce"   << "\n";
#endif

  fparameters_out << "\n==================init_parameters\n\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "radius_P: "  << Sheaths[1].P_r()  << "\n";
  fparameters_out << "radius_S_in: " << Sheaths[1].r_mid() << "\n";
#endif
  fparameters_out << "radius_S_out: " << Sheaths[1].r() << "\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "mass_P: "    << Sheaths[1].P_m() << "\n";
#endif
  fparameters_out << "mass_S: "   << Sheaths[1].m()   << "\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "A_P: "       << A_P       << "\n";
#endif
  fparameters_out << "A_S: "      << A_S      << "\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "Y_P: "       << Y_P       << "\n";
#endif
  fparameters_out << "Y_S: "      << Y_S      << "\n";
#ifdef ParticlesExist //ON or OFF//
  fparameters_out << "mu_P: "      << mu_P      << "\n";
#endif
  fparameters_out << "mu_S: "     << mu_S     << "\n";
  fparameters_out << "dt: "         << timestep   << "\n";
  fparameters_out << "nsteps: "     << nstep      << "\n";
  fparameters_out << "time: "  
                  << nstep*timestep               << "\n";

  fparameters_out << "\n==================\n\n";
  fparameters_out << "Number of Sheaths: " 
                  << Sheaths.size()               << "\n";


  fparameters_out << "Number of Particles: "
#ifdef ParticlesExist   
                  << 2*Sheaths.size()            << "\n";
#else
                  << "0"                         << "\n";
#endif


}



//==================================================  integrate
//==================================================  integrate
//==================================================  integrate

void integrate()
{

  for(unsigned int i=0;i<Sheaths.size();i++){
//    if(Sheaths[i].ptype()==0) {
      Sheaths[i].set_force_to_zero(); 
      Sheaths[i].predict(timestep);
//    } else {
//      Sheaths[i].boundary_conditions(i,timestep,Time);
//    }
  }



    make_forces();

  
  for(unsigned int i=0;i<Sheaths.size();i++){

//    if(Sheaths[i].ptype()==0) {
      Sheaths[i].correct(timestep);
//    }

  }


  for(unsigned int i=0;i<Sheaths.size();i++){

#ifdef OneDimensional
    Sheaths[i].periodic_bc (x_0, lx);
#endif

#ifdef TwoDimensional
    Sheaths[i].periodic_bc (x_0, y_0, lx, ly);
#endif

  }
  Time+=timestep;
}

//==================================================  init_parameters
//==================================================  init_parameters
//==================================================  init_parameters

void init_parameters(char * fname_ip)
{
  cout<<"======================init_parameters()\n";
  ifstream fparameters(fname_ip);
  while(fparameters.peek()=='#'){
    string type;
    fparameters >> type;
    if(type=="#number_of_grains:"){
      fparameters >> number_of_grains;
      fparameters.ignore(100,'\n');
      cout << "number_of_grains: " << number_of_grains << endl;
      fparameters_out << "number_of_grains: " << number_of_grains << endl;
    } else if(type=="#average_free_space:"){
      fparameters >> average_free_space;
      fparameters.ignore(100,'\n');
      cout << "average_free_space: " << average_free_space << endl;
      fparameters_out << "average_free_space: " << average_free_space << endl;
    } else if(type=="#gravity:"){
#ifdef OneDimensional
      fparameters >> G;
#endif

#ifdef TwoDimensional
      fparameters >> G.x() >> G.y() >> G.phi();
#endif

      fparameters.ignore(100,'\n');
      cout << "gravity: " << G << endl;
      fparameters_out << "gravity: " << G << endl;
    } else if(type=="#Time:"){
      fparameters >> Time;
      fparameters.ignore(100,'\n');
      cout << "Time: " << Time << endl;
      fparameters_out << "Time: " << Time << endl;
    } else if(type=="#timestep:"){
      fparameters >> timestep;
      fparameters.ignore(100,'\n');
      cout << "timestep: " << timestep << endl;
      fparameters_out << "timestep: " << timestep << endl;
    } else if(type=="#nstep:"){
      fparameters >> nstep;
      fparameters.ignore(100,'\n');
      cout << "nstep: " << nstep << endl;
      fparameters_out << "nstep: " << nstep << endl;
    } else if(type=="#nprint:"){
      fparameters >> nprint;
      fparameters.ignore(100,'\n');
      cout << "nprint: " << nprint << endl;
    } else if(type=="#nenergy:"){
      fparameters >> nenergy;
      fparameters.ignore(100,'\n');
      cout << "nenergy: " << nenergy << endl;
      fparameters_out << "nenergy: " << nenergy << endl;
    } else if(type=="#Density:"){
      fparameters >> Density;
      fparameters.ignore(100,'\n');
      cout << "Density: " << Density << endl;
    } else if(type=="#radius_S_out:"){
      fparameters >> radius_S_out;
      fparameters.ignore(100,'\n');
      cout << "radius_S_out: " << radius_S_out << endl;
    }  else if(type=="#A_S:"){
      fparameters >> A_S;
      fparameters.ignore(100,'\n');
      cout << "A_S: " << A_S << endl;
    } else if(type=="#Y_S:"){
      fparameters >> Y_S;
      fparameters.ignore(100,'\n');
      cout << "Y_S: " << Y_S << endl;
    } else if(type=="#mu_S:"){
      fparameters >> mu_S;
      fparameters.ignore(100,'\n');
      cout << "mu_S: " << mu_S << endl;
    }
      else if(type=="#Alpha:"){
#ifdef ParticlesExist
      fparameters >> Alpha;
      cout << "Alpha: " << Alpha << endl;
#endif
      fparameters.ignore(100,'\n');
    } else if(type=="#Beta:"){
#ifdef ParticlesExist
      fparameters >> Beta;
      cout << "Beta: " << Beta << endl;
#endif
      fparameters.ignore(100,'\n');
    } else if(type=="#A_P:"){
#ifdef ParticlesExist
      fparameters >> A_P;
      cout << "A_P: " << A_P << endl;
#endif
      fparameters.ignore(100,'\n');
    } else if(type=="#Y_P:"){
#ifdef ParticlesExist
      fparameters >> Y_P;
      cout << "Y_P: " << Y_P << endl;
#endif
      fparameters.ignore(100,'\n');
    } else if(type=="#mu_P:"){
#ifdef ParticlesExist
      fparameters >> mu_P;
      cout << "mu_P: " << mu_P << endl;
#endif
      fparameters.ignore(100,'\n');
   }

      else {
      cerr << "init_parameters(): unknown global property: " << type << endl;
    }
  }
}

//==================================================  init_system 
//==================================================  init_system 
//==================================================  init_system 
/*

void init_system(char * fname_is)
{
  cout<<"======================init_system()\n";
  fparameters_out<<"==================init_system"<<"\n";

// MersenneTwister random number generator
  long rng_seed = (long) 2;
  class MTRand *RandNumb = new MTRand (rng_seed);
// --------------------------------------

  ifstream fSheath(fname_is);
  while(fSheath.peek()=='#'){
    string type;
    fSheath >> type;
    if(type=="#lx:"){
      fSheath >> lx;
      fSheath.ignore(100,'\n');
      cout << "lx: " << lx << endl;
      fparameters_out << "lx: " << lx << endl;
    } 
#ifdef TwoDimensional
      else if(type=="#ly:"){
      fSheath >> ly;
      cout << "ly: " << ly << endl;
      fparameters_out << "ly: " << ly << endl;
      fSheath.ignore(100,'\n'); // ?????????????
    } 
#endif

      else {
      cerr << "init_system(): unknown global property: " << type << endl;
    }
  }
  while(fSheath){
    Sheath pp;
    fSheath >> pp;

    pp.r()     = radius_S_out;

#ifdef ParticlesExist
    pp.r_mid() = radius_S_out * ( 1.0 - Beta) ;
    pp.m()     = Density * 2 * (pp.r() - pp.r_mid());
#else
    pp.r_mid() = radius_S_out;
    pp.m()     = Density * 2 * pp.r();
#endif

    pp.A()     = A_S;
    pp.Y()     = Y_S;
    pp.mu()    = mu_S;

#ifdef ParticlesExist
    pp.P_x()  = pp.x();
    pp.P_r()  = pp.r() * Alpha ;
    pp.P_m()  = Density * 2 * pp.P_r();
    pp.P_A()  = A_P;
    pp.P_Y()  = Y_P;
    pp.P_mu() = mu_P;
#endif

    if(fSheath){

      if (pp.ptype()==0) {

        Num_of_type0++;

//        pp.vx() =   0.5 - Ranni.ran2(iseed);
        pp.vx() = 0.5 - RandNumb -> randDblExc();
#ifdef ParticlesExist
        pp.P_vx()=pp.vx();
#endif

#ifdef TwoDimensional
        pp.vy() = 0.5 - RandNumb -> randDblExc();
#ifdef ParticlesExist
        pp.P_vy()=pp.vy();
#endif
#endif

      }

      if (pp.ptype()==1) 
        Num_of_type1++;

      Sheaths.push_back(pp);
    }
    
  }

    
  
  number_of_grains=Sheaths.size();
  cout << number_of_grains << " Sheaths read\n" << flush;
}
*/

//==================================================  total_kinetic_eneregy
//==================================================  total_kinetic_eneregy
//==================================================  total_kinetic_eneregy

double total_kinetic_energy()
{
  double sum=0;
  for(unsigned int i=0;i<Sheaths.size();i++){
    if(Sheaths[i].ptype()==0){
      sum+=Sheaths[i].kinetic_energy();
    }
  }
  return sum;
}


//==================================================  phase_plot
//==================================================  phase_plot
//==================================================  phase_plot

#ifdef XYZOutputMaker
void phase_plot_XYZ()
{
  xyzfile  << Sheaths.size() << "\nAtom\n";

#ifdef ParticlesExist
  xyzfile2 << 2*Sheaths.size()-Num_of_type1
           << "\nAtom\n";
#else
  xyzfile2 << Sheaths.size() << "\nAtom\n";
#endif

  for(unsigned int i=0;i<Sheaths.size();i++){

#ifdef OneDimensional
    xyzfile  << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t0.0\t0.0\n";

    xyzfile2 << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t0.0\t0.0\n";
#ifdef ParticlesExist
    if (Sheaths[i].ptype()!=1){
      xyzfile2 << 3                        << "\t"
               << XYZscale*Sheaths[i].P_x()<< "\t0.0\t0.0\n";
    }
#endif
#endif


#ifdef TwoDimensional
    xyzfile  << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t"
             << XYZscale*Sheaths[i].y() << "\t0.0\n";

    xyzfile2 << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t"
             << XYZscale*Sheaths[i].y() << "\t0.0\n";
#ifdef ParticlesExist
    if (Sheaths[i].ptype()!=1){
      xyzfile2 << 3                         << "\t"
               << XYZscale*Particles[i].x() << "\t"
               << XYZscale*Particles[i].y() << "\t0.0\n";
    }
#endif
#endif

  }



}
#endif

//==================================================  phase_plot_XT
//==================================================  phase_plot_XT
//==================================================  phase_plot_XT
#ifdef XTOutputMaker
void phase_plot_XT()
{
  xtfile  << Time << " ";

  for(unsigned int i=0;i<Sheaths.size();i++){
    xtfile  << Sheaths[i].x() << " ";
  }

  xtfile  << "\n";
}
#endif
