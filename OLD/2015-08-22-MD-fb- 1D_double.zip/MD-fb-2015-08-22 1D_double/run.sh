#reset
rm simple_box
clear
g++ -std=c++11 -o simple_box common.cpp Sheath.cpp Particle.cpp simple.cpp MersenneTwister.cpp
./simple_box input_parameters.dat
rm simple_box
