//part 1 page 41

#include "Sheath.h"
#include <assert.h>
#include "properties.h"

extern Vector G;
#define GSmallNumber 1e-4
//====================================================
//==================================================== Sheath::P_slipped_out()
//====================================================
#ifdef ParticlesExist
bool Sheath::P_slipped_out(){

#ifdef OneDimensional
  double abs_dx = P_x() > x() ? P_x() - x() : x() - P_x() ;
#endif

  if (abs_dx > r() - GSmallNumber - P_r())
    return true;
  else
    return false;
}


#endif

//====================================================
//==================================================== Sheath::predict()
//====================================================

void Sheath::predict(double dt)
{
#ifdef ParticlesExist
    P.predict(dt);
#endif

  double a1 = dt;
  double a2 = a1*dt/2;
  double a3 = a2*dt/3;
  double a4 = a3*dt/4;

  rtd0 += a1*rtd1 + a2*rtd2 + a3*rtd3 + a4*rtd4;
  rtd1 += a1*rtd2 + a2*rtd3 + a3*rtd4;
  rtd2 += a1*rtd3 + a2*rtd4;
  rtd3 += a1*rtd4;
}

//====================================================
//==================================================== Sheath::correct()
//====================================================


void Sheath::correct(double dt)
{

#ifdef ParticlesExist
    P.correct(dt);
#endif

  static Vector accel,corr;
  double dtrez = 1/dt;
  const double coeff0 = double(19)/ double(90) * (dt*dt/double(2));
  const double coeff1 = double(3) / double(4)  * (dt/double(2));
  const double coeff3 = double(1) / double(2)  * (double(3)*dtrez);
  const double coeff4 = double(1) / double(12) * (double(12)*(dtrez*dtrez));

#ifdef GravityInnerForce

#ifdef OneDimensional
  accel = Vector((1/_m)*_force.x()+G.x());
#endif
#ifdef TwoDimensional
  accel = Vector((1/_m)*_force.x()+G.x(),
          (1/_m)*_force.y()+G.y(),
          (1/_J)*_force.phi()+G.phi());// *** in this case_ is that rotational gravity??
#endif

#else

#ifdef OneDimensional
  accel=Vector((1/_m)*_force.x());
#endif
#ifdef TwoDimensional
  accel=Vector((1/_m)*_force.x(),
    (1/_m)*_force.y(),
    (1/_J)*_force.phi());
#endif

#endif

  corr=accel-rtd2;

  rtd0 += coeff0*corr;
  rtd1 += coeff1*corr;
  rtd2  = accel;
  rtd3 += coeff3*corr;
  rtd4 += coeff4*corr;
}


//====================================================
//==================================================== Sheath::internal_force()
//====================================================

#ifdef ParticlesExist

#ifdef OneDimensional
void Sheath::internal_force(double lx)// Sheath and Particle friend
#endif

{



  double Y = P.Y(), mu = P.mu(), A = P.A(); 

  double dx = normalize2(x()-P.x(),lx);// X_1 - X_2

#ifdef OneDimensional
  double rr = sqrt(dx*dx);// distance between two Sheaths
#endif

#ifdef TwoDimensional
  double dy = normalize2(y()-P.y(),ly);// Y_1 - Y_2
  double rr = sqrt(dx*dx+dy*dy);// distance between two Sheaths
#endif


  double r1 = r();
  double r2 = P.r();
  double r3 = r_mid();

  double xi = rr+r2-r3;


  if (xi>0) {



    double dvx = vx()-P.vx();// relative velocity component x: (V_x)_1 -(V_x)_2 
#ifdef TwoDimensional
    double dvy = vy()-P.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
#endif

    double rr_rez = 1/rr;// distance^(-1)

    double ex = dx*rr_rez;// dX/rr

#ifdef OneDimensional
    double xidot = (ex*dvx);// -(dX*dV_x)/rr = - e_ij . dV_ij
#endif

#ifdef TwoDimensional
    double ey = dy*rr_rez;;//dy*rr_rez;// dX/rr
    double xidot = (ex*dvx+ey*dvy);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij
#endif






#ifdef HertzianForce
    double reff = (r1*r2)/(r1+r2);// effective radius // **** r1 or r3??
    double fn = sqrt(xi)*Y*sqrt(reff)*(xi+A*xidot);// normal force: Y * (x_i^(3/2) + A * x_i^(1/2) * d(xi)/dt)
#endif

#ifdef HookeanForce
    double fn = Y*xi+A*xidot;// normal force: Y * (x_i + A * d(xi)/dt) 
#endif

    double ft = 0;// *** no ft for inner Sheaths?? //-gamma*vtrel;// tangential force; almost: (eq 2.18)

#ifdef NoAdhesiveForce
    if(fn<0) fn = 0;// non-negative force condition : fn = max ( 0 , fn) // *** THIS MAY NEED CHANGE IN THIS CASE
#endif

//    if (dx>0 && fn<0) fn=0.0;
//    if (dx<0 && fn>0) fn=0.0;

#ifdef OneDimensional
    add_force   (Vector(-fn*ex));
    P.add_force (Vector( fn*ex));
#endif

#ifdef TwoDimensional
    add_force   (Vector(-fn*ex,-fn*ey, 0)); 
    P.add_force (Vector( fn*ex, fn*ey, 0)); 
// *** no ft for inner Sheaths??
#endif


  }


}

#endif


//====================================================
//==================================================== force()
//====================================================

// part 2 page 41
#ifdef OneDimensional
void force(Sheath & p1, Sheath & p2, double lx) 
#endif
#ifdef TwoDimensional
void force(Sheath & p1, Sheath & p2, double lx, double ly) 
#endif
{


//  double dx=normalize(p1.x()-p2.x(),lx);// X_1 - X_2 // inline function
// I don't get using inline double normalize(dx,lx)

// if (p1.x()-p2.x()>lx || p1.x()-p2.x()<-lx) flag_x=1; else flag_x=-1;

  double dx = p1.x()-p2.x();
  double abs_dx = dx < 0 ? -dx : dx;
  int mfx;
  double rdx;
  if (lx - abs_dx < abs_dx){
    rdx = lx - abs_dx;
    mfx = -1;
  } else {
    rdx = abs_dx;
    mfx = 1;
  }

//check normalize() and normalize2()

#ifdef OneDimensional
   double rr = sqrt (rdx*rdx);// distance between two Sheaths
/// double rr=rdx;// distance between two Sheaths
#endif

#ifdef TwoDimensional
  double dy = p1.y()-p2.y();
  double abs_dy = dy < 0 ? -dy : dy;

 
  double rr = sqrt(rdx*rdx + rdy*rdy);
#endif


  double r1 = p1.r();
  double r2 = p2.r();
  
  double xi = r1+r2-rr;// khee or chi : compression : radius1+radius2-distance

  if(xi>0){

/*
    double Y = p1.Y*p2.Y/(p1.Y+p2.Y);// effective Young modulus
    double A = 0.5*(p1.A+p2.A);// average of Dissipative constants
    double mu = (p1.mu<p2.mu ? p1.mu : p2.mu);// friction constant : the smaller friction is the appliciable one.
    double gamma = (p1._gamma<p2._gamma ? p1._gamma : p2._gamma);// gamma of friction
*/

    double Y = p1.Y();
    double A = p1.A(),mu = p1.mu(),gamma = 0.0; 


    double reff = (r1*r2)/(r1+r2);// effective radius
    double dvx = p1.vx()-p2.vx();// relative velocity component x: (V_x)_1 -(V_x)_2 
#ifdef TwoDimensional
    double dvy = p1.vy()-p2.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
#endif

#ifdef ThreeDimensional
    double dvy = p1.vy()-p2.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
    double dvz = p1.vz()-p2.vz();// relative velocity component z: (V_z)_1 -(V_z)_2 
#endif

    double rr_rez = 1/rr;// distance^(-1)
    double ex = dx*rr_rez;// dX/rr

#ifdef OneDimensional
    double xidot = -(ex*dvx);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij
#endif


#ifdef TwoDimensional
    double ey = dy*rr_rez;// dY/rr
    double xidot = -(ex*dvx+ey*dvy);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij
    double vtrel = -dvx*ey + dvy*ex + p1.omega()*p1.r()-p2.omega()*p2.r();// relative tangential velocity of the surfaces of the contacting Sheaths : (-dV_x*dY +dV_y*dX)/rr  + w_1*r_1 + w_2*r2: using e_ij_tangential . dV_ij
#endif

#ifdef ThreeDimensional
    double ey = dy*rr_rez;// dY/rr
    double ez = dz*rr_rez;// dZ/rr
    double xidot = -(ex*dvx+ey*dvy+ez*dvz);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij
    double vtrel = 0.0;// ***check this ***
#endif


#ifdef HertzianForce
    double fn = sqrt(xi)*Y*sqrt(reff)*(xi+A*xidot);// normal force: Y * (x_i^(3/2) + A * x_i^(1/2) * d(xi)/dt)
#endif

#ifdef HookeanForce
//    double fn=Y*sqrt(reff)*(xi+A*xidot);// normal force: Y * (x_i + A * d(xi)/dt) 
    double fn = Y*xi+A*xidot;// normal force: Basic linear dashpod
#endif


#ifdef TwoDimensional
    double ft = -gamma*vtrel;// tangential force; almost: (eq 2.18)
#endif

#ifdef ThreeDimensional
    double ft=0.0; // 
#endif


    if (fn < 0) fn=0;// non-negative force condition : fn = max ( 0 , fn)

#ifdef OneDimensional

    if (p1.ptype() == 0) {
      p1.add_force(Vector( fn*ex*mfx));
    }
    if (p2.ptype() == 0) {
      p2.add_force(Vector(-fn*ex*mfx));
    } 
#endif


#ifdef TwoDimensional
    if (ft < -mu*fn) ft = -mu*fn;// Coulomb's law of friction
    if (ft >  mu*fn) ft =  mu*fn;  // Coulomb's law of friction

    if (p1.ptype() == 0) {
      p1.add_force(Vector(fn*ex*mfx-ft*ey*mfy ,  fn*ey*mfx+ft*ex*mfy,  r1*ft));
    }
    if (p2.ptype() == 0) {
      p2.add_force(Vector(-fn*ex*mfx+ft*ey*mfy, -fn*ey*mfx-ft*ex*mfy, -r2*ft));
    } 
#endif



  }
}


//====================================================
//==================================================== Sheath::boundary_conditions ()
//====================================================

/*
void Sheath::boundary_conditions(int n, double timestep, double Time)
{

  switch(ptype()){
  case(0): break;
  case(1): break;

#ifdef TwoDimensional
  case(2): {
    x()=0.5-0.4*cos(10*Time);
    y()=0.1;
    vx()=10*0.4*sin(Time);
    vy()=0;
  } break;
  case(3): {
    double xx=x()-0.5;
    double yy=y()-0.5;
    double xp=xx*cos(timestep)-yy*sin(timestep);
    double yp=xx*sin(timestep)+yy*cos(timestep);
    x()=0.5+xp;
    y()=0.5+yp;
    vx()=-yp;
    vy()= xp;
    omega()=1;
  } break;
  case(4): {
    x()=0.5+0.1*cos(Time) + 0.4*cos(Time+2*n*M_PI/128);
    y()=0.5+0.1*sin(Time) + 0.4*sin(Time+2*n*M_PI/128);
    vx()=-0.1*sin(Time) - 0.4*sin(Time+2*n*M_PI/128);
    vy()= 0.1*cos(Time) - 0.4*cos(Time+2*n*M_PI/128);
    omega()=1;
  } break;
  case(5): {
    y()=0.1+0.02*sin(30*Time);
    vx()=0;
    vy()=0.02*30*cos(30*Time);
  } break;
  case(6): {
    int i=n/2;
    y()=i*0.02+0.1+0.02*sin(30*Time);
    vx()=0;
    vy()=0.02*30*cos(30*Time);
  } break;
  default: {
    cerr << "ptype: " << ptype() << " not implemented\n";
    //abort();  // what's this
    }
#endif

  }
}
*/
//====================================================
//==================================================== Sheath::periodic_bc ()
//====================================================


#ifdef OneDimensional
void Sheath::periodic_bc(double x_0, double lx)
{
#ifdef ParticlesExist
  while(rtd0.x()<x_0)    {rtd0.x() += lx; P.x() += lx;}
  while(rtd0.x()>x_0+lx) {rtd0.x() -= lx; P.x() -= lx;}
#else
  while(rtd0.x()<x_0)    {rtd0.x() += lx;}
  while(rtd0.x()>x_0+lx) {rtd0.x() -= lx;}
#endif
    
}
#endif


#ifdef TwoDimensional
void Sheath::periodic_bc(double x_0, double y_0, double lx, double ly)
{
#ifdef ParticlesExist
    P.periodic_bc(x_0, y_0, lx, ly);
#endif
  while(rtd0.x()<x_0)    rtd0.x() += lx;
  while(rtd0.x()>x_0+lx) rtd0.x() -= lx;
  while(rtd0.y()<y_0)    rtd0.y() += ly;
  while(rtd0.y()>y_0+ly) rtd0.y() -= ly;
}
#endif


//====================================================
//==================================================== Sheath::kinetic_energy()
//====================================================


double Sheath::kinetic_energy() const
{
#ifdef ParticlesExist

#ifdef OneDimensional
  return P.kinetic_energy() +
         _m*(rtd1.x()*rtd1.x())/2;
#endif

#ifdef TwoDimensional
  return _P.kinetic_energy()  +
         m*(rtd1.x()*rtd1.x() +
         rtd1.y()*rtd1.y())/2 +
         _J*rtd1.phi()*rtd1.phi()/2;
#endif




#else


#ifdef OneDimensional
  return  _m*(rtd1.x()*rtd1.x())/2;
#endif

#ifdef TwoDimensional
  return  _m*(rtd1.x()*rtd1.x() + 
          rtd1.y()*rtd1.y())/2  +
          _J*rtd1.phi()*rtd1.phi()/2;
#endif


#endif
}

//====================================================
//==================================================== istream & operator >> ()
//====================================================


/*
istream & operator >> (istream & is, Sheath & p)
{
  is >> p.rtd0 >>   p.rtd1
     >> p._r   >>   p._m >> p._ptype
     >> p._Y   >>   p._A >> p._mu   >> p._gamma
     >> p._force
     >> p.rtd2 >> p.rtd3 >> p.rtd4;

  p._J = p._m*p._r*p._r/2;
  return is;
}
*/

//====================================================
//==================================================== ostream & operator << ()
//====================================================

/*
ostream & operator << (ostream & os, const Sheath & p)
{
  os << p.rtd0   << " " << p.rtd1 << " ";
  os << p._r     << " " << p._m   << " " << p._ptype       << " ";
  os << p._Y     << " " << p._A   << " " << p._mu << " "   << p._gamma << " ";
  os << p._force << " ";
  os << p.rtd2   << " " << p.rtd3 << " " << p.rtd4 << "\n" << flush;
  return os;
}
*/


