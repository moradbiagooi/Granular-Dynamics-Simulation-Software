//page 33
#ifndef _common_h
#define _common_h

#include <math.h>
#include <fstream>
#include <vector> // an array class template. a good one of STL
#include <set>
#include <string>
#include "properties.h"

using namespace std;

extern double lx, x_0 ;  // horizontal system size ,lower left corner

#ifdef TwoDimensional
extern double ly, y_0;  // vertical system size,lower down corner
#endif

extern int inner_work; // functioning of inner Sheaths

extern unsigned int no_of_Sheaths;  // number of Sheaths
extern double Time; // elapsed real time

//extern ofstream fphase; // output file : phase space
//extern ofstream fenergy; //outpud file : energy of system

void step();//Performs one time step of the simulation[simple.cc]
void make_forces();//Computes the total forces acting on each Sheath[simple.cc]
void integrate();//Integrates Newton’s equation of motion using the Gear algorithm[common.cc]
void init_algorithm();//Initializes all data specific to the force summation algorithm[simple.cc]

void phase_plot_XYZ(); //Dumps the current positions into the file (xyz format)
void phase_plot_XT();  //Dumps the current positions into the file (xt format)

void  init_inner_Sheaths(); 

#endif
