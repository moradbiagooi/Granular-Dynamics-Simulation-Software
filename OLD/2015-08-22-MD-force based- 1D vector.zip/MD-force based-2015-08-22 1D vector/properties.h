
#ifndef _properties_h
#define _properties_h

/*-------------------------------------------------------------------
Here we can choose between different alternatives:
One of the numbers have to be active.
In the other case, have to turn something //ON or OFF//
-------------------------------------------------------------------*/

//=============================== Dimensions

#define OneDimensional    //(1) 
//#define TwoDimensional    //(2)

//=============================== Forces in 1Dimensions

#define OneDimLinForce    // ON or OFF linear force in OneDimensional Case
                          // Two wall concept should be the case
//=============================== Inner Forces correction

#define NoAdhesiveForce   // ON or OFF
                          // means force = max [0 , f(xi)]
//=============================== Forces type

#define HookeanForce    //(1)
//#define HertzianForce    //(2)

//=============================== Gravity works on the particles 

//#define InnerGravityForce //ON or OFF// 

//=============================== Sheaths's Particles available

#define ParticlesExist //ON or OFF//

//===============================  output: xyz format, used in VMD

//#define XYZOutputMaker    //ON or OFF

//===============================  output X(t) format, used for phase_time graph

#define XTOutputMaker

//===============================

#endif
