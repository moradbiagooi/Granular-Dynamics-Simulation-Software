
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _Particle_h
#define _Particle_h

#include <iostream>
#include <math.h>


#include "properties.h"

#ifdef TwoDimensional
#include "Vector.h"
#endif


using namespace std;



class Sheath;


class Particle {

#ifdef OneDimensional
  friend void force3(Sheath & p1, Particle & p2, double lx);
#endif


#ifdef TwoDimensional
  friend void force3(Sheath & p1, Particle & p2, double lx, double ly);
#endif


public:

#ifdef OneDimensional
  Particle(): rtd0(0), rtd1(0), rtd2(0), rtd3(0), rtd4(0)
  {}
#endif


#ifdef TwoDimensional
  Particle(): rtd0(null), rtd1(null), rtd2(null), rtd3(null), rtd4(null)
  {}
#endif


#ifdef OneDimensional
  double & x() {return rtd0;}
  double x() const {return rtd0;}

  double & vx() {return rtd1;}
  double vx() const {return rtd1;}
#endif


#ifdef TwoDimensional
  double & x() {return rtd0.x();}
  double x() const {return rtd0.x();}

  double & vx() {return rtd1.x();}
  double vx() const {return rtd1.x();}

  double & fx() {return _force.x();}
  double fx() const {return _force.x();}

  double & y() {return rtd0.y();}
  double y() const {return rtd0.y();}

  double & vy() {return rtd1.y();}
  double vy() const {return rtd1.y();}

  double & fy() {return _force.y();}
  double fy() const {return _force.y();}

  double & phi() {return rtd0.phi();}
  double phi() const {return rtd0.phi();}

  double & omega() {return rtd1.phi();}
  double omega() const {return rtd1.phi();}

  double J() const {return _J;}
  double & J() {return _J;}

  double gamma() const {return _gamma;}
  double & gamma() {return _gamma;}

  double & mu() {return _mu;}
  double mu() const {return _mu;}
#endif


  double & r() {return _r;}
  double r() const {return _r;}

  double m() const {return _m;}
  double & m() {return _m;}

  double & Y() {return _Y;}
  double Y () const {return _Y;}

  double & A() {return _A;}
  double A() const {return _A;}


#ifdef OneDimensional
  void add_force(const double & f){_force+=f;} 
//Adds a value to the total force _force of the Sheath
#endif


#ifdef TwoDimensional
  void add_force(const Vector & f){_force+=f;}
 //Adds a value to the total force _force of the Sheath
#endif


  void predict(double dt);
//First step of the Gear algorithm


  void correct(double dt);
//Second step of the Gear algorithm


  double kinetic_energy() const;
//Computes the kinetic energy of the Particle


  void set_force_to_zero(){
#ifdef OneDimensional
    _force=0;
#else
    _force=null;
#endif
  }


#ifdef OneDimensional
  void periodic_bc(double x_0, double lx);
//Enforces the periodic boundary conditions
#endif


#ifdef TwoDimensional
  void periodic_bc(double x_0, double y_0, double lx, double ly);
//Enforces the periodic boundary conditions
#endif



private:


  double _r, _m;
  double _Y, _A;


#ifdef OneDimensional
  double rtd0,rtd1,rtd2,rtd3,rtd4;
  double _force;
#endif


#ifdef TwoDimensional
  double _J, _gamma, _mu;

  Vector rtd0,rtd1,rtd2,rtd3,rtd4;
  Vector _force;
#endif

};

#endif
