
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <sys/stat.h> // used for mkdir()
#include <time.h>
#include <iomanip> 

#include "common.h"
#include "Sheath.h"   
#include "MersenneTwister.h"
#include "properties.h"

#define PI 3.14159265
#define GSmallNumber 1e-4

using namespace std;

double Time=0, timestep;

int nstep, nprint, nenergy;
int Atom=0;
int number_of_grains;

double XYZscale=.5;
double mean_free_space;
double init_gran_temp;
double init_ang_vel;

int Num_of_type0=0; // - number of active grains
int Num_of_type1=0; // - number of walls

#ifdef OneDimensional
double lx, x_0=0;
#endif

#ifdef TwoDimensional
double lx, ly,
       x_0=0, y_0=0;
#endif

double Density;

double Alpha; // Particle.r / Sheath.r_out

double Beta;  // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 

double radius_S_out;     //Sheath:   radius_out

double A_S, Y_S, mu_S, gamma_S;
//Sheath:   Dissip. coef., Young modulus, friction coef.

double A_P, Y_P, mu_P, gamma_P;
   //Particle: Dissip. coef., Young modulus, friction coef.


#ifdef OneDimensional
double G; // gravity 
#else
Vector G; // gravity 
#endif

vector< Sheath > Sheaths;   // outer Sheaths //

int mkdir(const char *path, mode_t mode);

ofstream ftemperature;
ofstream fparameters_out;

#ifdef XYZOutputMaker
ofstream xyzfile;  // dump Sheaths positions
ofstream xyzfile2; // dump Sheaths and Particles positions
#endif

#ifdef XTOutputMaker
ofstream xtfile;
#endif

void output_file_maker();

void temperature_normalizer(double);

void v_COM_zero(bool); 
// (true) : set COM velocity to zero, then print it.
// (false): print COM velocity without changing it.


/* // used when the system would be inputted from a file.
// void init_system     (char * fname_is); 
*/ 


void make_gas(int);

void init_parameters (char * fname_ip);

void cal_rest_coef();

void  final_prints(clock_t);

double total_kinetic_energy();

bool init_parameters_check();
//====================================================
//====================================================  main
//====================================================

int main (int argc, char ** argv)
{


  if (argc!=2){
    cerr << "Needs 1 input file, for example: \n\t \
             $ /a.out init_parameters.dat\n";
    exit(0);
    return 0; 
  }

/* // used when the system would be inputted from a file.
  if (argc!=3){
    cerr << "Needs 2 input files, for example: \n\t \
             $ /a.out init_system.dat init_parameters.dat";
    exit(0);
    return 0; 
  }
*/

  clock_t t1;

  t1 = clock();

  Sheaths.clear();

  ftemperature.precision(10); 

  init_parameters(argv[1]);
// takes system parameters from the inputted file in the command line

  if (!init_parameters_check())
    return 0;
  else
    cout << "\ninit_parameters_check() : OK \n";


/* // used when the system would be inputted from a file.
//    init_system(argv[1]); 
*/


  make_gas(number_of_grains);  
// DeAcTiVE this function when the system would be inputted from a file.

  output_file_maker();


  init_algorithm();


#ifdef XYZOutputMaker
  phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
  phase_plot_XT();
#endif


  cal_rest_coef(); // coefficient of restitution.



  v_COM_zero(true);


  temperature_normalizer(init_gran_temp); 

  cout<<"======================time loop()\n";

  for (int i=0;i<nstep;i++){

    step();      

#ifdef ParticlesExist
    for (unsigned j=0; j<Sheaths.size(); j++)
        if (Sheaths[j].P_slipped_out()){

          cerr << "Error: Particle " << j
               << " slipped out of its sheath at the step "
               << i << "\n";

          return 0;

        }
#endif

#ifdef XYZOutputMaker
    if ((i+1)%nprint==0)
      phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
    if ((i+1)%nprint==0)
      phase_plot_XT();
#endif

    if ((i+1)%nenergy==0){

      double temp_temp0 = total_kinetic_energy()
                        / (Num_of_type0*init_gran_temp); 

      ftemperature << Time << "\t" 
                   << temp_temp0
                   << endl;

      if (temp_temp0 > 3.0){

        cerr << "\n\nerror: increasing temperature\n"
             << "change your system parameters\n"
             << "Simulation stopped at the time step: "<< i <<"\n";

	return 0;

      }

    }

  }

  final_prints(t1);
 
  ftemperature.close();

  fparameters_out.close();

#ifdef XYZOutputMaker

  xyzfile.close();
 
 #ifdef ParticlesExist
  xyzfile2.close();
 #endif

#endif

  return 0;

}

//====================================================
//====================================================  init_parameters_check
//====================================================

bool init_parameters_check(){
#ifdef ParticlesExist
  if (Alpha < GSmallNumber || Alpha > 1.0 - GSmallNumber){
    cout << "Error: assign #Alpha between " << GSmallNumber << " and " << 1.0 - GSmallNumber << endl;
    return false;
  }
  if (Beta < GSmallNumber || Beta > 0.5 - GSmallNumber){
    cout << "Error: assign #Beta between " << GSmallNumber << " and " << 0.5 - GSmallNumber << endl;
    return false;
  }
  if (Alpha + Beta < 2.0*GSmallNumber || Alpha +Beta > 1.5 - 2.0*GSmallNumber){
    cout << "Error: assign #Alpha and #Beta so that (Alpha + Beta) would be between " << GSmallNumber << " and " << 1.5 - GSmallNumber << endl;
    return false;
  }
#endif
  return true;
}

//====================================================
//====================================================  final_prints
//====================================================

void final_prints(clock_t t1){

  clock_t t2;
  t2 = clock();

  cout << "\nfinal time: " << Time << "\n" 
       << "final granular temperature: " 
       << total_kinetic_energy()/(Num_of_type0) << endl
       << "normalized final granular temperature: " 
       << total_kinetic_energy()/(Num_of_type0*init_gran_temp)
       << endl;

  fparameters_out  
       << "final granular temperature: " 
       << total_kinetic_energy()/(Num_of_type0) << endl
       << "normalized final granular temperature: " 
       << total_kinetic_energy()/(Num_of_type0*init_gran_temp)
       << endl;

#ifdef XYZOutputMaker
  phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
  phase_plot_XT();
#endif

  cout            << "\n   Num. of active grains: " << Num_of_type0;
  cout            << "\n   Num. of wall grains: "   << Num_of_type1; 

  t2=clock();

  float diff ((float)t2-(float)t1);

  cout            << "\n\n  execution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n\n" ;
  fparameters_out << "\nexecution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n" ;

}

//====================================================
//====================================================  cal_rest_coef
//====================================================


void cal_rest_coef(){ 
#ifdef HookeanForce
 #ifdef SimilarGrains

  double j=0;
  for (int i = 0; i<Sheaths.size(); i++)
    if (Sheaths[i].ptype()==0) j = i; // in case there was walls, or we had
                                    // rest. coeff. instead of diss. coeff.

  #ifdef ParticlesExist
  double _m_eff = Sheaths[j].m() * Sheaths[j].P_m() / (Sheaths[j].m() + Sheaths[j].P_m()); 
  double _Y     = Sheaths[j].Y();
  double _gamma = Sheaths[j].P_A();
  #else
  double _m_eff = Sheaths[j].m() * Sheaths[j].m() / (Sheaths[j].m() + Sheaths[j].m()); 
  double _Y     = Sheaths[j].Y();
  double _gamma = Sheaths[j].A();
  #endif

  double _epsilon; // coefficient of restitution.


  #ifdef NoAdhesiveForce
  double _m       = 2.0 * _m_eff; // *******?? I'm not sure yet
  double _beta    = _gamma / _m;
  double _omega_0 = sqrt ( 2.0 * _Y / _m );


  if (_beta < (_omega_0 / sqrt(2.0))){
    double _omega   = sqrt (+_omega_0*_omega_0 - _beta*_beta);
    _epsilon = exp(-(_beta/_omega) *  (PI - atan ( (2.0 * _beta * _omega) / (_omega*_omega - _beta*_beta) )  ) ) ;
  }
  else if (_beta <= _omega_0) {
    double _omega   = sqrt (+_omega_0*_omega_0 - _beta*_beta);
    _epsilon = exp(-(_beta/_omega) *  (atan ( (2.0 * _beta * _omega) / (_omega*_omega - _beta*_beta) )  ) ) ;
  }
  else {
    double _OMEGA  = sqrt (-_omega_0*_omega_0 + _beta*_beta);
    _epsilon = exp(-(_beta/_OMEGA) * log ((_beta + _OMEGA) / (_beta - _OMEGA) ) ); 
  }

  #else
  _epsilon      = exp( -(PI) / sqrt(((4.0 * _m_eff * _Y)/(_gamma*_gamma)) - 1.0 ));
  #endif


  cout            << "epsilon : " << _epsilon << "\n";
  fparameters_out << "epsilon : " << _epsilon << "\n";
 #else
  cout            << "epsilon : " << "variable per particle" << "\n";
  fparameters_out << "epsilon : " << "variable per particle" << "\n";
 #endif
#else
  cout            << "epsilon : " << "variable per impact" << "\n";
  fparameters_out << "epsilon : " << "variable per impact" << "\n";
#endif
}


//====================================================
//====================================================  make_gas
//====================================================

void make_gas(int grains_num){

  cout<<"======================make_gas()\n";

// MersenneTwister random number generator
  long rng_seed = (long) 2;

  class MTRand *RandNumb = new MTRand (rng_seed);


// ----------------------- Making Sheaths Positions
cout << "Making Sheaths Positions: If this part took more than a few seconds, "
     << "you may have to increase #mean_free_space \n";
  lx = ((2.0 * radius_S_out) + mean_free_space) * grains_num; 
  cout << "lx = " << lx << endl;

  double grain_x [grains_num];

#ifdef TwoDimensional
  ly = ((2.0 * radius_S_out) + mean_free_space) * grains_num; 
  cout << "ly = " << ly << endl;

  double grain_y [grains_num];
#endif

  int grains_counter = 0;

  while (grains_counter < grains_num) {

    double temp_x = lx * RandNumb -> randDblExc();

#ifdef TwoDimensional
    double temp_y = ly * RandNumb -> randDblExc();
#endif

    bool flag_freeSpace = true;

    int i = 0;

    while (flag_freeSpace && i < grains_counter){

#ifdef OneDimensional
      if (   temp_x < grain_x[i] + 2.0 * radius_S_out + GSmallNumber
          && temp_x > grain_x[i] - 2.0 * radius_S_out - GSmallNumber)
        flag_freeSpace = false;
#endif

#ifdef TwoDimensional
      if (  (temp_x-grain_x[i])*(temp_x-grain_x[i]) 
          + (temp_y-grain_y[i])*(temp_y-grain_y[i]) <
            (2.0 * radius_S_out + GSmallNumber)
          * (2.0 * radius_S_out + GSmallNumber)      )
        flag_freeSpace = false;
#endif

        i++;

    }

    if (flag_freeSpace){

      grain_x[grains_counter] = temp_x;

#ifdef TwoDimensional
      grain_y[grains_counter] = temp_y;
#endif

      grains_counter++;

    }

  }
// -----------------------



// ----------------------- ordering grain_x[]
// used for OneDimensional Linear neighbors

#ifdef OneDimensional
  bool flag_disorder = true;

  while (flag_disorder){

    flag_disorder = false;

    for (int i=0;i<grains_num;i++){

      for (int j=0;j<grains_num;j++){

        if (grain_x[i] > grain_x[j] && i < j){

          flag_disorder = true;
          double temp_x = grain_x[i];
          grain_x[i]    = grain_x[j];
          grain_x[j]    = temp_x;

        }

      }

    }

  }
#endif
// -----------------------


#ifdef ParticlesExist
cout << "Making Particles Positions: If this part took more than a few seconds, "
     << "you may have to decrease (#Alpha + #Beta) \n";
#endif
// ----------------------- making grains 
  for (int i=0; i<grains_num ; i++){

    Sheath pp;

// ----------------------- radius, mass, rotational inertia

    pp.r()     = radius_S_out;

#ifdef ParticlesExist
    pp.r_mid() = radius_S_out * ( 1.0 - 2 * Beta);
    pp.P_r()   = pp.r() * Alpha;

 #ifdef OneDimensional
    pp.m()     = Density * 2 * (pp.r() - pp.r_mid());
    pp.P_m()   = Density * 2 * pp.P_r();
 #endif

 #ifdef TwoDimensional
    pp.m()     = Density * PI * (pp.r() * pp.r() - pp.r_mid() * pp.r_mid());
    pp.P_m()   = Density * PI * pp.P_r() * pp.P_r();

    pp.J()     = Density * 0.5 * pp.m() * ( pp.r() * pp.r() + pp.r_mid() * pp.r_mid() );
    pp.P_J()   = Density * 0.5 * pp.P_m() * ( pp.r() * pp.r() );
 #endif

#else
    pp.r_mid() = 0.0;

 #ifdef OneDimensional
    pp.m()     = Density * 2 * (pp.r() - pp.r_mid());
 #endif

 #ifdef TwoDimensional
    pp.m()     = Density * PI * (pp.r() * pp.r() - pp.r_mid() * pp.r_mid());
    pp.J()     = Density * 0.5 * pp.m() * ( pp.r() * pp.r() );
 #endif

#endif
// -----------------------



// ----------------------- positions
    pp.x()     = grain_x[i];

#ifdef TwoDimensional
    pp.y()     = grain_y[i];
    pp.phi()   = 0;
#endif


#ifdef ParticlesExist
find_new_rnd1:
    double temp_x = pp.x() 
                  + ( 0.5 - RandNumb -> randDblExc() ) * 2
                  * (pp.r_mid() - pp.P_r() - GSmallNumber) ; 


    if( pp.r_mid() 
        - (  sqrt((temp_x - pp.x()) * (temp_x - pp.x())) 
           + pp.P_r()) < 0) {

//      cout << "contact!. finding another position.\n"; 
      goto find_new_rnd1;

    }

    pp.P_x()  = temp_x; 


 #ifdef TwoDimensional
find_new_rnd2:
    double temp_y  = pp.y() 
                   + ( 0.5 - RandNumb -> randDblExc() ) * 2
                   * (sqrt( (pp.r_mid()-pp.P_r()) * (pp.r_mid()-pp.P_r())
                   - (pp.x()-temp_x) * (pp.x()-temp_x)) - GSmallNumber) ;



    if( pp.r_mid() 
        - (  sqrt( (temp_y - pp.y()) * (temp_y - pp.y())
                 + (temp_x - pp.x()) * (temp_x - pp.x())) 
           + pp.P_r()) < 0) {

//      cout << "contact!. finding another position.\n";
      goto find_new_rnd2;

    }

    pp.P_y()     = temp_y;

    pp.P_phi() = 0;
 #endif

#endif
// -----------------------



// ----------------------- random velocity
    pp.vx()   = (0.5 - RandNumb -> randDblExc()) * 2;

#ifdef ParticlesExist
    pp.P_vx() = (0.5 - RandNumb -> randDblExc()) * 2;
#endif


#ifdef TwoDimensional
    pp.vy() = (0.5 - RandNumb -> randDblExc()) * 2;

    pp.omega() = init_ang_vel * (0.5 - RandNumb -> randDblExc());
 #ifdef ParticlesExist
    pp.P_vy()= (0.5 - RandNumb -> randDblExc()) * 2;

    pp.P_omega() = init_ang_vel * (0.5 - RandNumb -> randDblExc());
 #endif

#endif
// -----------------------



// ----------------------- material properties
    pp.A()     = A_S;
    pp.Y()     = Y_S;

#ifdef TwoDimensional
    pp.mu()    = mu_S;
    pp.gamma() = gamma_S;
#endif


#ifdef ParticlesExist
    pp.P_A()  = A_P;
    pp.P_Y()  = Y_P;

 #ifdef TwoDimensional
    pp.P_mu()    = mu_P;
    pp.P_gamma() = gamma_P;
 #endif

#endif
// -----------------------

    
    pp.ptype() = 0;

    Num_of_type0++;
    
    Sheaths.push_back(pp);

  }
  
  cout << number_of_grains << " grains are made\n" << flush;
  cout << "======================\n";

}

//====================================================
//====================================================  v_COM_zero
//====================================================

void v_COM_zero(bool make_zero_velocity){

restart_make_zero:

  double v_COM_x=0;

#ifdef TwoDimensional
  double v_COM_y=0;
#endif

  for(unsigned int i=0;i<Sheaths.size();i++){

    if(Sheaths[i].ptype()==0){

      v_COM_x += Sheaths[i].vx();

#ifdef ParticlesExist
      v_COM_x += Sheaths[i].P_vx();
#endif

#ifdef TwoDimensional
      v_COM_y += Sheaths[i].vy();

 #ifdef ParticlesExist
      v_COM_y += Sheaths[i].P_vy();
 #endif
#endif

    }

  }


#ifdef ParticlesExist
  v_COM_x /= (2 * Num_of_type0);
#else
  v_COM_x /= ( Num_of_type0);
#endif


#ifdef TwoDimensional

 #ifdef ParticlesExist
  v_COM_y /= (2 * Num_of_type0);
 #else
  v_COM_y /= ( Num_of_type0);
 #endif

#endif 


  if (make_zero_velocity) {  

    for(unsigned int i=0;i<Sheaths.size();i++){

      if(Sheaths[i].ptype()==0){

        Sheaths[i].vx()   -= v_COM_x;

#ifdef ParticlesExist
        Sheaths[i].P_vx() -= v_COM_x;
#endif

#ifdef TwoDimensional
        Sheaths[i].vy()   -= v_COM_y;

 #ifdef ParticlesExist
        Sheaths[i].P_vy() -= v_COM_y;
 #endif
#endif

      }

    }

    make_zero_velocity = false;
    goto restart_make_zero;

  }

  cout << "center of mass velocity x: " << v_COM_x << "\n";
#ifdef TwoDimensional
  cout << "center of mass velocity y: " << v_COM_y << "\n";
#endif
  cout<<"======================\n";

}

//====================================================
//====================================================  temperature_normalizer
//====================================================

void temperature_normalizer(double temp_0){

  double temp_1 = total_kinetic_energy();
  double temp_r = Num_of_type0*temp_0/temp_1;
  double vel_r  = sqrt(temp_r);

  for(unsigned int i=0;i<Sheaths.size();i++){

    if(Sheaths[i].ptype()==0){


      Sheaths[i].vx()   = vel_r * Sheaths[i].vx() ;

 #ifdef ParticlesExist
      Sheaths[i].P_vx() = vel_r * Sheaths[i].P_vx();
 #endif


#ifdef TwoDimensional
      Sheaths[i].vy()   = vel_r * Sheaths[i].vy() ;
      Sheaths[i].omega()   = vel_r * Sheaths[i].omega();

 #ifdef ParticlesExist
      Sheaths[i].P_vy() = vel_r * Sheaths[i].P_vy();
      Sheaths[i].P_omega() = vel_r * Sheaths[i].P_omega();
 #endif

#endif


    }

  }

  cout << "initial kinetic energy : "
       <<  total_kinetic_energy() << "\n";
  cout << "initial granular temperature : "
       <<  total_kinetic_energy()/Num_of_type0  << "\n";

}

//====================================================
//====================================================  output_file_maker
//====================================================

void output_file_maker(){

  string str_folder_output;

  str_folder_output.append("outputs/"); 

  const char* char_folder_output=str_folder_output.c_str();
  mkdir(char_folder_output,0777);

  time_t rawtime;

  struct tm * timeinfo;
  char char_buffer [40];
  time (&rawtime);
  timeinfo = localtime (&rawtime);
  

//  strftime (buffer,80,"Now it's %I:%M%p.",timeinfo);
//  strftime (buffer,80,"Now it's %F_%T",timeinfo);

  strftime (char_buffer,80,"  %F  %T",timeinfo);

  string str_fname;

#ifdef OneDimensional    //(1) 
  str_fname.append("_1D");
#endif

#ifdef TwoDimensional    //(2)
  str_fname.append("_2D");
#endif

#ifdef ParticlesExist //ON or OFF//
  str_fname.append("_P:On");
#endif

#ifdef HookeanForce   //(1)
  str_fname.append("_Hook");
#endif

#ifdef HertzianForce    //(2)
  str_fname.append("_Hertz");
#endif

  char buffer[50]="";

  sprintf(buffer,"_nP:%lu",Sheaths.size());
  str_fname.append(buffer);

//  sprintf(buffer,"_dt:%g",timestep);
//  str_fname.append(buffer);
//  sprintf(buffer,"_nt:%u",nstep);

  sprintf(buffer,"_t:%g",nstep*timestep);
  str_fname.append(buffer);

#ifdef ParticlesExist
  sprintf(buffer,"_AP:%g",A_P);
  str_fname.append(buffer);
#else
  sprintf(buffer,"_AS:%g",A_S);
  str_fname.append(buffer);
#endif

#ifdef ParticlesExist
  sprintf(buffer,"_Alpha:%g",Alpha);
  str_fname.append(buffer);
  sprintf(buffer,"_Beta:%g",Beta);
  str_fname.append(buffer);
#endif

  sprintf(buffer,"_AFS:%g",mean_free_space);
  str_fname.append(buffer);

  string str_fname_T=str_folder_output;
  str_fname_T.append("/T");
  str_fname_T.append(str_fname);
  str_fname_T.append(".dat");
  const char * char_ftemperature=str_fname_T.c_str();
  ftemperature.open(char_ftemperature);

  string str_fname_P=str_folder_output;
  str_fname_P.append("/P");
  str_fname_P.append(str_fname);
  str_fname_P.append(".dat");
  const char * char_fparameters_out=str_fname_P.c_str();
  fparameters_out.open(char_fparameters_out);

#ifdef XYZOutputMaker

  string str_xyzfile=str_folder_output;
  str_xyzfile.append("/XYZ");
  str_xyzfile.append(str_fname);
  str_xyzfile.append(".xyz");
  const char * char_xyzfile=str_xyzfile.c_str();
  xyzfile.open(char_xyzfile);

 #ifdef ParticlesExist
  string str_xyzfile2=str_folder_output;
  str_xyzfile2.append("/XYZ2");
  str_xyzfile2.append(str_fname);
  str_xyzfile2.append(".xyz");
  const char * char_xyzfile2=str_xyzfile2.c_str();
  xyzfile2.open(char_xyzfile2);
 #endif

#endif

#ifdef XTOutputMaker
  string str_xtfile=str_folder_output;
  str_xtfile.append("/xt");
  str_xtfile.append(str_fname);
  str_xtfile.append(".dat");
  const char * char_xtfile=str_xtfile.c_str();
  xtfile.open(char_xtfile);
#endif

  cout            << "======================Date and time" << "\n";
  cout            << char_buffer                           << "\n";
  cout            << "======================"              << "\n";
  fparameters_out << "==================Date and time"     << "\n\n";
  fparameters_out << char_buffer                           << "\n\n";
  fparameters_out << "==================system properties" << "\n\n";

#ifdef OneDimensional    //(1) 
  fparameters_out << "OneDimensional"       << "\n";
#endif

#ifdef TwoDimensional    //(2)
  fparameters_out << "TwoDimensional"       << "\n";
#endif

#ifdef ParticlesExist 
  fparameters_out << "ParticlesExists"     << "\n";
#endif

#ifdef HookeanForce   
  fparameters_out << "HookeanForce"    << "\n";
#endif

#ifdef HertzianForce  
  fparameters_out << "HertzianForce"   << "\n";
#endif

  fparameters_out << "\n==================\n\n";
  fparameters_out << "radius_S_out: " << Sheaths[1].r() << "\n";

#ifdef ParticlesExist 
  fparameters_out << "radius_S_in: "  << Sheaths[1].r_mid() << "\n";
#endif

  fparameters_out << "Density: "  << Density  << "\n";
  fparameters_out << "mass_S: "   << Sheaths[1].m()   << "\n";
  fparameters_out << "A_S: "      << A_S      << "\n";
  fparameters_out << "Y_S: "      << Y_S      << "\n";
  fparameters_out << "mu_S: "     << mu_S     << "\n";
  fparameters_out << "gamma_S: "  << gamma_S  << "\n";

#ifdef ParticlesExist 
  fparameters_out << "Alpha: "     << Alpha             << "\n";
  fparameters_out << "Beta: "      << Beta              << "\n";

  fparameters_out << "radius_P: "  << Sheaths[1].P_r()  << "\n";
  fparameters_out << "mass_P: "    << Sheaths[1].P_m()  << "\n";
  fparameters_out << "A_P: "       << A_P       << "\n";
  fparameters_out << "Y_P: "       << Y_P       << "\n";
  fparameters_out << "mu_P: "      << mu_P      << "\n";
  fparameters_out << "gamma_P: "   << gamma_P   << "\n";
#endif

  fparameters_out << "\n==================\n\n";
  fparameters_out << "lx: "         << lx   << "\n";

#ifdef TwoDimensional
  fparameters_out << "ly: "         << ly   << "\n";
#endif

  fparameters_out << "mean_free_space: "      
                  <<  mean_free_space    << "\n";
  fparameters_out << "init_gran_temp: "      
                  <<  init_gran_temp     << "\n";
#ifdef TwoDimensional
  fparameters_out << "init_ang_vel: "      
                  <<  init_ang_vel       << "\n";
#endif

  fparameters_out << "\n==================\n\n";
  fparameters_out << "timestep: "   << timestep   << "\n";
  fparameters_out << "nsteps: "     << nstep      << "\n";
  fparameters_out << "final_time: "  
                  << nstep*timestep               << "\n";

  fparameters_out << "\n==================\n\n";
  fparameters_out << "Number of grains: " 
                  << Sheaths.size()               << "\n";


}

//====================================================
//====================================================  integrate
//====================================================

void integrate()
{

  for(unsigned int i=0;i<Sheaths.size();i++){

//    if(Sheaths[i].ptype()==0) { // enable when there's wall grains

      Sheaths[i].set_force_to_zero(); 

      Sheaths[i].predict(timestep);

//    } else { // enable when there's wall grains
//      Sheaths[i].boundary_conditions(i,timestep,Time); // enable when there's wall grains
//    } // enable when there's wall grains

  }



    make_forces();

  
  for(unsigned int i=0;i<Sheaths.size();i++){

//    if(Sheaths[i].ptype()==0) { // enable when there's wall grains

      Sheaths[i].correct(timestep);

//    } // enable when there's wall grains

  }


  for(unsigned int i=0;i<Sheaths.size();i++){

#ifdef OneDimensional
    Sheaths[i].periodic_bc (x_0, lx);
#endif

#ifdef TwoDimensional
    Sheaths[i].periodic_bc (x_0, y_0, lx, ly);
#endif

  }

  Time+=timestep;

}

//====================================================
//====================================================  init_parameters
//====================================================

void init_parameters(char * fname_ip)
{

  cout<<"======================init_parameters()\n";

  ifstream fparameters(fname_ip);

  while(fparameters.peek()=='#'){

    string type;

    fparameters >> type;

    if(type=="#number_of_grains:"){

      fparameters >> number_of_grains;
      fparameters.ignore(100,'\n');
      cout << "number_of_grains: " << number_of_grains << endl;
      fparameters_out << "number_of_grains: " << number_of_grains << endl;

    } else if(type=="#mean_free_space:"){

      fparameters >> mean_free_space;
      fparameters.ignore(100,'\n');
      cout << "mean_free_space: " << mean_free_space << endl;
      fparameters_out << "mean_free_space: " << mean_free_space << endl;

    } else if(type=="#init_gran_temp:"){

      fparameters >> init_gran_temp;
      fparameters.ignore(100,'\n');
      cout << "init_gran_temp: " << init_gran_temp << endl;
      fparameters_out << "init_gran_temp: " << init_gran_temp << endl;

    } else if(type=="#init_ang_vel:"){

      fparameters >> init_ang_vel;
      cout << "init_ang_vel: " << init_ang_vel << endl;
      fparameters_out << "init_ang_vel: " << init_ang_vel << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#gravity:"){

#ifdef OneDimensional
      fparameters >> G;
#endif

#ifdef TwoDimensional
      fparameters >> G.x() >> G.y() >> G.phi();
#endif

      fparameters.ignore(100,'\n');
      cout << "gravity: " << G << endl;
      fparameters_out << "gravity: " << G << endl;

    } else if(type=="#Time:"){

      fparameters >> Time;
      fparameters.ignore(100,'\n');
      cout << "Time: " << Time << endl;
      fparameters_out << "Time: " << Time << endl;

    } else if(type=="#timestep:"){

      fparameters >> timestep;
      fparameters.ignore(100,'\n');
      cout << "timestep: " << timestep << endl;
      fparameters_out << "timestep: " << timestep << endl;

    } else if(type=="#nstep:"){

      fparameters >> nstep;
      fparameters.ignore(100,'\n');
      cout << "nstep: " << nstep << endl;
      fparameters_out << "nstep: " << nstep << endl;

    } else if(type=="#nprint:"){

      fparameters >> nprint;
      fparameters.ignore(100,'\n');
      cout << "nprint: " << nprint << endl;

    } else if(type=="#nenergy:"){

      fparameters >> nenergy;
      fparameters.ignore(100,'\n');
      cout << "nenergy: " << nenergy << endl;
      fparameters_out << "nenergy: " << nenergy << endl;

    } else if(type=="#Density:"){

      fparameters >> Density;
      fparameters.ignore(100,'\n');
      cout << "Density: " << Density << endl;

    } else if(type=="#radius_S_out:"){

      fparameters >> radius_S_out;
      fparameters.ignore(100,'\n');
      cout << "radius_S_out: " << radius_S_out << endl;

    }  else if(type=="#A_S:"){

      fparameters >> A_S;
      fparameters.ignore(100,'\n');
      cout << "A_S: " << A_S << endl;

    } else if(type=="#Y_S:"){

      fparameters >> Y_S;
      fparameters.ignore(100,'\n');
      cout << "Y_S: " << Y_S << endl;

    } else if(type=="#mu_S:"){

      fparameters >> mu_S;
      fparameters.ignore(100,'\n');

      cout << "mu_S: " << mu_S << endl;
    } else if(type=="#gamma_S:"){

      fparameters >> gamma_S;
      cout << "gamma_S: " << gamma_S << endl;
      fparameters.ignore(100,'\n');

   } else if(type=="#Alpha:"){

      fparameters >> Alpha;
      cout << "Alpha: " << Alpha << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#Beta:"){

      fparameters >> Beta;
      cout << "Beta: " << Beta << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#A_P:"){

      fparameters >> A_P;
      cout << "A_P: " << A_P << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#Y_P:"){

      fparameters >> Y_P;
      cout << "Y_P: " << Y_P << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#mu_P:"){

      fparameters >> mu_P;
      cout << "mu_P: " << mu_P << endl;
      fparameters.ignore(100,'\n');

   } else if(type=="#gamma_P:"){
      fparameters >> gamma_P;
      cout << "gamma_P: " << gamma_P << endl;
      fparameters.ignore(100,'\n');

   }  else {

      cerr << "init_parameters(): unknown global property: " << type << endl;

    }

  }

}

//====================================================
//====================================================  init_system 
//====================================================

/* // used when the system would be inputted from a file.
void init_system(char * fname_is)
{

  cout<<"======================init_system()\n";
  fparameters_out<<"==================init_system"<<"\n";

// MersenneTwister random number generator
  long rng_seed = (long) 2;
  class MTRand *RandNumb = new MTRand (rng_seed);
// --------------------------------------

  ifstream fSheath(fname_is);

  while(fSheath.peek()=='#'){

    string type;
    fSheath >> type;

    if(type=="#lx:"){

      fSheath >> lx;
      fSheath.ignore(100,'\n');
      cout << "lx: " << lx << endl;
      fparameters_out << "lx: " << lx << endl;

    } 
#ifdef TwoDimensional
      else if(type=="#ly:"){

      fSheath >> ly;
      cout << "ly: " << ly << endl;
      fparameters_out << "ly: " << ly << endl;
      fSheath.ignore(100,'\n'); 

    } 
#endif

      else {
      cerr << "init_system(): unknown global property: " << type << endl;
    }
  }

  while(fSheath){

    Sheath pp;

    fSheath >> pp;

    pp.r()     = radius_S_out;

#ifdef ParticlesExist
    pp.r_mid() = radius_S_out * ( 1.0 - Beta) ;
    pp.m()     = Density * 2 * (pp.r() - pp.r_mid());
#else
    pp.r_mid() = radius_S_out;
    pp.m()     = Density * 2 * pp.r();
#endif

    pp.A()     = A_S;
    pp.Y()     = Y_S;
    pp.mu()    = mu_S;

#ifdef ParticlesExist
    pp.P_x()  = pp.x();
    pp.P_r()  = pp.r() * Alpha ;
    pp.P_m()  = Density * 2 * pp.P_r();
    pp.P_A()  = A_P;
    pp.P_Y()  = Y_P;
    pp.P_mu() = mu_P;
#endif

    if(fSheath){

      if (pp.ptype()==0) {

        Num_of_type0++;

//        pp.vx() =   0.5 - Ranni.ran2(iseed);
        pp.vx() = 0.5 - RandNumb -> randDblExc();

#ifdef ParticlesExist
        pp.P_vx()=pp.vx();
#endif

#ifdef TwoDimensional
        pp.vy() = 0.5 - RandNumb -> randDblExc();

 #ifdef ParticlesExist
        pp.P_vy()=pp.vy();
 #endif

#endif

      }

      if (pp.ptype()>0) 
        Num_of_type1++;

      Sheaths.push_back(pp);

    }
    
  }

  number_of_grains = Sheaths.size();

  cout << number_of_grains << " Sheaths read\n" << flush;

}
*/

//====================================================
//====================================================  total_kinetic_eneregy
//====================================================

double total_kinetic_energy()
{

  double sum=0;

  for(unsigned int i=0;i<Sheaths.size();i++){

    if(Sheaths[i].ptype()==0)
      sum+=Sheaths[i].kinetic_energy();

  }

  return sum;

}

//====================================================
//====================================================  phase_plot
//====================================================

#ifdef XYZOutputMaker
void phase_plot_XYZ()
{

  xyzfile  << Sheaths.size() << "\nAtom\n";

 #ifdef ParticlesExist
  xyzfile2 << 2*Sheaths.size()-Num_of_type1
           << "\nAtom\n";
 #else
  xyzfile2 << Sheaths.size() << "\nAtom\n";
 #endif

  for(unsigned int i=0;i<Sheaths.size();i++){

 #ifdef OneDimensional
    xyzfile  << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t0.0\t0.0\n";

    xyzfile2 << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t0.0\t0.0\n";

  #ifdef ParticlesExist
    if (Sheaths[i].ptype()!=1)
      xyzfile2 << 3                        << "\t"
               << XYZscale*Sheaths[i].P_x()<< "\t0.0\t0.0\n";
  #endif

 #endif


 #ifdef TwoDimensional
    xyzfile  << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t"
             << XYZscale*Sheaths[i].y() << "\t0.0\n";

    xyzfile2 << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t"
             << XYZscale*Sheaths[i].y() << "\t0.0\n";

  #ifdef ParticlesExist
    if (Sheaths[i].ptype()!=1)
      xyzfile2 << 3                         << "\t"
               << XYZscale*Sheaths[i].P_x() << "\t"
               << XYZscale*Sheaths[i].P_y() << "\t0.0\n";
    
  #endif

 #endif

  }

}
#endif

//====================================================
//====================================================  phase_plot_XT
//====================================================

#ifdef XTOutputMaker
void phase_plot_XT()
{

  xtfile  << Time << " ";

  for(unsigned int i=0;i<Sheaths.size();i++)
    xtfile  << Sheaths[i].x() << " ";

  xtfile  << "\n";

}
#endif
