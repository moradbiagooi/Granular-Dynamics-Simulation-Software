
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _common_h
#define _common_h

#include <math.h>
#include <fstream>
#include <vector>      
#include <string>

#include "properties.h"

using namespace std;

extern double lx, x_0; // horizontal system size ,lower left corner

#ifdef TwoDimensional
extern double ly, y_0; // vertical system size,lower down corner
#endif


extern double Time;    // elapsed real time


void step();           // Performs one time step of the simulation


void make_forces();    // Computes the total forces acting on each Sheath

void integrate();      // Integrates Newton’s equation of motion using the Gear algorithm 

#ifdef XYZOutputMaker
void phase_plot_XYZ(); // Dumps the current positions into the file (xyz format)
#endif

#ifdef XTOutputMaker
void phase_plot_XT();  // Dumps the current positions into the file (xt format)
#endif


void init_algorithm(); // 


#endif
