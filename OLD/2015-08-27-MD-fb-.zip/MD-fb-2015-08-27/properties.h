
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _properties_h
#define _properties_h

/*-------------------------------------------------------------------
Here we can choose between different alternatives:
One of the (1) or (2) have to be active.
In the other case, have to turn something //ON or OFF//
-------------------------------------------------------------------*/


//=============================== Dimensions
// in case of TwoDimensional, it is highly recommended to
// compile with "verlet.cpp" instead of "simple.cpp"
//

#define OneDimensional    // (1) //
//#define TwoDimensional    // (2) //


//=============================== 1-Dimensional force type
// Calculated the forces between neighbors,
// when neighbors in index are neigbors in position.
// if not defined, it will check the force between all
// of the particles.
//

#define OneDimLinForce     // ON or OFF //

                           
//=============================== Inner Forces correction
// To omit an unwanted artifact (probable adhesive force)
// force = max [0 , f(xi)] if NoAdhesiveForce is defined
// This makes a difference in calculation of restitution
// coefficient, according to
// Schwager, T., Pöschel, T., Granular Matter 9:465 (2007)
//
 
#define NoAdhesiveForce    // ON or OFF //


//=============================== Forces type
// using linear dashpot force if HookeanForce is defined.
//   F = Y * xi + A * xidot
//
// in case of HertzianForce, it would be like 
//   r_eff = (r1 * r2)/(r1 + r2)
//   F = sqrt(xi) * Y * sqrt(reff) * (xi + A * xidot)
// in this case, epsilon (restitution coefficient) would
// be a function of relative velocity in the impacts.
//

#define HookeanForce    // (1) //
//#define HertzianForce    // (2) //


//=============================== Sheaths's Particle existence
// If defined, each grain will have an inner radius and an inner Particle.
// 

#define ParticlesExist     // ON or OFF //


//=============================== Sheaths's Particle gravity
// The gravity functions on the Particles
//

//#define InnerGravityForce    // ON or OFF // 


//===============================  output: xyz
// Make a output file in "xyz" format
// it can be used in VMD visualization
// XYZ_  only Sheath's positions
// XYZ2_ Sheath's and particles positions
//

//#define XYZOutputMaker    // ON or OFF //


//===============================  output X(t)
// Make a output file in the format:
//     t1   x1   x2   ...   xn
//     t2   x1   x2   ...   xn
// it can be used to plot "phase vs time" graphs
//

#define XTOutputMaker    // ON or OFF //


//===============================  Grains Similarity
// If it is defined, it assumes that all of particles are similar.
// In force calculation, it uses material properties of one of the
// particles such as Young modulus, static friction, dissipative constant
// and gamma of rotation instead of calculating an effective one.
// This has to be activated to make the program output a rest. coef. value
//

#define SimilarGrains


//===============================
//
#endif
