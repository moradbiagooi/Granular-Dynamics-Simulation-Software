
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include "common.h"
#include "Sheath.h"
#include "properties.h"

using namespace std;

extern vector<Sheath> Sheaths;

//====================================================


void init_algorithm() 
{
}


//====================================================


void step()
{
  integrate();
}


//====================================================

void make_forces()
{

  for(unsigned int i=0;i<Sheaths.size();i++){

#ifdef OneDimensional

 #ifdef ParticlesExist
    Sheaths[i].internal_force(lx);
 #endif

 #ifdef OneDimLinForce
    if (i+1 == Sheaths.size()){
      force(Sheaths[i],Sheaths[0], lx); // Periodic B.C
    }
    else
    {
      force(Sheaths[i],Sheaths[i+1], lx); // LINEAR NEIGHBORS
    }
 #else
    for(unsigned int j=i+1;j<Sheaths.size();j++){
      force(Sheaths[i],Sheaths[j], lx); // between  Sheaths
    }
 #endif

#endif

#ifdef TwoDimensional

 #ifdef ParticlesExist
    Sheaths[i].internal_force(lx, ly);
 #endif

    for(unsigned int j=i+1;j<Sheaths.size();j++){
      force(Sheaths[i],Sheaths[j], lx, ly); // between Sheaths
    }

#endif

  }

}


