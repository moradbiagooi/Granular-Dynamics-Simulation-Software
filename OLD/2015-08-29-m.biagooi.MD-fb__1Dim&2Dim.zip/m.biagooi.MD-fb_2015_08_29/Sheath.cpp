
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include <assert.h>

#include "Sheath.h"
#include "properties.h"


#ifdef OneDimensional
extern double G;
#endif


#ifdef TwoDimensional
extern Vector G;
#endif


#define GSmallNumber 1e-4

//====================================================
//==================================================== S::P_slipped_out
//====================================================

#ifdef ParticlesExist
bool Sheath::P_slipped_out(){

 #ifdef OneDimensional
  double center_dist = P_x() > x() ? P_x() - x() : x() - P_x();
 #endif

 #ifdef TwoDimensional
  double center_dist = sqrt ((P_x() - x()) * (P_x() - x())
                            +(P_y() - y()) * (P_y() - y()));
 #endif

  if (center_dist > r() - GSmallNumber - P_r())
    return true;
  else
    return false;

}
#endif

//====================================================
//==================================================== S::predict
//====================================================

void Sheath::predict(double dt)
{

#ifdef ParticlesExist
    P.predict(dt);
#endif

  double a1 = dt;
  double a2 = a1*dt/2;
  double a3 = a2*dt/3;
  double a4 = a3*dt/4;

  rtd0 += a1*rtd1 + a2*rtd2 + a3*rtd3 + a4*rtd4;
  rtd1 += a1*rtd2 + a2*rtd3 + a3*rtd4;
  rtd2 += a1*rtd3 + a2*rtd4;
  rtd3 += a1*rtd4;

}

//====================================================
//==================================================== S::correct
//====================================================

void Sheath::correct(double dt)
{

#ifdef ParticlesExist
    P.correct(dt);
#endif

#ifdef OneDimensional
  static double accel,corr;
#endif

#ifdef TwoDimensional
  static Vector accel,corr;
#endif

  double dtrez = 1/dt;
  const double coeff0 = double(19)/ double(90) * (dt*dt/double(2));
  const double coeff1 = double(3) / double(4)  * (dt/double(2));
  const double coeff3 = double(1) / double(2)  * (double(3)*dtrez);
  const double coeff4 = double(1) / double(12) * (double(12)*(dtrez*dtrez));

#ifdef GravityInnerForce

 #ifdef OneDimensional
  accel = ((1/_m)*_force+G);
 #endif

 #ifdef TwoDimensional
  accel = Vector((1/_m)*_force.x()+G.x(),
          (1/_m)*_force.y()+G.y(),
          (1/_J)*_force.phi()+G.phi());
// a rotational gravity??
 #endif

#else

 #ifdef OneDimensional
  accel=((1/_m)*_force);
 #endif

 #ifdef TwoDimensional
  accel=Vector((1/_m)*_force.x(),
    (1/_m)*_force.y(),
    (1/_J)*_force.phi());
 #endif

#endif

  corr=accel-rtd2;

  rtd0 += coeff0*corr;
  rtd1 += coeff1*corr;
  rtd2  = accel;
  rtd3 += coeff3*corr;
  rtd4 += coeff4*corr;

}

//====================================================
//==================================================== S::internal_force
//====================================================

#ifdef ParticlesExist

 #ifdef OneDimensional
void Sheath::internal_force(double lx)
 #endif

 #ifdef TwoDimensional
void Sheath::internal_force(double lx, double ly)
 #endif

{

  double dx = x()-P.x();// X_1 - X_2

 #ifdef OneDimensional
  double rr = sqrt(dx*dx);// distance between center of P. and S.
 #endif

 #ifdef TwoDimensional
  double dy = y()-P.y();// Y_1 - Y_2

  double rr = sqrt(dx*dx+dy*dy);// distance between center of P. and S.
 #endif

  double r1 = r();
  double r2 = P.r();
  double r3 = r_mid();

  double xi = rr+r2-r3;

  if (xi>0) {

    double Y = P.Y(), A = P.A();

    double dvx = vx()-P.vx();// relative velocity component x: (V_x)_1 -(V_x)_2 

 #ifdef TwoDimensional
    double mu = P.mu();
    double dvy = vy()-P.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
 #endif

    double rr_rez = 1/rr;// distance^(-1)

    double ex = dx*rr_rez;// dX/rr

 #ifdef OneDimensional
    double xidot = (ex*dvx);// -(dX*dV_x)/rr = - e_ij . dV_ij
 #endif

 #ifdef TwoDimensional
    double ey = dy*rr_rez;;//dy*rr_rez;// dX/rr

    double xidot = (ex*dvx+ey*dvy);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij

 #endif

 #ifdef HertzianForce
    double reff = (r1*r2)/(r1+r2); // effective radius (two ordinary viscoelastic spheres)
//    double reff = (r3*r2)/(r3+r2); // effective radius (Hollow Sheath with internal Particles?)

    double fn = sqrt(xi)*Y*sqrt(reff)*(xi+A*xidot);
// normal force: Y * (x_i^(3/2) + A * x_i^(1/2) * d(xi)/dt)
 #endif

 #ifdef HookeanForce
    double fn = Y*xi+A*xidot;
// normal force: Y * (x_i + A * d(xi)/dt) 
 #endif


 #ifdef NoAdhesiveForce
    if(fn<0) fn = 0;
// non-negative force condition : fn = max ( 0 , fn) 
 #endif

 #ifdef OneDimensional
    add_force   (-fn*ex);
    P.add_force ( fn*ex);

 #endif

 #ifdef TwoDimensional
    double omega1 = omega(); 
    double omega2 = P.omega();
    double gamma  = P.gamma();

    double vtrel  = +dvx*ey - dvy*ex + omega1*r3 - omega2*r2;  

    double ft = -gamma*vtrel; 

    if (ft < -mu*fn) ft = -mu*fn;  // Coulomb's law of friction
    if (ft >  mu*fn) ft =  mu*fn;  // Coulomb's law of friction

    add_force  (Vector(-fn*ex+ft*ey, -fn*ey-ft*ex,  r3*ft));

    P.add_force(Vector( fn*ex-ft*ey,  fn*ey+ft*ex, -r2*ft));

 #endif


  }

}

#endif

//====================================================
//==================================================== force
//====================================================

#ifdef OneDimensional
void force(Sheath & p1, Sheath & p2, double lx) 
#endif
#ifdef TwoDimensional
void force(Sheath & p1, Sheath & p2, double lx, double ly) 
#endif
{

  double dx = normalize(p1.x()-p2.x(), lx);

#ifdef OneDimensional
   double rr = sqrt (dx*dx);// distance between center of two Sheaths
#endif

#ifdef TwoDimensional

  double dy = normalize(p1.y()-p2.y(), ly);

  double rr = sqrt(dx*dx + dy*dy);// distance between center of two Sheaths
#endif

 
  double r1 = p1.r();
  double r2 = p2.r();
  
  double xi = r1+r2-rr;//  compression : radius1+radius2-distance

  if(xi>0){

#ifdef SimilarGrains
    double Y = p1.Y();

    double A = p1.A();

 #ifdef TwoDimensional
    double gamma = p1.gamma();
    double mu    = p1.mu(); 
 #endif

#else
// The formula to find effective Y, A, mu and gamma
// when those are different for different grains

    double Y = p1.Y()*p2.Y()/(p1.Y()+p2.Y());
// effective Young modulus

    double A = 0.5*(p1.A()+p2.A());
// average of Dissipative constants

 #ifdef TwoDimensional
    double mu = (p1.mu()<p2.mu() ? p1.mu() : p2.mu());
// friction constant : the smaller friction is the appliciable one.

    double gamma = (p1.gamma()<p2.gamma() ? p1.gamma() : p2.gamma());
// gamma of friction
 #endif

#endif


    double reff = (r1*r2) / (r1 + r2);// effective radius

    double dvx = p1.vx() - p2.vx();// relative velocity component x: (V_x)_1 -(V_x)_2 

#ifdef TwoDimensional
    double dvy = p1.vy() - p2.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
#endif

    double rr_rez = 1/rr;// distance^(-1)

    double ex = dx*rr_rez;// dX/rr

#ifdef OneDimensional
    double xidot = -(ex*dvx);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij
#endif

#ifdef TwoDimensional
    double ey = dy*rr_rez;// dY/rr

    double xidot = -(ex*dvx + ey*dvy);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij

#endif

#ifdef HertzianForce
    double fn = sqrt(xi)*Y*sqrt(reff)*(xi+A*xidot);
// normal force: Y * (x_i^(3/2) + A * x_i^(1/2) * d(xi)/dt)
#endif

#ifdef HookeanForce
    double fn = Y*xi+A*xidot;
// normal force: Y * (x_i + A * d(xi)/dt) 
#endif

#ifdef NoAdhesiveForce
    if (fn < 0) fn=0;
// non-negative force condition : fn = max ( 0 , fn)
#endif

#ifdef OneDimensional
    if (p1.ptype() == 0) {
      p1.add_force( fn*ex);
    }
    if (p2.ptype() == 0) {
      p2.add_force(-fn*ex);
    } 
#endif


#ifdef TwoDimensional
    double omega1 = p1.omega();
    double omega2 = p2.omega();

    double vtrel = -dvx*ey + dvy*ex + omega1*r1 - omega2*r2;
// relative tangential velocity of the surfaces of the contacting Sheaths:
//  (-dV_x*dY +dV_y*dX)/rr  + w_1*r_1 + w_2*r2: using e_ij_tangential . dV_ij

    double ft = -gamma*vtrel;// tangential force;

    if (ft < -mu*fn) ft = -mu*fn;  // Coulomb's law of friction
    if (ft >  mu*fn) ft =  mu*fn;  // Coulomb's law of friction

    if (p1.ptype() == 0) 
      p1.add_force(Vector(fn*ex-ft*ey ,  fn*ey+ft*ex,  r1*ft));
    
    if (p2.ptype() == 0) 
      p2.add_force(Vector(-fn*ex+ft*ey, -fn*ey-ft*ex, -r2*ft));
#endif

  }

}

//====================================================
//==================================================== S::boundary_conditions
//====================================================

/* // Moving Walls
void Sheath::boundary_conditions(int n, double timestep, double Time)
{

  switch(ptype()){
  case(0): break;
  case(1): break;

#ifdef TwoDimensional
  case(2): {
    x()=0.5-0.4*cos(10*Time);
    y()=0.1;
    vx()=10*0.4*sin(Time);
    vy()=0;
  } break;
  case(3): {
    double xx=x()-0.5;
    double yy=y()-0.5;
    double xp=xx*cos(timestep)-yy*sin(timestep);
    double yp=xx*sin(timestep)+yy*cos(timestep);
    x()=0.5+xp;
    y()=0.5+yp;
    vx()=-yp;
    vy()= xp;
    omega()=1;
  } break;
  case(4): {
    x()=0.5+0.1*cos(Time) + 0.4*cos(Time+2*n*M_PI/128);
    y()=0.5+0.1*sin(Time) + 0.4*sin(Time+2*n*M_PI/128);
    vx()=-0.1*sin(Time) - 0.4*sin(Time+2*n*M_PI/128);
    vy()= 0.1*cos(Time) - 0.4*cos(Time+2*n*M_PI/128);
    omega()=1;
  } break;
  case(5): {
    y()=0.1+0.02*sin(30*Time);
    vx()=0;
    vy()=0.02*30*cos(30*Time);
  } break;
  case(6): {
    int i=n/2;
    y()=i*0.02+0.1+0.02*sin(30*Time);
    vx()=0;
    vy()=0.02*30*cos(30*Time);
  } break;
  default: {
    cerr << "ptype: " << ptype() << " not implemented\n";
    //abort();  // what's this
    }
#endif

  }

}
*/

//====================================================
//==================================================== S::periodic_bc
//====================================================

#ifdef OneDimensional
void Sheath::periodic_bc(double x_0, double lx)
{

 #ifdef ParticlesExist
  while(rtd0<x_0)    {rtd0 += lx; P.x() += lx;}
  while(rtd0>x_0+lx) {rtd0 -= lx; P.x() -= lx;}
 #else
  while(rtd0<x_0)    {rtd0 += lx;}
  while(rtd0>x_0+lx) {rtd0 -= lx;}
 #endif

}
#endif


#ifdef TwoDimensional
void Sheath::periodic_bc(double x_0, double y_0, double lx, double ly)
{

 #ifdef ParticlesExist
  while(rtd0.x()<x_0)    {rtd0.x() += lx; P.x() += lx;}
  while(rtd0.x()>x_0+lx) {rtd0.x() -= lx; P.x() -= lx;}

  while(rtd0.y()<y_0)    {rtd0.y() += ly; P.y() += ly;}
  while(rtd0.y()>y_0+ly) {rtd0.y() -= ly; P.y() -= ly;}
 #else
  while(rtd0.x()<x_0)    rtd0.x() += lx;
  while(rtd0.x()>x_0+lx) rtd0.x() -= lx;

  while(rtd0.y()<y_0)    rtd0.y() += ly;
  while(rtd0.y()>y_0+ly) rtd0.y() -= ly;
 #endif

}
#endif

//====================================================
//==================================================== S::kinetic_energy
//====================================================

double Sheath::kinetic_energy() const
{
#ifdef ParticlesExist

 #ifdef OneDimensional
  return P.kinetic_energy() +
         _m * ( rtd1 * rtd1 ) / 2;
 #endif

 #ifdef TwoDimensional
  return P.kinetic_energy()           +
         _m* ( rtd1.x() * rtd1.x()    +
               rtd1.y() * rtd1.y() )  / 2
     + _J * (rtd1.phi() * rtd1.phi()) / 2; //rotational Kinetic energy
 #endif

#else

 #ifdef OneDimensional
  return  _m * ( rtd1 * rtd1 ) / 2;
 #endif

 #ifdef TwoDimensional
  return  _m * ( rtd1.x() * rtd1.x()    + 
                 rtd1.y() * rtd1.y() )  / 2
       + _J * (rtd1.phi() * rtd1.phi()) / 2; //rotational Kinetic energy
 #endif

#endif
}

//====================================================
//==================================================== istream & operator >>
//====================================================

/* // used when the system would be inputted from a file.
istream & operator >> (istream & is, Sheath & p)
{

  is >> p.rtd0 >>   p.rtd1
     >> p._r   >>   p._m >> p._ptype
     >> p._Y   >>   p._A >> p._mu   >> p._gamma
     >> p._force
     >> p.rtd2 >> p.rtd3 >> p.rtd4;

  p._J = p._m*p._r*p._r/2;

  return is;

}
*/

//====================================================
//==================================================== ostream & operator <<
//====================================================

/*  // used when the system would be inputted from a file.
ostream & operator << (ostream & os, const Sheath & p)
{

  os << p.rtd0   << " " << p.rtd1 << " ";
  os << p._r     << " " << p._m   << " " << p._ptype       << " ";
  os << p._Y     << " " << p._A   << " " << p._mu << " "   << p._gamma << " ";
  os << p._force << " ";
  os << p.rtd2   << " " << p.rtd3 << " " << p.rtd4 << "\n" << flush;

  return os;

}
*/


