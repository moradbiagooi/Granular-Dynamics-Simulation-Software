// page 49
#include <fstream>
#include <stdlib.h>
#include <iostream>
#include "propertiesBox.h"
#include <time.h>

using namespace std;


int VMD_ATOM_NUMBER = 500; // Used in VMD - 
//replace here the "number of atoms" generated after one run
//or in the first line of "CheckVMD_?D.XYZ" 

int ii = 500; // number of dynamic particles

double rad = 0.005;// radius of static particles in meter
double sep = 0.01;// the seperation between two grains  ( sep >= 0.0 )


double x0 = rad; //origin in meter unit

#ifdef TwoDimensional
double y0 = rad; //origin in meter unit
#endif

#ifdef ThreeDimensional
double y0 = rad; //origin in meter unit
double z0 = rad; //origin in meter unit
#endif


double VelocityScale = 10.0; // Velocity = VelocityScale * (0.5 - RandomNumber)

double lx = x0 + (ii) * (2*rad+sep); // "+1" is for having no error;
int jj = int (lx / double(2*rad));// "+1" is for having no error;

//int jj=50;

#ifdef RandomRadius
const double Rmax = 0.006, Rmin = 0.004; // Used in random radius case for dynamic particles
#endif


long no_of_particles=0; // A counter for VMD Show
double VMDScale = double(1) / rad; // VMDScale*rad=1.0;


// Constants and coefficients of
// Young , friction, damping,
// tangential damping, density
// All in MKS units

double Young = 1e9   ,  friction = 0.5,
       damping = 0.01, tang_damp = 10.0;





double density = 1e4; // in the book it uses the 8e3 kg/m^3 density
		    // but in here, It just ignore it and uses a
		    // formula to make a mass around 1 kg
		    // I changed it to make the same mass for now
		    // Here I used the same 2D Mass formula for 1D

//--------------------------------------------------Mass Function
inline double Mass_function(double r){
#ifdef OneDimensional
  //double density=8e3;  
  return density*r*r*3.141592;
#endif

#ifdef TwoDimensional
  //double density=8e3;
  return density*r*r*3.141592;
#endif

#ifdef ThreeDimensional
  //double density=8e3;
  return density*r*r*3.141592;
#endif
}


//------------------------------------------------------------------
/*
// just to remember what was the standard input and output format
// rtd0,rtd1,rtd2,rtd3,rtd4 and _force are all of Vector Class
// Vector class in 1 dimensions: x
// Vector class in 2 dimensions: x , y , phi
// Vector class in 3 dimensions: x , y , z, phi , ??? , ???

istream & operator >> (istream & is, Sphere & p)
{
  is >> p.rtd0 >> p.rtd1
     >> p._r >> p._m >> p._ptype
     >> p.Y >> p.A >> p.mu >> p.gamma
     >> p._force
     >> p.rtd2 >> p.rtd3 >> p.rtd4;
  p._J=p._m*p._r*p._r/2;
  return is;
}
*/
//------------------------------------------------------------------

#ifdef OneDimensional
ofstream fout_XYZ("CheckVMD_1D.xyz");
#endif
#ifdef TwoDimensional
ofstream fout_XYZ("CheckVMD_2D.xyz");
#endif
#ifdef ThreeDimensional
ofstream fout_XYZ("CheckVMD_3D.xyz");
#endif


#ifdef OneDimensional
void dump_particle(ostream & os,
                   double x, double vx,
                   double radius, double mass, int type)
{ 
  no_of_particles++;
  fout_XYZ <<type +1<<"\t" << x * VMDScale <<"\t0.0\t0.0\n";

  os << x << "\t" << vx << "\t"
     << radius << "\t" << mass << "\t"<< type 
     << "\t" << Young << "\t" << damping 
     << "\t" << friction << "\t" << tang_damp
     << "\t0"
     << "\t0" << "\t0" << "\t0\n";

}
#endif


#ifdef TwoDimensional
void dump_particle(ostream & os,
                   double x, double y, double vx, double vy,
                   double radius, double mass, int type)
{ 

  no_of_particles++;
  fout_XYZ << type +1<<"\t" << x * VMDScale <<"\t"<< y * VMDScale  << "\t0.0\n";

  os << x << "\t" << y << "\t0\t" << vx << "\t" << vy << "\t0\t"
     << radius << "\t" << mass << "\t" << type 
     << "\t" << Young << "\t" << damping << "\t"
     << friction << "\t" << tang_damp
     << "\t0\t0\t0"
     << "\t0\t0\t0" << "\t0\t0\t0" << "\t0\t0\t0\n";
}
#endif


#ifdef ThreeDimensional
void dump_particle(ostream & os,
                   double x, double y, double z, double vx, double vy, double vz,
                   double radius, double mass, int type)
{ 

  no_of_particles++;
  fout_XYZ << type +1<<"\t" << x * VMDScale <<"\t"<< y * VMDScale  << "\t"<< z * VMDScale << "\n";

  os << x  << "\t" << y  << "\t" << z  << "\t"
     << vx << "\t" << vy << "\t" << vz << "\t"
     << radius << "\t" << mass << "\t" << type 
     << "\t" << Young << "\t" << damping << "\t"
     << friction << "\t" << tang_damp
     << "\t0\t0\t0"
     << "\t0\t0\t0" << "\t0\t0\t0" << "\t0\t0\t0\n";
}
#endif


//--------------------------------------------------Main Function

int main()
{

    clock_t t1,t2;
    t1=clock();
    //code goes here
//    t2=clock();
 //   float diff ((float)t2-(float)t1);
 //   cout<<diff<<endl;
 //   system ("pause");
 //   return 0;

  lx = lx+rad; //to not having errors in periodic B. C.

#ifdef OneDimensional
  ofstream fout("input_box_1D.dat");
#endif
#ifdef TwoDimensional
  ofstream fout("input_box_2D.dat");
#endif
#ifdef ThreeDimensional
  ofstream fout("input_box_3D.dat");
#endif

  fout.precision(5);
  fout_XYZ<<VMD_ATOM_NUMBER<<"\nAtom\n";

#ifdef ZeroGravity
  fout << "#gravity: 0 0 0\n";
#endif

#ifdef MKSGravity
  fout << "#gravity: 0 -9.81 0\n";
#endif

#ifdef SpecialGravity
  fout << "#gravity: -2.0 -7.0 0\n";
#endif

  fout << "#timestep: 1e-6\n"; //in seconds
  fout << "#nstep: 200000\n";
  fout << "#nprint: 1000\n";
  fout << "#nenergy: 1000\n";
  fout << "#Time: 0\n";//in seconds

  fout << "#lx: "<< lx <<"\n";//meter unit
//fout << "#lx: 1\n";//meter unit

#ifdef TwoDimensional
  fout << "#ly: "<< lx <<"\n";//meter unit
//fout << "#ly: 1\n";//meter unit
#endif

#ifdef ThreeDimensional
  fout << "#ly: "<< lx <<"\n";//meter unit
  fout << "#lz: "<< lx <<"\n";//meter unit
//fout << "#ly: 1\n";//meter unit
//fout << "#lz: 1\n";//meter unit
#endif

//------------------------Static Grains - WALLS
#ifdef OneDimensional
  double x = x0+ 0.0*rad;
  dump_particle(fout, x ,0, rad ,1,1);
#endif   

#ifdef TwoDimensional
  for(int i=0;i<jj;i++){

    double x1 = x0 + i*rad*2 , y1 = y0 + 0*rad*2 ;
    double x2 = x0 + 0*rad*2 , y2 = y0 + i*rad*2 ;
    double x3 = x0 + i*rad*2 , y3 = y0 + jj*rad*2;
    double x4 = x0 + jj*rad*2, y4 = y0 + i*rad*2 ;

    dump_particle(fout,x1, y1, 0, 0, rad, 1, 1);
    dump_particle(fout,x2, y2, 0, 0, rad, 1, 1);
    dump_particle(fout,x3, y3, 0, 0, rad, 1, 1);
    dump_particle(fout,x4, y4, 0, 0, rad, 1, 1);

  }

  double x5=x0 + jj*rad*2,y5=y0 + jj*rad*2;
  dump_particle(fout,x5, y5, 0, 0, rad, 1, 1);
#endif   

#ifdef ThreeDimensional

  for(int i=0;i<jj;i++){
    for(int j=0;j<jj;j++){
//--------------------------
      double x1 = x0 + i*rad*2 , y1 = y0 + j*rad*2, z1 = z0 + 0*rad*2    ;
      double x2 = x0 + i*rad*2 , y2 = y0 + j*rad*2, z2 = z0 + jj*rad*2 ;

      dump_particle(fout,x1, y1, z1, 0, 0, 0, rad, 1, 1);
      dump_particle(fout,x2, y2, z2, 0, 0, 0, rad, 1, 1);
//--------------------------
      double x3 = x0 + i*rad*2 , y3 = y0 + 0*rad*2   , z3 = z0 + j*rad*2 ;
      double x4 = x0 + i*rad*2 , y4 = y0 + jj*rad*2, z4 = z0 + j*rad*2 ;

      dump_particle(fout,x3, y3, z3, 0, 0, 0, rad, 1, 1);
      dump_particle(fout,x4, y4, z4, 0, 0, 0, rad, 1, 1);
//--------------------------
      double x5 = x0 + 0*rad*2    , y5 = y0 + j*rad*2, z5 = z0 + i*rad*2 ;
      double x6 = x0 + jj*rad*2 , y6 = y0 + j*rad*2, z6 = z0 + i*rad*2 ;

      dump_particle(fout,x5, y5, z5, 0, 0, 0, rad, 1, 1);
      dump_particle(fout,x6, y6, z6, 0, 0, 0, rad, 1, 1);
//--------------------------
    }

      dump_particle(fout,x0+i *rad*2, y0+jj*rad*2, z0+jj*rad*2, 0, 0, 0, rad, 1, 1);
      dump_particle(fout,x0+jj*rad*2, y0+i *rad*2, z0+jj*rad*2, 0, 0, 0, rad, 1, 1);
      dump_particle(fout,x0+jj*rad*2, y0+jj*rad*2, z0+i *rad*2, 0, 0, 0, rad, 1, 1);
  }
      dump_particle(fout,x0+jj*rad*2, y0+jj*rad*2, z0+jj*rad*2, 0, 0, 0, rad, 1, 1);
#endif   



//------------------------ Dynamic Grains - Starting 1D-----------------
  for(int i=0;i<ii-1;i++){ 

#ifdef OneDimensional
//      double x=x0+0.02*(i+1);
      double x=x0 + (i+1)*(2*rad +sep );

#ifdef ZeroVelocity
      double vx=0;
#endif

#ifdef GaussianVelocity
      double vx=VelocityScale * ( 0.5 - ( (drand48()+drand48()+drand48()+drand48()+drand48()) / (5)) );
#endif

#ifdef RandomVelocity
      double vx=VelocityScale * ( 0.5 - drand48() );
#endif

#ifdef RandomRadius

#endif

#ifdef RandomRadius
      double z=drand48();
      double rad2=Rmin*Rmax/(Rmax-z*(Rmax-Rmin)); // Z=0 :r=Rmin ; Z=1 :r=Rmax
      double Mass=density*rad2*rad2*3.141592;
#else
      double rad2=rad;
      double Mass=density*rad2*rad2*3.141592;
#endif

      dump_particle ( fout, x, vx , rad2 , Mass, 0); 
#endif



//------------------------ Dynamic Grains - Starting 2D-----------------
#ifdef TwoDimensional
      for(int k=0;k<ii-1;k++){ 
        double x = x0 + (i+1)*(2*rad + sep);
        double y = y0 + (k+1)*(2*rad + sep);

#ifdef ZeroVelocity
	double vx=0;
        double vy=0;
#endif

#ifdef GaussianVelocity
        double vx=VelocityScale * ( 0.5 - ( (drand48()+drand48()+drand48()+drand48()+drand48()) / (5)) );
        double vy=VelocityScale * ( 0.5 - ( (drand48()+drand48()+drand48()+drand48()+drand48()) / (5)) );
#endif

#ifdef RandomVelocity
        double vx=VelocityScale * ( 0.5 - drand48() );
        double vy=VelocityScale * ( 0.5 - drand48() );
#endif

#ifdef RandomRadius
        double z=drand48();
        double rad2=Rmin*Rmax/(Rmax-z*(Rmax-Rmin)); // Z=0 :r=Rmin ; Z=1 :r=Rmax
#else
        double rad2=rad;
#endif
        double Mass=Mass_function(rad2);
        dump_particle ( fout, x, y, vx , vy ,rad2 , Mass, 0); 
    }
#endif

//------------------------ Dynamic Grains - Starting 3D-----------------
#ifdef ThreeDimensional
      for(int k=0;k<ii-1;k++){ 
        for(int l=0;l<ii-1;l++){ 
          double x = x0 + (i+1)*(2*rad + sep);
          double y = y0 + (k+1)*(2*rad + sep);
          double z = z0 + (l+1)*(2*rad + sep);

#ifdef ZeroVelocity
	  double vx=0;
          double vy=0;
          double vz=0;
#endif

#ifdef GaussianVelocity
          double vx=VelocityScale * ( 0.5 - ( (drand48()+drand48()+drand48()+drand48()+drand48()) / (5)) );
          double vy=VelocityScale * ( 0.5 - ( (drand48()+drand48()+drand48()+drand48()+drand48()) / (5)) );
          double vz=VelocityScale * ( 0.5 - ( (drand48()+drand48()+drand48()+drand48()+drand48()) / (5)) );
#endif

#ifdef RandomVelocity
          double vx=VelocityScale * ( 0.5 - drand48() );
          double vy=VelocityScale * ( 0.5 - drand48() );
          double vz=VelocityScale * ( 0.5 - drand48() );
#endif

#ifdef RandomRadius
          double z=drand48();
          double rad2=Rmin*Rmax/(Rmax-z*(Rmax-Rmin)); // Z=0 :r=Rmin ; Z=1 :r=Rmax
#else
          double rad2=rad;
#endif
          double Mass=Mass_function(rad2);
          dump_particle ( fout, x, y, z, vx , vy, vz, rad2 , Mass, 0); 
	}
    }
#endif




  }


#ifdef OneDimensional
  x = x0 + (ii) * (2*rad + sep) ;
  dump_particle ( fout, x, 0, rad, 1, 1);
#endif


  cout<<"Number of Atoms: "<<no_of_particles<<" \n";

  t2=clock();
  float diff ((float)t2-(float)t1);
  cout<<"execution time :" << diff / CLOCKS_PER_SEC <<" seconds" <<endl;

  return 0;
}



