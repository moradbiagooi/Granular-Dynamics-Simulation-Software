#ifndef _propertiesBox_h
#define _propertiesBox_h


//=================================== Dimensions
//check the density in different dimensions


#define OneDimensional	//(1)
//#define TwoDimensional	//(2)
//#define ThreeDimensional	//(3)


//=================================== Initial Velocities

#define GaussianVelocity	//(1)
//#define RandomVelocity	//(2)
//#define ZeroVelocity		//(3)


//=================================== Gravity

//#define MKSGravity		//(1)
//#define SpecialGravity	//(2)
#define ZeroGravity		//(3)


//=================================== Radius of moving particles

//#define RandomRadius 		//ON or OFF

//===================================

#endif
