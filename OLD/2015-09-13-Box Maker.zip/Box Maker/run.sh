#reset
g++ -o box_maker.out box_maker.cc
./box_maker.out
#vmd CheckVMD.xyz
