g++ -o hopper_maker.out init_my_hopper.cc
./hopper_maker.out
