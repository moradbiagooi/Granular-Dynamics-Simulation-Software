//page 39
#ifndef _Particle_h
#define _Particle_h

#include <iostream>
#include "Vector.h"
#include "properties.h"

using namespace std;



inline double normalize2(double dx, double L)
{
  while(dx<-L/2) dx+=L;
  while(dx>=L/2) dx-=L;
  return dx;
}

class Sheath;

class Particle {

  

#ifdef OneDimensional
  friend double Distance(const Particle & p1, const Particle & p2, double lx){
    double dx=normalize2(p1.rtd0.x()-p2.rtd0.x(),lx);
    return sqrt(dx*dx);
  }

  friend void force3(Sheath & p1, Particle & p2, double lx);
#endif

#ifdef TwoDimensional
  friend double Distance(const Particle & p1, const Particle & p2, double lx, double ly){
    double dx=normalize2(p1.rtd0.x()-p2.rtd0.x(),lx);
    double dy=normalize2(p1.rtd0.y()-p2.rtd0.y(),ly);
    return sqrt(dx*dx+dy*dy);
  }

  friend void force3(Sheath & p1, Particle & p2, double lx, double ly);
#endif

#ifdef ThreeDimensional
  friend double Distance(const Particle & p1, const Particle & p2, double lx, double ly, double lz){
    double dx=normalize2(p1.rtd0.x()-p2.rtd0.x(),lx);
    double dy=normalize2(p1.rtd0.y()-p2.rtd0.y(),ly);
    double dz=normalize2(p1.rtd0.z()-p2.rtd0.z(),lz);
    return sqrt(dx*dx+dy*dy+dz*dz);
  }

  friend void force3(Sheath & p1, Particle & p2, double lx, double ly, double lz);
#endif

public:
  Particle(): rtd0(null), rtd1(null), rtd2(null), rtd3(null), rtd4(null)
  {}

#ifdef OneDimensional
  Particle ( double xx, double vxx) {

    rtd0.x()=xx;
    rtd1.x()=vxx;

  } 
#endif

#ifdef TwoDimensional
  Particle ( double xx, double yy, double vxx, double vyy) {

    rtd0.x()=xx;
    rtd0.y()=yy;
    rtd0.phi()=0.0;

    rtd1.x()=vxx;
    rtd1.y()=vyy;
    rtd1.phi()=0.0;

  } 
#endif

#ifdef ThreeDimensional
  Particle ( double xx, double yy, double zz, double vxx, double vyy, double vzz) {

    rtd0.x()=xx;
    rtd0.y()=yy;
    rtd0.z()=zz;

    rtd1.x()=vxx;
    rtd1.y()=vyy;
    rtd1.z()=vzz;

  } 
#endif



  Vector & pos() {return rtd0;}
  Vector pos() const {return rtd0;}

  double & x() {return rtd0.x();}
  double x() const {return rtd0.x();}
  double & vx() {return rtd1.x();}
  double vx() const {return rtd1.x();}
  double & fx() {return _force.x();}
  double fx() const {return _force.x();}

#ifdef TwoDimensional
  double & y() {return rtd0.y();}
  double y() const {return rtd0.y();}
  double & vy() {return rtd1.y();}
  double vy() const {return rtd1.y();}

  double & phi() {return rtd0.phi();}
  double phi() const {return rtd0.phi();}
  double & omega() {return rtd1.phi();}
  double omega() const {return rtd1.phi();}

  double & fy() {return _force.y();}
  double fy() const {return _force.y();}
#endif

#ifdef ThreeDimensional
  double & y() {return rtd0.y();}
  double y() const {return rtd0.y();}
  double & vy() {return rtd1.y();}
  double vy() const {return rtd1.y();}

  double & z() {return rtd0.z();}
  double z() const {return rtd0.z();}
  double & vz() {return rtd1.z();}
  double vz() const {return rtd1.z();}

  double & fy() {return _force.y();}
  double fy() const {return _force.y();}
  double & fz() {return _force.z();}
  double fz() const {return _force.z();}
#endif

  const Vector & velocity() const {return rtd1;}
  double & r() {return _r;}
  double r() const {return _r;}
  double m() const {return _m;}
  double & m() {return _m;}

  double & Y() {return _Y;}
  double Y () const {return _Y;}

  double & A() {return _A;}
  double A() const {return _A;}

  double & mu() {return _mu;}
  double mu() const {return _mu;}



  int ptype() const {return _ptype;}//Returns the type of the Sheath. Sheaths of type 0 are subject to Newton’s equationof motion, Sheaths of other types belong to walls.
  void predict(double dt);//First step of the Gear algorithm
  void add_force(const Vector & f){_force+=f;} //Adds a value to the total force _force of the Sheath
  void correct(double dt);//Second step of the Gear algorithm
  double kinetic_energy() const;//Computes the kinetic energy of the Sheath
  void set_force_to_zero(){_force=null;}

#ifdef OneDimensional
  void periodic_bc(double x_0, double lx);//Enforces the periodic boundary conditions
#endif

#ifdef TwoDimensional
  void periodic_bc(double x_0, double y_0, double lx, double ly);//Enforces the periodic boundary conditions
#endif

#ifdef ThreeDimensional
  void periodic_bc(double x_0, double y_0, double z_0, double lx, double ly, double lz);//Enforces the periodic boundary conditions
#endif


private:

  double _r, _m, _J;
  int _ptype;
  double _Y,_A,_mu,gamma;
  Vector rtd0,rtd1,rtd2,rtd3,rtd4;
  Vector _force;
};

#endif
