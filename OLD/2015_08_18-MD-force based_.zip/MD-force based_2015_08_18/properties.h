#ifndef _properties_h
#define _properties_h
/*-------------------------------------------------------------------
Here we can choose between different alternatives, It means  one and 
only one of the numbers should be active.
In the other case, have to turn something //ON or OFF//
-------------------------------------------------------------------*/
//=============================== Dimensions
// used in "force3.h", "sphere.h","sphere2.h","sphere.cc","sphere2.cc",
// "Vector.h", "common.h", "common.cc"

#define OneDimensional    //(1) 
//#define TwoDimensional    //(2)
//#define ThreeDimensional    //(3)

//=============================== Forces in 1Dimensions
// used in simple.cc

#define OneDimLinForce    // ON or OFF linear force in OneDimensional Case
                          // Two wall concept should be the case
//=============================== Inner Forces correction
// used in force3.h

#define NoAdhesiveForce   // ON or OFF
                          // means force = max [0 , f(xi)]

//=============================== Forces type
// used in Sheath.cc

#define HookeanForce    //(1)
//#define HertzianForce    //(2)


//=============================== Gravity works on the inner Sheaths 
// used in "Sheath.cc"

//#define InnerGravityForce //ON or OFF// 


//=============================== Inner Sheaths available
// used in "common.cc","Sheath.cc","Sheath.h","simple.cc"

#define ParticlesExist //ON or OFF//
//===============================  output: xyz format
//used in "common.cc"

//#define XYZOutputMaker    //ON or OFF
//===============================  output X(t) format
//used in "common.cc"
#define XTOutputMaker

#endif
