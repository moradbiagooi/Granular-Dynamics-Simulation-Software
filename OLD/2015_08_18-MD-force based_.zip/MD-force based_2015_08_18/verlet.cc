//page 
#include "common.h"
#include "Sheath.h" /* <===== replace this line if necessary */
#include "Particle.h"
#include "properties.h"

extern vector<Particle> Particles;
extern vector<Sheath> Sheaths; /* <===== replace this line if necessary */
//------
vector<Sheath> safe; 
double Timesafe; /* <===== replace this line if necessary */
// this 'safe' & 'Timesafe' serve as a backup for 'Sheath' and 'Time' in the rare case that the Verlet list become incorrect
//------

double verlet_ratio = 0.6, verlet_distance = 0.00025, verlet_grid = 0.05;
double verlet_increase = 1.1;
// for the performance of the algorithm
// verlet_ratio of 1.0 is very strict, no collision is missed and not really neccesary by what is written in p67
//---

int vnx;
double dx;

#ifdef OneDimensional//?????????????????????????????
//vector<vector<vector<int> > > celllist;
vector<vector<int> >  celllist;
#endif

#ifdef TwoDimensional
int vny;
double dy;

vector<vector<vector<int> > > celllist;

#endif

#ifdef ThreeDimensional
int vny,vnz;
double dy,dz;

vector<vector<vector<vector<int> > > > celllist;

#endif


vector<set<int> > verlet; // verlet list: only nearby Sheaths

bool verlet_needs_update();
bool make_verlet();
bool do_touch(int i, int k);

// part ========================================================
// part ========================================================
void make_forces() //specific for Verlet - calculate force only for verlet list of the Sheaths
{

  for(unsigned int i=0;i<Sheaths.size();i++){

#ifdef OneDimensional

#ifdef ParticlesExist
    force3(Sheaths[i], Particles[i], lx); // between inner and outer Sheaths
#endif

    set<int>::iterator iter;
    for(iter=verlet[i].begin();iter!=verlet[i].end();iter++){
      force(Sheaths[i],Sheaths[*iter], lx);
    }

#endif



#ifdef TwoDimensional

#ifdef ParticlesExist
    force3(Sheaths[i], Particles[i], lx, ly); // between inner and outer Sheaths
#endif

    set<int>::iterator iter;
    for(iter=verlet[i].begin();iter!=verlet[i].end();iter++){
      force(Sheaths[i],Sheaths[*iter], lx, ly);
    }

#endif


#ifdef ThreeDimensional

#ifdef ParticlesExist
    force3(Sheaths[i], Particles[i], lx, ly, lz); // between inner and outer Sheaths
#endif

    set<int>::iterator iter;
    for(iter=verlet[i].begin();iter!=verlet[i].end();iter++){
      force(Sheaths[i],Sheaths[*iter], lx, ly, lz);
    }

#endif
  }

}


// part ========================================================
// part ========================================================



// part ========================================================
// part ========================================================


bool make_verlet()
{

  bool ok=true;


//grid cells 'celllist', with the size dx*dy list consisted of Sheaths residing in them.


  verlet.resize(no_of_Sheaths); // current lists are discarded; these lists have been constructed in the preceding call of make_verlet()
  for(int ix=0;ix<vnx;ix++){ 
#ifdef OneDimensional
    celllist[ix].clear();
#endif
#ifdef TwoDimensional
    for(int iy=0;iy<vny;iy++){
      celllist[ix][iy].clear();
    }
#endif
#ifdef ThreeDimensional
    for(int iy=0;iy<vny;iy++){
      for(int iz=0;iz<vnz;iz++){
        celllist[ix][iy][iz].clear();
      }
    }
#endif
  }

//cout<<"dx:"<<dx<<" dy:"<<dy<<"\n\n";

  for(unsigned int i=0;i<no_of_Sheaths;i++){ //Sheaths are sorted in the grids
    int ix=int((Sheaths[i].x()-x_0)/dx);

#ifdef OneDimensional
    celllist[ix].push_back(i);// 
#endif

#ifdef TwoDimensional
    int iy=int((Sheaths[i].y()-y_0)/dy);
    celllist[ix][iy].push_back(i);// 
#endif

#ifdef ThreeDimensional
    int iy=int((Sheaths[i].y()-y_0)/dy);
    int iz=int((Sheaths[i].z()-z_0)/dz);
    celllist[ix][iy][iz].push_back(i);// 
#endif

  }
// /*
  for(unsigned int i=0;i<no_of_Sheaths;i++){

    set<int> oldverlet=verlet[i]; // copying old list
    verlet[i].clear();// clearing the list

    int ix=int((Sheaths[i].x()-x_0)/dx);// selecting the grid of Sheath[i]
#ifdef TwoDimensional
    int iy=int((Sheaths[i].y()-y_0)/dy);//  //  //  //
#endif

#ifdef ThreeDimensional
    int iy=int((Sheaths[i].y()-y_0)/dy);//  //  //  //
    int iz=int((Sheaths[i].z()-z_0)/dz);//  //  //  //
#endif


    for(int iix=ix-1;iix<=ix+1;iix++){ // adjacant cells of (ix,iy) cell
#ifdef TwoDimensional
      for(int iiy=iy-1;iiy<=iy+1;iiy++){ // adjacant cells 
#endif

#ifdef ThreeDimensional
      for(int iiy=iy-1;iiy<=iy+1;iiy++){ // adjacant cells 
      for(int iiz=iz-1;iiz<=iz+1;iiz++){ // adjacant cells 
#endif

        int wx = (iix+vnx)%vnx;
#ifdef TwoDimensional
        int wy = (iiy+vny)%vny;
#endif

#ifdef ThreeDimensional
        int wy = (iiy+vny)%vny;
        int wz = (iiz+vnz)%vnz;
#endif


#ifdef OneDimensional
        for(unsigned int k=0;k<celllist[wx].size();k++){

          int pk=celllist[wx][k];

          if(pk<(int)i){ 
            if(Distance(Sheaths[i],Sheaths[pk], lx)<
              Sheaths[i].r()+Sheaths[pk].r()+verlet_distance){

#endif


#ifdef TwoDimensional
        for(unsigned int k=0;k<celllist[wx][wy].size();k++){

          int pk=celllist[wx][wy][k];

          if(pk<(int)i){ 
            if(Distance(Sheaths[i],Sheaths[pk], lx, ly)<
              Sheaths[i].r()+Sheaths[pk].r()+verlet_distance){
#endif

#ifdef ThreeDimensional
        for(unsigned int k=0;k<celllist[wx][wy][wz].size();k++){

          int pk=celllist[wx][wy][wz][k];

          if(pk<(int)i){ 
            if(Distance(Sheaths[i],Sheaths[pk], lx, ly, lz)<
              Sheaths[i].r()+Sheaths[pk].r()+verlet_distance){
#endif

              if((Sheaths[i].ptype()==0) || (Sheaths[pk].ptype()==0)){
                verlet[i].insert(pk);

                if(oldverlet.find(pk)==oldverlet.end()){//if it doesn't existed in the old verlet list,.... 
                  if(do_touch(i,pk)) { // and if they tuch now, it means there was a big gap between this two steps. this is error
                    ok=false;
                  }
                }
              }
            }
          }
#ifdef TwoDimensional
        }
#endif

#ifdef ThreeDimensional
        }
        }
#endif

      }
    }  
  } 
//  */
  return ok;
}

//part 
bool do_touch(int i, int k)
{

// part ========================================================

#ifdef OneDimensional
return (Distance(Sheaths[i],Sheaths[k],lx)
        <Sheaths[i].r()+Sheaths[k].r());
#endif

#ifdef TwoDimensional
return (Distance(Sheaths[i],Sheaths[k],lx,ly)
        <Sheaths[i].r()+Sheaths[k].r());
#endif

#ifdef ThreeDimensional
return (Distance(Sheaths[i],Sheaths[k],lx,ly,lz)
        <Sheaths[i].r()+Sheaths[k].r());
#endif
}

// part ========================================================

bool verlet_needs_update()
{
  for(unsigned int i=0;i<no_of_Sheaths;i++){

#ifdef OneDimensional
    if(Distance(Sheaths[i],safe[i],lx)>= verlet_ratio*verlet_distance){
      return true;
    }
#endif

#ifdef TwoDimensional
    if(Distance(Sheaths[i],safe[i],lx,ly)>= verlet_ratio*verlet_distance){
      return true;
    }
#endif

#ifdef ThreeDimensional
    if(Distance(Sheaths[i],safe[i],lx,ly,lz)>= verlet_ratio*verlet_distance){
      return true;
    }
#endif

  }
  return false;
}

//part ========================================================

void step()
{

//cout<<"whoo \n";
  bool ok=true, newverlet=false;


  if(verlet_needs_update()){
    ok = make_verlet();
    newverlet=true;
  }

  if(!ok){
    cerr << "fail: going back from " << Time << " to " << Timesafe << endl;
    Sheaths=safe;
    Time=Timesafe;
    verlet_distance*=verlet_increase;
    make_verlet();
  }

  if(newverlet && ok){
    safe=Sheaths;
    Timesafe=Time;
  }
 /*
*/
  integrate();

}

//part ========================================================

void init_algorithm()
{
 
  safe=Sheaths;
  Timesafe=Time;

  vnx=int(lx/verlet_grid);
  if(vnx==0) vnx=1;
  dx=lx/vnx;
  celllist.resize(vnx);


#ifdef TwoDimensional
  vny=int(ly/verlet_grid);
  if(vny==0) vny=1;
  dy=ly/vny;
  for(int i=0;i<vnx;i++) celllist[i].resize(vny);
#endif

#ifdef ThreeDimensional
  vny=int(ly/verlet_grid);
  vnz=int(lz/verlet_grid);
 
  if(vny==0) vny=1;
  dy=ly/vny;

  if(vnz==0) vnz=1;
  dz=lz/vnz;

// for(int i=0;i<vnx;i++) celllist[i].resize(vny);
  

 for(int i=0;i<vnx;i++){
    celllist[i].resize(vny);
    for(int j=0;j<vnx;j++){
      celllist[i][j].resize(vnz);
    }
  }

/* 
 for(int i=0;i<vnx;i++){
    for(int j=0;j<vnx;j++){
      celllist[i][j].resize(vnz);
    }
  }
*/

#endif


 
 make_verlet();

}
