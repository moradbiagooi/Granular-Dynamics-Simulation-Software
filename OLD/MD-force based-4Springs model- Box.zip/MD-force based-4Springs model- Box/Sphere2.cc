//part 1 page 41

#include "Sphere2.h"
#include <assert.h>

extern Vector G;


void Sphere2::predict(double dt)
{
  double a1=dt;
  double a2=a1*dt/2;
  double a3=a2*dt/3;
  double a4=a3*dt/4;
//cout<<rtd0<<"&";
  rtd0+=a1*rtd1 + a2*rtd2 + a3*rtd3 + a4*rtd4;
  rtd1+=a1*rtd2 + a2*rtd3 + a3*rtd4;
  rtd2+=a1*rtd3 + a2*rtd4;
  rtd3+=a1*rtd4;
}


void Sphere2::correct(double dt)
{
  static Vector accel,corr;
  double dtrez = 1/dt;
  const double coeff0=double(19)/double(90)*(dt*dt/double(2));
  const double coeff1=double(3)/double(4)*(dt/double(2));
  const double coeff3=double(1)/double(2)*(double(3)*dtrez);
  const double coeff4=double(1)/double(12)*(double(12)*(dtrez*dtrez));
/*
  accel=Vector((1/_m)*_force.x()+G.x(),
    (1/_m)*_force.y()+G.y(),
    (1/_J)*_force.phi()+G.phi());
*/
_m=0.1;
// no Gravity on the inner particles

  accel=Vector((1/_m)*_force.x(),
    (1/_m)*_force.y(),
    (1/_J)*_force.phi());

  corr=accel-rtd2;

  rtd0 += coeff0*corr;
  rtd1 += coeff1*corr;
  rtd2 = accel;
  rtd3 += coeff3*corr;
  rtd4 += coeff4*corr;
}


// part 2 page 41
void force2(Sphere2 & p2, double x1, double y1, double rad1, double lx, double ly) // Sphere friend
{

  double d=rad1;
  Vector r1(d,0.,0.),r2(0.,d,0.),r3(-d,0.,0.),r4(0.,-d,0.); //springs position

  double kk=100000.01; // spring constant

  double dx=normalize2(x1-p2.x(),lx);// X_1 - X_2
  double dy=normalize2(y1-p2.y(),ly);// Y_1 -Y_2

  Vector r(-dx,-dy,0.); // inner particle position relative to outer particle cm

  Vector f1(r-r1),f2(r-r2),f3(r-r3),f4(r-r4); // spring forces acting on the inner particle

  double nnn=norm2d(r-r1);  f1*=kk*(nnn-d)/nnn; // Hookian force

  nnn=norm2d(r-r2);  f2*=kk*(nnn-d)/nnn;

  nnn=norm2d(r-r3);  f3*=kk*(nnn-d)/nnn;

  nnn=norm2d(r-r4);  f4*=kk*(nnn-d)/nnn;

  Vector f_tot(-1*(f1+f2+f3+f4));

  p2.set_force_to_zero();
  p2.add_force(f_tot);

//  if(p1.ptype()==0) 
//    p1.add_force(Vector(fn*ex-ft*ey, fn*ey+ft*ex, r1*ft));

//    p2.add_force(Vector(-fn*ex+ft*ey, -fn*ey-ft*ex, -r2*ft));

  
}


// part 3 page 43
/*
void Sphere2::boundary_conditions(int n, double timestep, double Time)
{
  switch(ptype()){
  case(0): break;
  case(1): break;
  case(2): {
    x()=0.5-0.4*cos(10*Time);
    y()=0.1;
    vx()=10*0.4*sin(Time);
    vy()=0;
  } break;
  case(3): {
    double xx=x()-0.5;
    double yy=y()-0.5;
    double xp=xx*cos(timestep)-yy*sin(timestep);
    double yp=xx*sin(timestep)+yy*cos(timestep);
    x()=0.5+xp;
    y()=0.5+yp;
    vx()=-yp;
    vy()= xp;
    omega()=1;
  } break;
  case(4): {
    x()=0.5+0.1*cos(Time) + 0.4*cos(Time+2*n*M_PI/128);
    y()=0.5+0.1*sin(Time) + 0.4*sin(Time+2*n*M_PI/128);
    vx()=-0.1*sin(Time) - 0.4*sin(Time+2*n*M_PI/128);
    vy()= 0.1*cos(Time) - 0.4*cos(Time+2*n*M_PI/128);
    omega()=1;
  } break;
  case(5): {
    y()=0.1+0.02*sin(30*Time);
    vx()=0;
    vy()=0.02*30*cos(30*Time);
  } break;
  case(6): {
    int i=n/2;
    y()=i*0.02+0.1+0.02*sin(30*Time);
    vx()=0;
    vy()=0.02*30*cos(30*Time);
  } break;
  default: {
    cerr << "ptype: " << ptype() << " not implemented\n";
    //abort();  // what's this
    }
  }
}
*/

//part  4 page 44
// THIS WHOULD BE FUNNY IF SOME PARTICLE GO FROM ONE SIDE TO ANOTHER
/*
void Sphere::periodic_bc(double x_0, double y_0, double lx, double ly)
{
  while(rtd0.x()<x_0) rtd0.x()+=lx;
  while(rtd0.x()>x_0+lx) rtd0.x()-=lx;
  while(rtd0.y()<y_0) rtd0.y()+=ly;
  while(rtd0.y()>y_0+ly) rtd0.y()-=ly;
}
*/

//part  5 page 45
double Sphere2::kinetic_energy() const
{
  return _m*(rtd1.x()*rtd1.x()/2 + rtd1.y()*rtd1.y()/2)
    + _J*rtd1.phi()*rtd1.phi()/2;
}


//part  6 page 45
/*
istream & operator >> (istream & is, Sphere2 & p)
{
  is >> p.rtd0 >> p.rtd1
     >> p._r >> p._m >> p._ptype
     >> p.Y >> p.A >> p.mu >> p.gamma
     >> p._force
     >> p.rtd2 >> p.rtd3 >> p.rtd4;
  p._J=p._m*p._r*p._r/2;
  return is;
}
*/

//part  7 page 45
/*
ostream & operator << (ostream & os, const Sphere2 & p)
{
  os << p.rtd0 << " " << p.rtd1 << " ";
  os << p._r << " " << p._m << " " << p._ptype << " ";
  os << p.Y << " " << p.A << " " << p.mu << " " << p.gamma << " ";
  os << p._force << " ";
  os << p.rtd2 << " " << p.rtd3 << " " << p.rtd4 << "\n" << flush;
  return os;
}
*/
//part  page

