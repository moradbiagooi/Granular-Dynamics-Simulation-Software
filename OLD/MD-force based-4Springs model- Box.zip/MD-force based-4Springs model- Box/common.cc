//page 34
#include <stdlib.h>
#include "common.h"
#include "Sphere.h"   /*replace this line if necessary*/
#include "Sphere2.h"

using namespace std;

double Time=0, timestep;
int nstep, nprint, nenergy;
Vector G;
double lx, ly, x_0, y_0;// in the init_hopper.cc there was no lx and ly value, so the code got stuck in normalize function

// vector ?Vector //
vector< Sphere > particle;   /*replace this line if necessary*/
vector< Sphere2 > particle2;

//is it from <vector.h> instead of "Vector.h" 

unsigned int no_of_particles;

ofstream fphase("phase.dat"), flast("lastframe.dat"),fenergy("energy.dat");
ofstream xyzfile("output.xyz");
ofstream xyzfile2("output2.xyz");

void init_system(char * fname);
double total_kinetic_energy();

//part 2 page 35
int main (int argc, char ** argv)
{
  if (argc!=2){
    cerr << "usage: " << argv[0] << " particle_initfile\n";
    exit(0);
      return 0; // my idea
  }
  fenergy.precision(10);
  init_system(argv[1]);
  init_inner_particles();
  init_algorithm();
  phase_plot(fphase);
  for (int i=0;i<nstep;i++){
//  cout<<" i="<<i;
    step();
    if ((i+1)%nprint==0){
      cout << "phase_plot: " << i+1 << "  " << particle.size() << " particles\n";
      phase_plot(fphase);
    }
    if ((i+1)%nenergy==0){
      fenergy << Time << "\t" << total_kinetic_energy() << endl;
    }
  }
  phase_plot(flast);
}

//part 3 page 37
void integrate()
{
//cout<<" ";
  for(unsigned int i=0;i<particle.size();i++){
    if(particle[i].ptype()==0) {
      particle[i].set_force_to_zero();
      particle[i].predict(timestep);

      particle2[i].predict(timestep); //===========

    } else {
      particle[i].boundary_conditions(i,timestep,Time);
    }
  }

  make_forces();
  
  for(unsigned int i=0;i<particle.size();i++){
    if(particle[i].ptype()==0) {

      particle[i].correct(timestep);

      particle2[i].correct(timestep);//===========
    }
  }

  for(unsigned int i=0;i<particle.size();i++){
    particle[i].periodic_bc(x_0, y_0, lx, ly);
  }
  Time+=timestep;
}

//part  page 46
void init_system(char * fname)
{
  ifstream fparticle(fname);
  while(fparticle.peek()=='#'){
    string type;
    fparticle >> type;
    if(type=="#gravity:"){
      fparticle >> G.x() >> G.y() >> G.phi();
      fparticle.ignore(100,'\n');
      cout << "gravity: " << G << endl;
    } else if(type=="#Time:"){
      fparticle >> Time;
      fparticle.ignore(100,'\n');
      cout << "Time: " << Time << endl;
    } else if(type=="#nstep:"){
      fparticle >> nstep;
      fparticle.ignore(100,'\n');
      cout << "nstep: " << nstep << endl;
    } else if(type=="#timestep:"){
      fparticle >> timestep;
      fparticle.ignore(100,'\n');
      cout << "timestep: " << timestep << endl;
    } else if(type=="#nprint:"){
      fparticle >> nprint;
      fparticle.ignore(100,'\n');
      cout << "nprint: " << nprint << endl;
    } else if(type=="#nenergy:"){
      fparticle >> nenergy;
      fparticle.ignore(100,'\n');
      cout << "nenergy: " << nenergy << endl;
    } else if(type=="#lx:"){
      fparticle >> lx;
      fparticle.ignore(100,'\n');
      cout << "lx: " << lx << endl;
    } else if(type=="#ly:"){
      fparticle >> ly;
      fparticle.ignore(100,'\n');
      cout << "ly: " << ly << endl;
    } else if(type=="#x_0:"){
      fparticle >> x_0;
      fparticle.ignore(100,'\n');
      cout << "x_0: " << x_0 << endl;
    } else if(type=="#y_0:"){
      fparticle >> y_0;
      fparticle.ignore(100,'\n');
      cout << "y_0: " << y_0 << endl;
    } else {
      cerr << "init: unknown global property: " << type << endl;
//      abort(); what's this
    }
  }
  while(fparticle){
    Sphere pp;
    fparticle >> pp;
    if(fparticle){
      particle.push_back(pp);
    }
  }
  no_of_particles=particle.size();
  cout << no_of_particles << " particles read\n" << flush;
}

//=================================================
void init_inner_particles(){
//int size_i=particle.size();

  for (unsigned int i=0;i<particle.size();i++){

    Sphere2 pp2(particle[i].x(),particle[i].y(),particle[i].vx(),particle[i].vy());
    particle2.push_back(pp2);
//    particle2[i].m()=particle[i].m()/2.0; ///???

  }
}

//=================================================



//part   page 47
double total_kinetic_energy()
{
  double sum=0;
  for(unsigned int i=0;i<particle.size();i++){
    if(particle[i].ptype()==0){
      sum+=particle[i].kinetic_energy();
    }
  }
  return sum;
}
//part  page 48
void phase_plot(ostream & os)
{
  os << "#NewFrame\n";
  os << "#no_of_particles: " << no_of_particles << endl;
  os << "#compressed: no\n";
  os << "#type: SphereXYPhiVxVyOmegaRMFixed25\n";
  os << "#gravity: " << G.x() << " " << G.y() << " " << G.phi() << endl;
  os << "#Time: " << Time << endl;
  os << "#timestep: " << timestep << endl;
  os << "#EndOfHeader\n";

 xyzfile<<"130\nAtom\n";
 xyzfile2<<"179\nAtom\n";
  for(unsigned int i=0;i<particle.size();i++){
    os << particle[i];
//    xyzfile << particle[i].rtd0();
    xyzfile  <<particle[i].ptype()+1 <<"\t"<<200*particle[i].x() <<"\t"<<200*particle[i].y() <<"\t0.0\n";

    xyzfile2 <<particle[i].ptype()+1 <<"\t"<<200*particle[i].x() <<"\t"<<200*particle[i].y() <<"\t0.0\n";
if (particle[i].ptype()!=1) 
   xyzfile2 << 3                    <<"\t"<<200*particle2[i].x()<<"\t"<<200*particle2[i].y()<<"\t0.0\n";

  }
  os << flush;
 //cout<<"\n this is the end \n";
}
