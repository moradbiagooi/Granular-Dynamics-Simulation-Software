g++ -o verlet_box.out common.cc Sphere.cc Sphere2.cc verlet.cc
./verlet_box.out input_box.dat
vmd output2.xyz
