//page 
#include "common.h"
#include "Sphere.h" /* <===== replace this line if necessary */
#include "Sphere2.h"

extern vector<Sphere2> particle2;
extern vector<Sphere> particle; /* <===== replace this line if necessary */
//------
vector<Sphere> safe; 
double Timesafe; /* <===== replace this line if necessary */
// this 'safe' & 'Timesafe' serve as a backup for 'particle' and 'Time' in the rare case that the Verlet list become incorrect
//------

double verlet_ratio = 0.6, verlet_distance = 0.00025, verlet_grid = 0.05;
double verlet_increase = 1.1;
// for the performance of the algorithm
// verlet_ratio of 1.0 is very strict, no collision is missed and not really neccesary by what is written in p67
//---

int vnx,vny;//??
double dx,dy;
vector<vector<vector<int> > > celllist;
vector<set<int> > verlet; // verlet list: only nearby particles

bool verlet_needs_update();
bool make_verlet();
bool do_touch(int i, int k);

//part

void make_forces() //specific for Verlet - calculate force only for verlet list of the particles
{

  for(unsigned int i=0;i<particle.size();i++){

//======== inseting spring force
  force2(particle2[i], particle[i].x(), particle[i].y()
        ,particle[i].r(), lx, ly);

  particle[i].add_force ( Vector (-particle2[i].fx(),
  				-particle2[i].fy(),0.0 ) );
//========

    set<int>::iterator iter;
    for(iter=verlet[i].begin();iter!=verlet[i].end();iter++){
      force(particle[i],particle[*iter], lx, ly);
    }
  }

}

//part 


bool make_verlet()
{

  bool ok=true;


//grid cells 'celllist', with the size dx*dy list consisted of particles residing in them.


  verlet.resize(no_of_particles); // current lists are discarded; these lists have been constructed in the preceding call of make_verlet()
  for(int ix=0;ix<vnx;ix++){ 
    for(int iy=0;iy<vny;iy++){
      celllist[ix][iy].clear();
    }
  }

//cout<<"dx:"<<dx<<" dy:"<<dy<<"\n\n";

  for(unsigned int i=0;i<no_of_particles;i++){ //particles are sorted in the grids
    int ix=int((particle[i].x()-x_0)/dx);
    int iy=int((particle[i].y()-y_0)/dy);

    celllist[ix][iy].push_back(i);// it crashes for small 'lx' and 'ly' in the input files
  }
// /*
  for(unsigned int i=0;i<no_of_particles;i++){

    set<int> oldverlet=verlet[i]; // copying old list
    verlet[i].clear();// clearing the list

    int ix=int((particle[i].x()-x_0)/dx);// selecting the grid of particle[i]
    int iy=int((particle[i].y()-y_0)/dy);//  //  //  //


    for(int iix=ix-1;iix<=ix+1;iix++){ // adjacant cells of (ix,iy) cell
      for(int iiy=iy-1;iiy<=iy+1;iiy++){ // adjacant cells 

        int wx = (iix+vnx)%vnx;//wut?
        int wy = (iiy+vny)%vny;//?
//      cout<<"wx & iix"<< wx<<" "<< iix<<endl;

        for(unsigned int k=0;k<celllist[wx][wy].size();k++){

          int pk=celllist[wx][wy][k];

          if(pk<(int)i){ // wut ????????
            if(Distance(particle[i],particle[pk], lx, ly)<
              particle[i].r()+particle[pk].r()+verlet_distance){

              if((particle[i].ptype()==0) || (particle[pk].ptype()==0)){
                verlet[i].insert(pk);

                if(oldverlet.find(pk)==oldverlet.end()){//if it doesn't existed in the old verlet list,.... 
                  if(do_touch(i,pk)) { // and if they tuch now, it means there was a big gap between this two steps. this is error
                    ok=false;
                  }
                }
              }
            }
          }
        }
      }
    }  
  } 
//  */
  return ok;
}

//part 
bool do_touch(int i, int k)
{
return (Distance(particle[i],particle[k],lx,ly)
        <particle[i].r()+particle[k].r());
}

// part

bool verlet_needs_update()
{
  for(unsigned int i=0;i<no_of_particles;i++){
    if(Distance(particle[i],safe[i],lx,ly)>= verlet_ratio*verlet_distance){
      return true;
    }
  }
  return false;
}

//part

void step()
{

//cout<<"whoo \n";
  bool ok=true, newverlet=false;


  if(verlet_needs_update()){
    ok = make_verlet();
    newverlet=true;
  }

  if(!ok){
    cerr << "fail: going back from " << Time << " to " << Timesafe << endl;
    particle=safe;
    Time=Timesafe;
    verlet_distance*=verlet_increase;
    make_verlet();
  }

  if(newverlet && ok){
    safe=particle;
    Timesafe=Time;
  }
 /*
*/
  integrate();

}

//part 

void init_algorithm()
{
 
  safe=particle;
  Timesafe=Time;

  vnx=int(lx/verlet_grid);
  vny=int(ly/verlet_grid);

  if(vnx==0) vnx=1;
  if(vny==0) vny=1;

  dx=lx/vnx;
  dy=ly/vny;

  celllist.resize(vnx);
  for(int i=0;i<vnx;i++) celllist[i].resize(vny);
 
 make_verlet();

}
