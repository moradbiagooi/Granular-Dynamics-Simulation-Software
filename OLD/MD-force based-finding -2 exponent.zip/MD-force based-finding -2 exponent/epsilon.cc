#include <iostream>
#include <math.h>
using namespace std;
double Pi=3.14159265;
int main(){
double mass_in,mass_out;
double radius_in,radius_mid,radius_out;
double A_in,A_out;   //Dissipation
double Y_in,Y_out;   //Young modulus
double mu_in,mu_out; //friction

mass_out=10.01;
radius_out=0.005;
Y_out=1e+09;
A_out=1e-04;

  double _m_eff=mass_out*mass_out/(mass_out+mass_out);
  double _Y     = Y_out * sqrt(radius_out/2);
  double _gamma = Y_out * sqrt(radius_out/2) * A_out;
  double _epsilon;
  _epsilon  =  exp( -((Pi*_gamma)/(2*_m_eff)) / sqrt((_Y/_m_eff)-(_gamma/(2*_m_eff))*(_gamma/(2*_m_eff))) );


  cout<<"epsilon : "<<_epsilon<<"\n";



}
