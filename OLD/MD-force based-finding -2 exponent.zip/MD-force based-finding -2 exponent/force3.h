#include "properties.h"

// This calculates the force between inner and outer particles
//double Young=1e9,friction=0.5,damping=0.01,tang_damp=10.0,density=8e3;




//===========================

#ifdef OneDimensional
void force3(Sphere & p1, Sphere2 & p2, double lx) // Sphere and Sphere2 friend
#endif

#ifdef TwoDimensional
void force3(Sphere & p1, Sphere2 & p2, double lx, double ly) // Sphere and Sphere2 friend
#endif

#ifdef ThreeDimensional
void force3(Sphere & p1, Sphere2 & p2, double lx, double ly, double lz) // Sphere and Sphere2 friend
#endif
{

//double Y=1e9,mu=0.5,A=.0001; // What about defining these in macro

  double Y=p2.Y(),mu=p2.mu(),A=p2.A(); // What about defining these in macro

  double dx=normalize2(p2.x()-p1.x(),lx);// X_1 - X_2

#ifdef OneDimensional
  double rr=sqrt(dx*dx);// distance between two spheres
#endif

#ifdef TwoDimensional
  double dy=normalize2(p2.y()-p1.y(),ly);// Y_1 - Y_2
  double rr=sqrt(dx*dx+dy*dy);// distance between two spheres
#endif

#ifdef ThreeDimensional
  double dy=normalize2(p2.y()-p1.y(),ly);// Y_1 - Y_2
  double dz=normalize2(p2.z()-p1.z(),lz);// Z_1 - Z_2
  double rr=sqrt(dx*dx+dy*dy+dz*dz);// distance between two spheres
#endif

  double r1=p1.r();
  double r2=p2.r();
  double thickness = r1 - p1.r_mid();

//  double r2=r1/20.0;// 

//  double thickness=r1/20.0;

  double xi=r1+r2-rr;// khee or chi : compression : radius1+radius2-distance

#ifdef OneDimensional
  double abs_dx;
  if (dx<0.0) abs_dx=-dx;
  else abs_dx=dx;
  double sai=((r1-thickness)-(abs_dx)) - r2;
#endif

#ifdef TwoDimensional
  double sai=((r1-thickness)-(rr)) - r2;
#endif

#ifdef ThreeDimensional
  double sai=((r1-thickness)-(rr)) - r2; // ***check if this is the same as 2D case
#endif


  if (sai<0) {

    xi=sai;


    double dvx=p2.vx()-p1.vx();// relative velocity component x: (V_x)_1 -(V_x)_2 
#ifdef TwoDimensional
    double dvy=p2.vy()-p1.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
#endif
#ifdef ThreeDimensional
    double dvy=p2.vy()-p1.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
    double dvz=p2.vz()-p1.vz();// relative velocity component z: (V_z)_1 -(V_z)_2 
#endif

    double rr_rez=1/rr;// distance^(-1)

    double ex=dx*rr_rez;// dX/rr

#ifdef OneDimensional
    double xidot=-(ex*dvx);// -(dX*dV_x)/rr = - e_ij . dV_ij
#endif

#ifdef TwoDimensional
    double ey=dy*rr_rez;;//dy*rr_rez;// dX/rr
    double xidot=-(ex*dvx+ey*dvy);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij
#endif

#ifdef ThreeDimensional
    double ey=dy*rr_rez;;//dy*rr_rez;// dY/rr
    double ez=dz*rr_rez;;//dz*rr_rez;// dZ/rr
    double xidot=-(ex*dvx+ey*dvy+ez*dvz);// -(dX*dV_x+dY*dV_y+dZ*dV_z)/rr = - e_ij . dV_ij // **** check
#endif


    double reff = (r1*r2)/(r1+r2);// effective radius

//  double fn=Y*xi+A*xidot;// normal force: Y * (x_i^(1) + A * d(xi)/dt) - Hookian

#ifdef HertzianInnerForce
    double fn=sqrt(-xi)*Y*sqrt(reff)*(xi+A*xidot);// normal force: Y * (x_i^(3/2) + A * x_i^(1/2) * d(xi)/dt)
#endif

#ifdef HookeanInnerForce
    double fn=Y*sqrt(reff)*(xi+A*xidot);// normal force: Y * (x_i + A * d(xi)/dt) 
#endif

    double ft=0.0;// *** no ft for inner particles?? //-gamma*vtrel;// tangential force; almost: (eq 2.18)

#ifdef NoAdhesiveForce
    if(fn>0) fn=0;// non-negative force condition : fn = max ( 0 , fn) // *** THIS MAY NEED CHANGE IN THIS CASE
#endif

//    if (dx>0 && fn<0) fn=0.0;
//    if (dx<0 && fn>0) fn=0.0;

#ifdef OneDimensional
    p2.add_force(Vector(fn*ex));
    p1.add_force(Vector(-fn*ex));
#endif

#ifdef TwoDimensional
    p2.add_force(Vector(fn*ex, fn*ey, 0)); // *** no ft for inner particles??
    p1.add_force(Vector(-fn*ex,-fn*ey, 0)); // *** no ft for inner particles??
#endif

#ifdef ThreeDimensional
    p2.add_force(Vector(fn*ex, fn*ey, fn*ez));
    p1.add_force(Vector(-fn*ex,-fn*ey, -fn*ez));
#endif

  }


}


//=================

