//page 34

#include <stdlib.h>
#include "common.h"
#include "Sphere.h"   /*replace this line if necessary*/
#include "Sphere2.h"
#include <math.h>
#include "force3.h"
#include "properties.h"

using namespace std;

double Time=0, timestep;

int nstep, nprint, nenergy;
int Atom=0,VMDscale=200;

int Num_of_type1=0; // used for VMD visualization - number of type1 particles

#ifdef OneDimensional
double lx, x_0;// 
#endif

#ifdef TwoDimensional
double lx, ly, x_0, y_0;// 
#endif



double Density1=1.0,Density2=1.0;

double Pi=3.14159265;

double Mass2=0.25; // mass of inner particles(2)
double Mass1=0.5-Mass2;// mass of outer particles(1)

//double Rad1=0.5;
//double Rad2=sqrt(Rad1*Rad1*Mass2/Mass1)

//double thickness=
// double free space=

//int inner_work=1; // 1 with inner particles - 0 without inner particles.


Vector G; // gravity 
// vector ? Vector //
vector< Sphere > particle;   // outer particles //

#ifdef InnerParticlesExist
vector< Sphere2 > particle2; // inner particles//
#endif


unsigned int no_of_particles;

ofstream fphase;
//ofstream fphase("phase.dat"), flast("lastframe.dat"),ftemperature("temperature.dat");
ofstream ftemperature("temperature.dat");
ofstream xyzfile("output.xyz"); // only outer particles
ofstream xyzfile2("output2.xyz"); // with inner particles

void init_system(char * fname);
double total_kinetic_energy1(),total_kinetic_energy2();// for particles type 1 and two

//part 2 page 35
int main (int argc, char ** argv)
{

  if (argc!=2){
    cerr << "usage: " << argv[0] << " particle_initfile\n";
    exit(0);
      return 0; // my idea
  }


  ftemperature.precision(10); 
  init_system(argv[1]);

#ifdef InnerParticlesExist
  init_inner_particles();
#endif

  init_algorithm();
  phase_plot();


  for (int i=0;i<nstep;i++){
//  cout<<" i="<<i;
    step();

    if ((i+1)%nprint==0){
      cout << "phase_plot: " << i+1 << "  " << particle.size() << " particles\n";
      phase_plot();
    }

    if ((i+1)%nenergy==0){
      double Tmp1=total_kinetic_energy1()/particle.size();

#ifdef InnerParticlesExist
      double Tmp2=total_kinetic_energy2()/particle2.size();
      ftemperature << Time << "\t" << Tmp1 << "\t"<< Tmp2 << "\t"<< Tmp1+Tmp2<< endl;
#else
      ftemperature << Time << "\t" << Tmp1 << endl;
#endif


    }

  }

  phase_plot();


}



//part 3 page 37
void integrate()
{

  for(unsigned int i=0;i<particle.size();i++){
    if(particle[i].ptype()==0) {
      particle[i].set_force_to_zero();
      particle[i].predict(timestep);
#ifdef InnerParticlesExist
      particle2[i].set_force_to_zero();
      particle2[i].predict(timestep); 
#endif

    } else {
      particle[i].boundary_conditions(i,timestep,Time);
    }
  }



    make_forces();

  
  for(unsigned int i=0;i<particle.size();i++){

    if(particle[i].ptype()==0) {
      particle[i].correct(timestep);
#ifdef InnerParticlesExist
      particle2[i].correct(timestep);
#endif
    }

  }


  for(unsigned int i=0;i<particle.size();i++){

#ifdef OneDimensional
    particle[i].periodic_bc (x_0, lx);
#ifdef InnerParticlesExist
    particle2[i].periodic_bc(x_0, lx);
#endif
#endif

#ifdef TwoDimensional
    particle[i].periodic_bc (x_0, y_0, lx, ly);
#ifdef InnerParticlesExist
    particle2[i].periodic_bc(x_0, y_0, lx, ly);
#endif
#endif

  }
  Time+=timestep;
}

//part  page 46
void init_system(char * fname)
{
  ifstream fparticle(fname);
  while(fparticle.peek()=='#'){
    string type;
    fparticle >> type;
    if(type=="#gravity:"){

#ifdef OneDimensional
      fparticle >> G.x();
#endif

#ifdef TwoDimensional
      fparticle >> G.x() >> G.y() >> G.phi();
#endif

      fparticle.ignore(100,'\n');
      cout << "gravity: " << G << endl;
    } else if(type=="#Time:"){
      fparticle >> Time;
      fparticle.ignore(100,'\n');
      cout << "Time: " << Time << endl;
    } else if(type=="#nstep:"){
      fparticle >> nstep;
      fparticle.ignore(100,'\n');
      cout << "nstep: " << nstep << endl;
    } else if(type=="#timestep:"){
      fparticle >> timestep;
      fparticle.ignore(100,'\n');
      cout << "timestep: " << timestep << endl;
    } else if(type=="#nprint:"){
      fparticle >> nprint;
      fparticle.ignore(100,'\n');
      cout << "nprint: " << nprint << endl;
    } else if(type=="#nenergy:"){
      fparticle >> nenergy;
      fparticle.ignore(100,'\n');
      cout << "nenergy: " << nenergy << endl;
    } else if(type=="#lx:"){
      fparticle >> lx;
      fparticle.ignore(100,'\n');
      cout << "lx: " << lx << endl;
    } 
#ifdef TwoDimensional
      else if(type=="#ly:"){
      fparticle >> ly;
      cout << "ly: " << ly << endl;
      fparticle.ignore(100,'\n'); // ?????????????

    } 
#endif
      else if(type=="#x_0:"){
      fparticle >> x_0;
      fparticle.ignore(100,'\n');
      cout << "x_0: " << x_0 << endl;
    } 
#ifdef TwoDimensional
      else if(type=="#y_0:"){
      fparticle >> y_0;
      cout << "y_0: " << y_0 << endl;
      fparticle.ignore(100,'\n');

    } 
#endif
      else {
      cerr << "init: unknown global property: " << type << endl;
//      abort(); what's this
    }
  }
  while(fparticle){
    Sphere pp;
    fparticle >> pp;
    pp.m()=Mass1;

    if(fparticle){
      particle.push_back(pp);
    }
  }
  no_of_particles=particle.size();
  cout << no_of_particles << " particles read\n" << flush;
}

//=================================================
#ifdef InnerParticlesExist
void init_inner_particles(){
//int size_i=particle.size();

  for (unsigned int i=0;i<particle.size();i++){
#ifdef OneDimensional
    Sphere2 pp2(particle[i].x(),particle[i].vx());

    if (particle[i].ptype()==1) {
    Num_of_type1++;
//    pp2.x()+=0.01;
    }

#endif
#ifdef TwoDimensional
    Sphere2 pp2(particle[i].x(),particle[i].y(),particle[i].vx(),particle[i].vy());

    if (particle[i].ptype()==1) {
    Num_of_type1++;
//    pp2.x()+=0.01;
//    pp2.y()+=0.01;
    }

#endif
    pp2.m()=Mass2;
    particle2.push_back(pp2);


  }
}
#endif
//=================================================



//part   page 47
double total_kinetic_energy1()
{
  double sum=0;
  for(unsigned int i=0;i<particle.size();i++){
    if(particle[i].ptype()==0){
      sum+=particle[i].kinetic_energy();
    }
  }
  return sum;
}

double total_kinetic_energy2()
{
  double sum=0;
#ifdef InnerParticlesExist
  for(unsigned int i=0;i<particle2.size();i++){
    if(particle2[i].ptype()==0){
      sum+=particle2[i].kinetic_energy();
    }
  }
#endif
  return sum;
}


//part  page 48
void phase_plot()
{
/*
  os << "#NewFrame\n";
  os << "#no_of_particles: " << no_of_particles << endl;
  os << "#compressed: no\n";
  os << "#type: SphereXYPhiVxVyOmegaRMFixed25\n";
  os << "#gravity: " << G.x() << " " << G.y() << " " << G.phi() << endl;
  os << "#Time: " << Time << endl;
  os << "#timestep: " << timestep << endl;
  os << "#EndOfHeader\n";
*/

  xyzfile<<particle.size()<<"\nAtom\n";

#ifdef InnerParticlesExist
  xyzfile2<<particle.size()+particle2.size()-Num_of_type1<<"\nAtom\n";
#else
  xyzfile2<<particle.size()<<"\nAtom\n";
#endif

  for(unsigned int i=0;i<particle.size();i++){

//    os << particle[i];
#ifdef OneDimensional
    xyzfile  <<particle[i].ptype()+1 <<"\t"<<VMDscale*particle[i].x() <<"\t0.0\t0.0\n";

    xyzfile2 <<particle[i].ptype()+1 <<"\t"<<VMDscale*particle[i].x() <<"\t0.0\t0.0\n";
#ifdef InnerParticlesExist
if (particle[i].ptype()!=1){
    xyzfile2 << 3                    <<"\t"<<VMDscale*particle2[i].x()<<"\t0.0\t0.0\n";
}
#endif
#endif


#ifdef TwoDimensional
    xyzfile  <<particle[i].ptype()+1 <<"\t"<<VMDscale*particle[i].x() <<"\t"<<VMDscale*particle[i].y() <<"\t0.0\n";

    xyzfile2 <<particle[i].ptype()+1 <<"\t"<<VMDscale*particle[i].x() <<"\t"<<VMDscale*particle[i].y() <<"\t0.0\n";
#ifdef InnerParticlesExist
if (particle[i].ptype()!=1){
    xyzfile2 << 3                    <<"\t"<<VMDscale*particle2[i].x()<<"\t"<<VMDscale*particle2[i].y()<<"\t0.0\n";
}
#endif
#endif
  }
//    os << flush;

}
