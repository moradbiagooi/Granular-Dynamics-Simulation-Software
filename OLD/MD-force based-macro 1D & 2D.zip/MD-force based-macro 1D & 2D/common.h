//page 33
#ifndef _common_h
#define _common_h

#include <math.h>
#include <fstream>
#include <vector> // an array class template. a good one of STL
#include <set>
#include <string>
#include "properties.h"

using namespace std;

extern double lx,x_0 ;  // horizontal system size ,lower left corner

#ifdef TwoDimensional
extern double ly,y_0;  // vertical system size,lower down corner
#endif

extern int inner_work; // functioning of inner particles

extern unsigned int no_of_particles;  // number of particles
extern double Time; // elapsed real time
extern ofstream fphase; // output file : phase space
extern ofstream fenergy; //outpud file : energy of system

void step();//Performs one time step of the simulation[simple.cc]
void make_forces();//Computes the total forces acting on each particle[simple.cc]
void integrate();//Integrates Newton’s equation of motion using the Gear algorithm[common.cc]
void init_algorithm();//Initializes all data specific to the force summation algorithm[simple.cc]
//void phase_plot(ostream & os);//Dumps the current positions, velocities, and further values into the output file[common.cc]
void phase_plot();//Dumps the current positions, velocities, and further values into the output fil
void  init_inner_particles(); 

#endif
