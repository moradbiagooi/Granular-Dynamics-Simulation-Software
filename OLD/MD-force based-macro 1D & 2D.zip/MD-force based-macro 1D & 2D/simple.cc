//part 1 page 36
#include "common.h"
#include "Sphere.h"
#include "Sphere2.h"   /* <==== replace this line if necessary */
#include "properties.h"

using namespace std;

extern vector<Sphere> particle;
extern vector<Sphere2> particle2;

void init_algorithm()
{
}

void step()
{
  integrate();
}


void make_forces()
{

  for(unsigned int i=0;i<particle.size();i++){

#ifdef OneDimensional

#ifdef InnerParticlesExist
    force3(particle[i], particle2[i], lx); // between inner and outer particles
#endif

//    force(particle[i],particle[i+1], lx); // LINEAR NEIGHBORS FORCE

    for(unsigned int j=i+1;j<particle.size();j++){
    force(particle[i],particle[j], lx); // between outer particles
    }

#endif



#ifdef TwoDimensional

#ifdef InnerParticlesExist
    force3(particle[i], particle2[i], lx, ly); // between inner and outer particles
#endif

//    force(particle[i],particle[i+1], lx, ly); // // LINEAR  NEIGHBORS FORCE


    for(unsigned int j=i+1;j<particle.size();j++){
    force(particle[i],particle[j], lx, ly); // between outer particles
    }

#endif

  }

}


