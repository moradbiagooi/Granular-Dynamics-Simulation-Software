//page 80
#include <string>
#include <stdlib.h>
#include "CompositeParticle.h"

//part
void force(CompositeParticle & p1, CompositeParticle & p2,
           double lx, double ly)
{
  for(unsigned int i=0;i<p1.particles.size();i++){
    for(unsigned int k=0;k<p2.particles.size();k++){
      force(p1.particles[i],p2.particles[k], lx, ly);
    }
  }
}

void CompositeParticle::internal_forces()
{
  for(unsigned int i=1;i<particles.size();i++){
    int k=i%(particles.size()-1)+1;
    double dx=particles[i].x()-particles[k].x();
    double dy=particles[i].y()-particles[k].y();
    double dvx=particles[i].vx()-particles[k].vx();
    double dvy=particles[i].vy()-particles[k].vy();
    double RR=sqrt(dx*dx+dy*dy);
    double dr=RR-restlength1[i-1];
    Vector fik;
    fik.x()=-(k1*dr*dx/RR+gamma1*dvx);
    fik.y()=-(k1*dr*dy/RR+gamma1*dvy);
    particles[i].add_force(fik);
    particles[k].add_force((-1)*fik);
    dx=particles[i].x()-particles[0].x();
    dy=particles[i].y()-particles[0].y();
    dvx=particles[i].vx()-particles[0].vx();
    dvy=particles[i].vy()-particles[0].vy();
    RR=sqrt(dx*dx+dy*dy);
    dr=RR-restlength2[i-1];
    fik.x()=-(k2*dr*dx/RR+gamma2*dvx);
    fik.y()=-(k2*dr*dy/RR+gamma2*dvy);
    particles[i].add_force(fik);
    particles[0].add_force((-1)*fik);
  }
}

//part
double Distance(const CompositeParticle & p1, const CompositeParticle & p2,
double lx, double ly)
{
double d=Distance(p1.particles[0],p2.particles[0], lx, ly);
return d;
}

//part
void CompositeParticle::predict(double dt)
{
  for(unsigned int i=0;i<particles.size();i++){
    particles[i].predict(dt);
  }
}

void CompositeParticle::correct(double dt)
{
  internal_forces();
  for(unsigned int i=0;i<particles.size();i++){
    particles[i].correct(dt);
  }
}

// part
void CompositeParticle::periodic_bc(double x_0, double y_0,
                                    double lx, double ly)
{
  for(unsigned int i=particles.size()-1; i>=0;i--){
    while(particles[0].pos().x()<x_0) particles[i].pos().x()+=lx;
    while(particles[0].pos().x()>x_0+lx) particles[i].pos().x()-=lx;
    while(particles[0].pos().y()<y_0) particles[i].pos().y()+=ly;
    while(particles[0].pos().y()>y_0+ly) particles[i].pos().y()-=ly;
  }
}

//part 
double CompositeParticle::kinetic_energy() const
{
  double sum=0;
  for(unsigned int i=0;i<particles.size();i++){
    sum+=particles[i].vx()*particles[i].vx()/2;
    sum+=particles[i].vy()*particles[i].vy()/2;
  }
  return sum;
}

// part

ostream & operator << (ostream & os, const CompositeParticle & p)
{
  os << "BeginCmpPart " << p.k1 << " " << p.gamma1
     << " " << p.k2 << " " << p.gamma2 << endl;
  for(unsigned int i=0;i<p.particles.size();i++){
    os << "p " << p.particles[i];
  }
  os << "end\n";
  return os;
}

// part

istream & operator >> (istream & is, CompositeParticle & p)
{
  p.particles.clear();
  p.restlength1.clear();
  p.restlength2.clear();
  string type;
  is >> type;
  if(is){
    if(type!="BeginCmpPart"){
      cerr << "syntax error in input file: missing BeginCmpPart\n";
      exit(0);
    }
    is >> p.k1 >> p.gamma1 >> p.k2 >> p.gamma2;
    do{
      is >> type;
        if(type=="p"){
          Sphere sp;
          is >> sp;
          p.particles.push_back(sp);
        } else if(type!="end"){
          cerr << "unknown type: ’" << type << "’\n";
          exit(0);
        }
      } while((type!="end") && is);
      if(type!="end"){
        cerr << "premature end of input file: " << type << "\n";
        exit(0);
      }
    }

/* Compute total mass */

    if(p.particles.size()>0){
      p._r=p.particles[0].r();
      double Rmax=0;
      for(unsigned int i=1;i<p.particles.size();i++){
        if(p.particles[i].r()>Rmax) Rmax=p.particles[i].r();
      }
      p._r+=2*Rmax;
      p._m=0;
      for(unsigned int i=0;i<p.particles.size();i++){
        p._m+=p.particles[i].m();
      }
    }
/* Compute rest lengths */
    if(p.particles.size()>0){
      p.restlength1.resize(p.particles.size()-1);
      p.restlength2.resize(p.particles.size()-1);

    for(unsigned int i=1;i<p.particles.size();i++){
      int k=i%(p.particles.size()-1)+1;
      double r0=p.particles[0].r();
      double ri=p.particles[i].r();
      double rk=p.particles[k].r();
      double rl1 = sqrt((r0+ri)*(r0+ri)+(r0+rk)*(r0+rk));
      double rl2 = r0+ri;
      p.restlength1[i-1]=rl1;
      p.restlength2[i-1]=rl2;
    }
  }
  return is;
}
