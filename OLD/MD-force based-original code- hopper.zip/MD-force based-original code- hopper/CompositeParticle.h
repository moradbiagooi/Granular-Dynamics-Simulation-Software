//page 79
#ifndef _CompositeParticle_h
#define _CompositeParticle_h

#include <vector>
#include "Vector.h"
#include "Sphere.h"

using namespace std;

class CompositeParticle {
  friend istream & operator >> (istream & is, CompositeParticle & p);
  friend ostream & operator << (ostream & os, const CompositeParticle & p);
  friend double Distance(const CompositeParticle & p1,
                         const CompositeParticle & p2,
                         double lx, double ly);
  friend void force(CompositeParticle & p1, CompositeParticle & p2,
                    double lx, double ly);
public:
  Vector & pos(){return particles[0].pos();}
  Vector pos() const {return particles[0].pos();}
  double & x(){return particles[0].x();}
  double x() const {return particles[0].x();}
  double & y(){return particles[0].y();}
  double y() const {return particles[0].y();}
  double & vx(){return particles[0].vx();}
  double vx() const {return particles[0].vx();}
  double & vy(){return particles[0].vy();};
  double vy() const {return particles[0].vy();};
  const Vector & velocity() const {return particles[0].velocity();}
  double r() const { return _r;}
  double m() const { return _m;}

  void read_positions(istream & os);
  double kinetic_energy() const;
  void predict(double dt);
  void correct(double dt);
  void set_force_to_zero()
  {
    for(unsigned int i=0;i<particles.size();i++)
      particles[i].set_force_to_zero();
  }
  int ptype() const { return particles[0].ptype();}
  void boundary_conditions(int n, double timestep, double Time)
  {
    for(unsigned int i=0;i<particles.size();i++){
      particles[i].boundary_conditions(n,timestep,Time);
    }
  }
 
  void periodic_bc(double x_0, double y_0, double lx, double ly);
private:
  vector<Sphere> particles;
  double k1,k2,gamma1,gamma2,_r,_m;
  vector<double> restlength1,restlength2;
  void internal_forces();
};
#endif
