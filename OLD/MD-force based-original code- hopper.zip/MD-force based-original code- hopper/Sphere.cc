//part 1 page 41

#include "Sphere.h"
#include <assert.h>

extern Vector G;


void Sphere::predict(double dt)
{
  double a1=dt;
  double a2=a1*dt/2;
  double a3=a2*dt/3;
  double a4=a3*dt/4;
//cout<<rtd0<<"&";
  rtd0+=a1*rtd1 + a2*rtd2 + a3*rtd3 + a4*rtd4;
  rtd1+=a1*rtd2 + a2*rtd3 + a3*rtd4;
  rtd2+=a1*rtd3 + a2*rtd4;
  rtd3+=a1*rtd4;
}


void Sphere::correct(double dt)
{
  static Vector accel,corr;
  double dtrez = 1/dt;
  const double coeff0=double(19)/double(90)*(dt*dt/double(2));
  const double coeff1=double(3)/double(4)*(dt/double(2));
  const double coeff3=double(1)/double(2)*(double(3)*dtrez);
  const double coeff4=double(1)/double(12)*(double(12)*(dtrez*dtrez));

  accel=Vector((1/_m)*_force.x()+G.x(),
    (1/_m)*_force.y()+G.y(),
    (1/_J)*_force.phi()+G.phi());
  corr=accel-rtd2;
//cout<<".accel "<<accel<<",corr "<<corr<< " " ;
  rtd0 += coeff0*corr;
  rtd1 += coeff1*corr;
  rtd2 = accel;
  rtd3 += coeff3*corr;
  rtd4 += coeff4*corr;
}


// part 2 page 41
void force(Sphere & p1, Sphere & p2, double lx, double ly) // Sphere friend
{
  double dx=normalize(p1.x()-p2.x(),lx);// X_1 - X_2
  double dy=normalize(p1.y()-p2.y(),ly);// Y_1 -Y_2
  double rr=sqrt(dx*dx+dy*dy);// distance between two spheres
  double r1=p1.r();
  double r2=p2.r();
  double xi=r1+r2-rr;// khee or chi : compression : radius1+radius2-distance

  if(xi>0){
    double Y=p1.Y*p2.Y/(p1.Y+p2.Y);// effective Young modulus
    double A=0.5*(p1.A+p2.A);// average of Dissipative constants
    double mu = (p1.mu<p2.mu ? p1.mu : p2.mu);// friction constant : the smaller friction is the appliciable one.
    double gamma = (p1.gamma<p2.gamma ? p1.gamma : p2.gamma);// gamma of friction
    double reff = (r1*r2)/(r1+r2);// effective radius
    double dvx=p1.vx()-p2.vx();// relative velocity component x: (V_x)_1 -(V_x)_2 
    double dvy=p1.vy()-p2.vy();// relative velocity component y: (V_y)_1 -(V_y)_2 
    double rr_rez=1/rr;// distance^(-1)
    double ex=dx*rr_rez;// dX/rr
    double ey=dy*rr_rez;// dX/rr
    double xidot=-(ex*dvx+ey*dvy);// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij
    double vtrel=-dvx*ey + dvy*ex + p1.omega()*p1.r()-p2.omega()*p2.r();// relative tangential velocity of the surfaces of the contacting spheres : (-dV_x*dY +dV_y*dX)/rr  + w_1*r_1 + w_2*r2: using e_ij_tangential . dV_ij
    double fn=sqrt(xi)*Y*sqrt(reff)*(xi+A*xidot);// normal force: Y * (x_i^(3/2) + A * x_i^(1/2) * d(xi)/dt)
    double ft=-gamma*vtrel;// tangential force; almost: (eq 2.18)

    if(fn<0) fn=0;// non-negative force condition : fn = max ( 0 , fn)
    if(ft<-mu*fn) ft=-mu*fn;// Coulomb's law of friction
    if(ft>mu*fn) ft=mu*fn;// Coulomb's law of friction
    if(p1.ptype()==0) {
      p1.add_force(Vector(fn*ex-ft*ey, fn*ey+ft*ex, r1*ft));
    }
    if(p2.ptype()==0) {
      p2.add_force(Vector(-fn*ex+ft*ey, -fn*ey-ft*ex, -r2*ft));
    } 
  }
}


// part 3 page 43
void Sphere::boundary_conditions(int n, double timestep, double Time)
{
  switch(ptype()){
  case(0): break;
  case(1): break;
  case(2): {
    x()=0.5-0.4*cos(10*Time);
    y()=0.1;
    vx()=10*0.4*sin(Time);
    vy()=0;
  } break;
  case(3): {
    double xx=x()-0.5;
    double yy=y()-0.5;
    double xp=xx*cos(timestep)-yy*sin(timestep);
    double yp=xx*sin(timestep)+yy*cos(timestep);
    x()=0.5+xp;
    y()=0.5+yp;
    vx()=-yp;
    vy()= xp;
    omega()=1;
  } break;
  case(4): {
    x()=0.5+0.1*cos(Time) + 0.4*cos(Time+2*n*M_PI/128);
    y()=0.5+0.1*sin(Time) + 0.4*sin(Time+2*n*M_PI/128);
    vx()=-0.1*sin(Time) - 0.4*sin(Time+2*n*M_PI/128);
    vy()= 0.1*cos(Time) - 0.4*cos(Time+2*n*M_PI/128);
    omega()=1;
  } break;
  case(5): {
    y()=0.1+0.02*sin(30*Time);
    vx()=0;
    vy()=0.02*30*cos(30*Time);
  } break;
  case(6): {
    int i=n/2;
    y()=i*0.02+0.1+0.02*sin(30*Time);
    vx()=0;
    vy()=0.02*30*cos(30*Time);
  } break;
  default: {
    cerr << "ptype: " << ptype() << " not implemented\n";
    //abort();  // what's this
    }
  }
}


//part  4 page 44
void Sphere::periodic_bc(double x_0, double y_0, double lx, double ly)
{
  while(rtd0.x()<x_0) rtd0.x()+=lx;
  while(rtd0.x()>x_0+lx) rtd0.x()-=lx;
  while(rtd0.y()<y_0) rtd0.y()+=ly;
  while(rtd0.y()>y_0+ly) rtd0.y()-=ly;
}


//part  5 page 45
double Sphere::kinetic_energy() const
{
  return _m*(rtd1.x()*rtd1.x()/2 + rtd1.y()*rtd1.y()/2)
    + _J*rtd1.phi()*rtd1.phi()/2;
}


//part  6 page 45
istream & operator >> (istream & is, Sphere & p)
{
  is >> p.rtd0 >> p.rtd1
     >> p._r >> p._m >> p._ptype
     >> p.Y >> p.A >> p.mu >> p.gamma
     >> p._force
     >> p.rtd2 >> p.rtd3 >> p.rtd4;
  p._J=p._m*p._r*p._r/2;
  return is;
}


//part  7 page 45
ostream & operator << (ostream & os, const Sphere & p)
{
  os << p.rtd0 << " " << p.rtd1 << " ";
  os << p._r << " " << p._m << " " << p._ptype << " ";
  os << p.Y << " " << p.A << " " << p.mu << " " << p.gamma << " ";
  os << p._force << " ";
  os << p.rtd2 << " " << p.rtd3 << " " << p.rtd4 << "\n" << flush;
  return os;
}
//part  page

