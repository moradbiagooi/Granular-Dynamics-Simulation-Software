//page 66
#include "Sphere.h" /* <===== replace this line if necessary */
#include "common.h" 

extern vector<Sphere> particle; /* <===== replace this line if necessary */

int nx, ny, gm;
double rmin, rmax, gk;
vector<vector<int> > partners, pindex;

void make_ilist();
void clear_pindex();

//page 66

void init_algorithm()
{
  rmin=particle[0].r();
  rmax=particle[0].r();
  for(unsigned int i=1;i<particle.size();i++){
    if(particle[i].r()<rmin){
      rmin=particle[i].r();
    }

    if(particle[i].r()>rmax){
      rmax=particle[i].r();
    }
  }

  gk=sqrt(2)*rmin;
  gm=int(2*rmax/gk)+1;
  nx=int(lx/gk)+1;
  ny=int(ly/gk)+1;

//page 67

  partners.resize(no_of_particles);
  pindex.resize(nx);
  for(unsigned int ix=0;ix<pindex.size();ix++){
    pindex[ix].resize(ny);
  }
  clear_pindex();
  make_ilist();
}

void clear_pindex()
{
  for(unsigned int ix=0;ix<pindex.size();ix++){
    for(unsigned int iy=0;iy<pindex[ix].size();iy++){
      pindex[ix][iy]=-1;
    }
  }
}

// part 67

void make_ilist()
{
  for(unsigned int i=0;i<particle.size();i++){
    double x=particle[i].x(), y=particle[i].y();
    if((x>=x_0) && (x<x_0+lx) && (y>=y_0) && (y<y_0+ly)){
      int ix=int((x-x_0)/gk);
      int iy=int((y-y_0)/gk);
      pindex[ix][iy]=i;
      partners[i].clear();
    }
  }
  for(unsigned int i=0;i<particle.size();i++){
    double x=particle[i].x(), y=particle[i].y();
    if((x>=x_0) && (x<x_0+lx) && (y>=y_0) && (y<y_0+ly)){
      int ix=int((x-x_0)/gk);
      int iy=int((y-y_0)/gk);
      for(int dx=-gm;dx<=gm;dx++){
        for(int dy=-gm;dy<=gm;dy++){
          int k=pindex[(ix+dx+nx)%nx][(iy+dy+ny)%ny];
          if(k>(int)i){
            partners[i].push_back(k);
          }
        }
      }
    }
  }
  clear_pindex();
}

// part 68

void make_forces()
{
  for(unsigned int i=0;i<particle.size();i++){
    for(unsigned int k=0;k<partners[i].size();k++){
      int pk=partners[i][k];
      force(particle[i],particle[pk], lx, ly);
    }
  }
}

//part 68

void step()
{
  make_ilist();
  integrate();
}
