//page 62
#include <stdlib.h> // bug --- exit() is defined in this file
#include "common.h"
#include "Sphere.h" /* <===== replace this line if necessary */

extern vector<Sphere> particle; /* <===== replace this line if necessary */

const int nx=10, ny=10;
vector<vector<vector<int> > > lc;
vector<vector<vector<pair<int,int> > > > neighbors;
void make_link_cell();
bool is_valid_neighbor(int ix, int iy, int iix, int iiy);
void init_neighbors();

//part

void make_link_cell()
{
  for(unsigned int ix=0;ix<lc.size();ix++){
    for(unsigned int iy=0;iy<lc[ix].size();iy++){
      lc[ix][iy].clear();
    }
  }
  for(unsigned int i=0;i<no_of_particles;i++){
    int ix=int(nx*(particle[i].x()-x_0)/lx);
    int iy=int(ny*(particle[i].y()-y_0)/ly);
    if((ix>=0) && (ix<nx) && (iy>=0) && (iy<ny)){
      lc[ix][iy].push_back(i);
    } else {
      cerr << "Particle " << i << " outside simulation area\n";
      exit(0);
    }
  }
}
// part

void init_neighbors()
{
  int iix,iiy;
  neighbors.resize(nx);
  for(int ix=0;ix<nx;ix++){
    neighbors[ix].resize(ny);
  }
  for(int ix=0;ix<nx;ix++){
    for(int iy=0;iy<ny;iy++){
      for(int dx=-1;dx<=1;dx++){
        for(int dy=-1;dy<=1;dy++){
          iix=(ix+dx+nx)%nx;
          iiy=(iy+dy+ny)%ny;
          if(is_valid_neighbor(ix,iy,iix,iiy)) {
            neighbors[ix][iy].push_back(pair<int,int>(iix,iiy));
          }
        }
      }
    }
  }
}

//part 

bool is_valid_neighbor(int ix, int iy, int iix, int iiy)
{
  if((iix==(ix-1+nx)%nx) && (iiy==(iy+1+ny)%ny)) return true;
  if((iix==(ix+nx)%nx) && (iiy==(iy+1+ny)%ny)) return true;
  if((iix==(ix+1+nx)%nx) && (iiy==(iy+1+ny)%ny)) return true;
  if((iix==(ix+1+nx)%nx) && (iiy==(iy+ny)%ny)) return true;
  return false;
}

// part

void make_forces()
{
  for(unsigned int ix=0;ix<lc.size();ix++){
    for(unsigned int iy=0;iy<lc[ix].size();iy++){
      for(unsigned int j=0;j<lc[ix][iy].size();j++){
        int pj=lc[ix][iy][j];
        for(unsigned int k=j+1;k<lc[ix][iy].size();k++){
          int pk=lc[ix][iy][k];
          force(particle[pj],particle[pk], lx, ly);
        }
        for(unsigned int n=0;n<neighbors[ix][iy].size();n++){
          int iix=neighbors[ix][iy][n].first;
          int iiy=neighbors[ix][iy][n].second;
          for(unsigned int k=0;k<lc[iix][iiy].size();k++){
            int pk=lc[iix][iiy][k];
            force(particle[pj],particle[pk], lx, ly);
          }
        }
      }
    }
  }
}

// part

void step()
{
  make_link_cell();
  integrate();
}
// part 
void init_algorithm()
{
  lc.resize(nx);
  for(unsigned int ix=0;ix<lc.size();ix++) lc[ix].resize(ny);
  init_neighbors();
  make_link_cell();
}

