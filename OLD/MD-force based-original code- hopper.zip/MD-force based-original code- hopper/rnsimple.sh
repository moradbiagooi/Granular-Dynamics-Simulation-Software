g++ -o simple.out common.cc Sphere.cc simple.cc
./simple.out input_hopper.dat
vmd output.xyz
