//part 1 page 36
#include "common.h"
#include "Sphere.h"   /* <==== replace this line if necessary */

using namespace std;

extern vector<Sphere> particle;    /* <==== replace this line if necessary */

void init_algorithm()
{
}

void step()
{
  integrate();
}

//part 2 page 38
void make_forces()
{
  for(unsigned int i=0;i<particle.size()-1;i++){
    for(unsigned int k=i+1;k<particle.size();k++){

      if((particle[i].ptype()==0) || (particle[k].ptype()==0)){  // bug ptype no "()"
        force(particle[i],particle[k],lx,ly);
      }
    }
  }
}

