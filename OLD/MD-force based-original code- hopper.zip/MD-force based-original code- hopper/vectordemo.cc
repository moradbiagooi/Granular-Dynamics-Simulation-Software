// Page 30
#include "Vector.h"

int main()
{
  Vector a(1,2,3), b(4,5,6), c;
  double d=7;
  c=a+b;
  cout<<endl<<c;
  c=a-b;
  cout<<endl<<c; //correct
  c+=a;  c=c+a;
  c-=a;  c=c-a;
  c*=d;  c=c*d;
  d=norm2d(a);
  d=scalprod2d(a,b);
  d=vecprod2d(a,b);
  c=Vector(0,0,0); c=null;

}

