
/* //==========================
   // Developed by Morad Biagooi
   // m.biagooi@gmail.com
   // m.biagooi@iasbs.ac.ir
*/ //==========================

#include <stdlib.h>
#include "common.h"
#include "Sphere.h"   
#include "Sphere2.h"
#include <math.h>
#include "force3.h"
#include "properties.h"
#include <string>
#include <sys/stat.h> // used for mkdir()
#include <time.h>

using namespace std;

double Time=0, timestep;

int nstep, nprint, nenergy;
int Atom=0,VMDscale=200;

int Num_of_type1=0; // used for VMD visualization
                    // - number of type1 particles

#ifdef OneDimensional
double lx, x_0;// *** if these are extern 
               //why we re-define them and
               // use them in the function arguments?
#endif
#ifdef TwoDimensional
double lx, ly, x_0, y_0;// *** above
#endif
#ifdef ThreeDimensional
double lx, ly, lz, 
       x_0, y_0, z_0;// *** above argument?
#endif


double Density1=1.0,Density2=1.0;

double Pi=3.14159265;

double mass_in,mass_out;
double radius_in,radius_mid,radius_out;
double A_in,A_out;   //Dissipation
double Y_in,Y_out;   //Young modulus
double mu_in,mu_out; //friction


Vector G; // gravity 

vector< Sphere > particle;   // outer particles //

#ifdef InnerParticlesExist
vector< Sphere2 > particle2; // inner particles//
#endif


unsigned int no_of_particles;


int mkdir(const char *path, mode_t mode);

ofstream ftemperature;
ofstream ftemperature_DT;
ofstream fparameters_out;
#ifdef VMDXYZOutput
ofstream xyzfile; // only outer particles
ofstream xyzfile2; // with inner particles
#endif

string str_folder_output;

void output_file_maker();
void tag_file_maker();





void init_system(char * fname_is);
void init_parameters(char * fname_ip);

double total_kinetic_energy1(),
       total_kinetic_energy2();// for particles type one and two

//==================================================  main
int main (int argc, char ** argv)
{


  if (argc!=3){
    cerr << "Needs 2 input files, for example: \n\t /a.out init_particles.dat init_parameters.dat";
//    cerr << "usage: " << argv[0] << " particle_initfile\n";
    exit(0);
      return 0; // my idea
  }
  clock_t t1,t2;
  t1=clock();




  ftemperature.precision(10); 
  ftemperature_DT.precision(10); 

  output_file_maker();

  tag_file_maker();

  init_parameters(argv[2]);

  init_system(argv[1]);


#ifdef InnerParticlesExist
  init_inner_particles();
#endif


  fparameters_out<<"=================="<<"\n";
  fparameters_out<<"Number of particles: "<<particle.size()<<"\n";

#ifdef InnerParticlesExist
  fparameters_out<<"Number of inner particles: "<<particle2.size()<<"\n";
#else
  fparameters_out<<"Number of inner particles: "<<"0"<<"\n";
#endif


  init_algorithm();
  phase_plot();

  cout<<"======================time loop()\n";
  for (int i=0;i<nstep;i++){
//  cout<<" i="<<i;
    step();

#ifdef VMDXYZOutput
    if ((i+1)%nprint==0){
      cout << "phase_plot: " << i+1 << "  " << particle.size() << " particles\n";
      phase_plot();
    }
#endif

    if ((i+1)%nenergy==0){
      cout << "temperature_plot: " << i+1 << "  " << particle.size() << " particles\n";
      double Tmp1=total_kinetic_energy1()/particle.size();

#ifdef InnerParticlesExist
      double Tmp2=total_kinetic_energy2()/particle2.size();
      ftemperature << Time << "\t" << Tmp1 << "\t"<< Tmp2 << "\t"<< Tmp1+Tmp2 << endl;
      ftemperature_DT << Time << "\t" << Tmp1 << "\t"<< Tmp2 << "\t"<< Tmp1+Tmp2 << endl;
#else
      ftemperature << Time << "\t" << Tmp1 << "\t"<< "0.0" << "\t"<< Tmp1 << endl;
      ftemperature_DT << Time << "\t" << Tmp1 << "\t"<< "0.0" << "\t"<< Tmp1 << endl;
#endif


    }

  }

  phase_plot();


  t2=clock();
  float diff ((float)t2-(float)t1);
  cout            << "execution time :" 
                  << diff / CLOCKS_PER_SEC <<" seconds" <<endl;
  fparameters_out <<"execution time :" 
                  << diff / CLOCKS_PER_SEC <<" seconds" <<endl;

  return 0;

}

//==================================================  output_file_maker
void output_file_maker(){



  str_folder_output.append("outputs/"); 

  const char* char_folder_output=str_folder_output.c_str();
  mkdir(char_folder_output,0777);
  // what if outputs already existed with fileswithin it




  time_t rawtime;
  struct tm * timeinfo;
  char char_buffer [40];
  time (&rawtime);
  timeinfo = localtime (&rawtime);
  cout << asctime(timeinfo)<<"\n";


  time (&rawtime);
  timeinfo = localtime (&rawtime);

//  strftime (buffer,80,"Now it's %I:%M%p.",timeinfo);
//  strftime (buffer,80,"Now it's %F_%T",timeinfo);

  strftime (char_buffer,80,"MD_%F_%T",timeinfo);

  
  str_folder_output.append(char_buffer);

  char_folder_output = str_folder_output.c_str();
  mkdir(char_folder_output,0777);

// ------------------

  string str_ftemperature=str_folder_output;
  str_ftemperature.append("/temperature.dat");
  const char * char_ftemperature=str_ftemperature.c_str();
  ftemperature.open(char_ftemperature);

  string str_ftemperature_DT=str_folder_output;
  str_ftemperature_DT.append("/Temperature_");
  str_ftemperature_DT.append(char_buffer);
  str_ftemperature_DT.append(".dat");
  const char * char_ftemperature_DT=str_ftemperature_DT.c_str();
  ftemperature_DT.open(char_ftemperature_DT);

// ------------------

/*
  string str_fparameters_out=str_folder_output;
  str_fparameters_out.append("/parameters_out.dat");
  const char * char_fparameters_out=str_fparameters_out.c_str();
  fparameters_out.open(char_fparameters_out);
*/

  string str_fparameters_out=str_folder_output;
  str_fparameters_out.append("/parameters_");
  str_fparameters_out.append(char_buffer);
  str_fparameters_out.append(".dat");
  const char * char_fparameters_out=str_fparameters_out.c_str();
  fparameters_out.open(char_fparameters_out);

// ------------------

#ifdef VMDXYZOutput
  string str_xyzfile=str_folder_output;
  str_xyzfile.append("/VMD.xyz");
  const char * char_xyzfile=str_xyzfile.c_str();
  xyzfile.open(char_xyzfile);


  string str_xyzfile2=str_folder_output;
  str_xyzfile2.append("/VMD2.xyz");
  const char * char_xyzfile2=str_xyzfile2.c_str();
  xyzfile2.open(char_xyzfile2);
#endif




}

//==================================================  tag_file_maker
void tag_file_maker(){
  fparameters_out<<"==================Tag files"<<"\n";
  string str_tag="";

#ifdef OneDimensional    //(1) 
  str_tag=str_folder_output;
  str_tag.append("/TAG_1_OneDimensional.TAG");
  const char * char_tag1 = str_tag.c_str();
  ofstream file_tag(char_tag1);
  file_tag.close();
  fparameters_out<<"1_OneDimensional"<<"\n";
#endif


#ifdef TwoDimensional    //(2)
  str_tag=str_folder_output;
  str_tag.append("/TAG_1_TwoDimensional.TAG");
  const char * char_tag1 = str_tag.c_str();
  ofstream file_tag(char_tag1);
  file_tag.close();
  fparameters_out<<"1_TwoDimensional"<<"\n";
#endif

#ifdef ThreeDimensional    //(3)
  str_tag=str_folder_output;
  str_tag.append("/TAG_1_ThreeDimensional.TAG");
  const char * char_tag1 = str_tag.c_str();
  ofstream file_tag(char_tag1);
  file_tag.close();
  fparameters_out<<"1_ThreeDimensional"<<"\n";
#endif

/*
#ifdef OneDimLinForce    // ON or OFF linear force in OneDimensional Case
ofstream("tag_2_OneDimLinForce.tag");                          // Two wall concept should be the case
#endif


#ifdef NoAdhesiveForce   // ON or OFF
ofstream("tag_3_NoAdhesiveForce.tag");                          // means force = max [0 , f(xi)]
#endif
*/

#ifdef HookeanInnerForce    //(1)
  str_tag=str_folder_output;
  str_tag.append("/TAG_4_HookeanInnerForce.TAG");
  const char * char_tag4 = str_tag.c_str();
  ofstream file_tag4(char_tag4);
  file_tag4.close();
  fparameters_out<<"4_HookeanInnerForce"<<"\n";
#endif

#ifdef HertzianInnerForce    //(2)
  str_tag=str_folder_output;
  str_tag.append("/TAG_4_HertzianInnerForce.TAG");
  const char * char_tag4 = str_tag.c_str();
  ofstream file_tag4(char_tag4);
  file_tag4.close();
  fparameters_out<<"4_HertzianInnerForce"<<"\n";
#endif


/*
#ifdef InnerGravityForce //ON or OFF// 
ofstream("tag_5_InnerGravityForce.tag");
#endif
*/

#ifdef HookeanOuterForce   //(1)
  str_tag=str_folder_output;
  str_tag.append("/TAG_6_HookeanOuterForce.TAG");
  const char * char_tag6 = str_tag.c_str();
  ofstream file_tag6(char_tag6);
  file_tag6.close();
  fparameters_out<<"6_HookeanOuterForce"<<"\n";
#endif

#ifdef HertzianOuterForce    //(2)
  str_tag=str_folder_output;
  str_tag.append("/TAG_6_HertzianOuterForce.TAG");
  const char * char_tag6 = str_tag.c_str();
  ofstream file_tag6(char_tag6);
  file_tag6.close();
  fparameters_out<<"6_HertzianOuterForce"<<"\n";
#endif


#ifdef ElasticOuterForce    //(1)
  str_tag=str_folder_output;
  str_tag.append("/TAG_7_ElasticOuterForce.TAG");
  const char * char_tag7 = str_tag.c_str();
  ofstream file_tag7(char_tag7);
  file_tag7.close();
  fparameters_out<<"7_ElasticOuterForce"<<"\n";
#endif

#ifdef LocalOuterForce    //(2)
  str_tag=str_folder_output;
  str_tag.append("/TAG_7_LocalOuterForce.TAG");
  const char * char_tag7 = str_tag.c_str();
  ofstream file_tag7(char_tag7);
  file_tag7.close();
  fparameters_out<<"7_LocalOuterForce"<<"\n";
#endif

#ifdef GlobalOuterForce    //(3)
  str_tag=str_folder_output;
  str_tag.append("/TAG_7_GlobalOuterForce.TAG");
  const char * char_tag7 = str_tag.c_str();
  ofstream file_tag7(char_tag7);
  file_tag7.close();
  fparameters_out<<"7_GlobalOuterForce"<<"\n";
#endif

#ifdef InnerParticlesExist //ON or OFF//
  str_tag=str_folder_output;
  str_tag.append("/TAG_8_InnerParticlesON.TAG");
  const char * char_tag8 = str_tag.c_str();
  ofstream file_tag8(char_tag8);
  file_tag8.close();
  fparameters_out<<"8_InnerParticlesON"<<"\n";
#else
  str_tag=str_folder_output;
  str_tag.append("/TAG_8_InnerParticlesOFF.TAG");
  const char * char_tag8 = str_tag.c_str();
  ofstream file_tag8(char_tag8);
  file_tag8.close();
  fparameters_out<<"8_InnerParticlesOFF"<<"\n";
#endif

}



//==================================================  integrate
void integrate()
{

  for(unsigned int i=0;i<particle.size();i++){
    if(particle[i].ptype()==0) {
      particle[i].set_force_to_zero();
      particle[i].predict(timestep);
#ifdef InnerParticlesExist
      particle2[i].set_force_to_zero();
      particle2[i].predict(timestep); 
#endif

    } else {
      particle[i].boundary_conditions(i,timestep,Time);
    }
  }



    make_forces();

  
  for(unsigned int i=0;i<particle.size();i++){

    if(particle[i].ptype()==0) {
      particle[i].correct(timestep);
#ifdef InnerParticlesExist
      particle2[i].correct(timestep);
#endif
    }

  }


  for(unsigned int i=0;i<particle.size();i++){

#ifdef OneDimensional
    particle[i].periodic_bc (x_0, lx);
#ifdef InnerParticlesExist
    particle2[i].periodic_bc(x_0, lx);
#endif
#endif

#ifdef TwoDimensional
    particle[i].periodic_bc (x_0, y_0, lx, ly);
#ifdef InnerParticlesExist
    particle2[i].periodic_bc(x_0, y_0, lx, ly);
#endif
#endif

#ifdef ThreeDimensional
    particle[i].periodic_bc (x_0, y_0, z_0, lx, ly, lz);
#ifdef InnerParticlesExist
    particle2[i].periodic_bc(x_0, y_0, z_0, lx, ly, lz);
#endif
#endif

  }
  Time+=timestep;
}
//==================================================  init_parameters

void init_parameters(char * fname_ip)
{
  cout<<"======================init_parameters()\n";
  fparameters_out<<"==================init_parameters"<<"\n";
  ifstream fparameters(fname_ip);
  while(fparameters.peek()=='#'){
    string type;
    fparameters >> type;
    if(type=="#radius_in:"){
      fparameters >> radius_in;
      fparameters.ignore(100,'\n');
      cout << "radius_in: " << radius_in << endl;
      fparameters_out << "radius_in: " << radius_in << endl;
    }
      else if(type=="#radius_mid:"){
      fparameters >> radius_mid;
      fparameters.ignore(100,'\n');
      cout << "radius_mid: " << radius_mid << endl;
      fparameters_out << "radius_mid: " << radius_mid << endl;
    }
      else if(type=="#radius_out:"){
      fparameters >> radius_out;
      fparameters.ignore(100,'\n');
      cout << "radius_out: " << radius_out << endl;
      fparameters_out << "radius_out: " << radius_out << endl;
    }
      else if(type=="#mass_in:"){
      fparameters >> mass_in;
      fparameters.ignore(100,'\n');
      cout << "mass_in: " << mass_in << endl;
      fparameters_out << "mass_in: " << mass_in << endl;
    }
      else if(type=="#mass_out:"){
      fparameters >> mass_out;
      fparameters.ignore(100,'\n');
      cout << "mass_out: " << mass_out << endl;
      fparameters_out << "mass_out: " << mass_out << endl;
    }
      else if(type=="#A_in:"){
      fparameters >> A_in;
      fparameters.ignore(100,'\n');
      cout << "A_in: " << A_in << endl;
      fparameters_out << "A_in: " << A_in << endl;
    }
      else if(type=="#A_out:"){
      fparameters >> A_out;
      fparameters.ignore(100,'\n');
      cout << "A_out: " << A_out << endl;
      fparameters_out << "A_out: " << A_out << endl;
    }
      else if(type=="#Y_in:"){
      fparameters >> Y_in;
      fparameters.ignore(100,'\n');
      cout << "Y_in: " << Y_in << endl;
      fparameters_out << "Y_in: " << Y_in << endl;
    }
      else if(type=="#Y_out:"){
      fparameters >> Y_out;
      fparameters.ignore(100,'\n');
      cout << "Y_out: " << Y_out << endl;
      fparameters_out << "Y_out: " << Y_out << endl;
    } else if(type=="#mu_in:"){
      fparameters >> mu_in;
      fparameters.ignore(100,'\n');
      cout << "mu_in: " << mu_in << endl;
      fparameters_out << "mu_in: " << mu_in << endl;
    }
      else if(type=="#mu_out:"){
      fparameters >> mu_out;
      fparameters.ignore(100,'\n');
      cout << "mu_out: " << mu_out << endl;
      fparameters_out << "mu_out: " << mu_out << endl;
    }


      else {
      cerr << "init_parameters(): unknown global property: " << type << endl;
//      abort(); what's this
    }
  }
}

//==================================================  init_system 
void init_system(char * fname_is)
{
  cout<<"======================init_system()\n";
  fparameters_out<<"==================init_system"<<"\n";
  ifstream fparticle(fname_is);
  while(fparticle.peek()=='#'){
    string type;
    fparticle >> type;
    if(type=="#gravity:"){

#ifdef OneDimensional
      fparticle >> G.x();
#endif

#ifdef TwoDimensional
      fparticle >> G.x() >> G.y() >> G.phi();
#endif

#ifdef ThreeDimensional
      fparticle >> G.x() >> G.y() >> G.z();
#endif

      fparticle.ignore(100,'\n');
      cout << "gravity: " << G << endl;
      fparameters_out << "gravity: " << G << endl;
    } else if(type=="#Time:"){
      fparticle >> Time;
      fparticle.ignore(100,'\n');
      cout << "Time: " << Time << endl;
      fparameters_out << "Time: " << Time << endl;
    } else if(type=="#nstep:"){
      fparticle >> nstep;
      fparticle.ignore(100,'\n');
      cout << "nstep: " << nstep << endl;
      fparameters_out << "nstep: " << nstep << endl;
    } else if(type=="#timestep:"){
      fparticle >> timestep;
      fparticle.ignore(100,'\n');
      cout << "timestep: " << timestep << endl;
      fparameters_out << "timestep: " << timestep << endl;
    } else if(type=="#nprint:"){
      fparticle >> nprint;
      fparticle.ignore(100,'\n');
      cout << "nprint: " << nprint << endl;
    } else if(type=="#nenergy:"){
      fparticle >> nenergy;
      fparticle.ignore(100,'\n');
      cout << "nenergy: " << nenergy << endl;
      fparameters_out << "nenergy: " << nenergy << endl;
    } else if(type=="#lx:"){
      fparticle >> lx;
      fparticle.ignore(100,'\n');
      cout << "lx: " << lx << endl;
      fparameters_out << "lx: " << lx << endl;
    } 
#ifdef TwoDimensional
      else if(type=="#ly:"){
      fparticle >> ly;
      cout << "ly: " << ly << endl;
      fparameters_out << "ly: " << ly << endl;
      fparticle.ignore(100,'\n'); // ?????????????
    } 
#endif

#ifdef ThreeDimensional
      else if(type=="#ly:"){
      fparticle >> ly;
      cout << "ly: " << ly << endl;
      fparameters_out << "ly: " << ly << endl;
      fparticle.ignore(100,'\n'); // ?????????????
    } 
      else if(type=="#lz:"){
      fparticle >> lz;
      cout << "lz: " << lz << endl;
      fparameters_out << "lz: " << lz << endl;
      fparticle.ignore(100,'\n'); // ?????????????
    } 
#endif

      else if(type=="#x_0:"){
      fparticle >> x_0;
      fparticle.ignore(100,'\n');
      cout << "x_0: " << x_0 << endl;
      fparameters_out << "x_0: " << x_0 << endl;
    } 
#ifdef TwoDimensional
      else if(type=="#y_0:"){
      fparticle >> y_0;
      cout << "y_0: " << y_0 << endl;
      fparameters_out << "y_0: " << y_0 << endl;
      fparticle.ignore(100,'\n');
    } 
#endif

#ifdef ThreeDimensional
      else if(type=="#y_0:"){
      fparticle >> y_0;
      cout << "y_0: " << y_0 << endl;
      fparameters_out << "y_0: " << y_0 << endl;
      fparticle.ignore(100,'\n');
    } 
      else if(type=="#z_0:"){
      fparticle >> z_0;
      cout << "z_0: " << z_0 << endl;
      fparameters_out << "z_0: " << z_0 << endl;
      fparticle.ignore(100,'\n');
    } 
#endif

      else {
      cerr << "init_system(): unknown global property: " << type << endl;
//      abort(); what's this
    }
  }
  while(fparticle){
    Sphere pp;
    fparticle >> pp;

    pp.m()=mass_out;
    pp.r()=radius_out;;
    pp.r_mid()=radius_mid;
    pp.A()=A_out;
    pp.Y()=Y_out;
    pp.mu()=mu_out;


    if(fparticle){
      particle.push_back(pp);
    }
  }
  no_of_particles=particle.size();
  cout << no_of_particles << " particles read\n" << flush;
}

//==================================================  init_inner_particles
#ifdef InnerParticlesExist
void init_inner_particles(){
//int size_i=particle.size();

  for (unsigned int i=0;i<particle.size();i++){
#ifdef OneDimensional
    Sphere2 pp2(particle[i].x(),particle[i].vx());

    if (particle[i].ptype()==1) {
    Num_of_type1++;
    }

#endif
#ifdef TwoDimensional
    Sphere2 pp2(particle[i].x() ,particle[i].y()
               ,particle[i].vx(),particle[i].vy());

    if (particle[i].ptype()==1) {
    Num_of_type1++;
    }

#endif
#ifdef ThreeDimensional
    Sphere2 pp2(particle[i].x() ,particle[i].y() ,particle[i].z()
               ,particle[i].vx(),particle[i].vy(),particle[i].vz());

    if (particle[i].ptype()==1) {
    Num_of_type1++;
    }

#endif

    pp2.m()=mass_in;
    pp2.r()=radius_in;
    pp2.A()=A_in;
    pp2.Y()=Y_in;
    pp2.mu()=mu_in;

    particle2.push_back(pp2);

  }
}
#endif




//==================================================  total_kinetic_eneregy
double total_kinetic_energy1()
{
  double sum=0;
  for(unsigned int i=0;i<particle.size();i++){
    if(particle[i].ptype()==0){
      sum+=particle[i].kinetic_energy();
    }
  }
  return sum;
}

double total_kinetic_energy2()
{
  double sum=0;
#ifdef InnerParticlesExist
  for(unsigned int i=0;i<particle2.size();i++){
    if(particle2[i].ptype()==0){
      sum+=particle2[i].kinetic_energy();
    }
  }
#endif
  return sum;
}


//==================================================  phase_plot
void phase_plot()
{
/*
  os << "#NewFrame\n";
  os << "#no_of_particles: " << no_of_particles << endl;
  os << "#compressed: no\n";
  os << "#type: SphereXYPhiVxVyOmegaRMFixed25\n";
  os << "#gravity: " << G.x() << " " << G.y() << " " << G.phi() << endl;
  os << "#Time: " << Time << endl;
  os << "#timestep: " << timestep << endl;
  os << "#EndOfHeader\n";
*/
#ifdef VMDXYZOutput
  xyzfile<<particle.size()<<"\nAtom\n";

#ifdef InnerParticlesExist
  xyzfile2<<particle.size()+particle2.size()-Num_of_type1<<"\nAtom\n";
#else
  xyzfile2<<particle.size()<<"\nAtom\n";
#endif

  for(unsigned int i=0;i<particle.size();i++){

//    os << particle[i];
#ifdef OneDimensional
    xyzfile  <<particle[i].ptype()+1    <<"\t"
             <<VMDscale*particle[i].x() <<"\t0.0\t0.0\n";

    xyzfile2 <<particle[i].ptype()+1    <<"\t"
             <<VMDscale*particle[i].x() <<"\t0.0\t0.0\n";
#ifdef InnerParticlesExist
if (particle[i].ptype()!=1){
    xyzfile2 << 3                       <<"\t"
             <<VMDscale*particle2[i].x()<<"\t0.0\t0.0\n";
}
#endif
#endif


#ifdef TwoDimensional
    xyzfile  <<particle[i].ptype()+1    <<"\t"
             <<VMDscale*particle[i].x() <<"\t"
             <<VMDscale*particle[i].y() <<"\t0.0\n";

    xyzfile2 <<particle[i].ptype()+1    <<"\t"
             <<VMDscale*particle[i].x() <<"\t"
             <<VMDscale*particle[i].y() <<"\t0.0\n";
#ifdef InnerParticlesExist
if (particle[i].ptype()!=1){
    xyzfile2 << 3                        <<"\t"
             <<VMDscale*particle2[i].x() <<"\t"
             <<VMDscale*particle2[i].y() <<"\t0.0\n";
}
#endif
#endif

#ifdef ThreeDimensional
    xyzfile  <<particle[i].ptype()+1    <<"\t"
             <<VMDscale*particle[i].x() <<"\t"
             <<VMDscale*particle[i].y() <<"\t"
             <<VMDscale*particle[i].z() <<"\n";

    xyzfile2 <<particle[i].ptype()+1    <<"\t"
             <<VMDscale*particle[i].x() <<"\t"
             <<VMDscale*particle[i].y() <<"\t"
             <<VMDscale*particle[i].z() <<"\n";
#ifdef InnerParticlesExist
if (particle[i].ptype()!=1){
    xyzfile2 << 3                        <<"\t"
             <<VMDscale*particle2[i].x() <<"\t"
             <<VMDscale*particle2[i].y() <<"\t"
             <<VMDscale*particle2[i].z() <<"\n";
}
#endif
#endif


  }
//    os << flush;
#endif
}
