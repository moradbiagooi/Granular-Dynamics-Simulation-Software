#ifndef _properties_h
#define _properties_h
/*-------------------------------------------------------------------
Here we can choose between different alternatives, It means  one and 
only one of the numbers should be active.
In the other case, have to turn something //ON or OFF//
-------------------------------------------------------------------*/
//=============================== Dimensions
// used in "force3.h", "sphere.h","sphere2.h","sphere.cc","sphere2.cc",
// "Vector.h", "common.h", "common.cc"

#define OneDimensional    //(1) 
//#define TwoDimensional    //(2)
//#define ThreeDimensional    //(3)

//=============================== Forces in 1Dimensions
// used in simple.cc

#define OneDimLinForce    // ON or OFF linear force in OneDimensional Case
                          // Two wall concept should be the case
//=============================== Inner Forces correction
// used in force3.h

#define NoAdhesiveForce   // ON or OFF
                          // means force = max [0 , f(xi)]

//=============================== Inner Forces type
// used in "force3.h"

#define HookeanInnerForce    //(1)
//#define HertzianInnerForce    //(2)


//=============================== Gravity works on the inner particles 
// used in "force3.h"

//#define InnerGravityForce //ON or OFF// 


//=============================== Outer Force
// used in "sphere.cc"

#define HookeanOuterForce   //(1)
//#define HertzianOuterForce    //(2)


//=============================== Collision Parameters:
// (1)_All Elastic, (2)_Local Dissipative,(3)_Global Dissipative,
// Global Dissipative: All of the particles have the same parameters
// Local Dissipative : Parameters of the input files are used
// used in "sphere.cc"

//#define ElasticOuterForce    //(1)
//#define LocalOuterForce    //(2)
#define GlobalOuterForce    //(3)


//=============================== Inner Particles available
// used in "common.cc"

#define InnerParticlesExist //ON or OFF//
//=============================== VMD output: xyz format
//used in "common.cc"

//#define VMDXYZOutput    //ON or OFF

//===============================
#endif
