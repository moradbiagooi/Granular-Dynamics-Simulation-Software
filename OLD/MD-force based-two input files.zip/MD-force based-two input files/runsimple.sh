#reset
#rm simple_box.out
#g++ -o simple_box.out common.cc Sphere.cc Sphere2.cc verlet.cc
g++ -o simple_box.out common.cc Sphere.cc Sphere2.cc simple.cc
#./simple_box.out input_box_1D.dat input_parameters.dat
#vmd output2.xyz
#rm phase.dat lastframe.dat
