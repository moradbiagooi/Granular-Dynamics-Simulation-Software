//page 
#include "common.h"
#include "Sphere.h" /* <===== replace this line if necessary */
#include "Sphere2.h"
#include "properties.h"

extern vector<Sphere2> particle2;
extern vector<Sphere> particle; /* <===== replace this line if necessary */
//------
vector<Sphere> safe; 
double Timesafe; /* <===== replace this line if necessary */
// this 'safe' & 'Timesafe' serve as a backup for 'particle' and 'Time' in the rare case that the Verlet list become incorrect
//------

double verlet_ratio = 0.6, verlet_distance = 0.00025, verlet_grid = 0.05;
double verlet_increase = 1.1;
// for the performance of the algorithm
// verlet_ratio of 1.0 is very strict, no collision is missed and not really neccesary by what is written in p67
//---

int vnx;
double dx;

#ifdef OneDimensional//?????????????????????????????
//vector<vector<vector<int> > > celllist;
vector<vector<int> >  celllist;
#endif

#ifdef TwoDimensional
int vny;
double dy;

vector<vector<vector<int> > > celllist;

#endif

#ifdef ThreeDimensional
int vny,vnz;
double dy,dz;

vector<vector<vector<vector<int> > > > celllist;

#endif


vector<set<int> > verlet; // verlet list: only nearby particles

bool verlet_needs_update();
bool make_verlet();
bool do_touch(int i, int k);

// part ========================================================
// part ========================================================
void make_forces() //specific for Verlet - calculate force only for verlet list of the particles
{

  for(unsigned int i=0;i<particle.size();i++){

#ifdef OneDimensional

#ifdef InnerParticlesExist
    force3(particle[i], particle2[i], lx); // between inner and outer particles
#endif

    set<int>::iterator iter;
    for(iter=verlet[i].begin();iter!=verlet[i].end();iter++){
      force(particle[i],particle[*iter], lx);
    }

#endif



#ifdef TwoDimensional

#ifdef InnerParticlesExist
    force3(particle[i], particle2[i], lx, ly); // between inner and outer particles
#endif

    set<int>::iterator iter;
    for(iter=verlet[i].begin();iter!=verlet[i].end();iter++){
      force(particle[i],particle[*iter], lx, ly);
    }

#endif


#ifdef ThreeDimensional

#ifdef InnerParticlesExist
    force3(particle[i], particle2[i], lx, ly, lz); // between inner and outer particles
#endif

    set<int>::iterator iter;
    for(iter=verlet[i].begin();iter!=verlet[i].end();iter++){
      force(particle[i],particle[*iter], lx, ly, lz);
    }

#endif
  }

}


// part ========================================================
// part ========================================================



// part ========================================================
// part ========================================================


bool make_verlet()
{

  bool ok=true;


//grid cells 'celllist', with the size dx*dy list consisted of particles residing in them.


  verlet.resize(no_of_particles); // current lists are discarded; these lists have been constructed in the preceding call of make_verlet()
  for(int ix=0;ix<vnx;ix++){ 
#ifdef OneDimensional
    celllist[ix].clear();
#endif
#ifdef TwoDimensional
    for(int iy=0;iy<vny;iy++){
      celllist[ix][iy].clear();
    }
#endif
#ifdef ThreeDimensional
    for(int iy=0;iy<vny;iy++){
      for(int iz=0;iz<vnz;iz++){
        celllist[ix][iy][iz].clear();
      }
    }
#endif
  }

//cout<<"dx:"<<dx<<" dy:"<<dy<<"\n\n";

  for(unsigned int i=0;i<no_of_particles;i++){ //particles are sorted in the grids
    int ix=int((particle[i].x()-x_0)/dx);

#ifdef OneDimensional
    celllist[ix].push_back(i);// 
#endif

#ifdef TwoDimensional
    int iy=int((particle[i].y()-y_0)/dy);
    celllist[ix][iy].push_back(i);// 
#endif

#ifdef ThreeDimensional
    int iy=int((particle[i].y()-y_0)/dy);
    int iz=int((particle[i].z()-z_0)/dz);
    celllist[ix][iy][iz].push_back(i);// 
#endif

  }
// /*
  for(unsigned int i=0;i<no_of_particles;i++){

    set<int> oldverlet=verlet[i]; // copying old list
    verlet[i].clear();// clearing the list

    int ix=int((particle[i].x()-x_0)/dx);// selecting the grid of particle[i]
#ifdef TwoDimensional
    int iy=int((particle[i].y()-y_0)/dy);//  //  //  //
#endif

#ifdef ThreeDimensional
    int iy=int((particle[i].y()-y_0)/dy);//  //  //  //
    int iz=int((particle[i].z()-z_0)/dz);//  //  //  //
#endif


    for(int iix=ix-1;iix<=ix+1;iix++){ // adjacant cells of (ix,iy) cell
#ifdef TwoDimensional
      for(int iiy=iy-1;iiy<=iy+1;iiy++){ // adjacant cells 
#endif

#ifdef ThreeDimensional
      for(int iiy=iy-1;iiy<=iy+1;iiy++){ // adjacant cells 
      for(int iiz=iz-1;iiz<=iz+1;iiz++){ // adjacant cells 
#endif

        int wx = (iix+vnx)%vnx;
#ifdef TwoDimensional
        int wy = (iiy+vny)%vny;
#endif

#ifdef ThreeDimensional
        int wy = (iiy+vny)%vny;
        int wz = (iiz+vnz)%vnz;
#endif


#ifdef OneDimensional
        for(unsigned int k=0;k<celllist[wx].size();k++){

          int pk=celllist[wx][k];

          if(pk<(int)i){ 
            if(Distance(particle[i],particle[pk], lx)<
              particle[i].r()+particle[pk].r()+verlet_distance){

#endif


#ifdef TwoDimensional
        for(unsigned int k=0;k<celllist[wx][wy].size();k++){

          int pk=celllist[wx][wy][k];

          if(pk<(int)i){ 
            if(Distance(particle[i],particle[pk], lx, ly)<
              particle[i].r()+particle[pk].r()+verlet_distance){
#endif

#ifdef ThreeDimensional
        for(unsigned int k=0;k<celllist[wx][wy][wz].size();k++){

          int pk=celllist[wx][wy][wz][k];

          if(pk<(int)i){ 
            if(Distance(particle[i],particle[pk], lx, ly, lz)<
              particle[i].r()+particle[pk].r()+verlet_distance){
#endif

              if((particle[i].ptype()==0) || (particle[pk].ptype()==0)){
                verlet[i].insert(pk);

                if(oldverlet.find(pk)==oldverlet.end()){//if it doesn't existed in the old verlet list,.... 
                  if(do_touch(i,pk)) { // and if they tuch now, it means there was a big gap between this two steps. this is error
                    ok=false;
                  }
                }
              }
            }
          }
#ifdef TwoDimensional
        }
#endif

#ifdef ThreeDimensional
        }
        }
#endif

      }
    }  
  } 
//  */
  return ok;
}

//part 
bool do_touch(int i, int k)
{

// part ========================================================

#ifdef OneDimensional
return (Distance(particle[i],particle[k],lx)
        <particle[i].r()+particle[k].r());
#endif

#ifdef TwoDimensional
return (Distance(particle[i],particle[k],lx,ly)
        <particle[i].r()+particle[k].r());
#endif

#ifdef ThreeDimensional
return (Distance(particle[i],particle[k],lx,ly,lz)
        <particle[i].r()+particle[k].r());
#endif
}

// part ========================================================

bool verlet_needs_update()
{
  for(unsigned int i=0;i<no_of_particles;i++){

#ifdef OneDimensional
    if(Distance(particle[i],safe[i],lx)>= verlet_ratio*verlet_distance){
      return true;
    }
#endif

#ifdef TwoDimensional
    if(Distance(particle[i],safe[i],lx,ly)>= verlet_ratio*verlet_distance){
      return true;
    }
#endif

#ifdef ThreeDimensional
    if(Distance(particle[i],safe[i],lx,ly,lz)>= verlet_ratio*verlet_distance){
      return true;
    }
#endif

  }
  return false;
}

//part ========================================================

void step()
{

//cout<<"whoo \n";
  bool ok=true, newverlet=false;


  if(verlet_needs_update()){
    ok = make_verlet();
    newverlet=true;
  }

  if(!ok){
    cerr << "fail: going back from " << Time << " to " << Timesafe << endl;
    particle=safe;
    Time=Timesafe;
    verlet_distance*=verlet_increase;
    make_verlet();
  }

  if(newverlet && ok){
    safe=particle;
    Timesafe=Time;
  }
 /*
*/
  integrate();

}

//part ========================================================

void init_algorithm()
{
 
  safe=particle;
  Timesafe=Time;

  vnx=int(lx/verlet_grid);
  if(vnx==0) vnx=1;
  dx=lx/vnx;
  celllist.resize(vnx);


#ifdef TwoDimensional
  vny=int(ly/verlet_grid);
  if(vny==0) vny=1;
  dy=ly/vny;
  for(int i=0;i<vnx;i++) celllist[i].resize(vny);
#endif

#ifdef ThreeDimensional
  vny=int(ly/verlet_grid);
  vnz=int(lz/verlet_grid);
 
  if(vny==0) vny=1;
  dy=ly/vny;

  if(vnz==0) vnz=1;
  dz=lz/vnz;

// for(int i=0;i<vnx;i++) celllist[i].resize(vny);
  

 for(int i=0;i<vnx;i++){
    celllist[i].resize(vny);
    for(int j=0;j<vnx;j++){
      celllist[i][j].resize(vnz);
    }
  }

/* 
 for(int i=0;i<vnx;i++){
    for(int j=0;j<vnx;j++){
      celllist[i][j].resize(vnz);
    }
  }
*/

#endif


 
 make_verlet();

}
