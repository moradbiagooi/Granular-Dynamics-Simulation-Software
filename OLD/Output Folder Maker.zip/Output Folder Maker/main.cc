#include <iostream>
#include <fstream>

#include <string>
#include <sys/stat.h>


int mkdir(const char *path, mode_t mode);


using namespace std;

int main()
{

//--------------making outputs/
string str_folder_output;
str_folder_output.append("outputs/"); 

const char* char_folder_output=str_folder_output.c_str();
mkdir(char_folder_output,0777);
// what if outputs already existed with fileswithin it

string str_time=__TIME__;
string str_date=__DATE__;


str_folder_output.append(str_date);
str_folder_output.append(" & ");
str_folder_output.append(str_time);


char_folder_output = str_folder_output.c_str();
mkdir(char_folder_output,0777);

// ------------------

string str_ftemperature=str_folder_output;
str_ftemperature.append("/temperature.dat");
const char * char_ftemperature=str_ftemperature.c_str();
ofstream ftemperature(char_ftemperature);
ftemperature<<"adsdas";

/*
string str_folder;
str_folder.append(str_date);
str_folder.append(" & ");
str_folder.append(str_time);

const char * char_folder = str_folder.c_str();
mkdir(char_folder,0777);
*/

/*
ofstream o1("test1.txt"); // Creates a file in the current directory
	o1 << "complete";
ofstream o2("new/test2.txt"); // Creates a file in the "new" directory of the current directory
	o2 << "complete";
ofstream o3("./test3.txt"); // Creates a file in the current directory
	o3 << "complete";
ofstream o4("../test4.txt"); // Creates a file 1 directory up
	o4 << "complete";
ofstream o5("../../test5.txt"); // Creates a file 2 directories up
	o5 << "complete";
ofstream o6("../Parallel Folder/test6.txt"); // Creates a file in "parallel folder" 1 directory up
	o6 << "complete";
*/

}

	


