g++ -o convertor.out xyz_convertor_final.cc
./convertor.out
vmd output.xyz
