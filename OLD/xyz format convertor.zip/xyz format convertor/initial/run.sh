g++ -o convertor.out xyz_convertor_initial.cc
./convertor.out
vmd output.xyz
