#include<fstream>
using namespace std;

int main()
{

ifstream inp_file("input.dat");
ofstream out_file("output.xyz");

int num=46; // number of atoms - lines 

//out_file<<"# contains n atoms \n";
out_file<<num-1<<"\nAtom\n";

float temp;
for (int i=0;i<num;i++)
{
	out_file<<"1\t"; // type of atoms

	inp_file>>temp;out_file<<temp<<"\t";
	inp_file>>temp;out_file<<temp<<"\t0.0\n";
//	inp_file>>"\n";


	for (int j=0;j<23;j++)
	{
		inp_file>>temp;
	}

}

return 0;

}
