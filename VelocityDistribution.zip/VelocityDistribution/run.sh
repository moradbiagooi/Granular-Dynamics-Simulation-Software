rm rvd
g++ -o rvd velocity_distribution.cpp
./rvd
