
#include <iostream>
#include <fstream>


using namespace std;


#define FILENAME_IN  "xv_PE_nP:10000_FT:10000_RC:0.5_Al:0.05_Be:0.1_EI:.dat"
#define FILENAME_OUT "output.dat"


const int no_of_snapshots     = 11;
const int no_of_grains        = 10000;
const int no_of_dist_box      = 100;


double velocity_data         [ no_of_snapshots * no_of_grains   ];
double velocity_distribution [ no_of_snapshots * no_of_dist_box ];


ifstream file_in_velocity;
ofstream file_out_velocity;


inline double abs ( double _x ) {
  return _x < 0 ? -_x : _x;
}

void input_data();
void make_vel_distrib ( int );


//###################################################

int main(){


  file_in_velocity.open ( FILENAME_IN  );
  file_out_velocity.open( FILENAME_OUT );


  input_data();


  for ( unsigned int i = 0; i < no_of_snapshots * no_of_dist_box; i++ )
    velocity_distribution [ i ] = 0;


  for ( unsigned int i = 0; i < no_of_snapshots; i++ )
    make_vel_distrib ( i );


  file_in_velocity.close ();
  file_out_velocity.close();


  return 0;

}

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


void input_data(){

  for ( unsigned int i = 0; i < no_of_snapshots * no_of_grains; i++ ){

    double dtemp;

    file_in_velocity >> dtemp;
    file_in_velocity >> dtemp;
    file_in_velocity >> velocity_data [ i ];

  }

}


//---------------------------------------------------

void make_vel_distrib ( int _snap_index ){

  int j = _snap_index * no_of_grains;

  double _max_velocity=0;


  for ( unsigned int i = 0; i < no_of_grains; i++ ){

    double _abs_vx = abs ( velocity_data[ i + j ] );

    if ( _abs_vx > _max_velocity ) _max_velocity = _abs_vx;

  }


  double dvx = 2.0 * _max_velocity / double ( no_of_dist_box );






  for ( unsigned int i = 0; i < no_of_grains; i++ ){

    int _box_index = int( ( _max_velocity + velocity_data [ i + j ] ) / dvx );

    int k = _box_index + _snap_index * no_of_dist_box;

    if ( k > 0 && k < no_of_snapshots * no_of_dist_box )
      velocity_distribution [ k ]++;

  }



  for ( unsigned int i = 0; i < no_of_dist_box; i++ ){

    int k = i + _snap_index * no_of_dist_box;

    file_out_velocity << _snap_index << " "
                      << -_max_velocity + ( i ) * dvx << " "
                      << double ( velocity_distribution [ k ] ) / ( double ( no_of_grains ) * dvx )
                      << "\n";

  }


}

//===================================================


