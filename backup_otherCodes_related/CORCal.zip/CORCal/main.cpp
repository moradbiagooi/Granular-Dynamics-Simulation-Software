
#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;
/*
inline double abs( double x ) {
    return x < 0 ? -x : x;
}
*/
int main(){

    int n_max = 100;

    double norm = 1.0;

    ofstream fCOR, fCOR2;

    fCOR.open ("data.dat");

    fCOR2.open ("data2.dat");

    for ( int i = 0; i < n_max; i++ ){

        for ( int j = 0; j < n_max; j++ ){

            double x = double ( i - ( n_max / 2 ) ) * norm;

            double y = double ( j - ( n_max / 2 ) ) * norm;

            double COR = abs ( ( x - y ) / ( x + y ) );

            fCOR << COR << " ";

            fCOR2 << x << " " << y << " " << COR << "\n";
        }

        fCOR << "\n";

    }




    fCOR.close();
    fCOR2.close();

    return 0;
}
