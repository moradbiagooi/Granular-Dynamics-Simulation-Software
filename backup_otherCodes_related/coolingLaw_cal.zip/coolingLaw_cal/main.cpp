#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;


int main() {

    double lambda   = 0.75;
    double rc       = 0.65;

    double c        = -(rc*rc - 1.0);

    double tau      = 10.0;

    double T_0      = 1.0;

    ofstream fileOut;

    fileOut.open ( "data_t_e1.dat" );


    for ( double T = 1.0; T > 0.0 ; T -= 0.00001 ){
        
        double t;

        t = ( - 1.0 / c ) * (   
            - 2.0 * lambda * (  (1.0 / sqrt ( T )) - (1.0 / sqrt ( T_0 ))  )
            + tau * log ( T / T_0 )   ) ;

        fileOut << t << " " << T << "\n";

    }


    fileOut.close();

    return 0;
}
