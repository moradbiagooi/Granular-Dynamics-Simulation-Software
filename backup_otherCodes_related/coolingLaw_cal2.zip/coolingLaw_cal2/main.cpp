#include <iostream>
#include <fstream>
#include <cmath>

#define PI 3.14159265

using namespace std;


int main() {

    double alpha    = 0.05;

    double beta     = 0.05;

    double delta    = 0.5;

    double lambda   = 0.9;

    double eta      = 500.0;

    double zeta_p   = 0.9;



    double sq_eta   = sqrt ( eta - 1.0 );

    double rc       = exp ( - PI / ( sq_eta ) );

    double tau      = PI * eta / ( 2.0 * sq_eta );

    double c        = 1.0 - rc * rc ;

    double l_free   = ( 1.0 - alpha - (2.0 * beta) ) * ( 1.0 - lambda ) / 2.0;

    double T_0      = zeta_p * zeta_p * 4.0 * delta * ( 1.0 - delta ) * l_free * l_free / eta ;



    ofstream fileOut;

/*
    fileOut.open ( "data.dat" );

    for ( eta = 1.0 ; eta < 100; eta += 0.01 ) {

        double _tau      = PI * eta / ( 2.0 * sq_eta );

        double _T_0      = zeta_p * zeta_p * 4.0 * delta * ( 1.0 - delta ) * l_free * l_free / eta ;

        fileOut << eta << " " <<  lambda / sqrt ( _T_0 ) << " " << _tau << "\n";

    }
*/


//      /*
 
   fileOut.open ( "data_t_e:50.dat" );

    for ( double T = T_0 ; T > 0.0 ; T -= 0.0000001 ){
        
        double t;

        t = ( - 1.0 / c ) * (   
            - 2.0 * lambda * (  (1.0 / sqrt ( T )) - (1.0 / sqrt ( T_0 ))  )
            + tau * log ( T / T_0 )   ) ;

        fileOut << t << " " << T << "\n";

    }

//      */

    fileOut.close();

    return 0;
}
