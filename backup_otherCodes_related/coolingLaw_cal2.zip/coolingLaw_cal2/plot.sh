set term png
#set terminal png size 800,600 font "Helvetica,15" enhanced
set terminal pngcairo dashed size 800,600 font "Helvetica,15" enhanced
set output "corrected_colling_law.png"
set border linewidth 2
set ylabel "temperature"
set xlabel "time"
#set ylabel "time"
#set ylabel "Energy"
#set ylabel "Velocity"
set key left bottom
set grid

set logscale
p [:] [:]\
    "data_t_e:50.dat" w l lw 2 ti "{/Symbol h} = 2" ,\
    "data_t_e:10.dat" w l lw 2 ti "{/Symbol h} = 10" ,\
    "data_t_e:20.dat" w l lw 2 ti "{/Symbol h} = 20" ,\
#    600*x**(-2) w l lw 2 ti "t^{-2}"
#"d_eta5:0.001_Ys:1000_Y:1e+06.dat" u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E-3" ,\
#"d_eta5:0.01_Ys:1000_Y:1e+06.dat"  u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E-2" ,\
#"d_eta5:0.1_Ys:1000_Y:1e+06.dat"   u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E-1" ,\
#"d_eta5:1_Ys:1000_Y:1e+06.dat"     u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E+0" ,\
#"d_eta5:10_Ys:1000_Y:1e+06.dat"    u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E+1" ,\

#"d_eta1:0.001_Ys:1000_Y:1e+06.dat" u 1:8 w l lw 2 ti "{/Symbol g} = 1E-3" ,\
#"d_eta1:0.01_Ys:1000_Y:1e+06.dat"  u 1:8 w l lw 2 ti "{/Symbol g} = 1E-2" ,\
#"d_eta1:0.1_Ys:1000_Y:1e+06.dat"   u 1:8 w l lw 2 ti "{/Symbol g} = 1E-1" ,\
#"d_eta1:1_Ys:1000_Y:1e+06.dat"     u 1:8 w l lw 2 ti "{/Symbol g} = 1E+0" ,\
#"d_eta1:10_Ys:1000_Y:1e+06.dat"    u 1:8 w l lw 2 ti "{/Symbol g} = 1E+1" ,\
#abs (1 - 2 * x) w p pt 2 lt rgb "black"  ti "|1 - 2 {/Symbol d }|"

