#include <iostream>
#include <fstream>
#include <cmath>


using namespace std;


int main() {

	ifstream fileIn;

	fileIn.open ( "output5_7_8.dat" );

	double dx = 0.001;

	const int max_moments = 10;
	
	double moments [ max_moments ] = {0};


	while ( !fileIn.eof() ) {

		double x, f;

		fileIn >> x >> f;
		
		for ( unsigned int i = 0; i < max_moments ; i++ ) {

			double y = x - 0.6;
//			y = x;
			moments [i] += pow ( y, i ) * f;
		}	
		

	}


	for ( unsigned int i = 0; i < max_moments ; i++ ) {

		cout << "moment " << i << " : " << moments [i] * dx << endl;

	}	
		

	fileIn.close ();

	return 0;
}


void chsone ( float bins[], float ebins[], int nbins, int knstrn, float *df,
        float *chsq, float *prob )
/*    Given the array bins[1..nbins] containing the observed numbers of events, and an array
    ebins[1..nbins] containing the expected numbers of events, and given the number of con-
    straints knstrn (normally one), this routine returns (trivially) the number of degrees of freedom
    df , and (nontrivially) the chi-square chsq and the significance prob . A small value of prob
    indicates a significant difference between the distributions bins and ebins . Note that bins
    and ebins are both float arrays, although bins will normally contain integer values. */
{
    float gammq(float a, float x);
    void nrerror(char error_text[]);
    int j;
    float temp;

    *df=nbins-knstrn;
    *chsq=0.0;
    for (j=1;j<=nbins;j++) {
        if (ebins[j] <= 0.0) nrerror("Bad expected number in chsone");
        temp=bins[j]-ebins[j];
        *chsq += temp*temp/ebins[j];
    }

    *prob=gammq(0.5*(*df),0.5*(*chsq));
}

float gammq(float a, float x)
 //   Returns the incomplete gamma function Q(a, x) ≡ 1 − P (a, x).
{
    void gcf(float *gammcf, float a, float x, float *gln);
    void gser(float *gamser, float a, float x, float *gln);
    void nrerror(char error_text[]);
    float gamser,gammcf,gln;
}
if (x < 0.0 || a <= 0.0) nrerror("Invalid arguments in routine gammq");
if (x < (a+1.0)) {
    Use the series representation
        gser(&gamser,a,x,&gln);
    return 1.0-gamser;
    and take its complement.
} else {
    Use the continued fraction representation.
        gcf(&gammcf,a,x,&gln);
    return gammcf;
}
