#include <iostream>
#include <fstream>
#include <cmath>


using namespace std;

double f ( double );

int main (){

	ofstream fileOut;
	
	fileOut.open ( "output5_7_8.dat" );

	double dx = 0.001;

	double integral_f = 0;

	for ( double x = 0; x < 1; x += dx ) {

		integral_f += f( x );

	}

	integral_f *= dx;

	double normalizer_f = 1.0 / integral_f;


	for ( double x = 0; x < 1; x += dx ) {

		fileOut << x << " " << f( x ) * normalizer_f << "\n";

	}

	fileOut.close();

	return 0;
}

double f ( double x ) {

	double arg1 =  x - 0.5;

	double arg2 =  x - 0.7;

	double arg3 =  x - 0.8;

	double f1 = 0.1 * exp ( -1000 * arg1 * arg1 );

	double f2 = 0.5 * exp ( -500 * arg2 * arg2 );

	double f3 = 1.2 * exp ( -1500 * arg3 * arg3 );

	return  f1 + f2 + f3;

}
