#include <iostream>
#include <fstream>
#include <cmath>


using namespace std;


int main() {

	ifstream fileIn;

	fileIn.open ( "output5.dat" );

	double dx = 0.001;

    double x0_min   = -10.0;
    double x0_max   = 10.0;
    double dx0      = 0.001;

    int nx0 = int ( ( x0_max - x0_min ) / dx0 ) ;

	const int max_moments = 10;
	
	double moments [ max_moments ] = {0};


	while ( !fileIn.eof() ) {

		double x, f;

		fileIn >> x >> f;
		
		for ( unsigned int i = 0; i < max_moments ; i++ ) {

            for ( double x0 = x0_min; x0 < x0_max; x0 += dx0 ) {

			    double y = x - x0;

			    moments [i] += pow ( y, i ) * f;

            }
		}	
		

	}


	for ( unsigned int i = 0; i < max_moments ; i++ ) {

		cout << "moment " << i << " : " << moments [i] * dx / double ( nx0 )  << endl;

	}	
		

	fileIn.close ();

	return 0;
}
