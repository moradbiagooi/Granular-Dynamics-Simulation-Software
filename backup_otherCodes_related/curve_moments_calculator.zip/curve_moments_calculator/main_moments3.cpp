#include <iostream>
#include <fstream>
#include <cmath>


using namespace std;


int main() {

	ifstream fileIn;

	fileIn.open ( "output7.dat" );

	double dx = 0.001;

	const int max_moments = 10;
	
	double moments [ max_moments ] = {0};


	while ( !fileIn.eof() ) {

		double x, f;

		fileIn >> x >> f;
		
		for ( unsigned int i = 0; i < max_moments ; i++ ) {

			double y = x - 0.6;
//			y = x;
//			moments [i] += pow ( y, i ) * f;
			moments [i] += pow ( f, i ) ;
		}	
		

	}


	for ( unsigned int i = 0; i < max_moments ; i++ ) {

		cout << "moment " << i << " : " << moments [i] * dx << endl;

	}	
		

	fileIn.close ();

	return 0;
}
