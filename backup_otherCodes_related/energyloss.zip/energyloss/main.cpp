#include <iostream>
#include <fstream>
#include <cmath>
#include <stdlib.h>

using namespace std;


double delta;
double A_1, A_2, A, B, C, phi;  // coefficients
double q, q_1, q_2, omega; // frequencies

double xi  ( double );
double vxi ( double );

int main (){

    double dm    = 0.1;
    double m     = 1 - dm;
    double m_eff = dm * m / ( dm + m );

    double t;
    double dt    = 0.0001;
    double t_max = 0.10;

    int    i_max = int ( t_max / dt );


    double Y     = 1000.0;
    double gamma = 118.0;

    delta = gamma * gamma - 4 * m_eff * Y;

    cout << "delta = " << delta << "\n";

    q     = gamma / ( 2 * m_eff );

    cout << "q = " << q << "\n";

    if ( delta > 0) {

        cout << "Delta > 0\n";



        q_1 =  q + ( sqrt ( delta ) / ( 2 * m_eff ) );
        q_2 =  q - ( sqrt ( delta ) / ( 2 * m_eff ) );

        cout << "q_1 = " << q_1 << "   q_2 = " << q_2 << "\n";

    } else if ( delta == 0 ) {

        cout << "Delta = 0\n";

    } else {

        cout << "Delta < 0\n";

        omega = sqrt ( ( Y / m_eff ) - q * q );

        cout << "omega = " << omega << "\n";
    }

    cout << " 1 - 2 * dm = " << 1 - 2 * dm << "\n";

    ofstream Fdata;

    Fdata.open( "data.dat" );


for ( int j = 0; j < 10; j++) {

    double x_c = 0.5 - double ( rand() ) / double (RAND_MAX) ;
    double x_s = 0.5 - double ( rand() ) / double (RAND_MAX) ;

    double v_c = 0.5 - double ( rand() ) / double (RAND_MAX) ;
    double v_s = 0.5 - double ( rand() ) / double (RAND_MAX) ;


    double x_com  =  dm * x_c  +  m * x_s;
    double v_com  =  dm * v_c  +  m * v_s;
    
    double xi_0   =  x_s  -  x_c;
    double vxi_0  =  v_s  -  v_c;


    if ( delta > 0) {

        A_1 = ( xi_0 * q_1  +  vxi_0 ) / ( q_1  -  q_2 );
        A_2 = ( xi_0 * q_2  +  vxi_0 ) / ( q_2  -  q_1 );

    } else if ( delta == 0 ) {

        A = vxi_0 + q * xi_0;
        B = xi_0;

    } else {
 
        phi   = atan ( ( vxi_0  +  xi_0 * q ) / omega );

        C     = xi_0 / cos ( phi );

    }


    double E_com_mean = 0.0, E_r_mean = 0.0;

    for ( int i = 0; i < i_max; i++ ) {

        t = dt * double ( i ) ;


        double E_r   = ( 2 * v_com + ( 2 * dm - 1 ) * vxi ( t ) ) / ( vxi ( t ) );

        E_r *= E_r;
        E_r_mean += E_r;

        double E_com = (  ( 2 * dm - 1 ) * v_com + 2 * dm * ( dm - 1 ) * vxi ( t ) )  / ( v_com );

        E_com *= E_com;
        E_com_mean += E_com;

        double E_tot = ( v_com * v_com ) + ( dm * (1 - dm) ) * vxi (t) * vxi (t) + Y * xi (t) * xi (t);


//        Fdata << t << " " << E_com << " " << E_r << "\n" ;
//        Fdata << t << " " << xi ( t ) << "\n" ;
//        Fdata << t << " " << E_tot << "\n" ;
//        Fdata << t << " " << E_com << " " << E_r  << " " << xi (t) << " " << vxi (t) << "\n" ;

    }
    Fdata << E_com_mean / i_max << " " << E_r_mean / i_max << "\n";

    Fdata << "\n\n";

}
    Fdata.close();

    cout << "\n";

    return 0 ;
}



double xi ( double t ) {


    if ( delta > 0) {

        return A_1 * exp ( - q_1 * t ) + A_2 * exp ( - q_2 * t );

    } else if ( delta == 0 ) {

        return ( A * t + B ) * exp ( - q * t);

    } else {

        return C * exp ( - q * t ) * cos ( omega * t - phi );

    }

  
}

double vxi ( double t ) {


    if ( delta > 0) {

//        return A_1 * exp ( - q_1 * t ) + A_2 * exp ( - q_2 * t );
        return - q_1 * A_1 * exp ( - q_1 * t ) - q_2 * A_2 * exp ( - q_2 * t );


    } else if ( delta == 0 ) {

//        return ( A * t + B ) * exp ( - q * t );
        return ( A + ( A * t + B ) * ( - q ) ) * exp ( - q * t );

    } else {

//        return C * exp ( - q * t ) * cos ( omega * t - phi );
        return exp ( - q * t ) * C * ( (-q) * cos ( omega * t - phi ) + (- omega ) * sin ( omega * t - phi ) );


    }

  
}
