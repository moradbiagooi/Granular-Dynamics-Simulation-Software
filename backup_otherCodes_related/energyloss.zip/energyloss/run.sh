rm a.out
icpc main.cpp
./a.out
