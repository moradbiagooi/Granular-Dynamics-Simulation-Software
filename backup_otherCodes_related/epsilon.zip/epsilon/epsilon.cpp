#include <fstream>
#include <cmath>

using namespace std;

int main() {

	ofstream file;
	file.open ("eepsilon.dat");

	for (double x = -3.0; x <3.0 ; x+= 0.005){

		double eta = pow (10.0,x);

		if ( eta < 1 ) {
			file << eta << ' ' << 0.5 << endl;
		} else {

		double f = 1.0 / (  (4./3.) * exp( - ( 3. * 3.141592 ) / ( 2. * sqrt ( eta - 1. ) )  )  +  2.  );
		
		file << eta << ' ' << f << endl;

		}

	}

	file.close();



	return 0;
}
