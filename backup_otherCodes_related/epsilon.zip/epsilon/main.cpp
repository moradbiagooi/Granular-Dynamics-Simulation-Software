#include <iostream>
#include <fstream>
#include <cmath>


using namespace std;


inline double my_abs ( double x ) {
    return x < 0 ? -x : x;
}

double xi ( double eta, double delta, double xi_0, double dxi_0, double t );

//##################

int main(){

    double x_s_0 = 0;
    double x_c_0 = 0;

    double v_s_0 = -1;
    double v_c_0 = +1;

    double xi_0  = x_s_0 - x_c_0;

    double dxi_0 = v_s_0 - v_c_0;



    ofstream File;

    double eta   = 0.75;
    double delta = 0.4;


    double v_com = delta * v_c_0 + (1 - delta) * v_s_0;

    File.open ( "e:0.75_d:0.4.dat" );

    for (double t = 0; t < 100; t+= 0.005 ) {

        double _xi = xi ( eta, delta , xi_0, dxi_0, t );

        double DE = ( (2 * delta - 1) * v_com + 2*delta *( 1 - delta ) * _xi    ) / ( v_com );

        double epsilon = my_abs ( DE );

        File << t << ' ' << epsilon << '\n';

    }

    File.close();


    return 0;
}

//------------------

double dxi ( double eta, double delta, double xi_0, double dxi_0,  double t ) {

    double _dxi;

    if ( eta < 1 ) {

        double q_1 = ( 2 / eta ) * ( 1 + sqrt ( 1 - eta ) );

        double q_2 = ( 2 / eta ) * ( 1 - sqrt ( 1 - eta ) );


        double A_1 = ( (xi_0 * q_2) + dxi_0 ) / ( q_2 - q_1 );

        double A_2 = ( (xi_0 * q_1) + dxi_0 ) / ( q_1 - q_2 );
       

        _dxi = - q_1 * A_1 * exp ( - q_1 * t ) - q_2 * A_2 * exp ( - q_2 * t );

    }

    if ( eta > 1 ) {

        double q = 2 / eta;

        double omega = 2 * sqrt ( ( 1 / eta ) - 1 / ( eta * eta ) );

        double phi, c;

        if ( xi_0 == 0 ) {

            phi = 3.14159265 / 2;

            c   =  dxi_0  / omega;


        } else {

            phi = atan ( ( dxi_0 + (xi_0 * q) ) / omega );

            c   = xi_0 / cos ( phi );

        }

        _dxi = exp ( - q * t ) * c * ( - q * cos ( omega * t - phi ) - omega * sin ( omega * t - phi ) );


    }


    return _dxi;
}

//==================

double xi ( double eta, double delta, double xi_0, double dxi_0,  double t ) {

    double _xi;

    if ( eta < 1 ) {

        double q_1 = ( 2 / eta ) * ( 1 + sqrt ( 1 - eta ) );

        double q_2 = ( 2 / eta ) * ( 1 - sqrt ( 1 - eta ) );


        double A_1 = ( (xi_0 * q_2) + dxi_0 ) / ( q_2 - q_1 );

        double A_2 = ( (xi_0 * q_1) + dxi_0 ) / ( q_1 - q_2 );
       

        _xi = A_1 * exp ( - q_1 * t ) + A_2 * exp ( - q_2 * t );

    }

    if ( eta > 1 ) {

        double q = 2 / eta;

        double omega = 2 * sqrt ( ( 1 / eta ) - 1 / ( eta * eta ) );

        double phi, c;

        if ( xi_0 == 0 ) {

            phi = 3.14159265 / 2;

            c   =  dxi_0  / omega;


        } else {

            phi = atan ( ( dxi_0 + (xi_0 * q) ) / omega );

            c   = xi_0 / cos ( phi );

        }

        _xi = exp ( - q * t ) * c * cos ( omega * t - phi );


    }


    return _xi;
}
