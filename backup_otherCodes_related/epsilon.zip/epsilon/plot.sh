set term png
#set terminal png size 800,600 font "Helvetica,15" enhanced
set terminal pngcairo dashed size 800,600 font "Helvetica,15" enhanced
set grid
set border linewidth 2

#set key left top
set key right top
#set key left bottom

#set xlabel "Position"
set xlabel "time"
#set xlabel "Collision number"

#set ylabel "time"
#set ylabel "Energy"
#set ylabel "Velocity"
set ylabel "Restitution Coefficient"
#set ylabel "Collision Duration"
#set ylabel "Free time between Collisions"

set output "rc:e:10_d.png"

p [0:50] [0:2] \
"e:10_d:0.1.dat" w l lw 2 ti "{/Symbol d} = 0.1",\
"e:10_d:0.2.dat" w l lw 2 ti  "{/Symbol d} = 0.2",\
"e:10_d:0.3.dat" w l lw 2 ti  "{/Symbol d} = 0.3",\
"e:10_d:0.4.dat" w l lw 2 ti  "{/Symbol d} = 0.4",\



#p [0:2] [0:1] \
#"e:0.95_d:0.2.dat" w l lw 2 ti "{/Symbol h} = 0.95",\
#"e:0.75_d:0.2.dat" w l lw 2 ti  "{/Symbol h} = 0.75",\
#"e:0.5_d:0.2.dat" w l lw 2 ti  "{/Symbol h} = 0.50",\
#"e:0.25_d:0.2.dat" w l lw 2 ti  "{/Symbol h} = 0.25",\
#"e:0.05_d:0.2.dat" w l lw 2 ti  "{/Symbol h} = 0.05",\

#p [:] [:] \
#"col_nP:2_FT:1_eta4:1_Mc:0.85_Ys:1000_Y:1e+06_EI:1.dat" u 1:4 w p pt 2 pointsize 5 ti ""

#p [1.5:] [:] \
#"col_nP:2_FT:1_eta4:1_Mc:0.85_Ys:1000_Y:1e+06_EI:1.dat" u 1:5 w p  pointsize 5 ti ""



#p [10.98:11.02] [0.48:0.62] \
#"xP_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 3:1 w l lw 2 ti "Core_1.x + 0.5" , \
#"xP_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 4:1 w l lw 2 ti "Core_2.x - 0.5" , \
#"xS_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 3:1 w l lw 2 ti "Shell_1.x + 0.5" , \
#"xS_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 4:1 w l lw 2 ti "Shell_2.x - 0.5" , \



#p [0.48:0.62] [:] \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:2 w l lw 2 ti "E_{com}", \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:5 w l lw 2 ti "E_{r}+U", \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:6 w l lw 2 ti "E_{tot}", \

#p [0.48:0.62] [-1:1] \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:7 w l lw 2 ti "V_{com}", \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:9 w l lw 2 ti "V_{S}", \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:10 w l lw 2 ti "V_{C}", \


#"d_eta5:0.001_Ys:1000_Y:1e+06.dat" u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E-3" ,\
#"d_eta5:0.01_Ys:1000_Y:1e+06.dat"  u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E-2" ,\
#"d_eta5:0.1_Ys:1000_Y:1e+06.dat"   u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E-1" ,\
#"d_eta5:1_Ys:1000_Y:1e+06.dat"     u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E+0" ,\
#"d_eta5:10_Ys:1000_Y:1e+06.dat"    u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E+1" ,\

#"d_eta1:0.001_Ys:1000_Y:1e+06.dat" u 1:8 w l lw 2 ti "{/Symbol g} = 1E-3" ,\
#"d_eta1:0.01_Ys:1000_Y:1e+06.dat"  u 1:8 w l lw 2 ti "{/Symbol g} = 1E-2" ,\
#"d_eta1:0.1_Ys:1000_Y:1e+06.dat"   u 1:8 w l lw 2 ti "{/Symbol g} = 1E-1" ,\
#"d_eta1:1_Ys:1000_Y:1e+06.dat"     u 1:8 w l lw 2 ti "{/Symbol g} = 1E+0" ,\
#"d_eta1:10_Ys:1000_Y:1e+06.dat"    u 1:8 w l lw 2 ti "{/Symbol g} = 1E+1" ,\
#abs (1 - 2 * x) w p pt 2 lt rgb "black"  ti "|1 - 2 {/Symbol d }|"

