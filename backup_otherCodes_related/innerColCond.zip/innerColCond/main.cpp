#include<iostream>
#include<fstream>
#include<cmath>


using namespace std;


double l_free ( double alpha, double beta, double lambda );

double xi ( double eta , double t);

double t_max ( double eta );

//#######################################################
int main(){

    double alpha  = 0.05;
    double beta   = 0.05;
    double lambda = 0.75;



    ofstream fileOut;

    fileOut.open ( "eta_xi.dat" );

    double l = l_free ( alpha , beta , lambda );

    for ( double x=-3.0; x < 3.0; x += 0.01 ) {

        double eta = pow ( 10.0 , x );

        if (abs ( eta - 1.0 ) > 0.01 ) {

            double t = t_max ( eta );

            double _xi = xi ( eta , t );

            fileOut << eta << " " << l / abs ( _xi ) << "\n";
        }

    }

    fileOut.close();   


    return 0;
}
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


double t_max ( double eta ) {

    double _t;

    if ( eta < 1.0 ) {

        double _sqrt = sqrt ( 1.0 - eta ) ;

        _t = ( 4.0 / eta ) * _sqrt * log ( ( 1.0 + _sqrt ) / ( 1.0 - _sqrt ) );

    } else if ( eta > 0.0 ) {

        double _sqrt = sqrt ( eta - 1.0 ) ;

        _t = ( eta / ( 2.0 * _sqrt ) ) * atan ( _sqrt );

    } else {

        cerr << "\nerr\n";

//        exit(0);
        _t = 0.0;


    }

    return _t;

}


//=======================================================

double xi ( double eta, double t ){ // t=t_max


    double _xi;

    if ( eta < 1.0 ) {

        double _sqrt = sqrt ( 1.0 - eta ) ;

        _xi = ( eta / ( 2.0 * _sqrt ) ) * ( 
                + exp ( - ( 2.0 / eta ) * ( 1.0 + _sqrt ) * t ) 
                - exp ( - ( 2.0 / eta ) * ( 1.0 - _sqrt ) * t ) );

    } else if ( eta > 1.0 ) {

        double _sqrt = sqrt ( eta - 1.0 ) ;

        _xi = - ( eta / _sqrt ) * exp ( - ( 2.0 / eta ) * t )
              * sin ( ( 2.0 / eta ) * _sqrt * t );


    } else {

        cerr << "\nerr\n";

        _xi = 0.0;

    }

    return _xi;

}

//-------------------------------------------------
double l_free ( double alpha, double beta, double lambda ){

    return ( 1.0 - alpha - 2.0 * beta ) * ( 1.0 - lambda ) / 2.0;

}
