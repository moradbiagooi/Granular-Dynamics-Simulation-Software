#include<iostream>
#include<fstream>
#include<cmath>


using namespace std;


double l_free ( double alpha, double beta, double lambda );

double xi ( double eta , double t);

double t_max ( double eta );

void f_xs ( double t, double * x_s, double * v_s );


double t_c;
double C_, phi_, omega;
double A_1,A_2, q_1, q_2;


//#######################################################
int main(){

    double alpha  = 0.05;
    double beta   = 0.05;
    double lambda = 0.75;

    double v = 1.0;


    ofstream fileOut;

    fileOut.open ( "eta_xi.dat" );



    double l = l_free ( alpha , beta , lambda );



    for ( double x=-3.0; x < 3.0; x += 0.01 ) {

        double eta = pow ( 10.0 , x );

        if (abs ( eta - 1.0 ) > 0.01 ) {

            double t = t_max ( eta );

            double _xi = xi ( eta , t );

            fileOut << eta << " " << l / abs ( _xi ) << "\n";
        }

    }



    fileOut.close();   


    return 0;
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

void f_kesi ( double t, double & kesi, double & d_kesi) {


    if ( eta < 1.0 ) {

        kesi   = A_1 * exp ( -q_1 ( t - t_c ) ) +
                 A_2 * exp ( -q_2 ( t - t_c ) ) ;

        d_kesi = - q_1 * A_1 * exp ( -q_1 ( t - t_c ) ) 
                 - q_2 * A_2 * exp ( -q_2 ( t - t_c ) ) ;



    } else if ( eta > 1.0 ) {

        kesi   = C_ * exp ( - q * (t - t_c) ) * 
                 cos ( omega * ( t - tc ) - phi_ );

        d_kesi = C_ * exp ( - q * (t - t_c) ) * 
                 ( -q * cos ( omega * ( t - tc ) - phi_ )
                   - omega * sin ( omega * ( t - tc ) - phi_ ) );

    }


}


//-------------------------------------------------------
void f_xs ( double t, double * x_s, double * v_s ){

    double kesi, d_kesi;

    f_kesi ( t, kesi, d_kesi );

    *x_s = v * ( 2.0 * delta - 1.0 ) * t + delta * kesi ( t );

    *v_s = v * ( 2.0 * delta - 1.0 )     + delta * d_kesi ( t );

}

// ------------------------------------------------------
double t_max ( double eta ) {

    double _t;

    if ( eta < 1.0 ) {

        double _sqrt = sqrt ( 1.0 - eta ) ;

        _t = ( 4.0 / eta ) * _sqrt * log ( ( 1.0 + _sqrt ) / ( 1.0 - _sqrt ) );

    } else if ( eta > 0.0 ) {

        double _sqrt = sqrt ( eta - 1.0 ) ;

        _t = ( eta / ( 2.0 * _sqrt ) ) * atan ( _sqrt );

    } else {

        cerr << "\nerr\n";

//        exit(0);
        _t = 0.0;


    }

    return _t;

}


//=======================================================

double xi ( double eta, double t ){ // t=t_max


    double _xi;

    if ( eta < 1.0 ) {

        double _sqrt = sqrt ( 1.0 - eta ) ;

        _xi = ( eta / ( 2.0 * _sqrt ) ) * ( 
                + exp ( - ( 2.0 / eta ) * ( 1.0 + _sqrt ) * t ) 
                - exp ( - ( 2.0 / eta ) * ( 1.0 - _sqrt ) * t ) );

    } else if ( eta > 1.0 ) {

        double _sqrt = sqrt ( eta - 1.0 ) ;

        _xi = - ( eta / _sqrt ) * exp ( - ( 2.0 / eta ) * t )
              * sin ( ( 2.0 / eta ) * _sqrt * t );


    } else {

        cerr << "\nerr\n";

        _xi = 0.0;

    }

    return _xi;

}

//-------------------------------------------------
double l_free ( double alpha, double beta, double lambda ){

    return ( 1.0 - alpha - 2.0 * beta ) * ( 1.0 - lambda ) / 2.0;

}
