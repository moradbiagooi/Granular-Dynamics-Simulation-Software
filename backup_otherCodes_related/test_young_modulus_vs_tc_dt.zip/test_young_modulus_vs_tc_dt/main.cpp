#include <iostream>
#include <cmath>

#define PI 3.14159265


using namespace std;


double epsilon ( double gamma, double Y, double m_eff );

double t_n ( double gamma, double Y, double m_eff );

//--------

int main() {

    double gamma = 0.0;

    double Y = 1000;

    double m_eff = 0.1;

    cout << "t_n = " << t_n ( gamma, Y, m_eff )     << endl;
    cout << "eps = " << epsilon ( gamma, Y, m_eff ) << endl;   


    return 0;

}

//--------

double epsilon ( double gamma, double Y, double m_eff ) {

    double _t_n = t_n ( gamma, Y, m_eff );

    return exp ( - gamma * _t_n / ( 2.0 * m_eff ) ) ;

}

//--------

double t_n ( double gamma, double Y, double m_eff ){

    double _x =  gamma / ( 2.0 * m_eff )  ;

    double _t_n = PI / sqrt ( (Y / m_eff) - ( _x * _x )  );

    return _t_n;
}




