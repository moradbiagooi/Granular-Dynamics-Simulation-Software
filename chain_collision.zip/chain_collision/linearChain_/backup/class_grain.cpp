#include "class_grain.h"
#include "headers.h"

void grain::print_x(){

    cout << "x_s = " << x_s() << "\n";

}
