#ifndef __FUNCTIONS_H
#define __FUNCTIONS_H


void calc_damping_status( int & , double & , double & );

#endif
