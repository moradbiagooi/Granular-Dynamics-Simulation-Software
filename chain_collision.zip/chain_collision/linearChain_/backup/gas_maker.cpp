
#include "gas_maker.h"
#include "pre_processors.h"
#include "class_grain.h"
#include "global_variables.h"
#include "headers.h"
#include "MersenneTwister.h"


extern vector < grain > grains;


void gas_maker ( MTRand * RandNumb) {



//    cout<<"======================make_gas()\n";
//
    double radius_out = 0.5;

    double mean_free_space = ( 1.0 / G_packing_factor ) - 1.0;

    double lx = ( ( 2.0 * radius_out ) + mean_free_space ) * G_no_grains; 

    double grain_x [ G_no_grains ];

#ifdef RandomInitialPosition

// ----------------------- Calculating Sheaths' Random Positions

//    cout << "Making Sheaths Positions: If this part took more than a few seconds, "
//         << "you may have to decrease G_packing_factor... ";

    int grains_counter = 0;

    while ( grains_counter < G_no_grains ) {

        double temp_x = lx * RandNumb -> randDblExc();


        bool flag_freeSpace = true;

        int i = 0;

        while ( flag_freeSpace && i < grains_counter ) {

            double _dist = abs( temp_x - grain_x[i] );

            if ( _dist > lx / 2.0 ) {
                _dist = lx - _dist;
            }

            if ( _dist < 2.0 * radius_out + MIN_INIT_SEPERATION )
                flag_freeSpace = false;

            i++;

        }

        if ( flag_freeSpace ) {

            grain_x[grains_counter] = temp_x;

            grains_counter++;

        }

    }
// -----------------------



// ----------------------- sorting grain_x[] from small to large


    bool flag_disorder = true;

    while ( flag_disorder ) {

        flag_disorder = false;

        for ( int i = 0; i < G_no_grains; i++ ) {

            for ( int j = 0; j < G_no_grains; j++ ) {

                if ( grain_x[i] > grain_x[j] && i < j ) {

                    flag_disorder = true;
                    double temp_x = grain_x[i];
                    grain_x[i]    = grain_x[j];
                    grain_x[j]    = temp_x;

                }

            }

        }

    }
#else

    double _inbetween_distance = lx / double( G_no_grains );

    for ( int i = 0; i < G_no_grains; i++ ) {

        grain_x [i]= mean_free_space/2.0 + double(i) * _inbetween_distance;

    }

#endif
// -----------------------
//  cout << "OK\n" << endl;
//  cout << "lx = " << lx << endl;

    for ( int i = 0; i < G_no_grains; i++ ){


        grain _grain;


        _grain.m_s()     = 1.0 - G_dm;
        _grain.m_c()     = G_dm;


        _grain.x_s()     = grain_x[i];
        _grain.x_c()     = grain_x[i];



/*
#ifdef CoreExists
 #ifdef RandomInitialPosition


        find_new_rnd1:

        double temp_x =  ( 0.5 - RandNumb -> randDblExc() ) * 2  * ( pp.r_mid() - pp.P_r() ); 

        if( abs( temp_x ) + pp.P_r() > pp.r_mid() - min_init_sep)
            goto find_new_rnd1;
    

        _grain.P_x()  = _grain.x() + temp_x; 

 #else

        _grain.P_x()  = _grain.x(); 
 #endif
#endif
*/
// -----------------------



// ----------------------- random velocity
        _grain.v_s()   = ( 0.5 - RandNumb -> randDblExc() ) * 2;
        _grain.v_c()   = _grain.v_s();
/*
#ifdef CoreExists
 #ifdef RandomInitialVelocity
        pp.P_vx() = ( 0.5 - RandNumb -> randDblExc() ) * 2;
 #else
        pp.P_vx() = pp.vx();
 #endif
#endif
*/

// -----------------------

  
   
        grains.push_back( _grain );
//        grains -> push_back( _grain );

    }

    cout << "OK\n" << endl;
    cout << G_no_grains << " grains are made\n" << flush;
    cout << "======================\n";

}


