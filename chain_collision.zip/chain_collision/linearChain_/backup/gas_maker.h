#ifndef __GAS_MAKER_H
#define __GAS_MAKER_H

#include "MersenneTwister.h"
//#include "class_grain.h"
//#include "headers.h"


void gas_maker ( MTRand * RandNumb );

#endif
