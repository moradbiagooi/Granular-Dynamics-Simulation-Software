
#include "main_SpringModel.h"

#include "headers.h"
#include "global_variables.h"

#include "class_grain.h"
#include "MersenneTwister.h"
#include "functions.h"
#include "gas_maker.h"
#include "update_coeff.h"


using namespace std;




vector < grain > grains;
//    class vector < grain > *  grains = new vector < grain >;
//    vector < grain > grains;




int main () {


    class MTRand *RandNumb = new MTRand ( G_random_seed );


    int damping_status;      // -1 for delta < 0 ; 0 for delta ==0 ; +1 for delta > 0


    double omega_1, omega_2; // Frequencies


    calc_damping_status ( damping_status, omega_1, omega_2 );


    gas_maker ( RandNumb );


    update_coeff_all ( damping_status, omega_1, omega_2 );



    for ( int collision = 0; collision < G_max_collisions; collision++ ) {

//        find_next_collision();

    }

    cout << "\n";
 

    return 0;
}





