#ifndef __PRE_PROCESSORS_H
#define __PRE_PROCESSORS_H


#define RandomInitialPosition

#define RandomInitialVelocity

#define MIN_INIT_SEPERATION 0.1 



#endif
