#ifndef __UPDATE_COEFF_H
#define __UPDATE_COEFF_H

void update_coeff_all ( int damping_status, double omega_1, double omega_2 );


#endif
