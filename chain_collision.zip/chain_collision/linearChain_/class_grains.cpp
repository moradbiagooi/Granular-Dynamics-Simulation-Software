#include "class_grains.h"
/*
inline double normalize ( double dx, double L ) {
    while ( dx <- L / 2 ) dx += L;
    while ( dx >= L / 2 ) dx -= L;
    return dx;
}
*/
        
//inline double abs ( double x ) { return x < 0 ? -x : x; }


//====================================================
//==================================================== Grains::
//====================================================


void Grains::create_grains(){

    shells = new Shell* [ G_no_grains ];

    for ( int i = 0; i < G_no_grains; i++ )

        shells[i] = new Shell;

}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::destroy_grains(){

    for ( int i = 0; i < G_no_grains; i++ )

        delete shells[i];

    delete [] shells;
}

//====================================================
//==================================================== Grains::
//====================================================

bool Grains::shell_jumped(){

    for ( int i = 0; i < G_no_grains; i++ ) {

        int j_1,j_2;

        if ( i == G_no_grains - 2  ) {
            j_1 = i+1;
            j_2 = 0;

        } else if ( i == G_no_grains - 1  ) {
            j_1 = 0;
            j_2 = 1;
        } else {
            j_1 = i+1;
            j_2 = i+2;
        }


        double distance_12 = abs ( normalize ( shells[i] -> x() - shells[j_1] -> x(), G_lx ) );
        double distance_13 = abs ( normalize ( shells[i] -> x() - shells[j_2] -> x(), G_lx ) );


        if ( distance_12 > distance_13 ) {

            cout << " Error: two grains jumped of one-another.\n";
            return true;

        }

    }

    return false;

}

//====================================================
//==================================================== Grains::
//====================================================


bool Grains::solve_eq_of_motion(){

    for ( int i = 0; i < G_no_grains; i++ ) {

        shells[i] -> set_force_to_zero();

        shells[i] -> predict ( );

    }


    for ( int i = 0; i < G_no_grains; i++ ){



       
        if ( i+1 < G_no_grains ) { 
            force( shells[i], shells[i+1] ); // LINEAR NEIGHBORS
        }

         if ( i == 0 ){
//            force( shells[i], shells[0] ); // Periodic B.C
            shells[i] -> force_wall ( 0 );
        }
        

    }

    for ( int i = 0; i < G_no_grains; i++ ) {

        shells[i] -> correct ( );

//        shells[i] -> periodic_bc ( );


    }

    return true;

}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::initial_condition ( class Init_Parameters * init_parameters, class MTRand * RandNumb, double vel )
{

    for ( int i = 0; i < G_no_grains; i++ ) {

        shells[i] -> set_parameters ( init_parameters, RandNumb );

        shells[i] -> pbc_index () = 0;

    }


/*
    double alpha    = init_parameters -> alpha  ();
    double beta     = init_parameters -> beta   ();
    double lambda   = init_parameters -> lambda ();


    double radius_out   = 0.5 * ( 1.0 - lambda );
    double radius_mid   = radius_out * ( 1.0 - 2.0 * beta );
    double radius_core  = radius_out * alpha;
*/


    for ( int i = 0; i < G_no_grains; i++ ) {

        shells[i] -> x()    = double(i) + double(5);

        shells[i] -> vx()   = - vel ;


    }



//
}
//====================================================
//==================================================== Grains::
//====================================================


double Grains::energy_com() {

    double E = 0;

//    for ( int i = 0; i < G_no_grains; i++ )

//        E += shells[i] -> E_com ();

    return E;
}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::output_data ( double time, ofstream & ofs_energy ) {

//    ofs_energy  << time << " " << energy_com() << "\n" ;
/*
    ofs_energy  << time << " " 
                << shells[0] -> x() + shells[0] -> r() + shells[0] -> pbc_index() * G_lx << " " 
                << shells[0] -> x() - shells[0] -> r() + shells[0] -> pbc_index() * G_lx << " "  
                << shells[1] -> x() + shells[1] -> r() + shells[1] -> pbc_index() * G_lx << " " 
                << shells[1] -> x() - shells[1] -> r() + shells[1] -> pbc_index() * G_lx << "\n" << flush;
*/
/*
    ofs_energy  << time << " " 
                << shells[0] -> x()         + shells[0] -> r()         + shells[0] -> pbc_index() * G_lx << " " 
                << shells[0] -> x()         - shells[0] -> r()         + shells[0] -> pbc_index() * G_lx << " "  
                << shells[1] -> x()         + shells[1] -> r()         + shells[1] -> pbc_index() * G_lx << " " 
                << shells[1] -> x()         - shells[1] -> r()         + shells[1] -> pbc_index() * G_lx << " "
                << shells[0] -> Core_x()    + shells[0] -> Core_r()    + shells[0] -> pbc_index() * G_lx << " " 
                << shells[0] -> Core_x()    - shells[0] -> Core_r()    + shells[0] -> pbc_index() * G_lx << " "  
                << shells[1] -> Core_x()    + shells[1] -> Core_r()    + shells[1] -> pbc_index() * G_lx << " " 
                << shells[1] -> Core_x()    - shells[1] -> Core_r()    + shells[1] -> pbc_index() * G_lx << "\n" << flush;
*/

    ofs_energy  << time << " ";

    for ( int i = 0; i < G_no_grains; i++ ) {

        ofs_energy  << shells [i] -> x()  +  shells [i] -> pbc_index() * G_lx << " ";

    }


    ofs_energy << "\n" << flush;



//    cout        << time << " " << energy_com() << "\n" ;
}

//====================================================
//==================================================== Grains::momentum_tut()
//====================================================
double Grains::momentum_tot()
{

    double momentum = 0.;

    for ( int i = 0; i < G_no_grains; i++ )
        momentum += shells [i] -> vx() * shells [i] -> m();

    return momentum;

}


//====================================================
//==================================================== Grains::
//====================================================


