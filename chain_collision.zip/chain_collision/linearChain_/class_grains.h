#ifndef _CLASS_GRAINS_H
#define _CLASS_GRAINS_H

#include "headers.h"
#include "class_shell.h"
#include "global_variables.h"
#include "MersenneTwister.h"


using namespace std;



class Grains {


    public:


        Grains(){};

        ~Grains() { destroy_grains (); }


        class Shell     **shells;


        void create_grains ();

        void destroy_grains ();

        void initial_condition ( class Init_Parameters *, class MTRand *, double vel );

        void set_initial_temperature ( double T0 );

        void output_data ( double time, ofstream & );


        bool solve_eq_of_motion ();

        bool shell_jumped();


        int gas_is_homogeneous();

        double momentum_tot ();
        double energy_com ();

        void mass_assign (int i, double mass ) { shells [i] -> m() = mass ; };

        double shells_x_0() { return shells [0] -> x(); };

        double shells_x_com()
        {
            double x;
            double m;
            for (int i=0; i < G_no_grains; i++)
            {
                x += shells [i] -> m() * shells [i] -> x();
                m += shells [i] -> m();
            }
            return x / m;

        }

        double shells_x_length() 
        {
            return abs ( shells [0] -> x() - shells [G_no_grains - 1] -> x() );
        }


};

#endif
