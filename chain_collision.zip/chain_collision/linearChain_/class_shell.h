#ifndef _CLASS_SHELL_H
#define _CLASS_SHELL_H

#include "headers.h"
#include "MersenneTwister.h"
#include "class_init_parameters.h"


//using namespace std;

//inline double abs ( double x ) { return x < 0 ? -x : x; }


inline double normalize ( double dx, double L ) {
    while ( dx <- L / 2 ) dx += L;
    while ( dx >= L / 2 ) dx -= L;
    return dx;
}



class Shell {

    friend void force ( Shell * p1, Shell * p2 );
    
public:

    Shell(): rtd0(0), rtd1(0), rtd2(0), rtd3(0), rtd4(0)
    {}

    int & pbc_index()       {return _pbc_index;} 
    int   pbc_index() const {return _pbc_index;} 

    double & x()            {return rtd0;}
    double   x() const      {return rtd0;}

    double & vx()           {return rtd1;}
    double   vx() const     {return rtd1;}


    double & r()            {return _r;}
    double   r() const      {return _r;}

    double & r_mid()        {return _r_mid;}
    double   r_mid() const  {return _r_mid;}

    double   m() const      {return _m;}
    double & m()            {return _m;}

    double & Y()            {return _Y;}
    double   Y() const      {return _Y;}

    double & A()            {return _A;}
    double   A() const      {return _A;}

    double   f()   const    {return _force;}

    void predict ( );                        //First step of the Gear algorithm

    void correct ( );                        //Second step of the Gear algorithm



    void set_force_to_zero(){
        _force=0;
    }

    void add_force ( const double & f )
    {   _force+=f; }                                //Adds a value to the total force _force of the Shell


    void periodic_bc ( );        //Enforces the periodic boundary conditions


    void force_wall ( double  wall_x );

    void set_parameters ( class Init_Parameters *, class MTRand * );


private:

    int _pbc_index;

    double _r, _m, _r_mid;
    double _Y, _A;


    double rtd0,rtd1,rtd2,rtd3,rtd4;
    double _force;

};


#endif
