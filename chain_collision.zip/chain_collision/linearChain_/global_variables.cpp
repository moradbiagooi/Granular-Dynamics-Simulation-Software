
#include "global_variables.h"


const long    G_random_seed     = 30;

const int     G_no_grains       = 20;

const double  G_lx              = double ( 5 * G_no_grains );

//const double  G_Y               = 1000.0;
//const double  G_gamma           = 1.0;
//const double  G_packing_factor  = 0.05;
//const double  G_radius          = 0.5;

const double  G_dt              = 1E-4;
//const double  G_time_final      = 1000.0;


