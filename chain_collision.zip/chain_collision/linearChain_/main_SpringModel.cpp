
#include "main_SpringModel.h"
#include "headers.h"
#include "global_variables.h"
#include "class_grains.h"
#include "MersenneTwister.h"
#include "functions.h"
#include "v_com_zero.h"
#include "class_init_parameters.h"


using namespace std;

void run_ensemble();
void run_one_collision();
void mass_read_from_file (double *, int i);

//==================================
//==================================
//==================================


int main () {

    clock_t time_start, time_end;
    time_start = clock ();
    
    
    run_ensemble();
//    run_one_collision();



    time_end = clock ();
    double total_time =  ( (float)time_end - (float)time_start ) / CLOCKS_PER_SEC; 
    cout << "\n\n  Total execution time: "  << total_time << " seconds\n\n" ;

    return 0;
}


//==================================
//==================================
//==================================

void mass_read_from_file (double *mass_list, int i)
{
    ifstream file_people ( "output_ga_people.txt" );
    double m;
    for ( int j = 0; j < i; j++)
      for ( int k = 0; k < G_no_grains; k++)
          file_people >> m;

    for ( int k = 0; k < G_no_grains; k++)
    {
          file_people >> mass_list[k];
          cout << k <<" " <<mass_list[k]<< endl;
    }


}

void run_ensemble()
{



    ofstream of_rc_vel;
    of_rc_vel.open ( "output_rc_vel.txt" );

    double mass_list [G_no_grains];

    mass_read_from_file ( mass_list, 1);

    
    for ( double x = -1.0; x < 0.0; x += 0.01 ) {

        double vel = pow ( 10.0, x );



        class MTRand    *RandNumb = new MTRand ( G_random_seed );

        class Grains    *grains   = new Grains;

        class Init_Parameters   *init_parameters = new Init_Parameters;





        init_parameters -> debug_parameters ();
        init_parameters -> make_parameters  ();



        grains -> create_grains ();

        grains -> initial_condition ( init_parameters, RandNumb, vel );
// /*
        for ( int i = 0; i < G_no_grains; i++ )
        {
 
            grains -> mass_assign (i, mass_list[i]);
        }
// */
        double initial_momentum = grains -> momentum_tot();


        long i = 0;

        bool collision_finished = false;

        while( ! collision_finished ) {

//            double time = double (i) * G_dt;

            if ( !grains -> solve_eq_of_motion () ) 

                collision_finished = true;


            if ( grains -> momentum_tot() > 0. )
            { 
                if ( grains -> shells_x_0() > G_no_grains ) // check this condition for unusual mass-spring distributions
                    collision_finished = true;
            }

            i++;
            
        }



        double final_momentum = grains -> momentum_tot();

        of_rc_vel << vel << " " <<  - final_momentum / initial_momentum << endl<<flush; 
        cout      << vel << " " <<  - final_momentum / initial_momentum << endl<<flush;    

//    cout << "RC : " << - final_momentum / initial_momentum << endl;
        
/*
*/


//    ofs_energy.close ();


//    grains -> destroy_grains ();

    delete grains;

    delete RandNumb;

    delete init_parameters;

    }
    
    of_rc_vel.close();



}

//==================================
//==================================
//==================================

void run_one_collision()
{


    double vel = 30.0;


    class MTRand    *RandNumb = new MTRand ( G_random_seed );

    class Grains    *grains   = new Grains;

    class Init_Parameters   *init_parameters = new Init_Parameters;



    ofstream ofs_energy;

    ofs_energy.open ( "output_x_t.txt" );



    init_parameters -> debug_parameters ();
    init_parameters -> make_parameters  ();



    grains -> create_grains ();

    grains -> initial_condition ( init_parameters, RandNumb, vel );






    double initial_momentum = grains -> momentum_tot();



    long i = 0;

    bool collision_finished = false;

    while( ! collision_finished ) {


        double time = double (i) * G_dt;


        if ( !grains -> solve_eq_of_motion () ) 

            collision_finished = true;
        

        if ( i % 100 == 0 ) {


//            cout << "time  " << time <<"\t" << - grains -> momentum_tot() / initial_momentum << endl;

            grains -> output_data ( time, ofs_energy );

        }




        if ( grains -> momentum_tot() > 0. )
        { 
            if ( grains -> shells_x_0() > G_no_grains ) // check this condition for unusual mass-spring distributions
                collision_finished = true;
        }

        i++;

    }


    double final_momentum = grains -> momentum_tot();

    cout << "RC : " << - final_momentum / initial_momentum << endl;
        

    ofs_energy.close ();


    grains -> destroy_grains ();

    delete grains;

    delete RandNumb;

    delete init_parameters;

       


}

