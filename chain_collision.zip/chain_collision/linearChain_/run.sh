rm a.out *~
#icpc *.cpp *.h
g++ -g -Wall *.cpp
./a.out
