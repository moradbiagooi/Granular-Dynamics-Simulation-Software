#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H


//void calc_damping_status( int & , double & , double & );

#endif
