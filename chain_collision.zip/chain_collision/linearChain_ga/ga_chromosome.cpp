#include "ga_chromosome.h"

void GA_Chromosome::new_rand_chrom ( class MTRand * randnumb )
{

    for ( unsigned int i = 0; i < NO_GENES; i++ )
    {
        double r =  randnumb -> randDblExc();

        _gene [i] = r ;
    }
}

void GA_Chromosome::parents ( int p1, int p2 ) 
{ 
    _parent_1 = p1;
    _parent_2 = p2; 
}

