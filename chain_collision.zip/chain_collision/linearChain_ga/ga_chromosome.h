#ifndef _GA_CHROMOSOME_H
#define _GA_CHROMOSOME_H

#include "headers.h"
#include "ga_macros.h"
#include "MersenneTwister.h"


class GA_Chromosome
{

public:


    GA_Chromosome ( )
    {
         _gene.resize ( NO_GENES );
    }

    ~GA_Chromosome ()   {  }

    void     new_rand_chrom ( class MTRand * );


    double & gene ( int i )       { return _gene[i]; }
    double   gene ( int i ) const { return _gene[i]; }

    int      parent_1 ()    const { return _parent_1; }
    int      parent_2 ()    const { return _parent_2; }

    void     parents ( int p1, int p2 );

    bool same_parents ( GA_Chromosome &c );



private:

    vector < double > _gene;
    int _parent_1,_parent_2;
};

#endif
