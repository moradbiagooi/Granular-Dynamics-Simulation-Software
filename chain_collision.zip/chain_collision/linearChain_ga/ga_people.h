#ifndef _CLASS_GA_PEOPLE_H
#define _CLASS_GA_PEOPLE_H

#include "headers.h"
#include "MersenneTwister.h"
#include "ga_chromosome.h"
#include "ga_macros.h"


class GA_People
{
    friend void GA_Chromosome_Copy ( class GA_People * best_people, int i, class GA_People * other_people, int j ); 

    public:

/*    GA_People () {};
    ~GA_People () {};*/
    GA_People ( ) 
    {
        _fitness.resize     ( NO_PEOPLE );
        _pr_fitness.resize  ( NO_PEOPLE );     
        _chromosomes.resize ( NO_PEOPLE );

    };

    ~GA_People ()   { };


    void print_data () { cout << "lala\n"; }

    void make_ran_people ( class MTRand * );

    void make_ran_child  ( class MTRand *, int i );

    void add_child ( GA_Chromosome &c, int i );

    int ran_select_by_fitness ( class MTRand * );

    void calc_tot_fitness();

    void normalize_fitness();

    double tot_fitness () const { return _tot_fitness; }

    double & fitness (int i)       { return _fitness [i]; }
    double   fitness (int i) const { return _fitness [i]; }

    double & pr_fitness (int i)       { return _pr_fitness [i]; }
    double   pr_fitness (int i) const { return _pr_fitness [i]; }

    int      no_people () const { return _chromosomes.size(); }


    bool same_parents ( int c1, int c2 )
    {
        int c1p1 = _chromosomes[c1].parent_1();
        int c1p2 = _chromosomes[c1].parent_2();
        int c2p1 = _chromosomes[c2].parent_1();
        int c2p2 = _chromosomes[c2].parent_2();
        return    (c1p1==c2p1) && (c1p1==c2p2) 
               && (c1p2==c2p1) && (c1p2==c2p2); 
    }

    double gene_of_chrom ( int chr_i, int gen_i ) const { return _chromosomes [ chr_i ].gene ( gen_i ); }




    private:
    vector < double >  _fitness, _pr_fitness;
    vector < GA_Chromosome > _chromosomes;
    double  _tot_fitness, _tot_pr_fitness;



};

#endif
