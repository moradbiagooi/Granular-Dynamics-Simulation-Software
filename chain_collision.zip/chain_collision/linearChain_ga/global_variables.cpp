
#include "global_variables.h"
#include "ga_macros.h"

const long    G_random_seed     = 30;

const int     G_no_grains       = NO_GENES;

const double  G_lx              = double ( 5 * G_no_grains );

const double  G_dt              = 1E-4;



