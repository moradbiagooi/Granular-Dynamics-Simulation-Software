#ifndef _HEADERS_H
#define _HEADERS_H


#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <time.h>
#include <sys/stat.h>
#include <string>
//#include <omp.h>

using namespace std;

#endif

