reset
rm a.out *~
#c++ -g -Wall *.cpp
c++ -Wall -fopenmp *.cpp
./a.out
