#define GA_FITNESS_FUNCTION(ga,ktype) 	\
		if (rank == root)	\
		{	\
			 	int cal_size = NO_PEOPLE;\
	    	if ( ktype == 2 )\
						cal_size = ga -> re_cal_list[0].size() + ga -> re_cal_list[1].size();\
				if(cal_size==0) do_nothing = 1;else do_nothing = 0;\
				int rec_data [ pr_size ];\
				for (int i = 0; i <pr_size; i++)\
						rec_data [i] = cal_size / pr_size;\
				int res_size = cal_size % pr_size;\
				for (int i = 0; i <res_size; i++)\
						rec_data [i] ++;\
				start_table [0] = 0;\
				for (int i = 1; i <pr_size; i++)\
						start_table [i] = start_table [i-1] + rec_data[i-1];\
				start_table [pr_size] = cal_size;\
				for (int i = 0; i <pr_size; i++)\
	  				no_fitness[i] =  start_table [i+1] - start_table [i];\
				no_fitness[pr_size]=0;			\
		}\
		if(ktype==2) \
				MPI_Bcast(&do_nothing,1,MPI_INT,0,MPI_COMM_WORLD);\
		if ( rank == root )\
		{\
    		if ( ktype == 2) \
				{\
						if ( do_nothing == 0 )\
   					{\
						int k = 0;\
        		for ( unsigned int i = 0 ; i < ga -> re_cal_list[0].size(); i++ )\
        		{\
								int l = ga -> re_cal_list[0][i];\
			          for ( int j = 0; j < NO_GENES; j++ )\
      		      {\
           			    genes[k] [j] = ga -> gene_people ( l , j, 0 );\
         		 		}\
								k++;\
        		}\
        		for ( unsigned int i = 0 ; i < ga -> re_cal_list[1].size(); i++ )\
        		{\
								int l = ga -> re_cal_list[1][i];\
           			for ( int j = 0; j < NO_GENES; j++ )\
           			{\
               			genes[k] [j] = ga -> gene_people ( l , j, 1 );\
          			}\
								k++;\
						}}\
    		} \
    		else\
    		{\
        	for ( int i = 0; i < NO_PEOPLE; i++ )\
        	{\
            		for ( int j = 0; j < NO_GENES; j++ )\
            		{\
                		genes [i][j] = ga -> gene_people ( i , j, ktype );\
            		}\
\
        		}\
    		}\
		}\
		MPI_Bcast (start_table, pr_size+1, MPI_INT, 0, MPI_COMM_WORLD);\
		MPI_Bcast (genes, NO_PEOPLE*NO_GENES, MPI_DOUBLE, 0, MPI_COMM_WORLD);\
		MPI_Bcast (start_table, pr_size+1, MPI_INT, 0, MPI_COMM_WORLD);\
		MPI_Bcast (no_fitness, pr_size+1, MPI_INT, 0, MPI_COMM_WORLD);\
		MPI_Barrier ( MPI_COMM_WORLD );\
 		if ( ktype == 2) \
		{\
				if ( do_nothing == 0 )\
				{\
        for ( int i = start_table[rank]; i < start_table[rank+1]; i++ )\
				{\
            for ( int j = 0; j < NO_GENES; j++ )\
            {\
                gene [j] = genes[i][j];\
            }\
            double fitness_value;\
            ga_run_code ( gene , fitness_value );\
						fitness[i] = fitness_value;\
				}}\
\
    } \
    else\
    {\
       for ( int i = start_table[rank]; i < start_table[rank+1]; i++ )\
        {\
            for ( int j = 0; j < NO_GENES; j++ )\
            {\
                gene [j] = genes[i][j];\
            }\
            double fitness_value;\
            ga_run_code ( gene , fitness_value );\
						fitness[i]=fitness_value;\
        }\
    }\
\
		MPI_Barrier ( MPI_COMM_WORLD );\
		if ( rank != root)\
				MPI_Send ( fitness+start_table[rank], no_fitness[rank], MPI_DOUBLE,root,0, MPI_COMM_WORLD);\
		MPI_Barrier ( MPI_COMM_WORLD );\
		if ( rank == root)\
		{	\
				for (int i=1; i<pr_size; i++)\
						MPI_Recv ( fitness+start_table[i], no_fitness[i], MPI_DOUBLE,i,0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);\
		}\
\
		if ( rank == root )\
		{\
    		if ( ktype == 2) \
				{\
						if ( do_nothing == 0 )\
   					{\
						int k = 0;\
        		for ( unsigned int i = 0 ; i < ga -> re_cal_list[0].size(); i++ )\
        		{\
								int l = ga -> re_cal_list[0][i];\
								ga -> assign_fitness ( l, fitness[k], 0 );\
								k++;\
        		}\
        		for ( unsigned int i = 0 ; i < ga -> re_cal_list[1].size(); i++ )\
        		{\
								int l = ga -> re_cal_list[1][i];\
								ga -> assign_fitness ( l, fitness[k], 1 );\
								k++;\
						}}\
    		} \
    		else\
    		{\
        		for ( int i = 0; i < NO_PEOPLE; i++ )\
        		{\
								ga -> assign_fitness ( i, fitness[i], ktype );\
       			}\
    		}\
		}\

#include <mpi.h>

#include "ga_functions.h"

void genetic_algorithm_run ()
{
		int root = 0 , rank , pr_size;
		double gene [ NO_GENES ];	
  	double genes [ NO_PEOPLE ][ NO_GENES ]; //input
		double fitness [ NO_PEOPLE ] ;					//output

		int start_table [ pr_size + 1 ];
		int no_fitness  [ pr_size + 1 ];
		int do_nothing = 0;
		
    class Genetic_Algorithm * ga;


		MPI_Init(NULL,NULL);
		MPI_Comm_rank (MPI_COMM_WORLD, &rank);
		MPI_Comm_size (MPI_COMM_WORLD, &pr_size);

		if (rank == root)
		{
    		ga = new Genetic_Algorithm ( );
    		ga -> initiate ( ); // make a random generation and call it old_people;
		}

 		GA_FITNESS_FUNCTION ( ga, 0 ); // check the fitness of old_people;

		if (rank == root)
    		ga -> output_generation_stat ( ); // output old_people statistic; 
	

    for ( int i = 0; i < GA_NO_GENERATIONS; i++ )
    {
			
				if (rank == root)
				{
        		cout << "\n generation: " << i << " ,\t" << flush;;
	       		ga -> make_new_people  ( ); // cross-over old_people by their fitness to make new_people with the same number.
				}

   			GA_FITNESS_FUNCTION ( ga, 1 ); // check the fitness of new_people

				
				if (rank == root)
				{
        		ga -> similar_people_check ();
				}

      	GA_FITNESS_FUNCTION ( ga, 2 ); // needs a total revision for parallel 

				if (rank == root)
				{
        		ga -> find_best_people ( );  // compare old_people and new_people. find best_people of them. then old_people = best_people.
        		ga -> output_generation_stat ( ); // output old_people statistics;
				}

//      here can be a function which stops the generation if a good answer has been found.


    }

		if (rank == root)
		{
    		ga -> output_generation_people ( ) ; // output old_people chromosomes;
    		delete ga;
		}

		MPI_Finalize();
		
}
#undef GA_FITNESS_FUNCTION
//  a prototype for ga_run_code

/*
void ga_run_code ( double * gene, double & fitness_value )
{

    double sum = 0.0;

    for ( int i = 0; i < NO_GENES; i++)
    {
        double f =  ( double (i) - (double (NO_GENES)/2))/double (NO_GENES) ; //??

        sum += abs ( (f * f) - gene[i] ); 
    }

    fitness_value = sum; // all of fitness values has to be positive, and a better fitness is a smaller value. the best fitness has to be zero;

}
*/
