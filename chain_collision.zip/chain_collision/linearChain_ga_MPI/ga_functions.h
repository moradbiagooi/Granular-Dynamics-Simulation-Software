#ifndef _GA_FUNCTIONS
#define _GA_FUNCTIONS

#include "ga_genetic_algorithm.h"
#include "ga_chromosome.h"
#include "ga_people.h"
#include "ga_macros.h"
#include "ga_functions.h"

void genetic_algorithm_run ();

void ga_run_code ( double * gene, double & fitness_value ); //there's a prototype of this function in "ga_functions.cpp"

#endif
