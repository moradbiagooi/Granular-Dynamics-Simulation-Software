#ifndef _GA_MACROS_H
#define _GA_MACROS_H

#define GA_NO_GENERATIONS   100
#define GA_RAND_SEED        5
#define NO_PEOPLE           10 //an even number
#define NO_GENES            20
#define PROB_MUTATION       0.1 //0.05 
#define PR_FITNESS_LIMIT    0.000001 // used in GA_People::normalize_fitness to avoid some bugs. not sure about it.
// #define PROB_CROSS_OVER     0.75 // isn't 

#endif
