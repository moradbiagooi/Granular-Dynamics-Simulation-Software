
#include "main_SpringModel.h"
#include "headers.h"
#include "global_variables.h"
#include "class_grains.h"
#include "MersenneTwister.h"
#include "functions.h"
#include "v_com_zero.h"
#include "class_init_parameters.h"


#include "ga_macros.h"
#include "ga_functions.h"
#include "ga_headers.h"


using namespace std;

void run_ensemble();
void run_one_collision();

//==================================
//==================================
//==================================


int main () {

    clock_t time_start, time_end;
    time_start = clock ();
    
    genetic_algorithm_run ();

    time_end = clock ();
    double total_time =  ( (float)time_end - (float)time_start ) / CLOCKS_PER_SEC; 
    cout << "\n\n  Total execution time: "  << total_time << " seconds\n\n" ;

    return 0;
}



void ga_run_code ( double * gene, double & fitness_value )
{

    double sum = 0.0;

//    cout << "r" <<flush;
    
    for ( double x = -2.0; x < 0.0; x += 0.2 ) {

        double vel = pow ( 10.0, x );
//        cout << vel << " " << flush;
        class MTRand    *RandNumb = new MTRand ( G_random_seed );

        class Grains    *grains   = new Grains;

        class Init_Parameters   *init_parameters = new Init_Parameters;

        init_parameters -> debug_parameters ();
        init_parameters -> make_parameters  ();

        grains -> create_grains ();

        grains -> initial_condition ( init_parameters, RandNumb, vel );

        for ( int i = 0; i < NO_GENES; i++ )
        {
            grains -> mass_assign (i ,  gene [i] );
        }

        double initial_momentum = grains -> momentum_tot();

        long i = 0;

        bool collision_finished = false;

        while( ! collision_finished ) {

            if ( !grains -> solve_eq_of_motion () ) 

                collision_finished = true;
        

            if ( grains -> momentum_tot() > 0. )
            { 
                if ( grains -> shells_x_0() > G_no_grains ) // check this condition for unusual mass-spring distributions
                    collision_finished = true;
            }

            i++;

        }


        double final_momentum = grains -> momentum_tot();
        double rc = final_momentum / initial_momentum;

        double f_target = -(vel*vel/10) + 1;

        sum += abs ( rc - f_target );

    delete grains;

    delete RandNumb;

    delete init_parameters;

    }

    fitness_value = sum;

}

//==================================
//==================================
//==================================
/*
void run_one_collision()
{


    double vel = 30.0;


    class MTRand    *RandNumb = new MTRand ( G_random_seed );

    class Grains    *grains   = new Grains;

    class Init_Parameters   *init_parameters = new Init_Parameters;



    ofstream ofs_energy;

    ofs_energy.open ( "output_x_t.txt" );



    init_parameters -> debug_parameters ();
    init_parameters -> make_parameters  ();



    grains -> create_grains ();

    grains -> initial_condition ( init_parameters, RandNumb, vel );






    double initial_momentum = grains -> momentum_tot();



    long i = 0;

    bool collision_finished = false;

    while( ! collision_finished ) {


        double time = double (i) * G_dt;


        if ( !grains -> solve_eq_of_motion () ) 

            collision_finished = true;
        

        if ( i % 100 == 0 ) {


//            cout << "time  " << time <<"\t" << - grains -> momentum_tot() / initial_momentum << endl;

            grains -> output_data ( time, ofs_energy );

        }




        if ( grains -> momentum_tot() > 0. )
        { 
            if ( grains -> shells_x_0() > G_no_grains ) // check this condition for unusual mass-spring distributions
                collision_finished = true;
        }

        i++;

    }


    double final_momentum = grains -> momentum_tot();

    cout << "RC : " << - final_momentum / initial_momentum << endl;
        

    ofs_energy.close ();


    grains -> destroy_grains ();

    delete grains;

    delete RandNumb;

    delete init_parameters;

       


}
*/
