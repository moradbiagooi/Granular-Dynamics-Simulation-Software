reset
rm a.out *~
#c++ -g -Wall *.cpp *.h
mpic++ -Wall *.cpp
mpirun -np 2 a.out
