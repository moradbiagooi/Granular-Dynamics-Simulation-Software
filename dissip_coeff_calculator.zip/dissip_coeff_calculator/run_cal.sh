g++ -o disp_calc main_disp_calc.cpp
./disp_calc
rm disp_calc
