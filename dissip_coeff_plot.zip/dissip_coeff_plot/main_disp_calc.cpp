#include <iostream>
#include <math.h>
#include <fstream>

#define ParticlesExist

#define PI 3.14159265
#define _Y 100000

using namespace std;


double rest_coef(double, double); // Dissipation coeff., m_eff

double m_eff_cal(double); // Alpha

double find_epsilon(double, double); // requested epsilon, m_eff // returns related Dissipation coeff

//###############################################

inline double abs(double x) {
  if (x<0.0) 
    return -x;
  else 
    return x;
}

int main (){

  double Alpha = 0.7;

  double m_eff = m_eff_cal(Alpha);
 
  double epsilon = 0.9995;

  double gamma = find_epsilon( epsilon, m_eff );


  cout << "\nDissipation coefficient = " << gamma 
       << "\nRestitution coefficient = " << rest_coef (gamma, m_eff);
  cout << "\nYoung Modulus ="<< _Y << "\n";
#ifdef ParticlesExist
  cout << "\nAlpha = " << Alpha;
  cout << "\nBeta  = 0.1\n";
  cout << "\nParticlesExist\n\n";
#else
  cout << "\nNo Particles\n\n";
#endif

  return 0;

}

// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
double find_epsilon(double epsilon, double m_eff){

  ofstream of;

  of.open("output.dat");

  int i_max = 1000000;
  
  double gamma     = 0;
  double gamma_max = 1000;

  double d_gamma= ( gamma_max - gamma ) / double( i_max );

  double best_gamma = 10.0;

  double nearest_value=10.0;

  for ( unsigned int i = 0; i<i_max; i++ ){


    of << gamma << " " << rest_coef ( gamma, m_eff ) << "\n";

    gamma += d_gamma;

  }

  of.close();

  return best_gamma;

}

//  ---------------------------------------------
//  ---------------------------------------------
//  ---------------------------------------------

double m_eff_cal ( double Alpha ) {

  double Beta  = 0.1;

#ifdef ParticlesExist

  double r_mid = 0.5 * ( 1.0 - 2.0 * Beta);
  double P_r   = 0.5 * Alpha;

  double S_m   =  2.0 * (0.5 - r_mid);
  double P_m   =  2.0 * P_r;

  double _m_eff = (S_m * P_m) / (S_m + P_m);  

#else

  double S_m    = 1.0; 

  double _m_eff = S_m / 2.0; 

#endif

  return _m_eff;

}

//  =============================================
//  =============================================
//  =============================================

double rest_coef (double _gamma, double _m){ 


  double _epsilon; // coefficient of restitution.

//  double _m       = _m_eff; 

  double _beta    = _gamma / (2.0 * _m);

  double _omega_0 = sqrt ( _Y / _m );


  if (_beta < (_omega_0 / sqrt(2.0))){
    double _omega   = sqrt (+_omega_0*_omega_0 - _beta*_beta);
    _epsilon = exp(-(_beta/_omega) *  (PI - atan ( (2.0 * _beta * _omega) / (_omega*_omega - _beta*_beta) )  ) ) ;
  }
  else if (_beta <= _omega_0) {
    double _omega   = sqrt (+_omega_0*_omega_0 - _beta*_beta);
    _epsilon = exp(+(_beta/_omega) *  (atan ( (2.0 * _beta * _omega) / (_omega*_omega - _beta*_beta) )  ) ) ;

  }
  else {
    double _OMEGA  = sqrt (-_omega_0*_omega_0 + _beta*_beta);
    _epsilon = exp(-(_beta/_OMEGA) * log ((_beta + _OMEGA) / (_beta - _OMEGA) ) ); 
  }


return _epsilon;

}

