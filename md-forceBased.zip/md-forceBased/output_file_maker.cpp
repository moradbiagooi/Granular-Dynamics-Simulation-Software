#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sys/stat.h> // used for mkdir()


#include "output_file_maker.h"
#include "Sheath.h"


using namespace std;


extern vector < Sheath > Sheaths;


extern ofstream FileDataOut;     // system parameters and simulation data
extern ofstream FileT;           // gas temperature vs time
extern ofstream FileX_S_A;    // ASSCI counterpart of X_S
extern ofstream FileX_S;       // Sheaths' position in total coordinates vs time
extern ofstream FileX_P;         // Particles' position vs 
extern ofstream FileV_S;           // Sheath's velocity vs time 
extern ofstream FileV_P;         // position vs velocity (snapshots with the same temperature)



extern int nstep;

extern long random_seed;

extern double Density;

extern double timestep;
extern double packing_factor;
extern double init_gran_temp;
extern double lx;
extern double Alpha;                        // Particle.r / Sheath.r_out
extern double Beta;                         // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 
extern double dissipative_coef;
extern double elastic_coef;
extern double restitution_coef;
extern double time_unit;                    // defined by (dissipative_coef) / (elastic_coef)

extern double elastic_coef_sp;
extern double Mass_Core;


//====================================================
//====================================================  output_file_maker
//====================================================

void output_file_maker ( int ensemble_index ){

    string str_folder_output;

    char buffer[50]="";

    str_folder_output.append("outputs"); 

    sprintf(buffer,"_seed%lu/",random_seed);
    str_folder_output.append(buffer);


    const char* char_folder_output=str_folder_output.c_str();
    mkdir(char_folder_output,0777);

    time_t rawtime;

    struct tm * timeinfo;
    char char_buffer [40];
    time (&rawtime);
    timeinfo = localtime (&rawtime);
  

    strftime (char_buffer,80,"  %F  %T",timeinfo);

    string str_fname;

    sprintf(buffer,"_nP:%lu",Sheaths.size());
    str_fname.append(buffer);


    sprintf(buffer,"_FT:%g",nstep*timestep);
    str_fname.append(buffer);

    sprintf(buffer,"_Mc:%g",Mass_Core);
    str_fname.append(buffer);

    sprintf(buffer,"_Ys:%g",elastic_coef_sp);
    str_fname.append(buffer);

    sprintf(buffer,"_As:%g",dissipative_coef);
    str_fname.append(buffer);

    sprintf(buffer,"_Y:%g",elastic_coef);
    str_fname.append(buffer);



//  sprintf(buffer,"_RC:%g",restitution_coef);
//  str_fname.append(buffer);

/*
    sprintf(buffer,"_Al:%g",Alpha);
    str_fname.append(buffer);
    sprintf(buffer,"_Be:%g",Beta);
    str_fname.append(buffer);
*/
    
    sprintf(buffer,"_EI:%u",ensemble_index);
    str_fname.append(buffer);

    string str_fname_T = str_folder_output;
    str_fname_T.append( "/T"      );

    str_fname_T.append( str_fname );
    str_fname_T.append( ".dat"    );
    const char * char_FileT = str_fname_T.c_str();
    FileT.open( char_FileT );


    string str_fname_P = str_folder_output;
    str_fname_P.append( "/P"      );
    str_fname_P.append( str_fname );
    str_fname_P.append( ".dat"    );
    const char * char_FileDataOut = str_fname_P.c_str();
    FileDataOut.open( char_FileDataOut );


    string str_FileX_S = str_folder_output;
    str_FileX_S.append( "/xS"     );
    str_FileX_S.append( str_fname );
    str_FileX_S.append( ".bin"    );
    const char * char_FileX_S = str_FileX_S.c_str();
    FileX_S.open( char_FileX_S, ios::binary | ios::out ) ;

//-----------------------------------
    string str_FileX_S_A = str_folder_output;
    str_FileX_S_A.append( "/xS"     );
    str_FileX_S_A.append( str_fname );
    str_FileX_S_A.append( ".dat"    );
    const char * char_FileX_S_A = str_FileX_S_A.c_str();
    FileX_S_A.open( char_FileX_S_A, ios::binary | ios::out ) ;
//----------------------------------

    string str_FileV_S = str_folder_output;
    str_FileV_S.append( "/vS"    );
    str_FileV_S.append( str_fname );
    str_FileV_S.append( ".bin"    );
    const char * char_FileV_S = str_FileV_S.c_str();
    FileV_S.open( char_FileV_S, ios::binary | ios::out );


    string str_FileX_P = str_folder_output;
    str_FileX_P.append( "/xP"     );
    str_FileX_P.append( str_fname );
    str_FileX_P.append( ".bin"    );
    const char * char_FileX_P = str_FileX_P.c_str();
    FileX_P.open( char_FileX_P, ios::binary | ios::out );


    string str_FileV_P = str_folder_output;
    str_FileV_P.append( "/vP"    );
    str_FileV_P.append( str_fname );
    str_FileV_P.append( ".bin"    );
    const char * char_FileV_P = str_FileV_P.c_str();
    FileV_P.open( char_FileV_P, ios::binary | ios::out );



    cout        << "======================Date and time"          << "\n";
    cout        << char_buffer                                    << "\n";
    cout        << "======================"                       << "\n";
    FileDataOut << "==================Date and time"              << "\n\n";
    FileDataOut << char_buffer                                    << "\n\n";
    FileDataOut << "==================system properties"          << "\n\n";

   
    FileDataOut << "Linear DashpotForce"                          << "\n\n";

    FileDataOut << "Sheath - Particle grains"                     << "\n";

    FileDataOut << "\n==================\n\n";

    FileDataOut << "random_seed: "         << random_seed         << "\n";

    FileDataOut << "radius_out: "          << Sheaths[1].r()      << "\n";

    FileDataOut << "radius_S_in: "         << Sheaths[1].r_mid()  << "\n";

    FileDataOut << "Density: "             << Density             << "\n";
    FileDataOut << "mass_S: "              << Sheaths[1].m()      << "\n";
    FileDataOut << "dissipative_coef: "    << dissipative_coef    << "\n";
    FileDataOut << "elastic_coef: "        << elastic_coef        << "\n";
    FileDataOut << "elastic_coef_sp: "     << elastic_coef        << "\n";


    FileDataOut << "Alpha: "               << Alpha               << "\n";
    FileDataOut << "Beta: "                << Beta                << "\n";

    FileDataOut << "radius_P: "            << Sheaths[1].P_r()    << "\n";
    FileDataOut << "mass_P: "              << Sheaths[1].P_m()    << "\n";


    FileDataOut << "\n==================\n\n";
    FileDataOut << "lx: "                  << lx                  << "\n";

    FileDataOut << "packing_factor: "      <<  packing_factor     << "\n";
    FileDataOut << "init_gran_temp: "      <<  init_gran_temp     << "\n";

    FileDataOut << "\n==================\n\n";
    FileDataOut << "timestep: "            << timestep            << "\n";
    FileDataOut << "nsteps: "              << nstep               << "\n";
    FileDataOut << "time_unit: "           << time_unit           << "\n";

    FileDataOut << "final_time: "          << nstep*timestep      << "\n";

    FileDataOut << "\n==================\n\n";
    FileDataOut << "Number of grains: "    << Sheaths.size()      << "\n";


}

