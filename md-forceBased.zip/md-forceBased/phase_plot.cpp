#include <vector>
#include <fstream>


#include "Sheath.h"
#include "phase_plot.h"


using namespace std;

extern vector< Sheath > Sheaths;


extern ofstream FileDataOut;     // system parameters and simulation data
extern ofstream FileT;           // gas temperature vs time
extern ofstream FileX_S_A;    // ASSCI counterpart of X_S
extern ofstream FileX_S;       // Sheaths' position in total coordinates vs time
extern ofstream FileX_P;         // Particles' position vs 
extern ofstream FileV_S;           // Sheath's velocity vs time 
extern ofstream FileV_P;         // position vs velocity (snapshots with the same temperature)

extern double lx;

extern double Time;

extern double time_unit;

extern int number_of_grains;

extern double init_gran_temp;

double total_kinetic_energy_S();
double total_kinetic_energy_P();
//====================================================
//====================================================  phase_plot_X
//====================================================

void phase_plot_X() {

    double _time = Time / time_unit;


    FileX_S_A << _time;

    FileX_S.write ( reinterpret_cast<char*>( &_time ), sizeof( double ) );

    FileX_P.write ( reinterpret_cast<char*>( &_time ), sizeof( double ) );


    for( unsigned int i = 0; i < Sheaths.size(); i++ ){


        double _X_S = Sheaths[i].x()   + Sheaths[i].pbc_index() * lx;

        FileX_S_A << " " << _X_S;

        FileX_S.write ( reinterpret_cast<char*>( &_X_S ) , sizeof( double ) );


        double _X_P = Sheaths[i].P_x() + Sheaths[i].pbc_index() * lx;

        FileX_P.write ( reinterpret_cast<char*>( &_X_P ) , sizeof( double ) );


     }

    FileX_S_A << "\n";

}

//====================================================
//====================================================  phase_plot_V
//====================================================

void phase_plot_V() {

    double _time = Time / time_unit;

    FileV_S.write ( reinterpret_cast<char*>( &_time ), sizeof( double ) );

    FileV_P.write ( reinterpret_cast<char*>( &_time ), sizeof( double ) );


    for( unsigned int i = 0; i < Sheaths.size(); i++ ){


        FileV_S.write ( reinterpret_cast<char*>( &Sheaths[i].vx()    ) , sizeof( double ) );

        FileV_P.write ( reinterpret_cast<char*>( &Sheaths[i].P_vx()  ) , sizeof( double ) );
 
  }

}


//====================================================
//==================================================== phase_plot_T
//====================================================

double phase_plot_T(){

    double _time = Time / time_unit;

    double _temperature_S = total_kinetic_energy_S()
                          / ( number_of_grains * init_gran_temp ); 



    double _temperature_P = total_kinetic_energy_P()
                          / ( number_of_grains * init_gran_temp ); 

    double _temperature = ( _temperature_S + _temperature_P ) / 2.0;

    FileT   << _time          << " " 
            << _temperature   << " " 
            << _temperature_S << " "
            << _temperature_P << "\n";


    return _temperature;

}



