#ifndef __PHASE_PLOT_H
#define __PHASE_PLOT_H

void phase_plot_X();
void phase_plot_V();

double phase_plot_T();

#endif
