
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _properties_h
#define _properties_h

// --------------------------


// === Initial Conditions ===

//#define RandomInitialPosition

//#define RandomInitialVelocity


// === Output Files ===

#define XOutputMaker

#define VOutputMaker


// --------------------------

#endif
