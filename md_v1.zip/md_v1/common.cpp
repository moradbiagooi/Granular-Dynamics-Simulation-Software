
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <time.h>
#include <iomanip> 


#include "common.h"
#include "Sheath.h"   
#include "MersenneTwister.h"
#include "properties.h"
#include "phase_plot.h"
#include "gas_maker.h"
#include "output_file_maker.h"
#include "init_parameters.h"


#define PI 3.14159265
#define GSmallNumber 1e-4


using namespace std;

bool was_in_collision = false;
int no_collision      = 0;
double col_time       = 0;


int XV_index;
int nstep;
int nprint_T;
int nprint_XV;
int nenergy;
int number_of_grains;
int number_of_ensembles;
int snapshot_counter = 1;

long random_seed;


double Density      = 1.0;
double radius_out   = 0.5;      // Sheath.r_out
double min_init_sep = 0.0005;   // minimum initial seperation


double Time;
double timestep;
double packing_factor;
double init_gran_temp;
double lx;
double Alpha;                   // Particle.r / Sheath.r_out
double Beta;                    // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 
double dissipative_coef;
double elastic_coef;
double elastic_coef_sp;
double Mass_Core;
double mass_S;
double mass_P;
double restitution_coef;
double time_unit;               // defined by (dissipative_coef) / (elastic_coef)


vector< Sheath > Sheaths;

ofstream FileDataOut;           // system parameters and simulation data
ofstream FileT;                 // gas temperature vs time

ofstream FileNEW;               // Other Parameters_such as energy...

#ifdef  XOutputMaker_ASCII
ofstream FileX_S_A;             //  Sheaths' position in total coordinates vs tim
ofstream FileX_P_A;             // Particles' position vs 
#endif

#ifdef  VOutputMaker_ASCII
ofstream FileV_S_A;             // Sheath's velocity vs time 
ofstream FileV_P_A;             // position vs velocity (snapshots with the same temperature)
#endif

#ifdef  XOutputMaker_binary
ofstream FileX_S_B;             // Sheaths' position in total coordinates vs tim
ofstream FileX_P_B;             // Particles' position vs 
#endif

#ifdef  VOutputMaker_binary
ofstream FileV_S_B;             // Sheath's velocity vs time 
ofstream FileV_P_B;             // position vs velocity (snapshots with the same temperature)
#endif


void temperature_normalizer();
void P_COM_zero(bool);          // (true) : momentum_COM = zero. (false): print momentum_COM;


void calc_damping_status();

void cal_rest_coef();
void final_prints( clock_t );


double total_kinetic_energy_S();
double total_kinetic_energy_P();

bool Particle_slipped_out( int );

bool print_data( int );

inline double abs ( double _x ) { return _x < 0 ? -_x : _x ; }


//====================================================
//====================================================  main
//====================================================


int main ( int argc, char ** argv ) {


    if ( argc != 2 ) {
        cerr << "Needs 1 input file, for example: \n\t $ /a.out init_parameters.dat\n";
        return 0; 
    }

    int simulation_fails = 0; // numbers of system sliping out or temperature rising;

    clock_t t0,t1;

    t0 = clock();

    FileT.precision(10); 

    FileX_S_A.precision(10); 

    if ( !init_parameters( argv[1] ) ) {
        cout << " The simulation stopped due to the problem above\n";
        return 0;
    }

/*
    if ( dissipative_coef != 0)
        time_unit = dissipative_coef / elastic_coef;
    else
*/
    time_unit = 1.0;

    class MTRand *RandNumb = new MTRand ( random_seed );
//--------------------------------------------------------

    for ( unsigned int ensemble_index = 1; ensemble_index <= number_of_ensembles; ensemble_index++ ){

        XV_index=0;

        t1 = clock();

        Sheaths.clear();

        Time=0;

/*
    if ( !init_parameters_check() )
      return 0;
    else
      cout << "\ninit_parameters_check() : OK \n";
*/

       gas_maker( RandNumb ); 

        calc_damping_status();

        output_file_maker ( ensemble_index );

        P_COM_zero(false);
        P_COM_zero(true);


        temperature_normalizer(); 


        phase_plot_X();
        phase_plot_V();
        phase_plot_T();


//---------------------------------------------------------------------
        cout <<"======================";
        cout <<"time loop() for ensemble number " << ensemble_index << "\n";

        double _g_i = Sheaths[0].v_com() - Sheaths[1].v_com();

        for ( int i = 0; i < nstep; i++ ){

            integrate();      


            if ( Particle_slipped_out(i) ) {
                ensemble_index--;
                i = nstep;
                simulation_fails++;
            }


            if ( !print_data(i)          ) {
                ensemble_index--;
                i = nstep;
                simulation_fails++;
            }    

        }

        double _g_f = Sheaths[0].v_com() - Sheaths[1].v_com();   
        cout << "XX RC = "<< _g_f / _g_i <<  " \t formula = " << 1.0 - 2.0*Mass_Core <<"\n";

        P_COM_zero(false);

        final_prints(t1);

        close_files();

        if( simulation_fails > 10 * number_of_ensembles ) {

            cout << "\n number of simulation fails: " << simulation_fails << "\n";
            cout << " The simulation stopped due to number of failures\n";

            return 0;
  
        }
    }



    cout << "\n number of simulation fails: " << simulation_fails << "\n";
    cout << "\n\n  Total ensemble execution time: " 
         << ((float)clock()-(float)t0) / CLOCKS_PER_SEC 
         << " seconds\n\n" ;

    return 0;

}

//====================================================
//==================================================== print_data
//====================================================

bool print_data ( int i ) {


    if ( (i+1) % nprint_XV ==0 ){

#ifdef XOutputMaker_call
        phase_plot_X();
#endif
#ifdef VOutputMaker_call
        phase_plot_V();
#endif

        phase_plot_NEW();

        snapshot_counter++;
    }


    if ( (i+1) % nprint_T == 0 ){

        double _temperature = phase_plot_T();

        if ( _temperature > 1.1 ){

            cerr << "\n\nerror: increasing temperature\n"
                 << "change your system parameters\n"
                 << "Simulation stopped at the time step: "<< i <<"\n";

            return false;

        }
    }

    return true;
}

//====================================================
//==================================================== Particle_slipped_out
//====================================================


bool Particle_slipped_out(int i){

    for ( unsigned j = 0; j < Sheaths.size(); j++ )

        if ( Sheaths[j].P_slipped_out() ){

            cerr << "Error: Particle " << j << " slipped out of its sheath at the step "  << i << "\n";

            return true;
        }

    return false;
}


//====================================================
//====================================================  final_prints
//====================================================

void final_prints(clock_t t1){

    clock_t t2;

    t2 = clock();

    float diff ((float)t2-(float)t1);

    FileDataOut     << "\n number snapshots in binary outputs: " << snapshot_counter << "\n";
    cout            << "\n number snapshots in binary outputs: " << snapshot_counter << "\n";
    cout            << "\n execution time: "  << diff / CLOCKS_PER_SEC << " seconds\n"      ;
    FileDataOut     << "\n execution time: "  << diff / CLOCKS_PER_SEC << " seconds\n"      ;

}

//====================================================
//====================================================  P_COM_zero
//====================================================

void P_COM_zero(bool make_zero_momentum){

    if (make_zero_momentum) 
        cout << "corrected "     ;  
    else
        cout << "not-corrected " ;


restart_make_zero:

    double P_COM_x = 0;


    for ( unsigned int i = 0; i < Sheaths.size(); i++ ){

        P_COM_x += mass_S * Sheaths[i].vx();

        P_COM_x += mass_P * Sheaths[i].P_vx();

    }


    double vx_correct = P_COM_x / ( number_of_grains * ( mass_S + mass_P ) );

    if (make_zero_momentum) {  

        for( unsigned int i = 0; i < Sheaths.size(); i++ ){

            Sheaths[i].vx()   -= vx_correct;

            Sheaths[i].P_vx() -= vx_correct;

        }

        make_zero_momentum = false;
        goto restart_make_zero;

    }

    cout << "center of mass momentum_x: " << P_COM_x << "\n";

}

//====================================================
//====================================================  temperature_normalizer
//====================================================

void temperature_normalizer(){


    double _temperature_S  = total_kinetic_energy_S() / ( number_of_grains ); 

    double _temperature_P  = total_kinetic_energy_P() / ( number_of_grains ); 

    double _temperature    = ( _temperature_S + _temperature_P ) / 2.0;


    double _vel_r  = sqrt( init_gran_temp / _temperature );

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        Sheaths[i].vx()   = _vel_r * Sheaths[i].vx() ;

        Sheaths[i].P_vx() = _vel_r * Sheaths[i].P_vx();

    }

    _temperature_S = total_kinetic_energy_S() / ( number_of_grains ); 

    _temperature_P = total_kinetic_energy_P() / ( number_of_grains ); 

    _temperature   = ( _temperature_S + _temperature_P ) / 2.0;

    cout << "initial granular temperature : "
         <<  _temperature  << "\n";


}


//====================================================
//====================================================  integrate
//====================================================

void integrate()
{

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){
  
        Sheaths[i].set_force_to_zero(); 

        Sheaths[i].predict( timestep );

    }


    make_forces();

  
    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        Sheaths[i].correct( timestep );

    }


    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        Sheaths[i].periodic_bc ( 0.0, lx );

    }

    Time += timestep;

//---------
//
    if ( abs ( Sheaths[0].x() - Sheaths[1].x() ) > 1.0 ) {
 

        if ( was_in_collision ) {

            was_in_collision = false;

            no_collision ++;

            //cout << no_collision << "_ " <<Time - col_time << "  ";
            cout << Time << "\n";

        } else {



        }


    } else {

        
        if ( was_in_collision ) {

            
        } else {

            was_in_collision = true;

            col_time = Time;
            cout << no_collision + 1 << "_ " <<Time << " : ";
        }


    } 

}

//====================================================
//====================================================  total_kinetic_eneregy
//====================================================

double total_kinetic_energy_S()
{

    double sum=0;

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        sum += Sheaths[i].kinetic_energy();

    }

    return sum;

}

double total_kinetic_energy_P()
{

    double sum=0;

    for( unsigned int i = 0 ; i < Sheaths.size(); i++ ){

        sum += Sheaths[i].P_kinetic_energy();

    }

    return sum;

}


// ----------------------------------------------

void calc_damping_status(){

    double m_eff = Mass_Core * ( 1.0 - Mass_Core );

    double delta = dissipative_coef * dissipative_coef - 4 * m_eff * elastic_coef_sp;

    cout        << "delta = " << delta << "\n";
    FileDataOut << "delta = " << delta << "\n";

    double q     = dissipative_coef / ( 2 * m_eff );

    cout        << "q = " << q << "\n";
    FileDataOut << "q = " << q << "\n";


    if ( delta > 0) {

        cout        << "Delta > 0\n";
        FileDataOut << "Delta > 0\n";

        double q_1 =  q + ( sqrt ( delta ) / ( 2 * m_eff ) );
        double q_2 =  q - ( sqrt ( delta ) / ( 2 * m_eff ) );

        cout        << "q_1 = " << q_1 << "   q_2 = " << q_2 << "\n";
        FileDataOut << "q_1 = " << q_1 << "   q_2 = " << q_2 << "\n";

    } else if ( delta == 0 ) {

        cout        << "Delta = 0\n";
        FileDataOut << "Delta = 0\n";

    } else {

        cout        << "Delta < 0\n";
        FileDataOut << "Delta < 0\n";

        double omega = sqrt ( ( elastic_coef_sp / m_eff ) - q * q );

        cout        << "omega = " << omega << "\n";
        FileDataOut << "omega = " << omega << "\n";

        double tc = PI / omega;
//        double ts = PI /  sqrt(  elastic_coef_sp / ( 1.0 - Mass_Core ) ) ;
        double alpha = ( 2.0 * Mass_Core - 1.0 ) * omega  / ( 2.0 * Mass_Core );
        double ts = sqrt ( 6.0 ) / omega;

        double a = - (omega * omega * omega  * q * q ) / (12.0);

        double b = - ( (omega * omega * omega ) / (6.0) )  +  ( (omega * q * q ) / (2.0) );

        double c = - alpha + omega;

        double DD = b * b - (4.0 * a * c);

        double ts1 = (-b + sqrt (DD) ) / ( 2.0 * a);
        double ts2 = (-b - sqrt (DD) ) / ( 2.0 * a);


        cout << " no of collision estimate: " <<  tc / sqrt (ts2) << "\n";

    }

}

//====================================================
//====================================================  init_parameters_check
//====================================================
/*
bool init_parameters_check(){
#ifdef ParticlesExist
  if ( Alpha < 0.0 || Alpha > 1.0 ){
    cout << "Error: assign #Alpha between " << 0.0 << " and " << 1.0 << endl;
    return false;
  }
  if ( Beta < 0.0 || Beta > 0.5 ){
    cout << "Error: assign #Beta between " << 0.0 << " and " << 0.5  << endl;
    return false;
  }
  if ( Alpha + Beta > 1.5 ){
    cout << "Error: assign #Alpha and #Beta so that (Alpha + Beta) would be between " << 0.0 << " and " << 1.5 << endl;
    return false;
  }
#endif
  return true;
}
*/



