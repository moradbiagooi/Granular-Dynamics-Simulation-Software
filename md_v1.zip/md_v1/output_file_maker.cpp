#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sys/stat.h> // used for mkdir()


#include "output_file_maker.h"
#include "Sheath.h"
#include "properties.h"


using namespace std;


extern vector < Sheath > Sheaths;

extern ofstream FileDataOut;        // system parameters and simulation data
extern ofstream FileT;              // gas temperature vs time

extern ofstream FileNEW;

#ifdef  XOutputMaker_ASCII
extern ofstream FileX_S_A;          //  Sheaths' position in total coordinates vs tim
extern ofstream FileX_P_A;          // Particles' position vs 
#endif

#ifdef  VOutputMaker_ASCII
extern ofstream FileV_S_A;          // Sheath's velocity vs time 
extern ofstream FileV_P_A;          // position vs velocity (snapshots with the same temperature)
#endif

#ifdef  XOutputMaker_binary
extern ofstream FileX_S_B;          // Sheaths' position in total coordinates vs tim
extern ofstream FileX_P_B;          // Particles' position vs 
#endif

#ifdef  VOutputMaker_binary
extern ofstream FileV_S_B;          // Sheath's velocity vs time 
extern ofstream FileV_P_B;          // position vs velocity (snapshots with the same temperature)
#endif

extern int nstep;

extern long random_seed;

extern double Density;

extern double timestep;
extern double packing_factor;
extern double init_gran_temp;
extern double lx;
extern double Alpha;                        // Particle.r / Sheath.r_out
extern double Beta;                         // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 
extern double dissipative_coef;
extern double elastic_coef;
extern double restitution_coef;
extern double time_unit;                    // defined by (dissipative_coef) / (elastic_coef)

extern double elastic_coef_sp;
extern double Mass_Core;


//====================================================
//====================================================  output_file_maker
//====================================================

void output_file_maker ( int ensemble_index ){

    string str_folder_output;

    char buffer[50]="";

    str_folder_output.append("outputs"); 

    sprintf(buffer,"_seed%lu/",random_seed);
    str_folder_output.append(buffer);


    const char* char_folder_output=str_folder_output.c_str();
    mkdir(char_folder_output,0777);

    time_t rawtime;

    struct tm * timeinfo;
    char char_buffer [40];
    time (&rawtime);
    timeinfo = localtime (&rawtime);
  

    strftime (char_buffer,80,"  %F  %T",timeinfo);

    string str_fname;

    sprintf(buffer,"_nP:%lu",Sheaths.size());
    str_fname.append(buffer);


    sprintf(buffer,"_FT:%g",nstep*timestep);
    str_fname.append(buffer);

    sprintf(buffer,"_Mc:%g",Mass_Core);
    str_fname.append(buffer);

    sprintf(buffer,"_Ys:%g",elastic_coef_sp);
    str_fname.append(buffer);

    sprintf(buffer,"_As:%g",dissipative_coef);
    str_fname.append(buffer);

    sprintf(buffer,"_Y:%g",elastic_coef);
    str_fname.append(buffer);



//  sprintf(buffer,"_RC:%g",restitution_coef);
//  str_fname.append(buffer);

/*
    sprintf(buffer,"_Al:%g",Alpha);
    str_fname.append(buffer);
    sprintf(buffer,"_Be:%g",Beta);
    str_fname.append(buffer);
*/
    
    sprintf(buffer,"_EI:%u",ensemble_index);
    str_fname.append(buffer);

    string str_fname_T = str_folder_output;
    str_fname_T.append( "/T"      );

    str_fname_T.append( str_fname );
    str_fname_T.append( ".dat"    );
    const char * char_FileT = str_fname_T.c_str();
    FileT.open( char_FileT );


    string str_fname_P = str_folder_output;
    str_fname_P.append( "/P"      );
    str_fname_P.append( str_fname );
    str_fname_P.append( ".dat"    );
    const char * char_FileDataOut = str_fname_P.c_str();
    FileDataOut.open( char_FileDataOut );

#ifdef  XOutputMaker_call
  #ifdef XOutputMaker_ASCII
    string str_FileX_S_A = str_folder_output;
    str_FileX_S_A.append( "/xS"     );
    str_FileX_S_A.append( str_fname );
    str_FileX_S_A.append( ".dat"    );
    const char * char_FileX_S_A = str_FileX_S_A.c_str();
    FileX_S_A.open( char_FileX_S_A, ios::binary | ios::out ) ;

    string str_FileX_P_A = str_folder_output;
    str_FileX_P_A.append( "/xP"     );
    str_FileX_P_A.append( str_fname );
    str_FileX_P_A.append( ".dat"    );
    const char * char_FileX_P_A = str_FileX_P_A.c_str();
    FileX_P_A.open( char_FileX_P_A, ios::binary | ios::out ) ;
  #endif
    
  #ifdef XOutputMaker_binary
    string str_FileX_S_B = str_folder_output;
    str_FileX_S_B.append( "/xS"     );
    str_FileX_S_B.append( str_fname );
    str_FileX_S_B.append( ".bin"    );
    const char * char_FileX_S_B = str_FileX_S_B.c_str();
    FileX_S_B.open( char_FileX_S_B, ios::binary | ios::out ) ;

    string str_FileX_P_B = str_folder_output;
    str_FileX_P_B.append( "/xP"     );
    str_FileX_P_B.append( str_fname );
    str_FileX_P_B.append( ".bin"    );
    const char * char_FileX_P_B = str_FileX_P_B.c_str();
    FileX_P_B.open( char_FileX_P_B, ios::binary | ios::out );
  #endif
#endif

#ifdef  VOutputMaker_call
  #ifdef VOutputMaker_ASCII
    string str_FileV_S_A = str_folder_output;
    str_FileV_S_A.append( "/vS"    );
    str_FileV_S_A.append( str_fname );
    str_FileV_S_A.append( ".dat"    );
    const char * char_FileV_S_A = str_FileV_S_A.c_str();
    FileV_S_A.open( char_FileV_S_A, ios::binary | ios::out );


    string str_FileV_P_A = str_folder_output;
    str_FileV_P_A.append( "/vP"    );
    str_FileV_P_A.append( str_fname );
    str_FileV_P_A.append( ".dat"    );
    const char * char_FileV_P_A = str_FileV_P_A.c_str();
    FileV_P_A.open( char_FileV_P_A, ios::binary | ios::out );
  #endif

  #ifdef VOutputMaker_binary
    string str_FileV_S_B = str_folder_output;
    str_FileV_S_B.append( "/vS"    );
    str_FileV_S_B.append( str_fname );
    str_FileV_S_B.append( ".bin"    );
    const char * char_FileV_S_B = str_FileV_S_B.c_str();
    FileV_S_B.open( char_FileV_S_B, ios::binary | ios::out );


    string str_FileV_P_B = str_folder_output;
    str_FileV_P_B.append( "/vP"    );
    str_FileV_P_B.append( str_fname );
    str_FileV_P_B.append( ".bin"    );
    const char * char_FileV_P_B = str_FileV_P_B.c_str();
    FileV_P_B.open( char_FileV_P_B, ios::binary | ios::out );
  #endif
#endif

    string str_FileNEW = str_folder_output;
    str_FileNEW.append( "/nEW"    );
    str_FileNEW.append( str_fname );
    str_FileNEW.append( ".dat"    );
    const char * char_FileNEW = str_FileNEW.c_str();
    FileNEW.open( char_FileNEW, ios::binary | ios::out );


    cout        << "======================Date and time"          << "\n";
    cout        << char_buffer                                    << "\n";
    cout        << "======================"                       << "\n";
    FileDataOut << "==================Date and time"              << "\n\n";
    FileDataOut << char_buffer                                    << "\n\n";
    FileDataOut << "==================system properties"          << "\n\n";

   
    FileDataOut << "Linear DashpotForce"                          << "\n\n";

    FileDataOut << "Sheath - Particle grains"                     << "\n";

    FileDataOut << "\n==================\n\n";

    FileDataOut << "random_seed: "         << random_seed         << "\n";

    FileDataOut << "radius_out: "          << Sheaths[1].r()      << "\n";

    FileDataOut << "radius_S_in: "         << Sheaths[1].r_mid()  << "\n";

    FileDataOut << "Density: "             << Density             << "\n";
    FileDataOut << "mass_S: "              << Sheaths[1].m()      << "\n";
    FileDataOut << "dissipative_coef: "    << dissipative_coef    << "\n";
    FileDataOut << "elastic_coef: "        << elastic_coef        << "\n";
    FileDataOut << "elastic_coef_sp: "     << elastic_coef        << "\n";


    FileDataOut << "Alpha: "               << Alpha               << "\n";
    FileDataOut << "Beta: "                << Beta                << "\n";

    FileDataOut << "radius_P: "            << Sheaths[1].P_r()    << "\n";
    FileDataOut << "mass_P: "              << Sheaths[1].P_m()    << "\n";


    FileDataOut << "\n==================\n\n";
    FileDataOut << "lx: "                  << lx                  << "\n";

    FileDataOut << "packing_factor: "      <<  packing_factor     << "\n";
    FileDataOut << "init_gran_temp: "      <<  init_gran_temp     << "\n";

    FileDataOut << "\n==================\n\n";
    FileDataOut << "timestep: "            << timestep            << "\n";
    FileDataOut << "nsteps: "              << nstep               << "\n";
    FileDataOut << "time_unit: "           << time_unit           << "\n";

    FileDataOut << "final_time: "          << nstep*timestep      << "\n";

    FileDataOut << "\n==================\n\n";
    FileDataOut << "Number of grains: "    << Sheaths.size()      << "\n";


}

//====================================================
//====================================================  close_files
//====================================================

void close_files(){

        FileDataOut.close();

        FileT.close();

#ifdef  XOutputMaker_call
  #ifdef  XOutputMaker_ASCII
        FileX_S_A.close();
        FileX_P_A.close();
  #endif

  #ifdef  XOutputMaker_binary
        FileX_S_B.close();
        FileX_P_B.close();
  #endif
#endif

#ifdef  VOutputMaker_call
  #ifdef  VOutputMaker_ASCII
        FileV_S_A.close();
        FileV_P_A.close();
  #endif

  #ifdef  VOutputMaker_binary
        FileV_S_B.close();
        FileV_P_B.close();
  #endif
#endif


}




