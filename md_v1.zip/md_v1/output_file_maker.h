#ifndef __OUTPUT_FILE_MAKER_H
#define __OUTPUT_FILE_MAKER_H

void output_file_maker ( int );

void close_files();

#endif
