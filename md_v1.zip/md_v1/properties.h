
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _properties_h
#define _properties_h

// --------------------------


// === Initial Conditions ===

//#define RandomInitialPosition

//#define RandomInitialVelocity


// === Output Files ===
#define XOutputMaker_call
//#define XOutputMaker_binary
#define XOutputMaker_ASCII


//#define VOutputMaker_call
//#define VOutputMaker_binary
#define VOutputMaker_ASCII

// --------------------------

#endif
