#!/bin/bash

# Filename without extention and initial ( xs_,nEW_ , ... )

FILENAME="nP:2_ft:100_dt:1e-05_e:0.05_d:0.75_zp:15_k:1e+07" 
XLABEL="x"
YLABEL="t"
DELTA="0.05"
ETA="0.75"
ZETA="15"
#FILENAME="nP:2_ft:100_dt:1e-05_e:$ETA_d:$DELTA_zp:$ZETA_k:1e+07" 

gnuplot << EOFa
set term png
#set terminal png size 800,600 font "Helvetica,15" enhanced
set terminal pngcairo dashed size 800,600 font "Helvetica,15" enhanced
#set terminal pngcairo size 800,600 font "Helvetica,15" enhanced
set output "out_x_$FILENAME.png"
set border linewidth 2
set xlabel "$XLABEL"
set ylabel "$YLABEL"
set key right top
set grid
set title " {/Symbol d} = $DELTA       {/Symbol h} = $ETA       {/Symbol z} = $ZETA"
plot [:][:] \
    for [i=2:9] "xs_$FILENAME.dat" u i:1 w l lw 2 lt 1 lc rgb "blue" notitle  , \
    for [i=2:5] "xp_$FILENAME.dat" u i:1 w l lw 2 lt 3 lc rgb "black" notitle  
EOFa

#"nEW_nP:2_ft:100_dt:1e-05_e:0.05_d:0.75_zp:15_k:1e+07.dat" u 1:2 w l lw 2 ti "E_{tot}", \
#"nEW_nP:2_ft:100_dt:1e-05_e:0.05_d:0.75_zp:15_k:1e+07.dat" u 1:3 w l lw 2 ti "E_{com}", \
#"nEW_nP:2_ft:100_dt:1e-05_e:0.05_d:0.75_zp:15_k:1e+07.dat" u 1:4 w l lw 2 ti "E_{r} + U", \


