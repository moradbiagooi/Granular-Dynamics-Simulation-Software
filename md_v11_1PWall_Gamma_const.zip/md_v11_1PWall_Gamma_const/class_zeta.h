#ifndef __CLASS_ZETA_H
#define __CALSS_ZETA_H

class class_zeta {

    public:

        class_zeta() {};

        class_zeta ( double alpha, double beta, double lambda ){
            _alpha = alpha; _beta = beta; _lambda = lambda;
        }

        double l_free ( );

        double xi ( double eta , double t);

        double t_max ( double eta );

        double temperature ( double eta, double zet );

        double zeta ( double eta , double temp );

        double & alpha  ()   { return _alpha;  }
        double & beta   ()   { return _beta;   }
        double & lambda ()   { return _lambda; }

    private:

        double _alpha, _beta, _lambda;
        

};

#endif
