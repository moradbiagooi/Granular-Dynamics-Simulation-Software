#!/bash/bin
rm a.out *~
g++ main_rc_analysis.cc
./a.out
