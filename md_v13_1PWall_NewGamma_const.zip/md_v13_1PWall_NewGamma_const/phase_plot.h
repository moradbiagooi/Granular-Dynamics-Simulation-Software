#ifndef __PHASE_PLOT_H
#define __PHASE_PLOT_H

void phase_plot_X();
void phase_plot_V();
void phase_plot_NEW();

double phase_plot_T();

#endif
