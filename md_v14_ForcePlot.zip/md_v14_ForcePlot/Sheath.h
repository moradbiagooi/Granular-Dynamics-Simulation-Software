
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _Sheath_h
#define _Sheath_h

#include <iostream>
#include <math.h>


#include "properties.h"


#include "Particle.h"


using namespace std;


inline double normalize(double dx, double L){
  while(dx<-L/2) dx+=L;
  while(dx>=L/2) dx-=L;
  return dx;
}



class Sheath {

    friend void force(Sheath & p1, Sheath & p2, double lx);

public:

    Sheath(): rtd0(0), rtd1(0), rtd2(0), rtd3(0), rtd4(0)
    {}


    double & P_x()          {return P.x();}
    double   P_x() const    {return P.x();}
 
    double & P_vx()         {return P.vx();}
    double   P_vx() const   {return P.vx();}


    double & P_r()          {return P.r();}
    double   P_r() const    {return P.r();}

    double   P_m() const    {return P.m();}
    double & P_m()          {return P.m();}

    double & P_Y_sp()          {return P.Y_sp();}
    double   P_Y_sp() const    {return P.Y_sp();}

    double & P_A_sp()          {return P.A_sp();}
    double   P_A_sp() const    {return P.A_sp();}

//    double P_energy_tot() const { return P.energy_tot();}

    int & pbc_index()       {return _pbc_index;} 
    int   pbc_index() const {return _pbc_index;} 

    double & x()            {return rtd0;}
    double   x() const      {return rtd0;}

    double & vx()           {return rtd1;}
    double   vx() const     {return rtd1;}


    double   x_com() const {
        return (  x() * m()  +  P_x()  * P_m() ) / ( m()  +  P_m() );
    }

    double   v_com() const {
        return ( vx() * m()  +  P_vx() * P_m() ) / ( m()  +  P_m() );
    }


    double & r()            {return _r;}
    double   r() const      {return _r;}

    double & r_mid()        {return _r_mid;}
    double   r_mid() const  {return _r_mid;}

    double   m() const      {return _m;}
    double & m()            {return _m;}

    double & Y()            {return _Y;}
    double   Y() const      {return _Y;}

    double & A()            {return _A;}
    double   A() const      {return _A;}

    double   f()   const    {return _force;}
    double   P_f() const    {return P.f();}

    void predict(double dt);                        //First step of the Gear algorithm

    void correct(double dt);                        //Second step of the Gear algorithm


    double E_tot    ( double delta, double eta  ) const;  
    double U        ( double delta, double eta  ) const;  
    double E_r      ( double delta              ) const;  
    double E_com    ( double delta              ) const;     


    bool P_slipped_out();
    bool P_S_collide();


    void set_force_to_zero(){
        _force=0;
        P.set_force_to_zero();
    }

    void add_force(const double & f)
    {   _force+=f; }                                //Adds a value to the total force _force of the Sheath


    void periodic_bc(double x_0, double lx);        //Enforces the periodic boundary conditions

    void internal_force(double lx);

    void set_init_forces (   
        double & f_spring_s, double & f_damp_s, double & f_cs_s, double & f_ss,
        double & f_spring_c, double & f_damp_c, double & f_cs_c 
        )
    {
        f_spring_s = _f_spring_s ; f_damp_s = _f_damp_s; f_cs_s = _f_cs_s; f_ss = _f_ss; 
        f_spring_c = _f_spring_c ; f_damp_c = _f_damp_c; f_cs_c = _f_cs_c;
     }
 

    void init_forces_zero () {
        _f_spring_s = 0; _f_damp_s = 0; _f_cs_s = 0; _f_ss = 0; 
        _f_spring_c = 0; _f_damp_c = 0; _f_cs_c = 0;
    }

    double & f_ss ()       { return _f_ss; }
    double   f_ss () const { return _f_ss; }


private:

    int _pbc_index;

    double _r, _m, _r_mid;
    double _Y, _A;
    double _f_spring_s, _f_spring_c, _f_damp_s, _f_damp_c,  _f_cs_s, _f_cs_c, _f_ss;

    double rtd0,rtd1,rtd2,rtd3,rtd4;
    double _force;

    Particle P;

};

#endif
