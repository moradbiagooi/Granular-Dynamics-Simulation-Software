#include <iostream>
#include <vector>


#include "gas_maker.h"
#include "MersenneTwister.h"
#include "Sheath.h"


using namespace std;

extern vector < Sheath > Sheaths;

inline double abs ( double _x ) { return _x < 0 ? -_x : _x ; }


extern int number_of_grains;

extern double Density;
extern double min_init_sep;    // minimum initial seperation

extern double lx;
extern double alpha;                        // Particle.r / Sheath.r_out
extern double beta;                         // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 
extern double lambda;
extern double delta;
extern double eta;
extern double kappa;

//====================================================
//====================================================  gas_maker
//====================================================
/*
void gas_maker( MTRand * RandNumb ){


    lx = double ( number_of_grains ); 

    double grain_x [2];

    grain_x [0] = 0.5;
    grain_x [1] = 1.5;

    double grain_vx [2];

    grain_vx [0] = 1.0;
    grain_vx [1] = -1.0;


    double radius_out = 0.5 * ( 1.0 - lambda );

    double _r_mid = radius_out * ( 1.0 - 2.0 * beta );
    double _r_P   = radius_out * alpha;


    for ( int i = 0; i < number_of_grains; i++ ){

        Sheath pp;

// ----------------------- radius, mass, rotational inertia

        pp.r()     = radius_out;
        pp.m()     = eta / ( 4.0 * delta );

        pp.r_mid() = _r_mid;
        pp.P_r()   = _r_P;

        pp.P_m()   = eta / ( 4.0 * ( 1.0 - delta ) );


// ----------------------- positions
        pp.x()     = grain_x[i];
        pp.vx()    = grain_vx[i];

        pp.pbc_index() = 0;

        pp.P_x()  = pp.x(); 
        pp.P_vx() = pp.vx();




// ----------------------- material properties

        pp.A()     = 0.0;
        pp.Y()     = kappa;

        pp.P_A_sp()  = 1.0;
        pp.P_Y_sp()  = 1.0;

// -----------------------
  
        Sheaths.push_back(pp);

    }

//    cout << "OK\n" << endl;
//    cout << number_of_grains << " grains are made\n" << flush;
//    cout << "======================\n";

}
*/
// ====================================================

void gas_maker( MTRand * RandNumb ){


//    double mean_free_space = lambda;
//

    lx = double ( number_of_grains );

    double radius_out = 0.5 * ( 1.0 - lambda );

    double _r_mid = radius_out * ( 1.0 - 2.0 * beta );
    double _r_P   = radius_out * alpha;


    double grain_x [number_of_grains];

// #ifdef RandomInitialPosition

    int grains_counter = 0;

#ifndef TwoGrainsPhasePlot

    while (grains_counter < number_of_grains) {

        double temp_x = lx * RandNumb -> randDblExc();


        bool flag_freeSpace = true;

        int i = 0;

        while (flag_freeSpace && i < grains_counter){

            double _dist = abs( temp_x - grain_x[i] );

            if ( _dist > lx / 2.0 ) {
                _dist = lx - _dist;
            }

//            if ( _dist < 2.0 * radius_out + min_init_sep)
            if ( _dist < 2.001 * radius_out ){
               flag_freeSpace = false;
            }

            i++;

        }

        if (flag_freeSpace){

            grain_x[grains_counter] = temp_x;

            grains_counter++;

        }

    }
// -----------------------



// ----------------------- sorting grain_x[]
// used for Linear neighbors


    bool flag_disorder = true;

    while (flag_disorder){

        flag_disorder = false;

        for (int i=0;i<number_of_grains;i++){

            for (int j=0;j<number_of_grains;j++){

                if (grain_x[i] > grain_x[j] && i < j){

                    flag_disorder = true;
                    double temp_x = grain_x[i];
                    grain_x[i]    = grain_x[j];
                    grain_x[j]    = temp_x;

                }

            }

        }

    }
/*
#else

    double _inbetween_distance = lx / double( number_of_grains );

    for ( int i = 0; i < number_of_grains; i++ ){
        grain_x [i]= mean_free_space/2.0 + double(i) * _inbetween_distance;
    }

#endif
*/
#endif
/*
#ifdef TwoGrainsPhasePlot
    grain_x[0] = 1.0;
    grain_x[1] = grain_x[0] + 3.0 * radius_out;
#endif
*/
    grain_x[0] = 0.5;

    for ( int i = 0; i < number_of_grains; i++ ){

        Sheath pp;

// ----------------------- radius, mass, rotational inertia

        pp.r()     = radius_out;
        pp.m()     = eta / ( 4.0 * delta );

        pp.r_mid() = _r_mid;
        pp.P_r()   = _r_P;

        pp.P_m()   = eta / ( 4.0 * ( 1.0 - delta ) );


// ----------------------- positions
        pp.x()     = grain_x[i];

#ifdef TwoGrainsPhasePlot
        if ( i == 0 ) {
            pp.vx() = +1.0;
        } else if ( i == 1 ) {
            pp.vx() = -1.0;
        }
#else
        pp.vx()    = (0.5 - RandNumb -> randDblExc()) * 2;
#endif


        pp.pbc_index() = 0;

        pp.P_x()  = pp.x(); 
        pp.P_vx() = pp.vx();

        pp.xiWall() = 0;


// ----------------------- material properties

        pp.A()     = 0.0;
        pp.Y()     = kappa;

        pp.P_A_sp()  = 1.0;
        pp.P_Y_sp()  = 1.0;

// -----------------------
  
        Sheaths.push_back(pp);

    }


}



//========================================================
//
/*

void gas_maker( MTRand * RandNumb ){


    double mean_free_space = (1.0/packing_factor) - 1.0;

    lx = ((2.0 * radius_out) + mean_free_space) * number_of_grains; 

    double grain_x [number_of_grains];

#ifdef RandomInitialPosition

// ----------------------- Calculating Sheaths' Random Positions
    cout << "Making Sheaths Positions: If this part took more than a few seconds, "
         << "you may have to increase #mean_free_space... ";

    int grains_counter = 0;

    while (grains_counter < number_of_grains) {

        double temp_x = lx * RandNumb -> randDblExc();


        bool flag_freeSpace = true;

        int i = 0;

        while (flag_freeSpace && i < grains_counter){

            double _dist = abs( temp_x - grain_x[i] );

            if ( _dist > lx / 2.0 ) {
                _dist = lx - _dist;
            }

            if ( _dist < 2.0 * radius_out + min_init_sep)
                flag_freeSpace = false;

            i++;

        }

        if (flag_freeSpace){

            grain_x[grains_counter] = temp_x;

            grains_counter++;

        }

    }
// -----------------------



// ----------------------- sorting grain_x[]
// used for Linear neighbors


    bool flag_disorder = true;

    while (flag_disorder){

        flag_disorder = false;

        for (int i=0;i<number_of_grains;i++){

            for (int j=0;j<number_of_grains;j++){

                if (grain_x[i] > grain_x[j] && i < j){

                    flag_disorder = true;
                    double temp_x = grain_x[i];
                    grain_x[i]    = grain_x[j];
                    grain_x[j]    = temp_x;

                }

            }

        }

    }
#else

    double _inbetween_distance = lx / double( number_of_grains );

    for ( int i = 0; i < number_of_grains; i++ ){
        grain_x [i]= mean_free_space/2.0 + double(i) * _inbetween_distance;
    }

#endif
// -----------------------
    cout << "OK\n" << endl;
    cout << "lx = " << lx << endl;


    cout << "\nMaking Particles Positions: If this part took more than a few seconds, "
         << "you may have to decrease (#Alpha + #Beta)... ";
// ----------------------- making grains 




    double _r_mid = radius_out * ( 1.0 - 2.0 * Beta );
    double _r_P   = radius_out * Alpha;

//  mass_S = Density * 2.0 * ( radius_out - _r_mid );
//  mass_P = Density * 2.0 * _r_P;

    mass_S = 1.0 - Mass_Core;
    mass_P = Mass_Core;


    for ( int i = 0; i < number_of_grains; i++ ){

        Sheath pp;

// ----------------------- radius, mass, rotational inertia

        pp.r()     = radius_out;
        pp.m()     = mass_S;



        pp.r_mid() = _r_mid;
        pp.P_r()   = _r_P;
        pp.P_m()   = mass_P;


// ----------------------- positions
        pp.x()     = grain_x[i];

        pp.pbc_index() = 0;

#ifdef RandomInitialPosition

find_new_rnd1:

        double temp_x =  ( 0.5 - RandNumb -> randDblExc() ) * 2  * ( pp.r_mid() - pp.P_r() ); 

        if( abs( temp_x ) + pp.P_r() > pp.r_mid() - min_init_sep)
            goto find_new_rnd1;
    

        pp.P_x()  = pp.x() + temp_x; 

#else
        pp.P_x()  = pp.x(); 
#endif


// -----------------------



// ----------------------- random velocity
        pp.vx()   = (0.5 - RandNumb -> randDblExc()) * 2;


#ifdef RandomInitialVelocity
        pp.P_vx() = (0.5 - RandNumb -> randDblExc()) * 2;
#else
        pp.P_vx() = pp.vx();
#endif



// ----------------------- material properties

        pp.A()     = 0.0;
        pp.Y()     = elastic_coef;

        pp.P_A_sp()  = dissipative_coef;
        pp.P_Y_sp()  = elastic_coef_sp;

// -----------------------
  
        Sheaths.push_back(pp);

    }

    cout << "OK\n" << endl;
    cout << number_of_grains << " grains are made\n" << flush;
    cout << "======================\n";

}

*/
