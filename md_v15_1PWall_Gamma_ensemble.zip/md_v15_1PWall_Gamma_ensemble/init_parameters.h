#ifndef __INIT_PARAMETERS_H
#define __INIT_PARAMETERS_H

bool init_parameters ( char * );

#endif
