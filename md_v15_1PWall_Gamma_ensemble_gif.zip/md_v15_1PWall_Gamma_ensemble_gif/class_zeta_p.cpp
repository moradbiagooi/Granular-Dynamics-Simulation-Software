#include <cmath>
#include <iostream>

#include "class_zeta_p.h"

using namespace std;


double class_zeta_p::zeta ( double eta, double temp, double delta ) {

    return sqrt (  ( eta * temp ) / ( 4.0 * delta * ( 1.0 - delta ) * l_free() * l_free() )  );

}

//=======================================================

double class_zeta_p::temperature ( double eta, double zeta, double delta ) {

    double lzeta = l_free() * zeta ;

    return  4.0 * delta * ( 1.0 - delta ) * lzeta * lzeta / eta ;

}

//=======================================================


double class_zeta_p::l_free ( ) {

    return ( 1.0 - _alpha - 2.0 * _beta ) * ( 1.0 - _lambda ) / 2.0;

}
