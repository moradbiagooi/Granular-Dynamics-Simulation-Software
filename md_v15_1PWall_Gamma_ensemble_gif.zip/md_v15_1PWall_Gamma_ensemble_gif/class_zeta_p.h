#ifndef __CLASS_ZETA_P_H
#define __CALSS_ZETA_P_H

class class_zeta_p {

    public:

        class_zeta_p () {};

        class_zeta_p ( double alpha, double beta, double lambda ){
            _alpha = alpha; _beta = beta; _lambda = lambda;
        }

        double l_free ( );

        double temperature ( double eta, double zet, double delta );

        double zeta ( double eta , double temp, double delta );

        double & alpha  ()   { return _alpha;  }
        double & beta   ()   { return _beta;   }
        double & lambda ()   { return _lambda; }

    private:

        double _alpha, _beta, _lambda;
        

};

#endif
