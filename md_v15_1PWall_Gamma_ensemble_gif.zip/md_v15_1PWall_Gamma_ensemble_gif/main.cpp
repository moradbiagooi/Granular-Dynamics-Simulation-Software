
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <time.h>
#include <iomanip> 


#include "main.h"
#include "Sheath.h"   
#include "MersenneTwister.h"
#include "properties.h"
#include "phase_plot.h"
#include "gas_maker.h"
#include "output_file_maker.h"
#include "init_parameters.h"
#include "class_zeta_p.h"


#define PI 3.14159265
#define GSmallNumber 1e-4


using namespace std;

bool col_time_fin_flag = false;
bool was_in_collision = false;
int no_collision      = 0;
double col_time_start = 0;
double col_time_finish = 0;
double col_time_between = 0;

double v_com_0; // used in calculating RC in consecutive collisions;

int nstep;
int nprint_T;
int nprint_XV;
int nenergy;
int number_of_grains;
int number_of_ensembles;
int snapshot_counter = 1;

long random_seed;

double RC_multipliction;

double alpha;                        // Particle.r / Sheath.r_out
double beta;                         // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 
double lambda;
double delta;
double eta;
double kappa;
double zeta_p;
double Gamma;

double Time;
double timestep;
double init_gran_temp;
double lx;

double v_rc;
int flag_rc;

double time_unit;               // defined by (dissipative_coef) / (elastic_coef)


vector< Sheath > Sheaths;


ofstream FileDataOut;           // system parameters and simulation data
ofstream FileT;                 // gas temperature vs time
ofstream FileNEW;               // Other Parameters_such as energy...
ofstream FileCollision;


ofstream FileData;

#ifdef  XOutputMaker_ASCII
ofstream FileX_S_A;             //  Sheaths' position in total coordinates vs tim
ofstream FileX_P_A;             // Particles' position vs 
#endif

#ifdef  VOutputMaker_ASCII
ofstream FileV_S_A;             // Sheath's velocity vs time 
ofstream FileV_P_A;             // position vs velocity (snapshots with the same temperature)
#endif

#ifdef  XOutputMaker_binary
ofstream FileX_S_B;             // Sheaths' position in total coordinates vs tim
ofstream FileX_P_B;             // Particles' position vs 
#endif

#ifdef  VOutputMaker_binary
ofstream FileV_S_B;             // Sheath's velocity vs time 
ofstream FileV_P_B;             // position vs velocity (snapshots with the same temperature)
#endif


void temperature_normalizer();
void V_COM_zero(bool);          // (true) : momentum_COM = zero. (false): print momentum_COM;

void renormalize_Gamma( );

void calc_damping_status();

void cal_rest_coef();

void final_prints( clock_t );

void calc_no_collisions();

bool Particle_slipped_out( int );

bool print_data( int );

inline double abs ( double _x ) { return _x < 0 ? -_x : _x ; }


//====================================================
//====================================================  main
//====================================================


int main ( int argc, char ** argv ) {


    if ( argc != 2 ) {
        cerr << "Needs 1 input file, for example: \n\t $ /a.out init_parameters.dat\n";
        return 0; 
    }

    int simulation_fails = 0; // numbers of system sliping out or temperature rising;

    clock_t t0,t1;

    t0 = clock();

    
    FileT.precision(10); 
    FileNEW.precision(6);
    FileX_S_A.precision(6); 
    FileX_P_A.precision(6); 
    FileV_S_A.precision(6); 
    FileV_P_A.precision(6); 



    if ( !init_parameters( argv[1] ) ) {
        cout << " The simulation stopped due to the problem above\n";
        return 0;
    }



    class MTRand *RandNumb = new MTRand ( random_seed );
    
    class_zeta_p c_zeta_p ( alpha, beta, lambda );

    init_gran_temp = c_zeta_p.temperature ( eta, zeta_p, delta );

//--------------------------------------------------------

    unsigned int ensemble_index = 1;




    double _dx = 0.05;

    for ( double _x = _dx ;    _x <= 10.0     ;    _x += _dx ) { 

//        eta = pow ( 10.0 , _x );
        Gamma = _x;

        cout << "Gamma = " << Gamma << endl;

        int no_col = 100000;

        int col_counter = -1;

        bool col_counter_finished = false;



        no_collision = 0;

        t1 = clock();

        Sheaths.clear();

        Time = 0;


        gas_maker ( RandNumb ); 

#ifndef TwoGrainsPhasePlot
        V_COM_zero ( true  );
        V_COM_zero ( false );
#endif

        init_gran_temp = c_zeta_p.temperature ( eta, zeta_p, delta );



        temperature_normalizer(); 

#ifndef TwoGrainsPhasePlot
        V_COM_zero ( false );
#endif

        output_file_maker_data();

#ifdef STCNOutputMaker
//        output_file_maker ( ensemble_index );

        phase_plot_X();
        phase_plot_V();
        phase_plot_T();
#endif

        renormalize_Gamma();
        v_rc = Sheaths[0].v_com();
        if ( v_rc > 0 ) flag_rc = 1;
        


        for ( int i = 0; i < nstep; i++ ){

            integrate();      


            if ( Particle_slipped_out(i) ) {
                ensemble_index--;
                i = nstep;
                simulation_fails++;
            }


            if ( !print_data(i)          ) {
                ensemble_index--;
                i = nstep;
                simulation_fails++;
            }




            double v_rc_now = Sheaths[0].v_com();

            if ( Sheaths[0].x() > 0.5 && v_rc_now > 0 ) {
                if ( flag_rc == 1 ) {    

                    flag_rc = -1;
                    double rc_now = abs ( v_rc_now / v_rc );

//                   cout << rc_now << " " ;
                    FileData << rc_now << " ";

                    renormalize_Gamma();
                    v_rc_now = Sheaths[0].v_com();
                    v_rc = v_rc_now;

                    col_counter++;
                    if ( col_counter == no_col ){
                        i = nstep;
                        col_counter_finished = true;
                    }

                 }
            } else if ( Sheaths[0].x() < 0.5 && v_rc_now < 0 ) {
                if ( flag_rc == -1 ) {    

                    flag_rc = +1;
                    double rc_now = abs ( v_rc_now / v_rc );

//                  cout << rc_now << " " ;
                    FileData << rc_now << " ";

                    renormalize_Gamma();
                    v_rc_now = Sheaths[0].v_com();
                    v_rc = v_rc_now;

                    col_counter++;
                    if ( col_counter == no_col ){
                        i = nstep;
                        col_counter_finished = true;
                    }
               }

            }

        }


#ifdef STCNOutputMaker
        final_prints(t1);
        close_files();
#endif
        FileData.close();
    


    }



    cout << "\n number of simulation fails: "        << simulation_fails << "\n";
    cout << "\n\n  Total ensemble execution time: "  << ((float)clock()-(float)t0) / CLOCKS_PER_SEC  << " seconds\n\n" ;

    delete RandNumb;

    return 0;

}
//====================================================
//==================================================== renormalize_Gamma
//====================================================

void renormalize_Gamma(){

    double Gamma_p = lambda / abs ( Sheaths[0].v_com() );

    double alpha_p = Gamma / Gamma_p;

    Sheaths[0].vx()   = Sheaths[0].vx()   / alpha_p ;

    Sheaths[0].P_vx() = Sheaths[0].P_vx() / alpha_p ;

//cout << "corrected Gamma: "<< lambda / abs ( Sheaths[0].v_com() ) << endl;
}


//====================================================
//==================================================== calc_no_collisions
//====================================================



void calc_no_collisions(){


//---------
    if ( abs ( Sheaths[0].x() - Sheaths[1].x() ) > 2.0 * Sheaths[0].r() ) {
 

        if ( was_in_collision ) {

            was_in_collision = false;

            no_collision ++;

            col_time_finish = Time - timestep;

            double col_duration = col_time_finish - col_time_start;

            double RC = abs ( Sheaths[0].v_com() / v_com_0  );

            RC_multipliction *= RC;

            FileCollision << no_collision << " " << Time             << " " <<  RC << " ";

            FileCollision << col_duration << " " << col_time_between << " ";

            FileCollision << "\n";




        } else {



        }

        v_com_0 = Sheaths[0].v_com();


    } else {

        
        if ( was_in_collision ) {

            
        } else {

            was_in_collision = true;

            col_time_start = Time;

            col_time_between = col_time_start - col_time_finish;

        }


    } 

};

//====================================================
//==================================================== calc_damping_status
//====================================================


void calc_damping_status(){

    double q     = 2.0 / eta ;

    if ( eta < 1) {

        double q_1 =  q * ( 1.0 + sqrt ( 1.0 - eta ) );
        double q_2 =  q * ( 1.0 - sqrt ( 1.0 - eta ) );

//        cout        << "q_1 = " << q_1 << "   q_2 = " << q_2 << "\n";
        FileDataOut << "q_1 = " << q_1 << "   q_2 = " << q_2 << "\n";


//        FileData  << q_1 << " " << q_2 << " ";

    } else if ( eta == 1 ) {

//        FileData << q << " " << q << " ";

    } else {

        double omega = 2.0 * sqrt ( (1.0/eta) - (1.0/(eta*eta)) );

//        cout        << "q = " << q << "   omega = " << omega << "\n";
        FileDataOut << "q = " << q << "   omega = " << omega << "\n";

//        FileData << q << " " << omega << " ";



    }

}



//====================================================
//==================================================== print_data
//====================================================

bool print_data ( int i ) {


    if ( (i+1) % nprint_XV ==0 ){

#ifdef XOutputMaker_call
        phase_plot_X();
#endif
#ifdef VOutputMaker_call
        phase_plot_V();
#endif

#ifdef NEWOutputMaker_call
        phase_plot_NEW();
#endif
        snapshot_counter++;
    }


    if ( (i+1) % nprint_T == 0 ){

        double _temperature = phase_plot_T();
/*
        if ( _temperature > 1.1 * init_gran_temp ){

            cerr << "\n\nerror: increasing temperature\n"
                 << "change your system parameters\n"
                 << "Simulation stopped at the time step: "<< i <<"\n";

            return false;

        }
*/
    }

    return true;
}


//====================================================
//====================================================  final_prints
//====================================================

void final_prints(clock_t t1){

    clock_t t2;

    t2 = clock();

    float diff ((float)t2-(float)t1);

    cout            << "\n execution time: "  << diff / CLOCKS_PER_SEC << " seconds\n"      ;
    FileDataOut     << "\n execution time: "  << diff / CLOCKS_PER_SEC << " seconds\n"      ;

}

//====================================================
//====================================================  V_COM_zero
//====================================================

void V_COM_zero( bool make_zero_momentum ){
   

    double p_com_x = 0.0;

    for ( unsigned int i = 0; i < Sheaths.size(); i++ ){

        p_com_x += Sheaths[i].v_com();

    }

    p_com_x /= double ( Sheaths.size() );

    cout << "\np_com = " << p_com_x << endl;

    if ( make_zero_momentum ) {

        for ( unsigned int i = 0; i < Sheaths.size(); i++ ){

            Sheaths[i].vx()   -= p_com_x;
            Sheaths[i].P_vx() -= p_com_x;

        }

    }


}

//====================================================
//====================================================  temperature_normalizer
//====================================================

void temperature_normalizer(){

    double _temp_com = 0;

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        _temp_com += Sheaths[i].v_com() *  Sheaths[i].v_com() ; 

    }

    _temp_com /= Sheaths.size();


//    cout << " T0 = " << _temp_com << endl;

//    double _scale = 1.0 / sqrt ( _temp_com );
    double _scale = sqrt ( init_gran_temp / _temp_com  );

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        Sheaths[i].vx()     *= _scale;
        Sheaths[i].P_vx()   *= _scale;

    }

    _temp_com = 0;

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        _temp_com += Sheaths[i].vx() *  Sheaths[i].vx() ; 

    }

    _temp_com /= Sheaths.size();

//    cout << " T1 = " << _temp_com << endl;



}


//====================================================
//====================================================  integrate
//====================================================

void integrate()
{

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){
  
        Sheaths[i].set_force_to_zero(); 

        Sheaths[i].predict( timestep );

    }


    make_forces();

  
    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        Sheaths[i].correct( timestep );

    }


    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        Sheaths[i].periodic_bc ( 0.0, lx );

    }

    Time += timestep;

#ifdef TwoGrainsPhasePlot
   
    calc_no_collisions();

#endif

}
//====================================================
//==================================================== Particle_slipped_out
//====================================================


bool Particle_slipped_out(int i){

    for ( unsigned j = 0; j < Sheaths.size(); j++ )

        if ( Sheaths[j].P_slipped_out() ){

            cerr << "Error: Particle " << j << " slipped out of its sheath at the step "  << i << "\n";

            return true;
        }

    return false;
}

//====================================================
//====================================================  init_parameters_check
//====================================================
/*
bool init_parameters_check(){
#ifdef ParticlesExist
  if ( Alpha < 0.0 || Alpha > 1.0 ){
    cout << "Error: assign #Alpha between " << 0.0 << " and " << 1.0 << endl;
    return false;
  }
  if ( Beta < 0.0 || Beta > 0.5 ){
    cout << "Error: assign #Beta between " << 0.0 << " and " << 0.5  << endl;
    return false;
  }
  if ( Alpha + Beta > 1.5 ){
    cout << "Error: assign #Alpha and #Beta so that (Alpha + Beta) would be between " << 0.0 << " and " << 1.5 << endl;
    return false;
  }
#endif
  return true;
}
*/



