#!/bin/bash
LIST="$(ls o_d_e*.dat)"
for file in $LIST; do
    if [ -e $file ] ; then
        gnuplot << EOF
        set term png size 800,600
        set output "pic_$file.png"
        p [0.8:1.1] "$file" w l lw 2
EOF
    fi
done
