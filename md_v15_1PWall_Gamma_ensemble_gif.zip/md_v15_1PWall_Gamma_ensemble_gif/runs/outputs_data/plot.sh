set term png
#set terminal png size 800,600 font "Helvetica,15" enhanced
set terminal pngcairo dashed size 800,600 font "Helvetica,15" enhanced
#set terminal pngcairo size 800,600 font "Helvetica,15" enhanced
#set output "check.png"
set border linewidth 2
#set xlabel "Shell and Core boundaries"
#set label "time"
set ylabel "Distribution Function"
set xlabel "Restitution Coef"
#set ylabel "Velocity"
set key right top
set grid
set xtic 0.02
#set output "check.png"
set output "rc_o_d_e:0.5_d:0.04_l:0.75_G:0.25.png"
set title "{/Symbol h} = 0.5    {/Symbol d} = 0.04      {/Symbol l} = 0.75    {/Symbol G} = 0.25"

p [0.86:1.02] \
    "o_d_e:0.5_d:0.04_l:0.75_G:0.25.dat" u 1:2 w l lw 2 ti ""

#p [:0.1] [:] \
#"nEW_nP:2_ft:100_dt:1e-05_e:0.05_d:0.75_zp:15_k:1e+07.dat" u 1:2 w l lw 2 ti "E_{tot}", \
#"nEW_nP:2_ft:100_dt:1e-05_e:0.05_d:0.75_zp:15_k:1e+07.dat" u 1:3 w l lw 2 ti "E_{com}", \
#"nEW_nP:2_ft:100_dt:1e-05_e:0.05_d:0.75_zp:15_k:1e+07.dat" u 1:4 w l lw 2 ti "E_{r} + U", \


#plot [:][:0.1] \
#    for [i=2:9] "xs_nP:2_ft:100_dt:1e-05_e:0.05_d:0.75_zp:15_k:1e+07_EI:1.dat" u i:1 w l lw 2 lt 1 lc rgb "blue" notitle  , \
#    for [i=2:5] "xp_nP:2_ft:100_dt:1e-05_e:0.05_d:0.75_zp:15_k:1e+07_EI:1.dat" u i:1 w l lw 2 lt 3 lc rgb "black" notitle  


#p [0.48:0.62] [:] \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:2 w l lw 2 ti "E_{com}", \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:5 w l lw 2 ti "E_{r}+U", \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:6 w l lw 2 ti "E_{tot}", \

#p [0.48:0.62] [-1:1] \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:7 w l lw 2 ti "V_{com}", \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:9 w l lw 2 ti "V_{S}", \
#"nEW_nP:2_FT:1_Mc:0.8_Ys:1000_As:89.4427_Y:1e+06_EI:1.dat" u 1:10 w l lw 2 ti "V_{C}", \


#"d_eta5:0.001_Ys:1000_Y:1e+06.dat" u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E-3" ,\
#"d_eta5:0.01_Ys:1000_Y:1e+06.dat"  u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E-2" ,\
#"d_eta5:0.1_Ys:1000_Y:1e+06.dat"   u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E-1" ,\
#"d_eta5:1_Ys:1000_Y:1e+06.dat"     u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E+0" ,\
#"d_eta5:10_Ys:1000_Y:1e+06.dat"    u 1:8 w l lw 2 ti "{/Symbol h}_{5} = 1E+1" ,\

#"d_eta1:0.001_Ys:1000_Y:1e+06.dat" u 1:8 w l lw 2 ti "{/Symbol g} = 1E-3" ,\
#"d_eta1:0.01_Ys:1000_Y:1e+06.dat"  u 1:8 w l lw 2 ti "{/Symbol g} = 1E-2" ,\
#"d_eta1:0.1_Ys:1000_Y:1e+06.dat"   u 1:8 w l lw 2 ti "{/Symbol g} = 1E-1" ,\
#"d_eta1:1_Ys:1000_Y:1e+06.dat"     u 1:8 w l lw 2 ti "{/Symbol g} = 1E+0" ,\
#"d_eta1:10_Ys:1000_Y:1e+06.dat"    u 1:8 w l lw 2 ti "{/Symbol g} = 1E+1" ,\
#abs (1 - 2 * x) w p pt 2 lt rgb "black"  ti "|1 - 2 {/Symbol d }|"

