#!/bin/bash
rm a.out *~
g++ main_rc_analysis.cc
mkdir o_
LIST="$(ls d_e*.dat)"
for file in $LIST; do
if [ -e $file ] ; then
echo "processing $file"
./a.out "$file" 0.001
mv "o_$file" o_/
fi
done
