#!/bin/bash
LIST="$(ls o_d_e*.dat)"
for file in $LIST; do
    if [ -e $file ] ; then
        gnuplot << EOF
	set xlabel "RC"
	set ylabel "p(RC)"
        set xtics 0.02
        set term png size 640,480
        set output "pic_$file.png"
        p [0.82:1.1] [:30] "$file" w l lw 2
EOF
    fi
echo "pic_$file.png"
done

mkdir png
mv *.png png/
