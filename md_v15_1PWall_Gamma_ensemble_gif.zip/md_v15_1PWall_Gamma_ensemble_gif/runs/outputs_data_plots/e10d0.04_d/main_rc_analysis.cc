#include <iostream>
#include <fstream>
#include <sstream>


using namespace std;


void analysis( ifstream &, ofstream &, double & );
void make_box();



int main ( int argc, char ** argv ) {


    if ( argc != 3 ) {
        cerr << "it should be like this: \n\t $ /a.out filename dr \n";
        return 0; 
    }

    string str_dr = argv[2];
    istringstream istr_dr ( str_dr );
    double d_dr;
    istr_dr >> d_dr;

    
    string str_fileIn = argv[1];
    string str_fileOut = "o_";
   
    str_fileOut.append( str_fileIn );

    const char * char_fileIn  = str_fileIn.c_str();
    const char * char_fileOut = str_fileOut.c_str();

    ifstream fileIn;
    ofstream fileOut;

    fileIn.open     ( char_fileIn  );
    fileOut.open    ( char_fileOut );



    analysis ( fileIn, fileOut, d_dr );


    fileIn.close();
    fileOut.close();

    return 0;
}



void analysis( ifstream & fileIn, ofstream & fileOut, double & d_dr ){

    double rc;

    double box_width = d_dr;

    const int box_size = int ( 3.0 / box_width );

    int box [ box_size ];

    int no_data = 0;

    for ( int i = 0; i < box_size; i++ ) {
        box [i] = 0;
    }


    fileIn >> rc;

    double rc_min = +5.0;
    double rc_max = -5.0;

    while ( !fileIn.eof() ) {

        fileIn >> rc;

        if ( rc < rc_min ) {
            rc_min = rc;
        }

        if ( rc > rc_max ) {
            rc_max = rc;
        }


        no_data ++;

        int box_index = int ( rc / box_width );

        box [box_index]++;

    }

//    bool flag_print = true;
    double normalizer = 1.0 / double ( no_data * box_width );


    for ( int i = 0; i < box_size-1; i++ ) {

        double d_index = double ( i ) * box_width ;
        double d_value = double ( box [i] ) * normalizer;

        if ( d_value != 0 ) {

            fileOut << d_index << " "<< d_value << endl;

        } else if ( d_value == 0 && ( box [i+1] != 0 || box [i-1] != 0 ) ){

            fileOut << d_index << " "<< d_value << endl;

        }
    }

   cout << "number of collisions: " << no_data << "\n";
   cout << "rc_min: " << rc_min << "\n";
   cout << "rc_max: " << rc_max << "\n";
}
