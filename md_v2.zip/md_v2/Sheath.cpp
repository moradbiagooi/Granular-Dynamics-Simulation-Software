
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include <assert.h>

#include "Sheath.h"
#include "properties.h"


#define GSmallNumber 1e-4

//====================================================
//==================================================== S::P_slipped_out
//====================================================

bool Sheath::P_slipped_out(){

    double center_dist = P_x() > x() ? P_x() - x() : x() - P_x();

    if (center_dist > r() - GSmallNumber - P_r())
        return true;
    else
        return false;

}

//====================================================
//==================================================== S::predict
//====================================================

void Sheath::predict( double dt )
{

    P.predict( dt );

    double a1 = dt;
    double a2 = a1 * dt / 2;
    double a3 = a2 * dt / 3;
    double a4 = a3 * dt / 4;

    rtd0 += a1 * rtd1 + a2 * rtd2 + a3 * rtd3 + a4 * rtd4;
    rtd1 += a1 * rtd2 + a2 * rtd3 + a3 * rtd4;
    rtd2 += a1 * rtd3 + a2 * rtd4;
    rtd3 += a1 * rtd4;

}

//====================================================
//==================================================== S::correct
//====================================================

void Sheath::correct( double dt )
{

    P.correct( dt );

    static double accel, corr;

    double dtrez = 1 / dt;

    const double coeff0 = double(19) / double(90)  * ( dt * dt / double(2)            );
    const double coeff1 = double(3 ) / double(4 )  * ( dt      / double(2)            );
    const double coeff3 = double(1 ) / double(2 )  * ( double(3 ) *   dtrez           );
    const double coeff4 = double(1 ) / double(12)  * ( double(12) * ( dtrez * dtrez ) );

    accel = ( ( 1 / _m ) * _force );

    corr  = accel - rtd2;

    rtd0 += coeff0 * corr;
    rtd1 += coeff1 * corr;
    rtd2  = accel;
    rtd3 += coeff3 * corr;
    rtd4 += coeff4 * corr;

}

//====================================================
//==================================================== S::internal_force
//====================================================

void Sheath::internal_force( double lx )
{

// - Spring Part ----

    double dx = x() - P.x();          // X_1 - X_2

    double Y_sp = P.Y_sp();

    double A_sp = P.A_sp();

    double dvx = vx() - P.vx();       // relative velocity component x: (V_x)_1 -(V_x)_2 

    double fs = Y_sp * dx + A_sp * dvx;     // Linear dashpod Force

// --- -------- --- Sheath contact part

    double rr = sqrt( dx * dx );      // distance between center of P. and S.

    double r1 = _r;

    double r2 = P.r();

    double r3 = _r_mid;

    double xi = rr + r2 - r3;

    if ( xi > 0 ) {

        double Y = _A;

        double A = _A;

        double rr_rez = 1 / rr;         // distance^(-1)

        double ex = dx * rr_rez;        // dX/rr

        double xidot = ( ex * dvx );    // -(dX*dV_x)/rr = - e_ij . dV_ij

        double fn = Y * xi + A * xidot; // Linear dashpod Force


        if( fn < 0 ) fn = 0;            // non-negative force condition : fn = max ( 0 , fn) 

        add_force   ( -fn * ex - fs );
        P.add_force (  fn * ex + fs );

    } else {

        add_force   ( -fs );
        P.add_force (  fs );

    }

}

//====================================================
//==================================================== force
//====================================================

void force( Sheath & p1, Sheath & p2, double lx ) 
{

    double dx = normalize( p1.x() - p2.x(), lx );

    double rr = sqrt ( dx * dx );// distance between center of two Sheaths
 
    double r1 = p1.r();
    double r2 = p2.r();
  
    double xi = r1 + r2 - rr;//  compression : radius1+radius2-distance

    if( xi > 0 ){


        double Y = p1.Y();

        double A = p1.A();

        double reff = ( r1 * r2 ) / ( r1 + r2 );// effective radius

        double dvx = p1.vx() - p2.vx();// relative velocity component x: (V_x)_1 -(V_x)_2 

        double rr_rez = 1 / rr;// distance^(-1)

        double ex = dx * rr_rez;// dX/rr

        double xidot = -( ex * dvx );// -(dX*dV_x+dY*dV_y)/rr = - e_ij . dV_ij

        double fn = Y * xi + A * xidot; // Linear dashpod Force

        if ( fn < 0 ) fn = 0; // non-negative force condition : fn = max ( 0 , fn)

        p1.add_force( fn * ex  );
        
        p2.add_force( -fn * ex );

         

    }

}

//====================================================
//==================================================== S::periodic_bc
//====================================================


void Sheath::periodic_bc( double x_0, double lx )
{
    while( rtd0 < x_0 )      { rtd0 += lx; P.x() += lx; _pbc_index--; }
    while( rtd0 > x_0 + lx ) { rtd0 -= lx; P.x() -= lx; _pbc_index++; }
}

//====================================================
//==================================================== S::kinetic_energy
//====================================================

double Sheath::kinetic_energy() const 
{
    return  _m * ( rtd1 * rtd1 ) / 2;
}


