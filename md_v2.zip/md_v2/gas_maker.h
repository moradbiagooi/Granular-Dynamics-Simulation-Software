#ifndef __GAS_MAKER_H
#define __GAS_MAKER_H

#include "MersenneTwister.h"

void gas_maker ( MTRand * );

#endif
