#ifndef __CLASS_GRAIN_H
#define __CLASS_GRAIN_H

class grain {


    public:
        grain (){}

        double x_c ()   const { return _x_c;   }
        double x_s ()   const { return _x_s;   }        
        double v_c ()   const { return _v_c;   }
        double v_s ()   const { return _v_s;   }        
        double xi  ()   const { return _xi;    }
        double vxi ()   const { return _vxi;   }
        double x_com () const { return _x_com; }        
        double v_com () const { return _v_com; }


        double & x_c ()       { return _x_c;   }
        double & x_s ()       { return _x_s;   }        
        double & v_c ()       { return _v_c;   }
        double & v_s ()       { return _v_s;   }        
        double & xi  ()       { return _xi;    }
        double & vxi ()       { return _vxi;   }
        double & x_com ()     { return _x_com; }        
        double & v_com ()     { return _v_com; }

        double m_c ()   const { return _m_c;   }
        double m_s ()   const { return _m_s;   }        

        double & m_c ()       { return _m_c;   }
        double & m_s ()       { return _m_s;   }

        double t_p ()   const { return _t_p;   }
        double t_n ()   const { return _t_n;   }        

        double & t_p ()       { return _t_p;   }
        double & t_n ()       { return _t_n;   }

        double A_1 ()   const { return _A_1;   }
        double A_2 ()   const { return _A_2;   }        

        double & A_1 ()       { return _A_1;   }
        double & A_2 ()       { return _A_2;   }


        void print_x();



    private:

        double _x_c, _x_s, _v_c  , _v_s  ;  // Position and velocity of Core or Shell
        double _xi , _vxi, _x_com, _v_com;  // x_s - x_c , v_s - v_c , Center of mass Position and velocity
        double _m_s, _m_c;                  // Mass of shell and core
        double _A_1, _A_2;                  // Coefficients used in xi(t) and vxi(t)  
        double _t_p, _t_n;                  // the time of previous and next collision

};

#endif
