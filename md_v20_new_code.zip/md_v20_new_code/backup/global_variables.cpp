
#include "global_variables.h"


const long    G_random_seed     = 10;

const int     G_no_grains       = 10;
const int     G_max_collisions  = 10;

 
const double  G_Y               = 1000.0;
const double  G_gamma           = 1.0;
const double  G_dm              = 0.1;

const double  G_packing_factor  = 0.05;

const double  G_radius          = 0.5;

//const double  G_dt            = 0.1;
//const double  G_max_time      = 1.0;


