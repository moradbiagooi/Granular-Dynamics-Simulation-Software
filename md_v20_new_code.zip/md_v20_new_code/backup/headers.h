#ifndef __GRAIN_H
#define __GRAIN_H


#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>

using namespace std;

#endif

