rm a.out *~
icpc *.cpp *.h
./a.out
