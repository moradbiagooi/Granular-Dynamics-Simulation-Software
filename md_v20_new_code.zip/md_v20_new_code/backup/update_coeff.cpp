#include "update_coeff.h"

#include "headers.h"
#include "class_grain.h"
#include "global_variables.h"


extern vector < grain > grains;


void update_coeff_all ( int damping_status, double omega_1, double omega_2 ) {


    for ( unsigned int i = 0; i < G_no_grains; i++ ) {


        grains[i].t_p() = 0.0;


        double xi_0  = grains[i].xi();
        double vxi_0 = grains[i].vxi();



        if ( damping_status == 1) {

            double q_1 = omega_1;
            double q_2 = omega_2;

            double A_1 = ( xi_0 * q_1  +  vxi_0 ) / ( q_1  -  q_2 );
            double A_2 = ( xi_0 * q_2  +  vxi_0 ) / ( q_2  -  q_1 );

            grains[i].A_1() = A_1;
            grains[i].A_2() = A_2;


        } else if ( damping_status == 0 ) {

            double q = omega_1;

            double A = vxi_0 + q * xi_0;
            double B = xi_0;

            grains[i].A_1() = A;
            grains[i].A_1() = B;

        } else {

            double q     = omega_1;
            double omega = omega_2;

            double phi   = atan ( ( vxi_0  +  xi_0 * q ) / omega );
    
            double C     = xi_0 / cos ( phi );

            grains[i].A_1() = phi;
            grains[i].A_2() = C;           

        }

    }






}
