
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include "class_core.h"
#include "global_variables.h"


//====================================================
//==================================================== P::predict
//====================================================

void Core::predict( )
{

    double a1 = G_dt;
    double a2 = a1 * G_dt/2;
    double a3 = a2 * G_dt/3;
    double a4 = a3 * G_dt/4;

    rtd0 += a1*rtd1 + a2*rtd2 + a3*rtd3 + a4*rtd4;
    rtd1 += a1*rtd2 + a2*rtd3 + a3*rtd4;
    rtd2 += a1*rtd3 + a2*rtd4;
    rtd3 += a1*rtd4;

}

//====================================================
//==================================================== P::correct
//====================================================

void Core::correct( )
{

    static double accel,corr;

    double dtrez = double(1)/G_dt;

    const double coeff0 = double(19) / double(90) *(G_dt*G_dt       / double(2)     );
    const double coeff1 = double(3)  / double(4)  *(G_dt            / double(2)     );
    const double coeff3 = double(1)  / double(2)  *(double(3)   * dtrez             );
    const double coeff4 = double(1)  / double(12) *(double(12)  * (dtrez*dtrez)     );

    accel = ((1/_m)*_force);

    corr  = accel-rtd2;

    rtd0 += coeff0*corr;
    rtd1 += coeff1*corr;
    rtd2  = accel;
    rtd3 += coeff3*corr;
    rtd4 += coeff4*corr;
}


