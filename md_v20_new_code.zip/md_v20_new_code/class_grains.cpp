#include "class_grains.h"
/*
inline double normalize ( double dx, double L ) {
    while ( dx <- L / 2 ) dx += L;
    while ( dx >= L / 2 ) dx -= L;
    return dx;
}
*/
        
//inline double abs ( double x ) { return x < 0 ? -x : x; }


//====================================================
//==================================================== Grains::
//====================================================


void Grains::create_grains(){

    shells = new Shell* [ G_no_grains ];

    for ( int i = 0; i < G_no_grains; i++ )

        shells[i] = new Shell;

}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::destroy_grains(){

    for ( int i = 0; i < G_no_grains; i++ )

        delete shells[i];

    delete [] shells;
}

//====================================================
//==================================================== Grains::
//====================================================

bool Grains::shell_jumped(){

    for ( int i = 0; i < G_no_grains; i++ ) {

        int j_1,j_2;

        if ( i == G_no_grains - 2  ) {
            j_1 = i+1;
            j_2 = 0;

        } else if ( i == G_no_grains - 1  ) {
            j_1 = 0;
            j_2 = 1;
        } else {
            j_1 = i+1;
            j_2 = i+2;
        }


        double distance_12 = abs ( normalize ( shells[i] -> x() - shells[j_1] -> x(), G_lx ) );
        double distance_13 = abs ( normalize ( shells[i] -> x() - shells[j_2] -> x(), G_lx ) );


        if ( distance_12 > distance_13 ) {

            cout << " Error: two grains jumped of one-another.\n";
            return true;

        }

    }

    return false;

}

//====================================================
//==================================================== Grains::
//====================================================

int Grains::gas_is_homogeneous(){

    int lattice [ G_no_grains ];

    for ( int i = 0; i < G_no_grains; i++ ) {
        
        lattice [i] = 0;

    }

    for ( int i = 0; i < G_no_grains; i++ ) {

        int shell_index = int ( shells[i] -> x() );

        lattice [ shell_index ] ++;

    }

    int no_zeros = 0;

    for ( int i = 0; i < G_no_grains; i++ ) {
        if ( lattice [i] == 0 )
            no_zeros ++;
    }

    return no_zeros;

}

//====================================================
//==================================================== Grains::
//====================================================


bool Grains::solve_eq_of_motion(){

    for ( int i = 0; i < G_no_grains; i++ ) {

        shells[i] -> set_force_to_zero();

        shells[i] -> predict ( );

    }


    for ( int i = 0; i < G_no_grains; i++ ){

        shells[i] -> internal_force ();

        if ( i+1 == G_no_grains ){
            force( shells[i], shells[0] ); // Periodic B.C
        }
        else
        {
            force( shells[i], shells[i+1] ); // LINEAR NEIGHBORS
        }

    }

    for ( int i = 0; i < G_no_grains; i++ ) {

        shells[i] -> correct ( );

        shells[i] -> periodic_bc ( );

        if ( shells[i] -> Core_slipped_out ( ) ){

            cout << " Error : a core went out of its shell.\n";

            return false;
        }

    }

    return true;

}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::initial_condition ( class Init_Parameters * init_parameters, class MTRand * RandNumb )
{

    for ( int i = 0; i < G_no_grains; i++ ) {

        shells[i] -> set_parameters ( init_parameters, RandNumb );

        shells[i] -> pbc_index () = 0;

    }


    double alpha    = init_parameters -> alpha  ();
    double beta     = init_parameters -> beta   ();
    double lambda   = init_parameters -> lambda ();


    double radius_out   = 0.5 * ( 1.0 - lambda );
    double radius_mid   = radius_out * ( 1.0 - 2.0 * beta );
    double radius_core  = radius_out * alpha;


    double grain_x [ G_no_grains ];

    int grains_counter = 0;


    while ( grains_counter < G_no_grains ) {

        double temp_x = G_lx * RandNumb -> randDblExc();


        bool flag_freeSpace = true;

        int i = 0;

        while ( flag_freeSpace && i < grains_counter ){

            double distance = abs( temp_x - grain_x[i] );

            if ( distance > G_lx / 2.0 ) {
                distance = G_lx - distance;
            }

            if ( distance < 2.1 * radius_out ){
               flag_freeSpace = false;
            }

            i++;

        }

        if ( flag_freeSpace ){

            grain_x [ grains_counter ] = temp_x;

            grains_counter++;

        }

    }

// -----------------------
// ----------------------- sorting grain_x[]


    bool flag_disorder = true;

    while ( flag_disorder ){

        flag_disorder = false;

        for ( int i = 0; i < G_no_grains; i++ ){

            for ( int j = 0; j < G_no_grains; j++ ){

                if ( grain_x[i] > grain_x[j] && i < j ){

                    flag_disorder = true;
                    double temp_x = grain_x[i];
                    grain_x[i]    = grain_x[j];
                    grain_x[j]    = temp_x;

                }

            }

        }

    }



    for ( int i = 0; i < G_no_grains; i++ ) {

        shells[i] -> x()    = grain_x [i];

        shells[i] -> vx()   = ( 0.5 - RandNumb -> rand() );


        shells[i] -> Core_x()   = shells[i] -> x();

        shells[i] -> Core_vx () = shells[i] -> vx();

    }



/*
    for ( int i = 0; i < G_no_grains; i++ ) {

        shells[i] -> x()    = double ( i ) + 0.5;

        shells[i] -> vx()   = ( 0.5 - RandNumb -> rand() );


        shells[i] -> Core_x()   = shells[i] -> x();

        shells[i] -> Core_vx () = shells[i] -> vx();

    }
*/

//
}
//====================================================
//==================================================== Grains::
//====================================================


double Grains::energy_com() {

    double E = 0;

    for ( int i = 0; i < G_no_grains; i++ )

        E += shells[i] -> E_com ();

    return E;
}

//====================================================
//==================================================== Grains::
//====================================================



void Grains::set_initial_temperature ( double T0 ) {


    bool check_it = true;

check_point_temperature:    
    
    double temp_com = 0;

    for( unsigned int i = 0; i < G_no_grains; i++ ){

        temp_com += shells [i] -> v_com()  *  shells [i] -> v_com(); 

    }

    temp_com /= double ( G_no_grains );


    cout << " T0 = " << temp_com << endl;

    if ( check_it ) {

        check_it = false;


        double scale_temp = sqrt ( T0 / temp_com  );

        for( unsigned int i = 0; i < G_no_grains; i++ ){

            shells [i] -> vx()          *= scale_temp;
            shells [i] -> Core_vx()     *= scale_temp;

        }

        goto check_point_temperature;
    }


}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::set_tot_momentum_to_zero () {


    bool check_it = true;

check_point_momentum:

    double p_com_x = 0.0;

    for ( unsigned int i = 0; i < G_no_grains; i++ ){

        p_com_x += shells [i] -> v_com();

    }

    p_com_x /= double ( G_no_grains );

    cout << "\np_com = " << p_com_x << endl;


    if ( check_it ) {

        check_it = false;


        for ( unsigned int i = 0; i < G_no_grains; i++ ){

            shells [i] -> vx()      -= p_com_x;
            shells [i] -> Core_vx() -= p_com_x;

        }


        goto check_point_momentum;
    }


}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::output_data ( double time, ofstream & ofs_energy ) {

//    ofs_energy  << time << " " << energy_com() << "\n" ;
/*
    ofs_energy  << time << " " 
                << shells[0] -> x() + shells[0] -> r() + shells[0] -> pbc_index() * G_lx << " " 
                << shells[0] -> x() - shells[0] -> r() + shells[0] -> pbc_index() * G_lx << " "  
                << shells[1] -> x() + shells[1] -> r() + shells[1] -> pbc_index() * G_lx << " " 
                << shells[1] -> x() - shells[1] -> r() + shells[1] -> pbc_index() * G_lx << "\n" << flush;
*/
/*
    ofs_energy  << time << " " 
                << shells[0] -> x()         + shells[0] -> r()         + shells[0] -> pbc_index() * G_lx << " " 
                << shells[0] -> x()         - shells[0] -> r()         + shells[0] -> pbc_index() * G_lx << " "  
                << shells[1] -> x()         + shells[1] -> r()         + shells[1] -> pbc_index() * G_lx << " " 
                << shells[1] -> x()         - shells[1] -> r()         + shells[1] -> pbc_index() * G_lx << " "
                << shells[0] -> Core_x()    + shells[0] -> Core_r()    + shells[0] -> pbc_index() * G_lx << " " 
                << shells[0] -> Core_x()    - shells[0] -> Core_r()    + shells[0] -> pbc_index() * G_lx << " "  
                << shells[1] -> Core_x()    + shells[1] -> Core_r()    + shells[1] -> pbc_index() * G_lx << " " 
                << shells[1] -> Core_x()    - shells[1] -> Core_r()    + shells[1] -> pbc_index() * G_lx << "\n" << flush;
*/

    ofs_energy  << time << " ";

    for ( int i = 0; i < G_no_grains; i++ ) {

        ofs_energy  << shells [i] -> x()  +  shells [i] -> pbc_index() * G_lx << " ";

    }

    ofs_energy << gas_is_homogeneous() << " ";

    ofs_energy << "\n" << flush;



//    cout        << time << " " << energy_com() << "\n" ;
}

//====================================================
//==================================================== Grains::
//====================================================

//====================================================
//==================================================== Grains::
//====================================================


