#ifndef _CLASS_GRAINS_H
#define _CLASS_GRAINS_H

#include "headers.h"
#include "class_shell.h"
#include "global_variables.h"
#include "MersenneTwister.h"


using namespace std;



class Grains {


    public:


        Grains(){};
				~Grains() { destroy_grains(); }


        class Shell     **shells;


        void create_grains ();

        void destroy_grains ();

        void initial_condition ( class Init_Parameters *, class MTRand * );

        void set_initial_temperature ( double T0 );

        void output_data ( double time, ofstream & );

        void set_tot_momentum_to_zero ();


        bool solve_eq_of_motion ();

        bool shell_jumped();


        int gas_is_homogeneous();


        double energy_com ();


};

#endif
