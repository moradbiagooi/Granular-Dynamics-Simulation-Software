#ifndef _CLASS_SHELL_H
#define _CLASS_SHELL_H

#include "headers.h"
#include "class_core.h"
#include "MersenneTwister.h"
#include "class_init_parameters.h"


//using namespace std;

//inline double abs ( double x ) { return x < 0 ? -x : x; }


inline double normalize ( double dx, double L ) {
    while ( dx <- L / 2 ) dx += L;
    while ( dx >= L / 2 ) dx -= L;
    return dx;
}



class Shell {

    friend void force ( Shell * p1, Shell * p2 );
    
public:

    Shell(): rtd0(0), rtd1(0), rtd2(0), rtd3(0), rtd4(0)
    {}


    double & Core_x()          {return _C.x();}
    double   Core_x() const    {return _C.x();}
 
    double & Core_vx()         {return _C.vx();}
    double   Core_vx() const   {return _C.vx();}


    double & Core_r()          {return _C.r();}
    double   Core_r() const    {return _C.r();}

    double   Core_m() const    {return _C.m();}
    double & Core_m()          {return _C.m();}

    double & Core_Y_sp()          {return _C.Y_sp();}
    double   Core_Y_sp() const    {return _C.Y_sp();}

    double & Core_A_sp()          {return _C.A_sp();}
    double   Core_A_sp() const    {return _C.A_sp();}

    int & pbc_index()       {return _pbc_index;} 
    int   pbc_index() const {return _pbc_index;} 

    double & x()            {return rtd0;}
    double   x() const      {return rtd0;}

    double & vx()           {return rtd1;}
    double   vx() const     {return rtd1;}


    double   x_com() const {
        return (  x() * m()  +  Core_x()  * Core_m() ) / ( m()  +  Core_m() );
    }

    double   v_com() const {
        return ( vx() * m()  +  Core_vx() * Core_m() ) / ( m()  +  Core_m() );
    }


    double & r()            {return _r;}
    double   r() const      {return _r;}

    double & r_mid()        {return _r_mid;}
    double   r_mid() const  {return _r_mid;}

    double   m() const      {return _m;}
    double & m()            {return _m;}

    double & Y()            {return _Y;}
    double   Y() const      {return _Y;}

    double & A()            {return _A;}
    double   A() const      {return _A;}

    double   f()   const    {return _force;}
    double   Core_f() const {return _C.f();}

    void predict ( );                        //First step of the Gear algorithm

    void correct ( );                        //Second step of the Gear algorithm


    double E_tot    ( ) const;  
    double U        ( ) const;  
    double E_r      ( ) const;  
    double E_com    ( ) const;     


    bool Core_slipped_out();
    bool Core_S_collide();


    void set_force_to_zero(){
        _force=0;
        _C.set_force_to_zero();
    }

    void add_force ( const double & f )
    {   _force+=f; }                                //Adds a value to the total force _force of the Shell


    void periodic_bc ( );        //Enforces the periodic boundary conditions

    void internal_force ( );


    void set_parameters ( class Init_Parameters *, class MTRand * );


private:

    int _pbc_index;

    double _r, _m, _r_mid;
    double _Y, _A;


    double rtd0,rtd1,rtd2,rtd3,rtd4;
    double _force;

    Core _C;

};


#endif
