
#include "functions.h"
#include "global_variables.h"
#include "headers.h"


/*
void calc_damping_status( int  & damping_status, double & omega_1, double & omega_2  ){


    double m_eff = G_dm * ( 1.0 - G_dm );

    double delta = G_gamma * G_gamma - 4 * m_eff * G_Y;

    cout << "delta = " << delta << "\n";

    double q     = G_gamma / ( 2 * m_eff );

    cout << "q = " << q << "\n";

    if ( delta > 0) {

        damping_status = 1;

        cout << "Delta > 0\n";



        double q_1 =  q + ( sqrt ( delta ) / ( 2 * m_eff ) );
        double q_2 =  q - ( sqrt ( delta ) / ( 2 * m_eff ) );

        cout << "q_1 = " << q_1 << "   q_2 = " << q_2 << "\n";

        omega_1 = q_1;
        omega_2 = q_2;

    } else if ( delta == 0 ) {

        damping_status = 0;

        cout << "Delta = 0\n";

        omega_1 = q;
        omega_2 = q;

    } else {

        damping_status = -1;

        cout << "Delta < 0\n";

        double omega = sqrt ( ( G_Y / m_eff ) - q * q );

        cout << "omega = " << omega << "\n";

        omega_1 = q;
        omega_2 = omega;
    }




}
*/

//===================================================================
/*

double xi ( double t ) {


    if ( delta > 0) {

        return A_1 * exp ( - q_1 * t ) + A_2 * exp ( - q_2 * t );

    } else if ( delta == 0 ) {

        return ( A * t + B ) * exp ( - q * t);

    } else {

        return C * exp ( - q * t ) * cos ( omega * t - phi );

    }

  
}


//===================================================================


double vxi ( double t ) {


    if ( delta > 0) {

//        return A_1 * exp ( - q_1 * t ) + A_2 * exp ( - q_2 * t );
        return - q_1 * A_1 * exp ( - q_1 * t ) - q_2 * A_2 * exp ( - q_2 * t );


    } else if ( delta == 0 ) {

//        return ( A * t + B ) * exp ( - q * t );
        return ( A + ( A * t + B ) * ( - q ) ) * exp ( - q * t );

    } else {

//        return C * exp ( - q * t ) * cos ( omega * t - phi );
        return exp ( - q * t ) * C * ( (-q) * cos ( omega * t - phi ) + (- omega ) * sin ( omega * t - phi ) );


    }

  
}*/
