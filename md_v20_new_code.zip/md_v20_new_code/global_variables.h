#ifndef _GLOBAL_VARIABLES_H
#define _GLOBAL_VARIABLES_H

extern const long    G_random_seed     ;

extern const int     G_no_grains       ;
//extern const int     G_max_collisions  ;

extern const double  G_lx;

//extern const double  G_Y               ;
//extern const double  G_gamma           ;
//extern const double  G_dm              ;
//extern const double  G_packing_factor  ;
//extern const double  G_radius          ;

extern const double  G_dt              ;
extern const double  G_time_final      ;

#endif
