
#include "main_SpringModel.h"
#include "headers.h"
#include "global_variables.h"
#include "class_grains.h"
#include "MersenneTwister.h"
#include "functions.h"
#include "v_com_zero.h"
#include "class_init_parameters.h"


using namespace std;



int main () {


    clock_t time_start, time_end;

    time_start = clock ();


    class MTRand    *RandNumb = new MTRand ( G_random_seed );

    class Grains    *grains   = new Grains;

    class Init_Parameters   *init_parameters = new Init_Parameters;



    ofstream ofs_energy;

    ofs_energy.open ( "energy.txt" );



    init_parameters -> debug_parameters ();
    init_parameters -> make_parameters  ();


    grains -> create_grains ();

    grains -> initial_condition ( init_parameters, RandNumb );

    grains -> set_tot_momentum_to_zero ();

    grains -> set_initial_temperature ( init_parameters -> initial_temperature() );


    if ( !init_parameters -> G_dt_is_small_enough () ) {
        cout << " Error: there's a problem\n";
    }

    long i_max = long ( G_time_final / G_dt );


    for ( long i = 0; i < i_max; i++ ) {


        double time = double (i) * G_dt;


        if ( !grains -> solve_eq_of_motion () ) 

            i = i_max;
        

        if ( i % 10 == 0 ) {


            if ( grains -> shell_jumped() ) 
                i = i_max;


            grains -> output_data ( time, ofs_energy );

        }


    }

 


    time_end = clock ();

    double total_time =  ( (float)time_end - (float)time_start ) / CLOCKS_PER_SEC; 

    cout << "\n\n  Total ensemble execution time: "  << total_time << " seconds\n\n" ;



    ofs_energy.close ();


    delete grains;

    delete RandNumb;

    delete init_parameters;


    return 0;
}





