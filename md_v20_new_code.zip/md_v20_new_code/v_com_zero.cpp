#include "v_com_zero.h"
#include "class_grains.h"
#include "headers.h"
#include "global_variables.h"
#include "global_variables.h"

/*
extern vector < grain > grains;


void v_com_zero() {

    double v_x_tot = 0.0;

    for ( int i = 0; i < G_no_grains; i++ ) {

        v_x_tot += grains[i].v_com();

    }

    double v_correct = v_x_tot / double ( G_no_grains ) ;

    for ( int i = 0; i < G_no_grains; i++ ) {

        grains[i].v_c() -= v_correct;
        grains[i].v_s() -= v_correct;

    }

    v_x_tot = 0.0;

    for ( int i = 0; i < G_no_grains; i++ ) {

        v_x_tot += grains[i].v_com();

    }

    cout << "V_COM = " << v_x_tot << "\n";


}*/
