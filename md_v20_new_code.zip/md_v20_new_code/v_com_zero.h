#ifndef _V_COM_ZERO_H
#define _V_COM_ZERO_H
void v_com_zero();
#endif
