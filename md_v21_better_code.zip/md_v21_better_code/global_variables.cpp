
#include "global_variables.h"


const long         G_random_seed     = 30;

const unsigned int G_no_grains       = 20;

const double       G_lx              = double ( G_no_grains );

//const double  G_packing_factor  = 0.05;

const double  G_dt              		= 1E-4;
const double  G_time_final      		= 100.;


