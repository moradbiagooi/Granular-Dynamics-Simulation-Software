#ifndef _GLOBAL_VARIABLES_H
#define _GLOBAL_VARIABLES_H

extern const long    G_random_seed     ;

extern const unsigned int     G_no_grains       ;

extern const double  G_lx;

//extern const double  G_packing_factor  ;

extern const double  G_dt              ;
extern const double  G_time_final      ;

#endif
