#ifndef _PRE_PROCESSORS_H
#define _PRE_PROCESSORS_H


#define RandomInitialPosition

#define RandomInitialVelocity

#define MIN_INIT_SEPERATION 0.1 

#define PI 3.14159265

#define NO_BOXES 10
#define NO_SIGMAS 3
#define NO_POS_MOMENTS 5


#endif
