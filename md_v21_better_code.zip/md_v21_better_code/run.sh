rm a.out *~
g++ -Wall *.cpp
./a.out
