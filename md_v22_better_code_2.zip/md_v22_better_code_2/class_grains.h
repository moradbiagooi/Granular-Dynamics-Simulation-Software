#ifndef _CLASS_GRAINS_H
#define _CLASS_GRAINS_H

#include "headers.h"
#include "class_shell.h"
#include "global_variables.h"
#include "MersenneTwister.h"


using namespace std;



class Grains {


    public:


        Grains();
				~Grains();

				vector <Shell> shells;

        void create_grains ();

        void destroy_grains ();

        void initial_condition ( class Init_Parameters *, class MTRand * );

        void set_initial_temperature ( double T0 );

        void output_data ( double time, int type ); // type 0 to be outputed in most steps, type 1 for large amount of data to be outputted less.

        void set_tot_momentum_to_zero ();

				void calc_distribution_stat ();

				void make_output_files ();

				void calc_energies ();


        bool solve_eq_of_motion ();

        bool shell_jumped ( double time );

				bool energy_increased ( );


		private:

				bool 		init_energy_assigned;
				double 	init_energy;

        double energy_com ();

				double sigma 						[ NO_SIGMAS 		 ];
				double pos_moments 			[ NO_POS_MOMENTS ];
				double vel_c_moments 		[ NO_VEL_MOMENTS ];
				double vel_s_moments 		[ NO_VEL_MOMENTS ];
				double vel_com_moments 	[ NO_VEL_MOMENTS ];

				double en_tot, en_kin, en_kin_core, en_kin_shell, en_spr_ss, en_spr_sc, en_spr_in; // energies

				ofstream ofs_energy, ofs_pos_moments, ofs_vel_s_moments, ofs_vel_c_moments, ofs_vel_com_moments, ofs_sigma, ofs_positions, ofs_velocities;
				
};

#endif
