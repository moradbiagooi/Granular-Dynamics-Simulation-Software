#ifndef _HEADERS_H
#define _HEADERS_H


#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <time.h>

using namespace std;

#endif

