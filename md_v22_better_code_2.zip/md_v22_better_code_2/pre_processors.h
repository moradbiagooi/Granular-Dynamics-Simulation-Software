#ifndef _PRE_PROCESSORS_H
#define _PRE_PROCESSORS_H


#define RandomInitialPosition

#define RandomInitialVelocity


#define PI 3.14159265

#define NO_BOXES 10				// used for calculating sigmas
#define NO_SIGMAS 3				// a measure for position homogeneouosity of the gas
#define NO_POS_MOMENTS 4	// another measure for position homogeneousity of the gas
#define NO_VEL_MOMENTS 4	// a measure for velocity distribution shape
#define XSCALE_TOT 1.0		// scale all radiuses and system size. It doesn't change the initial velocity.

#define _ALPHA		0.05
#define _BETA			0.05
#define _LAMBDA		0.75
#define _DELTA		0.51
#define _KAPPA		double(1E7) // Young modulus of contacts


#define _UNITS_METHOD_0
//#define _UNITS_METHOD_1
//#define _UNITS_METHOD_2



#define _ETA			1.5

#define _Y_SP 10.0
#define _A_SP 10.0

#define _INIT_TEMP 0.1


#endif
