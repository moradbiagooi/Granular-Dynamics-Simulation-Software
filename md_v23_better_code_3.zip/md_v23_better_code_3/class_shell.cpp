#include "class_shell.h"
#include "headers.h"
#include "global_variables.h"
#include "pre_processors.h"

//====================================================
//==================================================== S::Core_slipped_out
//====================================================

bool Shell::Core_slipped_out()
{
    double distance = abs ( x() - Core_x() ) + Core_r();

    if ( distance > r() * double(0.99999) )
        return true;
    else
        return false;
}

//====================================================
//==================================================== S::predict
//====================================================

void Shell::predict( )
{
		_xi_ss = _xi_sc = _xi_sp = 0.0;

    _C.predict( );

    double a1 = G_dt;
    double a2 = a1 * G_dt / double(2);
    double a3 = a2 * G_dt / double(3);
    double a4 = a3 * G_dt / double(4);

    rtd0 += a1 * rtd1 + a2 * rtd2 + a3 * rtd3 + a4 * rtd4;
    rtd1 += a1 * rtd2 + a2 * rtd3 + a3 * rtd4;
    rtd2 += a1 * rtd3 + a2 * rtd4;
    rtd3 += a1 * rtd4;

}

//====================================================
//==================================================== S::correct
//====================================================

void Shell::correct( )
{

    _C.correct( );

    static double accel, corr;

    double dtrez = double(1) / G_dt;

    const double coeff0 = double(19) / double(90)  * ( G_dt * G_dt / double(2)            );
    const double coeff1 = double(3 ) / double(4 )  * ( G_dt        / double(2)            );
    const double coeff3 = double(1 ) / double(2 )  * ( double(3 ) *   dtrez               );
    const double coeff4 = double(1 ) / double(12)  * ( double(12) * ( dtrez * dtrez )     );

    accel = ( ( double(1) / _m ) * _force );

    corr  = accel - rtd2;

    rtd0 += coeff0 * corr;
    rtd1 += coeff1 * corr;
    rtd2  = accel;
    rtd3 += coeff3 * corr;
    rtd4 += coeff4 * corr;

}

//====================================================
//==================================================== S::internal_force
//====================================================

void Shell::internal_force ( )
{

// =============== the spring connected between shell and core part

    double dx 	=  x() - _C.x();          // relative position

    double dvx 	= vx() - _C.vx();       // relative velocity

#ifdef _UNITS_METHOD_0
    double fs = _Y_sp * dx + _A_sp * dvx;     // Linear dashpod Force
#endif

#ifdef _UNITS_METHOD_1
    double fs = dx + dvx;			// dimensionless units
#endif

#ifdef _UNITS_METHOD_2
		double fs = ??;
#endif
		_xi_sp = dx;
// ================ the shell and core contact part


    double rr = abs ( dx );

    double r2 = _C.r();

    double r3 = _r_mid;

    double xi = rr + r2 - r3;

    if ( xi > 0 ) {

			  _xi_sc = xi;

        double rr_rez = double(1) / rr;         // distance^(-1)

        double ex = dx * rr_rez;        // dX/rr

        double fn = _Y * xi;


        if( fn < 0 ) fn = 0;            // non-negative force condition : fn = max ( 0 , fn)

        add_force    ( -fn * ex - fs );
        _C.add_force (  fn * ex + fs );

    } else {

        add_force    ( -fs );
        _C.add_force (  fs );

    }

}

//====================================================
//==================================================== force
//====================================================

void force( Shell &p1, Shell &p2 ) 
{

    double dx = normalize( p1.x() - p2.x(), G_lx );

 
    double rr = abs ( dx );

    double r1 = p1.r();
    double r2 = p2.r();
  
    double xi = r1 + r2 - rr;//  compression : radius1+radius2-distance

    if ( xi > 0 ) {

				p1.xi_ss() = xi;
				p2.xi_ss() = xi;

        double rr_rez = double(1) / rr;// distance^(-1)

        double ex 		= dx * rr_rez;// dX/rr

        double fn 		= p1.Y() * xi;

        if ( fn < 0 ) fn = 0; // non-negative force condition : fn = max ( 0 , fn)

        p1.add_force(  fn * ex );

        p2.add_force( -fn * ex );

         

    }

}

//====================================================
//==================================================== S::periodic_bc
//====================================================


void Shell::periodic_bc ()
{
    while( rtd0 < 0    )    { rtd0 += G_lx; _C.x() += G_lx; _pbc_index--; }
    while( rtd0 > G_lx )    { rtd0 -= G_lx; _C.x() -= G_lx; _pbc_index++; }
}

//====================================================
//==================================================== Shell::Energy
//====================================================

double Shell::E_com ( ) const 
{

    double sqEc1  = Core_m() * Core_vx();
    double sqEc2  =      m() *      vx();

//    double E_com = ( sqEc1 * sqEc1 + sqEc2 * sqEc2 ) / double(2) ; // what is this? :) probably made out of the second way of making dimensionless parameters
		return  0.5 * ( sqEc1 + sqEc2 )*( sqEc1 + sqEc2 );
}

double Shell::E_rel (  ) const 
{

    double dxi   = vx() - Core_vx() ;

		double delta = _C.m();

    return ( delta * ( 1.0 - delta ) * dxi * dxi ) * 0.5 ;

}

double Shell::E_sp_in ( ) const 
{

		double xi    = x()  - Core_x()  ;
#ifdef _UNITS_METHOD_0
    return ( 0.5 * _Y_sp * xi * xi ) ; 
#endif
#ifdef _UNITS_METHOD_1
		double delta = _C.m();
    return ( 2.0 * delta * ( 1.0 - delta ) * xi * xi ) / _eta ; 
#endif
#ifdef _UNITS_METHOD_2
		double delta = _C.m();
    return ( 2.0 * delta * ( 1.0 - delta ) * xi * xi ) / _eta ; 
#endif

}

double Shell::E_tot ( ) const 
{
    return E_com ( ) + E_rel (  ) + E_sp_in ( );
}

double Shell::E_sp_ss ( ) const 
{
    return 0.5 * _Y * _xi_ss * _xi_ss;
}

double Shell::E_sp_sc ( ) const 
{
    return 0.5 * _Y * _xi_sc * _xi_sc;
}

double Shell::E_kin_s ( ) const 
{
    return 0.5 * _m * vx() * vx();
}
double Shell::E_kin_c ( ) const 
{
    return 0.5 * Core_m() * Core_vx() * Core_vx();
}






//====================================================
//==================================================== Shell::set_parameters
//====================================================


void Shell::set_parameters ( class Init_Parameters * init_parameters ){


    double core_mass        =  init_parameters -> core_mass         ();
    double shell_mass       =  init_parameters -> shell_mass        ();
    double shell_radius_out =  init_parameters -> shell_radius_out  ();
    double shell_radius_in  =  init_parameters -> shell_radius_in   ();
    double core_radius      =  init_parameters -> core_radius       ();
    double young_modulus    =  init_parameters -> young_modulus     ();


    r       () = shell_radius_out;
    r_mid   () = shell_radius_in;
    Core_r  () = core_radius;
    Y       () = young_modulus;

#ifdef _UNITS_METHOD_0
    _Y_sp        	= init_parameters -> Y_sp  ();
    _A_sp        	= init_parameters -> A_sp  ();
    Core_m  () 		= core_mass;
    m       () 		= shell_mass;

#endif
#ifdef _UNITS_METHOD_1
    double eff_mass         =  init_parameters -> eff_mass          ();
    _eta 			 = init_parameters -> eta ();
    Core_m  () = _eta * core_mass  / ( 4.0 * eff_mass );
    m       () = _eta * shell_mass / ( 4.0 * eff_mass );
#endif
#ifdef _UNITS_METHOD_2

#endif
}
