
#include "global_variables.h"
#include "pre_processors.h"

const long         G_random_seed     = 30;

const unsigned int G_no_grains       = 20;

const double       G_lx              = XSCALE_TOT * double ( G_no_grains );

const double  		 G_dt           	 = 1E-4;
const double  		 G_time_final   	 = 500.;


