#include "class_grains.h"

//====================================================
//==================================================== Grains::
//====================================================


Grains::Grains() {

    shells.resize ( G_no_grains );
		init_energy_assigned = false;

}

//====================================================
//==================================================== Grains::
//====================================================


Grains::~Grains () {

		ofs_energy.close 						();
		ofs_pos_moments.close 			();
		ofs_vel_c_moments.close 		();
		ofs_vel_s_moments.close 		();
		ofs_vel_com_moments.close 	();
		ofs_sigma.close 						();
		ofs_positions.close 				();
		ofs_velocities_s.close 			();
		ofs_velocities_c.close 	  	();
		ofs_velocities_com.close 		();
		ofs_parameters.close 				();

}

//====================================================
//==================================================== Grains::
//====================================================

bool Grains::error_happened ( double time ) {
		bool error_stat = false;

		if ( G_no_grains > 3 ) 
     		if ( shell_jumped ( time ) ) 
         		error_stat = true;

		if ( energy_increased () )
				error_stat = true;

		return error_stat;
}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::make_output_files ( class Init_Parameters * init_parameters ) {

#ifdef OUTPUT_FILE_DEBUG_MODE
		ofs_energy.open						("ofs_energy.txt");
		ofs_pos_moments.open			("ofs_pos_moments.txt");
		ofs_vel_c_moments.open		("ofs_vel_c_moments.txt");
		ofs_vel_s_moments.open		("ofs_vel_s_moments.txt");
		ofs_vel_com_moments.open	("ofs_vel_com_moments.txt");
		ofs_sigma.open						("ofs_sigma.txt");
		ofs_positions.open				("ofs_positions.txt");
		ofs_velocities_s.open			("ofs_velocites_s.txt");
		ofs_velocities_c.open	  	("ofs_velocites_c.txt");
		ofs_velocities_com.open		("ofs_velocites_com.txt");
		ofs_parameters.open				("ofs_parameters.txt");
#else
		string 	str_energy 						= "o_e" 		,
		 				str_pos_moments 			= "o_pm"		,
						str_vel_c_moments 		= "o_vcm" 	,
						str_vel_s_moments 		= "o_vsm" 	,
						str_vel_com_moments 	=	"o_vmm"	  ,
						str_sigma 						= "o_s" 		,
						str_positions 				= "o_p"	  	,
						str_velocities_s 			= "o_vs"		,
						str_velocities_c 			= "o_vc"		,
						str_velocities_com		= "o_vm"		,
						str_parameters 				= "o_par" 	;


		string str_filename = "";
		char buffer[50] = "";

  	sprintf ( buffer, "_ng%u", G_no_grains );
		str_filename.append ( buffer);


		sprintf ( buffer, "_s%lu", G_random_seed );
		str_filename.append ( buffer);


		str_filename.append ( ".txt" );


		str_energy.append 					( str_filename );
		str_pos_moments.append 			( str_filename );
		str_vel_c_moments.append 		( str_filename );
		str_vel_s_moments.append 		( str_filename );
		str_vel_com_moments.append 	( str_filename );
		str_sigma.append 						( str_filename );
		str_positions.append 				( str_filename );
		str_velocities_s.append 		( str_filename );
		str_velocities_c.append 		( str_filename );
		str_velocities_com.append 	( str_filename );
		str_parameters.append 			( str_filename );


		const char * 	char_energy 					= str_energy.c_str 					();
		const char *	char_pos_moments 			= str_pos_moments.c_str 		();
		const char *	char_vel_c_moments 		= str_vel_c_moments.c_str 	();
		const char *	char_vel_s_moments 		= str_vel_s_moments.c_str 	();
		const char *	char_vel_com_moments 	= str_vel_com_moments.c_str ();
		const char *	char_sigma 						= str_sigma.c_str 					();
		const char *	char_positions 				= str_positions.c_str 			();
		const char *	char_velocities_s 		= str_velocities_s.c_str 		();
		const char *	char_velocities_c 		= str_velocities_c.c_str 		();
		const char *	char_velocities_com 	= str_velocities_com.c_str 	();
		const char *	char_parameters 			= str_parameters.c_str 			();


		ofs_energy.open						( char_energy 					);
		ofs_pos_moments.open			( char_pos_moments 			);
		ofs_vel_c_moments.open		( char_vel_c_moments 		);
		ofs_vel_s_moments.open		( char_vel_s_moments 		);
		ofs_vel_com_moments.open	( char_vel_com_moments 	);
		ofs_sigma.open						( char_sigma		 				);
		ofs_positions.open				( char_positions 				);
		ofs_velocities_s.open			( char_velocities_s 		);
		ofs_velocities_c.open	  	( char_velocities_c 		);
		ofs_velocities_com.open		( char_velocities_com		);
		ofs_parameters.open				( char_parameters 			);

#endif
}

//====================================================
//==================================================== Grains::
//====================================================

void Grains::calc_energies () {

		en_tot = en_kin = en_kin_core = en_kin_shell = en_spr_ss = en_spr_sc = en_spr_in = en_com = en_rel = 0.0;

		for ( unsigned i = 0; i < G_no_grains; i++ ) {
			en_kin_core		+= shells [i].E_kin_c();
			en_kin_shell 	+= shells [i].E_kin_s();
			en_spr_ss 		+= shells [i].E_sp_ss();
			en_spr_sc 		+= shells [i].E_sp_sc();
			en_spr_in 		+= shells [i].E_sp_in();

			en_com				+= shells [i].E_com(); // doesn't contribute to en_tot when adding en_kin_core and en_kin_shell
			en_rel 				+= shells [i].E_rel(); // doesn't contribute to en_tot ...
		}


		en_kin = en_kin_shell + en_kin_core + en_spr_ss + en_spr_sc;	
		en_tot = en_kin + en_spr_in;

}

//====================================================
//==================================================== Grains::
//====================================================

bool Grains::energy_increased () {

		if ( !init_energy_assigned ) {
				init_energy = en_tot;
				init_energy_assigned = true;
				return false;
		} else {
				if ( en_tot > 1.5 * init_energy ) {
						cout << "Error: Total energy is increasing.\n";
						return true;
				} else {
						return false;
				}
		}
}

//====================================================
//==================================================== Grains::
//====================================================

bool Grains::shell_jumped ( double time ){

    for ( unsigned int i = 0; i < G_no_grains; i++ ) {

        int j_1,j_2;

        if ( i == G_no_grains - 2  ) {
            j_1 = i+1;
            j_2 = 0;


        } else if ( i == G_no_grains - 1  ) {
            j_1 = 0;
            j_2 = 1;

        } else {
            j_1 = i+1;
            j_2 = i+2;

        }


        double distance_12 = abs ( normalize ( shells[i].x() - shells[j_1].x(), G_lx ) );
        double distance_13 = abs ( normalize ( shells[i].x() - shells[j_2].x(), G_lx ) );


        if ( distance_12 > distance_13 ) {

            cout << " Error: two grains jumped of one-another at t:" << time << " .\n";
            return true;

        }

    }

    return false;

}

//====================================================
//==================================================== Grains::
//====================================================


bool Grains::solve_eq_of_motion(){

    for ( unsigned int i = 0; i < G_no_grains; i++ ) {

        shells[i].set_force_to_zero();

        shells[i].predict ( );

    }


    for ( unsigned int i = 0; i < G_no_grains; i++ ){

        shells[i].internal_force ();

        if ( i+1 == G_no_grains ){
            force( shells[i], shells[0] ); // Periodic B.C
        }
        else
        {
            force( shells[i], shells[i+1] ); // LINEAR NEIGHBORS
        }

    }

		double thickness = shells[0].r() - shells[0].r_mid();

    for ( unsigned int i = 0; i < G_no_grains; i++ ) {

        shells[i].correct ( );

        shells[i].periodic_bc ( );

        if ( shells[i].Core_slipped_out ( ) ) {

            cout << " Error : a core went out of its shell.\n";

            return false;
        }

				if ( shells[i].xi_ss() > thickness * 0.999 ) {

						cout << "Error: too much compression of two shells at a collision.\n";

						return false;
				}
		}

    return true;

}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::initial_condition ( class Init_Parameters * init_parameters, class MTRand * RandNumb )
{

    for ( unsigned int i = 0; i < G_no_grains; i++ ) {

        shells[i].set_parameters ( init_parameters );

        shells[i].pbc_index () = 0;

    }



//    double lambda   		= init_parameters -> lambda ();

    double radius_out   = init_parameters -> shell_radius_out ();

    double grain_x [ G_no_grains ];

    unsigned int grains_counter = 0;


    while ( grains_counter < G_no_grains ) {

        double temp_x = G_lx * RandNumb -> randDblExc();


        bool flag_freeSpace = true;

        unsigned int i = 0;

        while ( flag_freeSpace && i < grains_counter ){

            double distance = abs( temp_x - grain_x[i] );

            if ( distance > G_lx / 2.0 ) {
                distance = G_lx - distance;
            }

            if ( distance < 2.1 * radius_out ){
               flag_freeSpace = false;
            }

            i++;

        }

        if ( flag_freeSpace ){

            grain_x [ grains_counter ] = temp_x;

            grains_counter++;

        }

    }

// -----------------------
// ----------------------- sorting grain_x[]


    bool flag_disorder = true;

    while ( flag_disorder ){

        flag_disorder = false;

        for ( unsigned int i = 0; i < G_no_grains; i++ ){

            for ( unsigned int j = 0; j < G_no_grains; j++ ){

                if ( grain_x[i] > grain_x[j] && i < j ){

                    flag_disorder = true;
                    double temp_x = grain_x[i];
                    grain_x[i]    = grain_x[j];
                    grain_x[j]    = temp_x;

                }

            }

        }

    }



    for ( unsigned int i = 0; i < G_no_grains; i++ ) {

        shells[i].x()    = grain_x [i];

        shells[i].vx()   = ( 0.5 - RandNumb -> rand() );


        shells[i].Core_x()   = shells[i].x();

        shells[i].Core_vx () = shells[i].vx();

    }



}
//====================================================
//==================================================== Grains::
//====================================================


double Grains::energy_com() {

    double E = 0;

    for ( unsigned int i = 0; i < G_no_grains; i++ )

        E += shells[i].E_com ();

    return E;
}

//====================================================
//==================================================== Grains::
//====================================================



void Grains::set_initial_temperature ( double T0 ) {

		init_temp = T0;

    bool check_it = true;

check_point_temperature:    
    
    double temp_com = 0;

    for( unsigned int i = 0; i < G_no_grains; i++ ){

        temp_com += shells [i].v_com()  *  shells [i].v_com(); 

    }

    temp_com *= 0.5 / double ( G_no_grains );


    cout << " T0 = " << temp_com << endl;

    if ( check_it ) {

        check_it = false;


        double scale_temp = sqrt ( T0 / temp_com  );

        for( unsigned int i = 0; i < G_no_grains; i++ ){

            shells [i].vx()          *= scale_temp;
            shells [i].Core_vx()     *= scale_temp;

        }

        goto check_point_temperature;
    }


}

//====================================================
//==================================================== Grains::
//====================================================


void Grains::set_tot_momentum_to_zero () {


    bool check_it = true;

check_point_momentum:

    double p_com_x = 0.0;

    for ( unsigned int i = 0; i < G_no_grains; i++ ){

        p_com_x += shells [i].v_com();

    }

    p_com_x /= double ( G_no_grains );

    cout << "p_com = " << p_com_x << endl;


    if ( check_it ) {

        check_it = false;


        for ( unsigned int i = 0; i < G_no_grains; i++ ){

            shells [i].vx()      -= p_com_x;
            shells [i].Core_vx() -= p_com_x;

        }


        goto check_point_momentum;
    }


}
//====================================================
//==================================================== Grains::
//====================================================


void Grains::calc_distribution_stat() {
	
		int box [ NO_BOXES ];
		const double mean = double(G_no_grains) / double(NO_BOXES);
		const double box_l = G_lx / NO_BOXES;
		const double box_sh = box_l / NO_SIGMAS;

		for ( unsigned int j = 0; j < NO_SIGMAS; j++) {
				double box_sh_j = box_sh * j;
				for ( unsigned int i =0; i < NO_BOXES; i++ )
						box [i] = 0;

				for ( unsigned int i =0; i < G_no_grains; i++ ) {
						int index = int(( shells[i].x() - box_sh_j )/ box_l) + 1;
						if (index<0) index = NO_BOXES - 1; if (index>=int(NO_BOXES)) index = 0;
						++box [index];
				}

				sigma [j] = 0.0;
				for ( unsigned int i =0; i < NO_BOXES; i++ ) { 
						sigma[j] += ( mean - double(box[i]))*( mean - double(box[i]));
				}
				sigma [j] /= double(G_no_grains*NO_BOXES);

		}


		double lx_shift = G_lx / 2.0;
		for ( unsigned int i =0; i < NO_POS_MOMENTS; i++ )	
				pos_moments [i] = 0.0;
		for ( unsigned int i =0; i < G_no_grains; i++ ) {
				double x = shells[i].x() - lx_shift;
				double x_p = 1.0;
				for ( unsigned int j = 0; j < NO_POS_MOMENTS; j++) {
						x_p *= x; 
						pos_moments[j] += x_p;
				}

		}

		for ( unsigned int i =0; i < NO_POS_MOMENTS ; i++ ) {
				pos_moments [i] /= G_no_grains;
		}

		pos_moments [2] /= sqrt ( pos_moments [1] * pos_moments [1] * pos_moments [1] );
		pos_moments [3] /= pos_moments [1] * pos_moments [1];
		pos_moments [1] /= G_lx * G_lx;

		for ( unsigned int i =0; i < NO_VEL_MOMENTS; i++ ) {	
				vel_s_moments 	[i] = 0.0;
				vel_c_moments 	[i] = 0.0;
				vel_com_moments [i] = 0.0;
		}
		for ( unsigned int i =0; i < G_no_grains; i++ ) {
				double v_s 		= shells[i].vx();
				double v_c 		= shells[i].Core_vx();
				double v_com 	= shells[i].v_com();
				double v_s_p 		= 1.0;
				double v_c_p 		= 1.0;
				double v_com_p 	= 1.0;
				for ( unsigned int j = 0; j < NO_VEL_MOMENTS; j++) {
						v_s_p 	*= v_s; 
						v_c_p 	*= v_c; 
						v_com_p *= v_com; 
						vel_s_moments		[j] += v_s_p;
						vel_c_moments		[j] += v_c_p;
						vel_com_moments	[j] += v_com_p;
				}

		}
		for ( unsigned int i =0; i < NO_VEL_MOMENTS ; i++ ) {
				vel_s_moments 	[i]	/= G_no_grains;
				vel_c_moments 	[i]	/= G_no_grains;
				vel_com_moments [i] /= G_no_grains;
		}
		vel_s_moments   [2] /= sqrt (vel_s_moments   [1] * vel_s_moments   [1] * vel_s_moments    [1]);
  	vel_c_moments   [2] /= sqrt (vel_c_moments   [1] * vel_c_moments   [1] * vel_c_moments    [1]);
		vel_com_moments [2] /= sqrt (vel_com_moments [1] * vel_com_moments [1] * vel_com_moments  [1]);


		vel_s_moments   [3] /= vel_s_moments   [1] * vel_s_moments   [1];
		vel_c_moments   [3] /= vel_c_moments   [1] * vel_c_moments   [1];
		vel_com_moments [3] /= vel_com_moments [1] * vel_com_moments [1];

}


//====================================================
//==================================================== Grains::
//====================================================


void Grains::output_data ( double time, int type ) {



		if (type == 0 ) {
				double en_norm = 1.0 / ( init_temp * double (G_no_grains) );

    		ofs_energy  << time 								  << " "
										<< en_tot				* en_norm << " "
										<< en_kin_core	* en_norm << " "
										<< en_kin_shell	* en_norm << " "
										<< en_spr_in		* en_norm << " "
										<< en_spr_ss		* en_norm << " "
										<< en_spr_sc		* en_norm << " "
										<< en_com				* en_norm << " "
										<< en_rel				* en_norm << "\n" << flush;
//													<< en_tot/G_no_grains << "\n" << flush;
//												<< en_tot/G_no_grains << " " << en_kin/G_no_grains << "\n" << flush;

    		ofs_pos_moments  	<< time << " ";
    		for ( unsigned int i = 0; i < NO_POS_MOMENTS; i++ ) {
						ofs_pos_moments << pos_moments[i] << " ";
				}
				ofs_pos_moments << "\n" << flush;

    		ofs_vel_s_moments  		<< time << " ";
    		ofs_vel_c_moments  		<< time << " ";
    		ofs_vel_com_moments  	<< time << " ";
    		for ( unsigned int i = 0; i < NO_VEL_MOMENTS; i++ ) {
						ofs_vel_s_moments 	<< vel_s_moments[i] 	<< " ";
						ofs_vel_c_moments 	<< vel_c_moments[i] 	<< " ";
						ofs_vel_com_moments << vel_com_moments[i] << " ";
				}
				ofs_vel_s_moments 	<< "\n" << flush;
				ofs_vel_c_moments 	<< "\n" << flush;
				ofs_vel_com_moments << "\n" << flush;

				double sigma_mean = 0.0;
				ofs_sigma  				<< time << " ";
    		for ( unsigned int i = 0; i < NO_SIGMAS; i++ ) {
						ofs_sigma << sigma [i] << " ";
						sigma_mean += sigma [i];
				}
				ofs_sigma << sigma_mean/NO_SIGMAS <<"\n" << flush;

		} else if (type == 1 ) {

    		ofs_positions  		<< time << " ";
    		for ( unsigned int i = 0; i < G_no_grains; i++ ) {
        		ofs_positions  << shells [i].x()  +  shells [i].pbc_index() * G_lx << " ";
    		}
    		ofs_positions << "\n" << flush;


    		ofs_velocities_s  		<< time << " ";
    		ofs_velocities_c  		<< time << " ";
    		ofs_velocities_com 		<< time << " ";
    		for ( unsigned int i = 0; i < G_no_grains; i++ ) {
        		ofs_velocities_s    << shells [i].vx() 			<< " ";
        		ofs_velocities_c    << shells [i].Core_vx() << " ";
        		ofs_velocities_com  << shells [i].v_com() 	<< " ";
    		}
    		ofs_velocities_s 		<< "\n" << flush;
    		ofs_velocities_c 		<< "\n" << flush;
    		ofs_velocities_com 	<< "\n" << flush;

		} else if (type == 2) {

/*
    ofs_positions  	<< time << " " 
                		<< shells[0].x() + shells[0].r() + shells[0].pbc_index() * G_lx << " " 
                		<< shells[0].x() - shells[0].r() + shells[0].pbc_index() * G_lx << " "  
                		<< shells[1].x() + shells[1].r() + shells[1].pbc_index() * G_lx << " " 
                		<< shells[1].x() - shells[1].r() + shells[1].pbc_index() * G_lx << "\n" << flush;
*/
// /*
    ofs_positions  	<< time << " " 
                		<< shells[0].x()         + shells[0].r()         + shells[0].pbc_index() * G_lx << " " 
                		<< shells[0].x()         - shells[0].r()         + shells[0].pbc_index() * G_lx << " "  
                		<< shells[1].x()         + shells[1].r()         + shells[1].pbc_index() * G_lx << " " 
                		<< shells[1].x()         - shells[1].r()         + shells[1].pbc_index() * G_lx << " "
                		<< shells[0].Core_x()    + shells[0].Core_r()    + shells[0].pbc_index() * G_lx << " " 
                		<< shells[0].Core_x()    - shells[0].Core_r()    + shells[0].pbc_index() * G_lx << " "  
                		<< shells[1].Core_x()    + shells[1].Core_r()    + shells[1].pbc_index() * G_lx << " " 
                		<< shells[1].Core_x()    - shells[1].Core_r()    + shells[1].pbc_index() * G_lx << "\n" << flush;
// */

		}

}

//====================================================
//==================================================== Grains::
//====================================================

//====================================================
//==================================================== Grains::
//====================================================


