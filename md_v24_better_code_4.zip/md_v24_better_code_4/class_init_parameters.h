#ifndef _CLASS_INIT_PARAMETERS_H
#define _CLASS_INIT_PARAMETERS_H


#include "global_variables.h"
#include "pre_processors.h"
#include "headers.h"


class Init_Parameters {

    public:

        Init_Parameters() { }
				~Init_Parameters(){ }


				void make_parameters() {


         		_alpha   		= _ALPHA;
         		_beta    		= _BETA;
         		_lambda  		= _LAMBDA;
						_delta   		= _DELTA;
						_kappa   		= _KAPPA;
						_init_temp 	= _INIT_TEMP;


#ifdef _UNITS_METHOD_0
            _core_mass  = _delta;
            _shell_mass = 1.0 - _delta;
						_Y_sp 			= _Y_SP;
						_A_sp 			= _A_SP;
#endif

#ifdef _UNITS_METHOD_1
         		_eta     		= _ETA;
            _core_mass  = _eta / ( 4.0 * ( 1.0 - _delta ) );
            _shell_mass = _eta / ( 4.0 * _delta );
#endif

#ifdef _UNITS_METHOD_2

//            _young_modulus      = (1E-4) * PI * PI * _core_mass / ( G_dt * G_dt );
//            cout << "young modulus = " << _young_modulus << endl;
						_epsilon				= _EPSILON;
						_Gamma					= _GAMMA;						
         		_eta     				= _ETA;
            _young_modulus  = _KAPPA;
            _core_mass      = G_dt * G_dt * _young_modulus * double (10000) / ( PI * PI );
            _shell_mass     = _core_mass * ( 1.0 + _epsilon ) / ( 1.0 - _epsilon );
            _tau_1          = _eta / double (2);

#endif
            _eff_mass           = _core_mass * _shell_mass / ( _core_mass + _shell_mass );
            _shell_radius_out   =  XSCALE_TOT * 0.5 * ( 1.0 - _lambda );
            _shell_radius_in    =  _shell_radius_out * ( 1.0 - 2.0 * _beta );
            _core_radius        =  _shell_radius_out * _alpha;
            _young_modulus      = _KAPPA;

        }

				double initial_temperature () const {
#ifdef _UNITS_METHOD_2
            double ls = G_lx / double ( G_no_grains );

            double v0 = _lambda * ls / ( _tau_1 * _Gamma );

            return v0 * v0;
#else
 						return _init_temp;
#endif				
        } 
/*
	 			void output_parameters ( ofstream & ofs_parameters ) {

         		cout 	<<  _alpha   		<< 
         					<<	_beta    		<<
         					<<	_lambda  		<<
									<<	_delta   		<<
									<<	_kappa   		<<
									<<	_init_temp 	<<


#ifdef _UNITS_METHOD_0
            _core_mass  = _delta;
            _shell_mass = 1.0 - _delta;
						_Y_sp 			= _Y_SP;
						_A_sp 			= _A_SP;
#endif

#ifdef _UNITS_METHOD_1
         		_eta     		= _ETA;
            _core_mass  = _eta / ( 4.0 * ( 1.0 - _delta ) );
            _shell_mass = _eta / ( 4.0 * _delta );
#endif

#ifdef _UNITS_METHOD_2

//            _young_modulus      = (1E-4) * PI * PI * _core_mass / ( G_dt * G_dt );
//            cout << "young modulus = " << _young_modulus << endl;
						_epsilon				= _EPSILON;
						_Gamma					= _GAMMA;						
         		_eta     				= _ETA;
            _young_modulus  = _KAPPA;
            _core_mass      = G_dt * G_dt * _young_modulus * double (10000) / ( PI * PI );
            _shell_mass     = _core_mass * ( 1.0 + _epsilon ) / ( 1.0 - _epsilon );
            _tau_1          = _eta / double (2);

#endif
            _eff_mass           = _core_mass * _shell_mass / ( _core_mass + _shell_mass );
            _shell_radius_out   =  XSCALE_TOT * 0.5 * ( 1.0 - _lambda );
            _shell_radius_in    =  _shell_radius_out * ( 1.0 - 2.0 * _beta );
            _core_radius        =  _shell_radius_out * _alpha;
            _young_modulus      = _KAPPA;

				}	
*/		

        double  alpha   () const    { return _alpha    ; }
        double  beta    () const    { return _beta     ; }
        double  lambda  () const    { return _lambda   ; }
        double  epsilon () const    { return _epsilon  ; }

        double  delta   () const    { return _delta    ; }
        double  eta     () const    { return _eta      ; }
        double  kappa   () const    { return _kappa    ; }   
        double  zeta    () const    { return _zeta     ; }
        double  Gamma   () const    { return _Gamma    ; }   
        double  tau_1   () const    { return _tau_1    ; }  

        double  Y_sp   () const    { return _Y_sp      ; } 
        double  A_sp   () const    { return _A_sp      ; }  


        double core_mass        () const    { return _core_mass         ; }
        double shell_mass       () const    { return _shell_mass        ; }
        double eff_mass         () const    { return _eff_mass          ; }
        double shell_radius_out () const    { return _shell_radius_out  ; }
        double shell_radius_in  () const    { return _shell_radius_in   ; }
        double core_radius      () const    { return _core_radius       ; }
        double young_modulus    () const    { return _young_modulus     ; }
/*
        bool  G_dt_is_small_enough () {

            double tau_1 = 1.0;
            double Gamma = 1.0;

            double dt = (1E-3) * tau_1 * Gamma * _beta * ( 1.0 - _lambda ) * sqrt ( 2.0 * PI * PI * _core_mass / _shell_mass ) / _lambda ;

            cout << " dt = " << dt << "\t , G_dt = " << G_dt << endl;

            if ( dt > G_dt )
                return true;
            else
                return false;

        }
*/

    private:

        double _alpha,_beta,_delta, _kappa,_zeta,_lambda, _init_temp;
				double _Y_sp, _A_sp; // inner spring elastic and inelastic coef.
				double _eta;
				double _Gamma, _epsilon;

        double _core_mass, _shell_mass, _eff_mass, 
               _shell_radius_out, _shell_radius_in, _core_radius,
               _young_modulus, _tau_1;

};

#endif
