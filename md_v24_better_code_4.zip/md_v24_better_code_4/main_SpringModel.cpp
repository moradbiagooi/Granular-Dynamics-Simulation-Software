
#include "main_SpringModel.h"
#include "headers.h"
#include "global_variables.h"
#include "class_grains.h"
#include "MersenneTwister.h"
#include "class_init_parameters.h"


using namespace std;

void time_stamp ( clock_t, clock_t );

int main () {


    clock_t time_start, time_end;
    time_start = clock ();


    class MTRand    			*RandNumb 				= new MTRand ( G_random_seed );
    class Grains    			*grains   				= new Grains;
    class Init_Parameters *init_parameters 	= new Init_Parameters;


    init_parameters -> make_parameters  ();


    grains -> initial_condition 				( init_parameters, RandNumb );
    grains -> set_tot_momentum_to_zero 	( );
    grains -> set_initial_temperature 	( init_parameters -> initial_temperature() );
		grains -> make_output_files 				( init_parameters );

   

    unsigned long i_max 			= long ( G_time_final / G_dt );
		unsigned long i_energy 		= (i_max/1000) < 1 ? 1 : (i_max/1000) ;
		unsigned long i_position 	= i_max / 100;
		unsigned long i_time 			= i_max / 10;
		cout << "Final time : " << G_time_final << "\n" << flush;
    for ( unsigned long i = 0; i < i_max; i++ ) {

        double time = double (i) * G_dt;

        if ( !grains -> solve_eq_of_motion () ) 
            i = i_max;
  						
     
        if ( i % i_energy == 0 ) {

						grains -> calc_energies ();
						grains -> calc_distribution_stat ();
            grains -> output_data ( time, 0 ); // output energy and distribution status
						
						if ( grains -> error_happened ( time ) )
								i = i_max;

        }

 
				if ( i % i_position == 0 )
						grains -> output_data ( time, 1 ); // output_ position and velocities

//				if ( i % 1000 == 0 )
//						grains -> output_data ( time, 2 ); // output_ position and velocities for G_no_grains = 2


				if ( i % i_time == 0 )
						cout << "t: " << time << " " << flush;
    }
		cout << "\nSimulation finished\n";


    time_end = clock ();
		time_stamp ( time_start, time_end );

		delete grains;
    delete RandNumb;
    delete init_parameters;

    return 0;
}

// ========================================================

void time_stamp ( clock_t time_start, clock_t time_end ) {

    double total_time =  ( (float)time_end - (float)time_start ) / CLOCKS_PER_SEC;
		int time_d = int ((total_time)/86400.),  
				time_h = int ((total_time - time_d*86400.)/3600.),
			 	time_m = int ((total_time - time_d*86400. - time_h*3600.)/ 60. ),
			  time_s = int ((total_time - time_d*86400. - time_h*3600. - time_m*60.));

		cout << "\nTotal execution time (d:h:m:s) "  << time_d << ":" << time_h << ":" << time_m << ":" << time_s << ".\n" ;

}
