
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _CLASS_CORE_H
#define _CLASS_CORE_H

#include "headers.h"



using namespace std;


class Shell;


class Core {

    friend void force3( Shell & p1, Core & p2, double lx );

public:

    Core(): rtd0(0), rtd1(0), rtd2(0), rtd3(0), rtd4(0)
    {}

    double & x()            {return rtd0;}
    double   x() const      {return rtd0;}

    double & vx()           {return rtd1;}
    double   vx() const     {return rtd1;}

    double & r()            {return _r;}
    double   r() const      {return _r;}

    double   m() const      {return _m;}
    double & m()            {return _m;}

    double & Y_sp()         {return _Y_sp;}
    double   Y_sp() const   {return _Y_sp;}

    double & A_sp()         {return _A_sp;}
    double   A_sp() const   {return _A_sp;}

    double   f()   const    {return _force;}

    void add_force( const double & f ){ _force += f; } //Adds a value to the total force _force of the Shell

    void predict( ); //First step of the Gear algorithm

    void correct( ); //Second step of the Gear algorithm

    void set_force_to_zero(){ _force = 0;}


private:

    double _r, _m;
    double _Y_sp, _A_sp;

    double rtd0, rtd1, rtd2, rtd3, rtd4;
    double _force;

};

#endif
