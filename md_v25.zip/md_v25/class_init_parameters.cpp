#include "class_init_parameters.h"

//====================================================
//==================================================== Init_Parameters::
//====================================================


void Init_Parameters::make_parameters() {


         		_alpha   		= _ALPHA;
         		_beta    		= _BETA;
         		_lambda  		= _LAMBDA;
						_delta   		= _DELTA;
						_kappa   		= _KAPPA;
						_init_temp 	= _INIT_TEMP;


#ifdef _UNITS_METHOD_0
            _core_mass  = _delta;
            _shell_mass = 1.0 - _delta;
						_Y_sp 			= _Y_SP;
						_A_sp 			= _A_SP;
#endif

#ifdef _UNITS_METHOD_1
         		_eta     		= _ETA;
            _core_mass  = _eta / ( 4.0 * ( 1.0 - _delta ) );
            _shell_mass = _eta / ( 4.0 * _delta );
#endif

#ifdef _UNITS_METHOD_2

//            _young_modulus      = (1E-4) * PI * PI * _core_mass / ( G_dt * G_dt );
//            cout << "young modulus = " << _young_modulus << endl;
						_epsilon				= _EPSILON;
						_Gamma					= _GAMMA;						
         		_eta     				= _ETA;
            _core_mass      = G_dt * G_dt * _young_modulus * double (10000) / ( PI * PI );
            _shell_mass     = _core_mass * ( 1.0 + _epsilon ) / ( 1.0 - _epsilon );
            _tau_1          = _eta / double (2);

#endif
            _eff_mass           = _core_mass * _shell_mass / ( _core_mass + _shell_mass );
            _shell_radius_out   =  XSCALE_TOT * 0.5 * ( 1.0 - _lambda );
            _shell_radius_in    =  _shell_radius_out * ( 1.0 - 2.0 * _beta );
            _core_radius        =  _shell_radius_out * _alpha;
            _young_modulus      = _KAPPA;

}

//====================================================
//==================================================== Init_Parameters::
//====================================================


double Init_Parameters::initial_temperature () const {
#ifdef _UNITS_METHOD_2
            double ls = G_lx / double ( G_no_grains );

            double v0 = _lambda * ls / ( _tau_1 * _Gamma );

            return v0 * v0;
#else
 						return _init_temp;
#endif				
} 

//====================================================
//==================================================== Init_Parameters::
//====================================================



void Init_Parameters::output_parameters ( ofstream & ofs_ ) {
         		ofs_ << "XSCALE_TOT					"	<<  XSCALE_TOT	<< "\n";

         		ofs_ << "\n"
								 << "_alpha   					"	<<  _alpha   		<< "\n"
         				 <<	"_beta    					"	<< 	_beta   		<< "\n"
         				 <<	"_lambda  					"	<<	_lambda   	<< "\n"
								 <<	"_delta   					"	<<  _delta  		<< "\n"
								 <<	"_kappa   					"	<<  _kappa   		<< "\n"
								 <<	"_init_temp 				"	<<  _init_temp  << "\n";


#ifdef _UNITS_METHOD_0
						ofs_ << "\n"
							   << "_UNITS_METHOD_0		"  << "\n"
								 << "_core_massi    		"  << _core_mass  << "\n"
								 << "_shell_mass    		"  << _shell_mass << "\n"
								 << "_Y_sp          		"  << _Y_sp       << "\n"
								 << "_A_sp          		"  << _A_sp       << "\n"; 
#endif

#ifdef _UNITS_METHOD_1
						ofs_ << "\n"								 
							   << "_UNITS_METHOD_1		"  << "\n"
								 << "_eta           		"  << _eta        << "\n"
								 << "_core_mass     		"  << _core_mass  << "\n"
								 << "_shell_mass    		"  << _shell_mass << "\n";
#endif

#ifdef _UNITS_METHOD_2
						ofs_ << "\n" 		
								 << "_UNITS_METHOD_2		"  << "\n"
								 << "_epsilon        		"  << _epsilon    << "\n"
								 << "_Gamma          		"  << _Gamma      << "\n"
								 << "_eta           		"  << _eta        << "\n"
								 << "_core_mass     		"  << _core_mass  << "\n"
								 << "_shell_mass    		"  << _shell_mass << "\n"
								 << "_tau_1          		"  << _tau_1      << "\n";

#endif
						ofs_ << "\n" 
             		 << "_eff_mass          " << _eff_mass           	<< "\n"
             		 << "_shell_radius_out 	" << _shell_radius_out   	<< "\n"
             		 << "_shell_radius_in   "	<< _shell_radius_in   	<< "\n"
             		 << "_core_radius       "	<< _core_radius      		<< "\n"
             		 << "_young_modulus     " << _young_modulus   		<< "\n";

						ofs_ << flush;

				}	

//====================================================
//==================================================== Init_Parameters::
//====================================================


/*
bool  Init_Parameters::G_dt_is_small_enough () {

            double tau_1 = 1.0;
            double Gamma = 1.0;

            double dt = (1E-3) * tau_1 * Gamma * _beta * ( 1.0 - _lambda ) * sqrt ( 2.0 * PI * PI * _core_mass / _shell_mass ) / _lambda ;

            cout << " dt = " << dt << "\t , G_dt = " << G_dt << endl;

            if ( dt > G_dt )
                return true;
            else
                return false;

}
*/

//====================================================
//==================================================== Init_Parameters::
//====================================================


