#ifndef _CLASS_INIT_PARAMETERS_H
#define _CLASS_INIT_PARAMETERS_H


#include "global_variables.h"
#include "pre_processors.h"
#include "headers.h"


class Init_Parameters {

    public:

        Init_Parameters() { }
				~Init_Parameters(){ }


				void make_parameters();

				double initial_temperature () const; 

	 			void output_parameters ( ofstream & ofs_ ) ;



        double  alpha   () const    { return _alpha    ; }
        double  beta    () const    { return _beta     ; }
        double  lambda  () const    { return _lambda   ; }
        double  epsilon () const    { return _epsilon  ; }

        double  delta   () const    { return _delta    ; }
        double  eta     () const    { return _eta      ; }
        double  kappa   () const    { return _kappa    ; }   
        double  zeta    () const    { return _zeta     ; }
        double  Gamma   () const    { return _Gamma    ; }   
        double  tau_1   () const    { return _tau_1    ; }  

        double  Y_sp   () const    { return _Y_sp      ; } 
        double  A_sp   () const    { return _A_sp      ; }  


        double core_mass        () const    { return _core_mass         ; }
        double shell_mass       () const    { return _shell_mass        ; }
        double eff_mass         () const    { return _eff_mass          ; }
        double shell_radius_out () const    { return _shell_radius_out  ; }
        double shell_radius_in  () const    { return _shell_radius_in   ; }
        double core_radius      () const    { return _core_radius       ; }
        double young_modulus    () const    { return _young_modulus     ; }

//        bool  G_dt_is_small_enough () ;


    private:

        double _alpha,_beta,_delta, _kappa,_zeta,_lambda, _init_temp;
				double _Y_sp, _A_sp; // inner spring elastic and inelastic coef.
				double _eta;
				double _Gamma, _epsilon;

        double _core_mass, _shell_mass, _eff_mass, 
               _shell_radius_out, _shell_radius_in, _core_radius,
               _young_modulus, _tau_1;

};

#endif
