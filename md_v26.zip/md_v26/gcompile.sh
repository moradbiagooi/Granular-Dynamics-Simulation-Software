#!/bin/sh
module load intel/13.1.0

CPP_FILE=global_variables.cpp
H_FILE=pre_processors.h

NO_GRAINS=100
FINAL_TIME=10000.0


Y_SP=1.5  #units_method_0
A_SP=0.6  #units_method_0

ETA=lalala  #units_method_1

#START_RAND_SEED=1
#STEP_RAND_SEED=1
#STOP_RAND_SEED=1

RAND_SEED=10

#for RAND_SEED in `seq $START_RAND_SEED $STEP_RAND_SEED $STOP_RAND_SEED`
#do

	cp src/* .
	
	echo RAND_SEED

	sed -e "s|S_RAND_SEED|$RAND_SEED|" $CPP_FILE > temp.cpp
	mv temp.cpp $CPP_FILE

	sed -e "s|S_NO_GRAINS|$NO_GRAINS|" $CPP_FILE > temp.cpp
	mv temp.cpp $CPP_FILE

	sed -e "s|S_FINAL_TIME|$FINAL_TIME|" $CPP_FILE > temp.cpp
	mv temp.cpp $CPP_FILE



	sed -e "s|S_A_SP|$A_SP|" $H_FILE > temp.h
	mv temp.h $H_FILE

	sed -e "s|S_Y_SP|$Y_SP|" $H_FILE > temp.h
	mv temp.h $H_FILE

	sed -e "s|S_ETA|$ETA|" $H_FILE > temp.h
	mv temp.h $H_FILE



  #g++ -Wall *.cpp -o myoutput

	icpc -o -I/usr/include/x86_64-linux-gnu/c++/4.8/ *.cpp -o myoutput

	rm *.cpp *.h *.cpp~ *.h~ *.sh~

	#./myoutput


#done
