#!/bin/sh
#SBATCH --job-name="s"
#SBATCH -n 1
#SBATCH --output=so
#SBATCH --nodes=1-1
#SBATCH -p all
#SBATCH --time=48:00:00
./myoutput
