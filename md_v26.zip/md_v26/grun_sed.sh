#!/bin/sh
#SBATCH --job-name="sSED_SED"
#SBATCH -n 1
#SBATCH --output=so
#SBATCH --nodes=1-1
#SBATCH -p all
#SBATCH --time=48:00:00
./myoutput
