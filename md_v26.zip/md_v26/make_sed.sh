#!/bin/sh

SH_FILE=gcompile_sed.sh
SH_FILE2=grun_sed.sh

START_RAND_SEED=1
STEP_RAND_SEED=1
STOP_RAND_SEED=10

for RAND_SEED in `seq $START_RAND_SEED $STEP_RAND_SEED $STOP_RAND_SEED`
do
	mkdir -p o_$RAND_SEED

	cp grun_sed.sh o_$RAND_SEED

	sed -e "s|SED_SED|$RAND_SEED|" $SH_FILE > temp_$SH_FILE
	chmod +x temp_$SH_FILE
	mv temp_$SH_FILE o_$RAND_SEED/$SH_FILE

	sed -e "s|SED_SED|$RAND_SEED|" $SH_FILE2 > temp_$SH_FILE2
	chmod +x temp_$SH_FILE2
	mv temp_$SH_FILE2 o_$RAND_SEED/$SH_FILE2

done

for RAND_SEED in `seq $START_RAND_SEED $STEP_RAND_SEED $STOP_RAND_SEED`
do

	cd o_$RAND_SEED
	./$SH_FILE
	sbatch $SH_FILE2 >job_id
	cd ..

done




