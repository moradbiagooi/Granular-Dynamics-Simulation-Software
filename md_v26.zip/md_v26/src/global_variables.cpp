
#include "global_variables.h"
#include "pre_processors.h"

const long         G_random_seed     = S_RAND_SEED;

const unsigned int G_no_grains       = S_NO_GRAINS;

const double       G_lx              = XSCALE_TOT * double ( G_no_grains );

const double  		 G_dt           	 = 1E-4;
const double  		 G_time_final   	 = S_FINAL_TIME;


