set term png
#set terminal png size 800,600 font "Helvetica,15" enhanced
set terminal pngcairo dashed size 800,600 font "Helvetica,15" enhanced
set output "k1e+6_l_nc_delta.png"
set border linewidth 2
set xlabel "{/Symbol d}"
#set ylabel "{/Symbol d}"
set ylabel "Restitution Coefficient"
#set ylabel "time"
#set ylabel "Energy"
#set ylabel "Velocity"
#set key right top
set grid

p [:] [:] for [i=1:9] "d_e\:0.1_d\:0.65_k\:1e+06_l.dat" u 2:8 every::0+10*i*98::97+10*i*98 w l lw 2 notitle
#p [:] [:] "d_e\:0.1_d\:0.65_k\:1e+06_l.dat" u 1:6  w l  notitle

#set view map
#set dgrid3d 150,150

#set pm3d; set palette
#set palette color
#set pm3d map
#set cbrange [0:1]
#set cbrange [1:]
#set samples 10
#set isosamples 2
#set palette model RGB
#set palette defined 


#set palette defined (0 0 0 0, 1 0 0 1, 3 0 1 0, 4 1 0 0, 6 1 1 1)
#set cbrange [0:1]
#set cbrange [1:]


#splot [:] [:] "d_e\:0.1_d\:0.65_k\:1e+06_l.dat" u 1:2:6 with pm3d
