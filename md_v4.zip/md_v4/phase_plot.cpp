#include <vector>
#include <fstream>


#include "Sheath.h"
#include "phase_plot.h"


using namespace std;

extern vector< Sheath > Sheaths;


extern ofstream FileDataOut;        // system parameters and simulation data
extern ofstream FileT;              // gas temperature vs time

extern ofstream FileNEW; 

#ifdef  XOutputMaker_ASCII
extern ofstream FileX_S_A;          //  Sheaths' position in total coordinates vs tim
extern ofstream FileX_P_A;          // Particles' position vs 
#endif

#ifdef  VOutputMaker_ASCII
extern ofstream FileV_S_A;          // Sheath's velocity vs time 
extern ofstream FileV_P_A;          // position vs velocity (snapshots with the same temperature)
#endif

#ifdef  XOutputMaker_binary
extern ofstream FileX_S_B;          // Sheaths' position in total coordinates vs tim
extern ofstream FileX_P_B;          // Particles' position vs 
#endif

#ifdef  VOutputMaker_binary
extern ofstream FileV_S_B;          // Sheath's velocity vs time 
extern ofstream FileV_P_B;          // position vs velocity (snapshots with the same temperature)
#endif

extern double lx;

extern double Time;

extern double time_unit;

extern int number_of_grains;

extern double init_gran_temp;

inline double abs ( double _x ) { return _x < 0 ? -_x : _x ; }


double total_kinetic_energy_S();
double total_kinetic_energy_P();


//====================================================
//====================================================  phase_plot_NEW
//====================================================

void phase_plot_NEW() {


    double _time = Time / time_unit;


    FileNEW << _time;


//    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        unsigned int i  = 0;

        double Y_sp    = Sheaths[i].P_Y_sp ();

        double X_S     = Sheaths[i].x      (); 
        double X_P     = Sheaths[i].P_x    ();

        double V_S     = Sheaths[i].vx     (); 
        double V_P     = Sheaths[i].P_vx   ();

        double M_S     = Sheaths[i].m      (); 
        double M_P     = Sheaths[i].P_m    (); 

//        double scale    = 1;//.001;
//        double move     = 0;//1.495;

        double U_r      = Y_sp * ( X_S - X_P ) * ( X_S - X_P );

        double E_r      = M_S * M_P * ( V_S - V_P ) * ( V_S - V_P );

        double E_com    = ( M_S * V_S + M_P * V_P ) * ( M_S * V_S + M_P * V_P );

        double V_com    = V_S * M_S + V_P * M_P;

        double V_r      = V_S - V_P;

        double P_com    = V_com;

        double P_r      = V_S * M_S - V_P * M_P;

        double ss       = V_S * M_P + V_P * M_S;

        double F_s      = Sheaths[i].f();

        double F_p      = Sheaths[i].P_f();

        FileNEW << " " << E_com             << " " << E_r               << " " << U_r
                << " " << E_r + U_r         << " " << E_com + E_r + U_r 
                << " " << V_com             << " " << V_r               << " " << V_S       
                << " " << V_P;//            << " " << E_com + E_r - U_r;

//        FileNEW << " " << E_com << " " <<   ;

//        FileNEW << " " << abs ( P_com ) - abs ( P_r ) << " " << abs (V_com) - abs (V_r) ;
        
//        FileNEW << " " << ss + V_r  <<  " " << ss - V_r  << " " <<  V_com - V_r  << " " << V_com + V_r << " " << V_com - ss << " " <<  V_com + ss ; 

/*
        FileNEW << " " << E_com             << " " << E_r               << " " << U_r
                << " " << E_r + U_r         << " " << E_com + E_r + U_r << " " << E_com - E_r - U_r
                << " " << E_com - E_r       << " " << E_com - U_r       << " " << E_r - U_r       
                << " " << E_com - E_r + U_r << " " << E_com + E_r - U_r;
*/
//    }


    FileNEW << "\n";


}


//====================================================
//====================================================  phase_plot_X
//====================================================

void phase_plot_X() {

    double _time = Time / time_unit;

#ifdef  XOutputMaker_ASCII
    FileX_S_A << _time;
    FileX_P_A << _time;
#endif

#ifdef  XOutputMaker_binary
    FileX_S_B.write ( reinterpret_cast<char*>( &_time ), sizeof( double ) );
    FileX_P_B.write ( reinterpret_cast<char*>( &_time ), sizeof( double ) );
#endif

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){


        double _X_S = Sheaths[i].x  () + Sheaths[i].pbc_index() * lx;
        double _X_P = Sheaths[i].P_x() + Sheaths[i].pbc_index() * lx;

#ifdef  XOutputMaker_ASCII
//        FileX_S_A << " " << _X_S;
        FileX_S_A << " " << _X_S - Sheaths[i].r() << " " << _X_S + Sheaths[i].r();
//        FileX_P_A << " " << _X_P;
        FileX_P_A << " " << _X_P - Sheaths[i].r() << " " << _X_P + Sheaths[i].r();
#endif

#ifdef  XOutputMaker_binary
        FileX_S_B.write ( reinterpret_cast<char*>( &_X_S ) , sizeof( double ) );
        FileX_P_B.write ( reinterpret_cast<char*>( &_X_P ) , sizeof( double ) );
#endif

     }

#ifdef  XOutputMaker_ASCII
    FileX_S_A << "\n";
    FileX_P_A << "\n";
#endif

}

//====================================================
//====================================================  phase_plot_V
//====================================================

void phase_plot_V() {

    double _time = Time / time_unit;

#ifdef  VOutputMaker_ASCII 
    FileV_S_A << _time;
    FileV_P_A << _time;
#endif

#ifdef  VOutputMaker_binary
    FileV_S_B.write ( reinterpret_cast<char*>( &_time ), sizeof( double ) );
    FileV_P_B.write ( reinterpret_cast<char*>( &_time ), sizeof( double ) );
#endif

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){

        double _V_S = Sheaths[i].vx  (); 
        double _V_P = Sheaths[i].P_vx();

#ifdef  VOutputMaker_ASCII
//        FileV_S_A << " " << _V_S;
//        FileV_P_A << " " << _V_P;

        FileV_S_A << " " << 1  +abs( _V_S - _V_P ) / 10.0;
        FileV_P_A << " " << _V_P;
#endif

#ifdef  VOutputMaker_binary
        FileV_S_B.write ( reinterpret_cast<char*>( &_V_S  ) , sizeof( double ) );
        FileV_P_B.write ( reinterpret_cast<char*>( &_V_P  ) , sizeof( double ) );
#endif
 
    }

#ifdef  VOutputMaker_ASCII
    FileV_S_A << "\n";
    FileV_P_A << "\n";
#endif


}


//====================================================
//==================================================== phase_plot_T
//====================================================

double phase_plot_T(){

    double _time = Time / time_unit;

    double _temperature_S = total_kinetic_energy_S()
                          / ( number_of_grains * init_gran_temp ); 



    double _temperature_P = total_kinetic_energy_P()
                          / ( number_of_grains * init_gran_temp ); 

    double _temperature = ( _temperature_S + _temperature_P ) / 2.0;

    FileT   << _time          << " " 
            << _temperature   << " " 
            << _temperature_S << " "
            << _temperature_P << "\n";


    return _temperature;

}



