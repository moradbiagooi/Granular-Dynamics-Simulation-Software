rm simple_box *~
#clear
echo "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
g++ -o simple_box *.cpp
./simple_box input_parameters.dat
