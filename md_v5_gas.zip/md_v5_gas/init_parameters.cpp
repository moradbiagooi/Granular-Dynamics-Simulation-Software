#include <fstream>
#include <iostream>
#include <string>


using namespace std;


extern ifstream FileDataIn;
extern ofstream FileDataOut;


extern int nstep;
extern int nprint_T;
extern int nprint_XV;
extern int nenergy;
extern int number_of_grains;
extern int number_of_ensembles;


extern long random_seed;


extern double init_gran_temp;
extern double timestep;;
extern double alpha;                        // Particle.r / Sheath.r_out
extern double beta;                         // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 
extern double lambda;
extern double delta;
extern double eta;
extern double kappa;
//====================================================
//====================================================  init_parameters
//====================================================

bool init_parameters( char * fname_ip )
{

    cout << "======================init_parameters()\n";

    ifstream FileDataIn( fname_ip );

    while( FileDataIn.peek() == '#' ){

        string type;

        FileDataIn >> type;

        if(type=="#random_seed:"){

            FileDataIn >> random_seed;
            FileDataIn.ignore(100,'\n');
            cout        << "random_seed: " << random_seed << endl;
            FileDataOut << "random_seed: " << random_seed << endl;

        } else if(type=="#number_of_ensembles:"){

            FileDataIn >> number_of_ensembles;
            FileDataIn.ignore(100,'\n');
            cout        << "number_of_ensembles: " << number_of_ensembles << endl;
            FileDataOut << "number_of_ensembles: " << number_of_ensembles << endl;

        } else if(type=="#number_of_grains:"){

            FileDataIn >> number_of_grains;
            FileDataIn.ignore(100,'\n');
            cout        << "number_of_grains: " << number_of_grains << endl;
            FileDataOut << "number_of_grains: " << number_of_grains << endl;

        } else if(type=="#init_gran_temp:"){

            FileDataIn >> init_gran_temp;
            FileDataIn.ignore(100,'\n');
            cout        << "init_gran_temp: " << init_gran_temp << endl;
            FileDataOut << "init_gran_temp: " << init_gran_temp << endl;

        } else if(type=="#timestep:"){

            FileDataIn >> timestep;
            FileDataIn.ignore(100,'\n');
            cout        << "timestep: " << timestep << endl;
            FileDataOut << "timestep: " << timestep << endl;

        } else if(type=="#nstep:"){

            FileDataIn >> nstep;
            FileDataIn.ignore(100,'\n');
            cout        << "nstep: " << nstep << endl;
            FileDataOut << "nstep: " << nstep << endl;

        } else if(type=="#nprint_T:"){

            FileDataIn >> nprint_T;
            FileDataIn.ignore(100,'\n');
            cout        << "nprint_T: " << nprint_T << endl;
            FileDataOut << "nprint_T: " << nprint_T << endl;

        } else if(type=="#nprint_XV:"){

            FileDataIn >> nprint_XV;
            FileDataIn.ignore(100,'\n');
            cout        << "nprint_XV: " << nprint_XV << endl;
            FileDataOut << "nprint_XV: " << nprint_XV << endl;

        } else if(type=="#alpha:"){

            FileDataIn >> alpha;
            FileDataIn.ignore(100,'\n');
            cout        << "alpha: " << alpha << endl;
            FileDataOut << "alpha: " << alpha << endl;

        } else if(type=="#beta:"){

            FileDataIn >> beta;
            FileDataIn.ignore(100,'\n');
            cout        << "beta: " << beta << endl;
            FileDataOut << "beta: " << beta << endl;

        } else if(type=="#lambda:"){

            FileDataIn >> lambda;
            FileDataIn.ignore(100,'\n');
            cout        << "lambda: " << lambda << endl;
            FileDataOut << "lambda: " << lambda << endl;

        } else if(type=="#delta:"){

            FileDataIn >> delta;
            FileDataIn.ignore(100,'\n');
            cout        << "delta: " << delta << endl;
            FileDataOut << "delta: " << delta << endl;

        } else if(type=="#eta:"){

            FileDataIn >> eta;
            FileDataIn.ignore(100,'\n');
            cout        << "eta: " << eta << endl;
            FileDataOut << "eta: " << eta << endl;

        } else if(type=="#kappa:"){

            FileDataIn >> kappa;
            FileDataIn.ignore(100,'\n');
            cout        << "kappa: " << kappa << endl;
            FileDataOut << "kappa: " << kappa << endl;

        } else {

            cerr << "init_parameters(): unknown global property: " << type << endl;

            return false;

        }

    }

    return true;
}


