#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sys/stat.h> // used for mkdir()


#include "output_file_maker.h"
#include "Sheath.h"
#include "properties.h"


using namespace std;


extern vector < Sheath > Sheaths;

extern ofstream FileDataOut;        // system parameters and simulation data
extern ofstream FileT;              // gas temperature vs time

extern ofstream FileNEW;
extern ofstream FileData;
extern ofstream FileCollision;

#ifdef  XOutputMaker_ASCII
extern ofstream FileX_S_A;          //  Sheaths' position in total coordinates vs tim
extern ofstream FileX_P_A;          // Particles' position vs 
#endif

#ifdef  VOutputMaker_ASCII
extern ofstream FileV_S_A;          // Sheath's velocity vs time 
extern ofstream FileV_P_A;          // position vs velocity (snapshots with the same temperature)
#endif

#ifdef  XOutputMaker_binary
extern ofstream FileX_S_B;          // Sheaths' position in total coordinates vs tim
extern ofstream FileX_P_B;          // Particles' position vs 
#endif

#ifdef  VOutputMaker_binary
extern ofstream FileV_S_B;          // Sheath's velocity vs time 
extern ofstream FileV_P_B;          // position vs velocity (snapshots with the same temperature)
#endif


extern int nstep;

extern long random_seed;

extern double timestep;

extern double alpha;                        // Particle.r / Sheath.r_out
extern double beta;                         // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 
extern double lambda;
extern double delta;
extern double eta;
extern double kappa;


//====================================================
//====================================================  output_file_maker
//====================================================

void output_file_maker_data ( ){

    string str_folder_output;

    char buffer[50]="";

    str_folder_output.append("outputs"); 
    str_folder_output.append("_data"); 


    const char* char_folder_output=str_folder_output.c_str();
    mkdir(char_folder_output,0777);


    string str_fname;

//    sprintf(buffer,"_nP:%lu",Sheaths.size());
//    str_fname.append(buffer);


//    sprintf(buffer,"_FT:%g",nstep*timestep);
//    str_fname.append(buffer);


//    sprintf(buffer,"_e:%g",eta);
//    str_fname.append(buffer);

//    sprintf(buffer,"_d:%g",delta);
//    str_fname.append(buffer);

    sprintf(buffer,"_ft:%g",double(nstep*timestep));
    str_fname.append(buffer);

    sprintf(buffer,"_dt:%g",double(timestep));
    str_fname.append(buffer);

    sprintf(buffer,"_k:%g",kappa);
    str_fname.append(buffer);


    
    string str_fname_Data = str_folder_output;
    str_fname_Data.append( "/d"      );

    str_fname_Data.append( str_fname );
    str_fname_Data.append( ".dat"    );
    const char * char_FileData = str_fname_Data.c_str();
    FileData.open( char_FileData );
}
//====================================================
//====================================================  output_file_maker
//====================================================

void output_file_maker ( int ensemble_index ){

    string str_folder_output;

    char buffer[50]="";

    str_folder_output.append("outputs"); 

    sprintf(buffer,"_seed%lu/",random_seed);
    str_folder_output.append(buffer);


    const char* char_folder_output=str_folder_output.c_str();
    mkdir(char_folder_output,0777);

    time_t rawtime;

    struct tm * timeinfo;
    char char_buffer [40];
    time (&rawtime);
    timeinfo = localtime (&rawtime);
  

    strftime (char_buffer,80,"  %F  %T",timeinfo);

    string str_fname;

    sprintf(buffer,"_nP:%lu",Sheaths.size());
    str_fname.append(buffer);


    sprintf(buffer,"_ft:%g",double(nstep*timestep));
    str_fname.append(buffer);

    sprintf(buffer,"_dt:%g",double(timestep));
    str_fname.append(buffer);


    sprintf(buffer,"_e:%g",eta);
    str_fname.append(buffer);

    sprintf(buffer,"_d:%g",delta);
    str_fname.append(buffer);


    sprintf(buffer,"_k:%g",kappa);
    str_fname.append(buffer);


/*
    sprintf(buffer,"_Al:%g",Alpha);
    str_fname.append(buffer);

    sprintf(buffer,"_Be:%g",Beta);
    str_fname.append(buffer);
*/
    

    sprintf(buffer,"_EI:%u",ensemble_index);
    str_fname.append(buffer);


    string str_fname_T = str_folder_output;
    str_fname_T.append( "/t"      );

    str_fname_T.append( str_fname );
    str_fname_T.append( ".dat"    );
    const char * char_FileT = str_fname_T.c_str();
    FileT.open( char_FileT );


    string str_fname_P = str_folder_output;
    str_fname_P.append( "/stat"      );
    str_fname_P.append( str_fname );
    str_fname_P.append( ".dat"    );
    const char * char_FileDataOut = str_fname_P.c_str();
    FileDataOut.open( char_FileDataOut );

#ifdef  XOutputMaker_call
  #ifdef XOutputMaker_ASCII
    string str_FileX_S_A = str_folder_output;
    str_FileX_S_A.append( "/xs"     );
    str_FileX_S_A.append( str_fname );
    str_FileX_S_A.append( ".dat"    );
    const char * char_FileX_S_A = str_FileX_S_A.c_str();
    FileX_S_A.open( char_FileX_S_A, ios::binary | ios::out ) ;

    string str_FileX_P_A = str_folder_output;
    str_FileX_P_A.append( "/xp"     );
    str_FileX_P_A.append( str_fname );
    str_FileX_P_A.append( ".dat"    );
    const char * char_FileX_P_A = str_FileX_P_A.c_str();
    FileX_P_A.open( char_FileX_P_A, ios::binary | ios::out ) ;
  #endif
    
  #ifdef XOutputMaker_binary
    string str_FileX_S_B = str_folder_output;
    str_FileX_S_B.append( "/xs"     );
    str_FileX_S_B.append( str_fname );
    str_FileX_S_B.append( ".bin"    );
    const char * char_FileX_S_B = str_FileX_S_B.c_str();
    FileX_S_B.open( char_FileX_S_B, ios::binary | ios::out ) ;

    string str_FileX_P_B = str_folder_output;
    str_FileX_P_B.append( "/xp"     );
    str_FileX_P_B.append( str_fname );
    str_FileX_P_B.append( ".bin"    );
    const char * char_FileX_P_B = str_FileX_P_B.c_str();
    FileX_P_B.open( char_FileX_P_B, ios::binary | ios::out );
  #endif
#endif

#ifdef  VOutputMaker_call
  #ifdef VOutputMaker_ASCII
    string str_FileV_S_A = str_folder_output;
    str_FileV_S_A.append( "/vs"    );
    str_FileV_S_A.append( str_fname );
    str_FileV_S_A.append( ".dat"    );
    const char * char_FileV_S_A = str_FileV_S_A.c_str();
    FileV_S_A.open( char_FileV_S_A, ios::binary | ios::out );


    string str_FileV_P_A = str_folder_output;
    str_FileV_P_A.append( "/vp"    );
    str_FileV_P_A.append( str_fname );
    str_FileV_P_A.append( ".dat"    );
    const char * char_FileV_P_A = str_FileV_P_A.c_str();
    FileV_P_A.open( char_FileV_P_A, ios::binary | ios::out );
  #endif

  #ifdef VOutputMaker_binary
    string str_FileV_S_B = str_folder_output;
    str_FileV_S_B.append( "/vs"    );
    str_FileV_S_B.append( str_fname );
    str_FileV_S_B.append( ".bin"    );
    const char * char_FileV_S_B = str_FileV_S_B.c_str();
    FileV_S_B.open( char_FileV_S_B, ios::binary | ios::out );


    string str_FileV_P_B = str_folder_output;
    str_FileV_P_B.append( "/vp"    );
    str_FileV_P_B.append( str_fname );
    str_FileV_P_B.append( ".bin"    );
    const char * char_FileV_P_B = str_FileV_P_B.c_str();
    FileV_P_B.open( char_FileV_P_B, ios::binary | ios::out );
  #endif
#endif

/*
    string str_FileNEW = str_folder_output;
    str_FileNEW.append( "/nEW"    );
    str_FileNEW.append( str_fname );
    str_FileNEW.append( ".dat"    );
    const char * char_FileNEW = str_FileNEW.c_str();
    FileNEW.open( char_FileNEW, ios::binary | ios::out );


    string str_FileCollision = str_folder_output;
    str_FileCollision.append( "/col"    );
    str_FileCollision.append( str_fname );
    str_FileCollision.append( ".dat"    );
    const char * char_FileCollision = str_FileCollision.c_str();
    FileCollision.open( char_FileCollision, ios::binary | ios::out );
*/

    cout        << "======================Date and time"          << "\n";
    cout        << char_buffer                                    << "\n";
    cout        << "======================"                       << "\n";
    FileDataOut << "==================Date and time"              << "\n\n";
    FileDataOut << char_buffer                                    << "\n\n";
    FileDataOut << "==================system properties"          << "\n\n";



}

//====================================================
//====================================================  close_files
//====================================================

void close_files(){

        FileDataOut.close();

        FileT.close();

#ifdef  XOutputMaker_call
  #ifdef  XOutputMaker_ASCII
        FileX_S_A.close();
        FileX_P_A.close();
  #endif

  #ifdef  XOutputMaker_binary
        FileX_S_B.close();
        FileX_P_B.close();
  #endif
#endif

#ifdef  VOutputMaker_call
  #ifdef  VOutputMaker_ASCII
        FileV_S_A.close();
        FileV_P_A.close();
  #endif

  #ifdef  VOutputMaker_binary
        FileV_S_B.close();
        FileV_P_B.close();
  #endif
#endif


}




