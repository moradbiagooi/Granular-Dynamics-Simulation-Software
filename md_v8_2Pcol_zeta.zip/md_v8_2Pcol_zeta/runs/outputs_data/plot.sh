set term png
#set terminal png size 800,600 font "Helvetica,15" enhanced
set terminal pngcairo dashed size 1024,768 font "Helvetica,15" enhanced
set border linewidth 2
set xlabel "{/Symbol h}"
set ylabel "{/Symbol z}"
#set title "{/Symbol d} = 0.75"
#set ylabel "{/Symbol d}"
#set ylabel "time"
#set ylabel "Energy"
#set ylabel "Velocity"
#set key right top
#set grid

#set view 30,35

#set view map
#set dgrid3d 100,200 qnorm 4

#set pm3d; set palette
set palette color

set cbrange [400:]

#set cbrange [0:20]
#set cbtics 1

#set cbrange [0:1]
#set cbtics 0.1

set palette model RGB
set palette defined 
#set cbtics 0.1
#set cbtics 5

#set cblabel "Restitution Coefficient"
set cblabel "Number of Shell-Shell Collisions (not scaled)"
#set palette defined (0 0 0 0, 1 0 0 1, 3 0 1 0, 4 1 0 0, 6 1 1 1)

#set title "Number of Collisions ( up to 100 )"
#set title "Number of Collisions ( up to 100 )"
#set title "Restitution Coefficient"
set logscale xy

set title "{/Symbol d} = 0.75"
set output "d_ft:100_dt:1e-05_d:0.75_k:1e+07_nc_ns.png"
#plot [0.01:100] [0.01:100] "d_ft:100_dt:1e-05_zp:0.5_k:1e+07.dat" using 1:2:3 with image ti ""
set tics front
#set logscale cb
plot [:][0.1:]"d_ft:100_dt:1e-05_d:0.75_k:1e+07.dat" using 1:2:4 with points lc palette z pt 7 notitle
#plot [0.01:100] [0.01:100] "d_ft:100_dt:1e-05_zp:0.5_k:1e+07.dat" using 1:2:3 with image ti ""
#splot [:] [:] "d_ft:100_dt:1e-05_zp:0.3_k:1e+07.dat" u 1:2:4 with pm3d ti ""
