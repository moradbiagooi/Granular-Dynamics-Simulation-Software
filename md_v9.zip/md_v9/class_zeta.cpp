#include <cmath>
#include <iostream>

#include "class_zeta.h"

using namespace std;


double class_zeta::zeta ( double eta, double temp ) {

    return sqrt ( temp ) * abs ( xi ( eta, t_max ( eta ) ) ) / l_free();

}

//=======================================================

double class_zeta::temperature ( double eta, double zet ) {

    double _temp = zet * l_free () / xi ( eta, t_max ( eta ) );

    return _temp * _temp;

}

//=======================================================

double class_zeta::t_max ( double eta ) {

    double _t;

    if ( 0.0 < eta && eta < 1.0 ) {

        double _sqrt = sqrt ( 1.0 - eta ) ;

        _t = ( - eta / ( 4.0  * _sqrt ) ) * log ( ( 1.0 - _sqrt ) / ( 1.0 + _sqrt ) );

    } else if ( eta > 1.0 ) {

        double _sqrt = sqrt ( eta - 1.0 ) ;

        _t = ( eta / ( 2.0 * _sqrt ) ) * atan ( _sqrt );

    } else {

        cerr << "eta\t"<< eta << "\terr\n";

//        exit(0);
        _t = 0.0;


    }

    return _t;

}

//=======================================================

double class_zeta::xi ( double eta, double t ){ // t=t_max


    double _xi;

    if ( eta < 1.0 ) {

        double _sqrt = sqrt ( 1.0 - eta ) ;

        _xi = ( - eta / ( 2.0 * _sqrt ) ) * ( 
                + exp ( - ( 2.0 / eta ) * ( 1.0 + _sqrt ) * t ) 
                - exp ( - ( 2.0 / eta ) * ( 1.0 - _sqrt ) * t ) );

    } else if ( eta > 1.0 ) {

        double _sqrt = sqrt ( eta - 1.0 ) ;

        _xi = - ( eta / _sqrt ) * exp ( - ( 2.0 / eta ) * t )
              * sin ( ( 2.0 / eta ) * _sqrt * t );


    } else {

        cerr << "\nerr\n";

        _xi = 0.0;

    }

    return _xi;

}

//=======================================================

double class_zeta::l_free ( ) {

    return ( 1.0 - _alpha - 2.0 * _beta ) * ( 1.0 - _lambda ) / 2.0;

}
