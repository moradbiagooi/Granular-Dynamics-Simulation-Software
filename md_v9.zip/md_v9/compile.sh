rm simple_box
icpc -o simple_box *.cpp
#g++ -o simple_box *.cpp
mv simple_box runs/
