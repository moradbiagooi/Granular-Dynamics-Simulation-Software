#ifndef __OUTPUT_FILE_MAKER_H
#define __OUTPUT_FILE_MAKER_H

void output_file_maker ( int );

void output_file_maker_data ();

void close_files();

#endif
