#include "common.h"
#include "global_variables.h"

//====================================================
//====================================================  cal_rest_coef
//====================================================


void cal_rest_coef(){ 

  double j=0;
  for (int i = 0; i<Sheaths.size(); i++)
    if (Sheaths[i].ptype()==0) j = i; // in case there was walls, or we had
                                    // rest. coeff. instead of diss. coeff.

  #ifdef ParticlesExist
  double _m_eff = Sheaths[j].m() * Sheaths[j].P_m() / (Sheaths[j].m() + Sheaths[j].P_m()); 
  double _Y     = Sheaths[j].Y();
  double _gamma = Sheaths[j].P_A();
  #else
  double _m_eff = Sheaths[j].m() * Sheaths[j].m() / (Sheaths[j].m() + Sheaths[j].m()); 
  double _Y     = Sheaths[j].Y();
  double _gamma = Sheaths[j].A();
  #endif

  double _epsilon; // coefficient of restitution.



  double _m       = _m_eff; 
  double _beta    = _gamma / (2.0 * _m);
  double _omega_0 = sqrt ( _Y / _m );


  if (_beta < (_omega_0 / sqrt(2.0))){
    double _omega   = sqrt (+_omega_0*_omega_0 - _beta*_beta);
    _epsilon = exp(-(_beta/_omega) *  (PI - atan ( (2.0 * _beta * _omega) / (_omega*_omega - _beta*_beta) )  ) ) ;
  }
  else if (_beta <= _omega_0) {
    double _omega   = sqrt (+_omega_0*_omega_0 - _beta*_beta);
    _epsilon = exp(-(_beta/_omega) *  (atan ( (2.0 * _beta * _omega) / (_omega*_omega - _beta*_beta) )  ) ) ;
  }
  else {
    double _OMEGA  = sqrt (-_omega_0*_omega_0 + _beta*_beta);
    _epsilon = exp(-(_beta/_OMEGA) * log ((_beta + _OMEGA) / (_beta - _OMEGA) ) ); 
  }



  cout            << "epsilon : " << _epsilon << "\n";
  fparameters_out << "epsilon : " << _epsilon << "\n";

}



