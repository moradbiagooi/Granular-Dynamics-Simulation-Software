
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _common_h
#define _common_h

#include <math.h>
#include <fstream>
#include <vector>      
#include <string>

#include "properties.h"
#include "MersenneTwister.h"

using namespace std;



void step();           // Performs one time step of the simulation


void velocity_distribution( unsigned int );


void make_gas( int, MTRand * RandNumb );


void make_forces();    // Computes the total forces acting on each Sheath


void integrate();      // Integrates Newton’s equation of motion using the Gear algorithm 


#ifdef XYZOutputMaker
void phase_plot_XYZ(); // Dumps the current positions into the file (xyz format)
#endif

#ifdef XTOutputMaker
void phase_plot_XT();  // Dumps the current positions into the file (xt format)
#endif


void init_algorithm(); // 

void output_file_maker(int);

void temperature_normalizer(double);

void v_COM_zero(bool); 
// (true) : set COM velocity to zero, then print it.
// (false): print COM velocity without changing it.



void init_parameters ( char * fname_ip );

void cal_rest_coef();

void  final_prints( clock_t );

double total_kinetic_energy();

bool init_parameters_check();

#ifdef ParticlesExist
bool Particle_slipped_out( int );
#endif

bool Particle_slipped_out( int );

bool print_data_failed( int );


#endif
