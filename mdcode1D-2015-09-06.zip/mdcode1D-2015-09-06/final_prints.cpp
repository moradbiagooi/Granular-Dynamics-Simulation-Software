#include "common.h"
#include "global_variables.h"


//====================================================
//====================================================  final_prints
//====================================================

void final_prints(clock_t t1){

  clock_t t2;
  t2 = clock();

  cout << "\nfinal time: " << Time << "\n" 
       << "final granular temperature: " 
       << total_kinetic_energy()/(number_of_grains) << endl
       << "normalized final granular temperature: " 
       << total_kinetic_energy()/(number_of_grains*init_gran_temp)
       << endl;

  fparameters_out  
       << "final granular temperature: " 
       << total_kinetic_energy()/(number_of_grains) << endl
       << "normalized final granular temperature: " 
       << total_kinetic_energy()/(number_of_grains*init_gran_temp)
       << endl;

#ifdef XYZOutputMaker
  phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
  phase_plot_XT();
#endif

  cout            << "\n   Num. of active grains: " << number_of_grains;

  t2=clock();

  float diff ((float)t2-(float)t1);

  cout            << "\n\n  execution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n\n" ;
  fparameters_out << "\nexecution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n" ;

}


