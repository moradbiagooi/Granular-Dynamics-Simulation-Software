#ifndef _GLOBAL_VARIABLES_H
#define _GLOBAL_VARIABLES_H

#include "Sheath.h"
#include <fstream>
#include <vector>


#define PI 3.14159265
#define GSmallNumber 1e-4


extern ofstream ftemperature;
extern ofstream fvelocity;
extern ofstream fparameters_out;

#ifdef XYZOutputMaker
extern ofstream xyzfile;  // dump Sheaths positions
 #ifdef ParticlesExist
extern ofstream xyzfile2; // dump Sheaths and Particles positions
 #endif
#endif

#ifdef XTOutputMaker
extern ofstream xtfile;
#endif


extern vector <Sheath> Sheaths;

extern int nstep, nprint, nenergy;
extern int number_of_grains;


extern long random_seed;

extern double timestep, Time;

extern double mean_free_space;
extern double init_gran_temp;

extern double lx;
extern double x0;

extern double Density;

extern double Alpha; // Particle.r / Sheath.r_out

extern double Beta;  // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 

extern double radius_S_out;     //Sheath:   radius_out

extern double A_S, Y_S;
//Sheath:   Dissip. coef., Young modulus, friction coef.

extern double A_P, Y_P;
   //Particle: Dissip. coef., Young modulus, friction coef.


extern double G; // gravity 

#endif
