#include "common.h"
#include <fstream>

#include "global_variables.h"

//====================================================
//====================================================  init_parameters
//====================================================

void init_parameters(char * fname_ip)
{

  cout<<"======================init_parameters()\n";

  ifstream fparameters(fname_ip);

  while(fparameters.peek()=='#'){

    string type;

    fparameters >> type;

    if(type=="#random_seed:"){

      fparameters >> random_seed;
      fparameters.ignore(100,'\n');
      cout << "random_seed: " << random_seed << endl;
      fparameters_out << "random_seed: " << random_seed << endl;

    } else if(type=="#number_of_grains:"){

      fparameters >> number_of_grains;
      fparameters.ignore(100,'\n');
      cout << "number_of_grains: " << number_of_grains << endl;
      fparameters_out << "number_of_grains: " << number_of_grains << endl;

    } else if(type=="#mean_free_space:"){

      fparameters >> mean_free_space;
      fparameters.ignore(100,'\n');
      cout << "mean_free_space: " << mean_free_space << endl;
      fparameters_out << "mean_free_space: " << mean_free_space << endl;

    } else if(type=="#init_gran_temp:"){

      fparameters >> init_gran_temp;
      fparameters.ignore(100,'\n');
      cout << "init_gran_temp: " << init_gran_temp << endl;
      fparameters_out << "init_gran_temp: " << init_gran_temp << endl;
    
    } else if(type=="#gravity:"){


      fparameters >> G;

      fparameters.ignore(100,'\n');
      cout << "gravity: " << G << endl;
      fparameters_out << "gravity: " << G << endl;

    } else if(type=="#Time:"){

      fparameters >> Time;
      fparameters.ignore(100,'\n');
      cout << "Time: " << Time << endl;
      fparameters_out << "Time: " << Time << endl;

    } else if(type=="#timestep:"){

      fparameters >> timestep;
      fparameters.ignore(100,'\n');
      cout << "timestep: " << timestep << endl;
      fparameters_out << "timestep: " << timestep << endl;

    } else if(type=="#nstep:"){

      fparameters >> nstep;
      fparameters.ignore(100,'\n');
      cout << "nstep: " << nstep << endl;
      fparameters_out << "nstep: " << nstep << endl;

    } else if(type=="#nprint:"){

      fparameters >> nprint;
      fparameters.ignore(100,'\n');
      cout << "nprint: " << nprint << endl;

    } else if(type=="#nenergy:"){

      fparameters >> nenergy;
      fparameters.ignore(100,'\n');
      cout << "nenergy: " << nenergy << endl;
      fparameters_out << "nenergy: " << nenergy << endl;

    } else if(type=="#Density:"){

      fparameters >> Density;
      fparameters.ignore(100,'\n');
      cout << "Density: " << Density << endl;

    } else if(type=="#radius_S_out:"){

      fparameters >> radius_S_out;
      fparameters.ignore(100,'\n');
      cout << "radius_S_out: " << radius_S_out << endl;

    }  else if(type=="#A_S:"){

      fparameters >> A_S;
      fparameters.ignore(100,'\n');
      cout << "A_S: " << A_S << endl;

    } else if(type=="#Y_S:"){

      fparameters >> Y_S;
      fparameters.ignore(100,'\n');
      cout << "Y_S: " << Y_S << endl;

    } else if(type=="#Alpha:"){

      fparameters >> Alpha;
      cout << "Alpha: " << Alpha << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#Beta:"){

      fparameters >> Beta;
      cout << "Beta: " << Beta << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#A_P:"){

      fparameters >> A_P;
      cout << "A_P: " << A_P << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#Y_P:"){

      fparameters >> Y_P;
      cout << "Y_P: " << Y_P << endl;
      fparameters.ignore(100,'\n');

    } else {

      cerr << "init_parameters(): unknown global property: " << type << endl;

    }

  }

}


