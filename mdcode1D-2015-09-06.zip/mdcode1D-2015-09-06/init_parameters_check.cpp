#include "common.h"
#include "global_variables.h"

//====================================================
//====================================================  init_parameters_check
//====================================================

bool init_parameters_check(){
#ifdef ParticlesExist
  if (Alpha < GSmallNumber || Alpha > 1.0 - GSmallNumber){
    cout << "Error: assign #Alpha between " << GSmallNumber << " and " << 1.0 - GSmallNumber << endl;
    return false;
  }
  if (Beta < GSmallNumber || Beta > 0.5 - GSmallNumber){
    cout << "Error: assign #Beta between " << GSmallNumber << " and " << 0.5 - GSmallNumber << endl;
    return false;
  }
  if (Alpha + Beta < 2.0*GSmallNumber || Alpha +Beta > 1.5 - 2.0*GSmallNumber){
    cout << "Error: assign #Alpha and #Beta so that (Alpha + Beta) would be between " << GSmallNumber << " and " << 1.5 - GSmallNumber << endl;
    return false;
  }
#endif
  return true;
}


