#include "common.h"
#include "global_variables.h"


//====================================================
//====================================================  integrate
//====================================================

void integrate()
{

  for( unsigned int i = 0; i < Sheaths.size(); i++ ){

      Sheaths[i].set_force_to_zero(); 

      Sheaths[i].predict( timestep );

  }


    make_forces();

  
  for( unsigned int i = 0; i < Sheaths.size(); i++ ){

      Sheaths[i].correct( timestep );

  }


  for( unsigned int i = 0; i < Sheaths.size(); i++ ){


//    Sheaths[i].periodic_bc ( x_0, lx );
    Sheaths[i].periodic_bc ( 0, lx );

  }

  Time += timestep;

}



