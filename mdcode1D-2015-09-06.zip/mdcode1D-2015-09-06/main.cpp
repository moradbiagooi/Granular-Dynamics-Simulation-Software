
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>

#include <time.h>
#include <iomanip> 

#include "common.h"
#include "Sheath.h"   
#include "MersenneTwister.h"
#include "properties.h"

#include "global_variables.h"


using namespace std;


double Time=0, timestep;

int nstep, nprint, nenergy;
int number_of_grains;


long random_seed;

double XYZscale=.5;

double mean_free_space;
double init_gran_temp;



double lx, x_0=0;



double Density;

double Alpha; // Particle.r / Sheath.r_out

double Beta;  // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 

double radius_S_out;     //Sheath:   radius_out

double A_S, Y_S;
//Sheath:   Dissip. coef., Young modulus, friction coef.

double A_P, Y_P;
   //Particle: Dissip. coef., Young modulus, friction coef.


double G; // gravity 


vector< Sheath > Sheaths;   // outer Sheaths //

int mkdir(const char *path, mode_t mode);


ofstream ftemperature;
ofstream fvelocity;
ofstream fparameters_out;

#ifdef XYZOutputMaker
ofstream xyzfile;  // dump Sheaths positions
 #ifdef ParticlesExist
ofstream xyzfile2; // dump Sheaths and Particles positions
 #endif
#endif

#ifdef XTOutputMaker
ofstream xtfile;
#endif

//====================================================
//====================================================  main
//====================================================


int main ( int argc, char ** argv ){


  if (argc!=2){
    cerr << "Needs 1 input file, for example: \n\t \
             $ /a.out init_parameters.dat\n";
    exit(0);
    return 0; 
  }


  clock_t t0,t1;

  t0 = clock();

  ftemperature.precision( 10 ); 

  unsigned int  ensemble_index;

  unsigned int  ensemble_number = 20;

  init_parameters( argv[1] );

  class MTRand *RandNumb = new MTRand ( random_seed );

  for ( ensemble_index =1; ensemble_index <= ensemble_number; ensemble_index++ ){

    t1 = clock();

    Sheaths.clear();

    Time=0;





// takes system parameters from the inputted file in the command line

    if ( !init_parameters_check() )
      return 0;
    else
      cout << "\ninit_parameters_check() : OK \n";



    make_gas( number_of_grains, RandNumb );  
// DeAcTiVE this function when the system would be inputted from a file.


    output_file_maker ( ensemble_index );


#ifdef XYZOutputMaker
    phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
    phase_plot_XT();
#endif


    cal_rest_coef(); // coefficient of restitution.


    v_COM_zero(true);


    temperature_normalizer(init_gran_temp); 

    cout <<"======================";
    cout <<"time loop() for ensemble number " << ensemble_index << "\n";

    for ( int i=0; i < nstep; i++ ){

      step();      

#ifdef ParticlesExist
      if ( Particle_slipped_out( i ) ) return 0;
#endif

      if ( print_data_failed   ( i ) ) return 0;

    }
    
    velocity_distribution( 20 );    

    final_prints( t1 );
 

    ftemperature.close();
    fparameters_out.close();
    fvelocity.close();

#ifdef XYZOutputMaker
    xyzfile.close();
 #ifdef ParticlesExist
    xyzfile2.close();
 #endif
#endif
#ifdef XTOutputMaker
    xtfile.close();
#endif

  }


  cout            << "\n\n  Total ensemble execution time: " 
                  << ((float)clock()-(float)t0) / CLOCKS_PER_SEC << " seconds\n\n" ;

  return 0;

}
//====================================================

bool print_data_failed (int i) {

#ifdef XYZOutputMaker
  if ((i+1)%nprint==0)
    phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
  if ((i+1)%nprint==0)
    phase_plot_XT();
#endif


  if ((i+1)%nenergy==0){

    double temp_temp0 = total_kinetic_energy()
                      / (number_of_grains*init_gran_temp); 

    ftemperature << Time << "\t" 
                 << temp_temp0
                 << endl;

    if (temp_temp0 > 3.0){

      cerr << "\n\nerror: increasing temperature\n"
           << "change your system parameters\n"
           << "Simulation stopped at the time step: "<< i <<"\n";

      return true;

    }
  }

  return false;
}


//====================================================

#ifdef ParticlesExist
bool Particle_slipped_out(int i){

  for (unsigned j=0; j<Sheaths.size(); j++)
    if (Sheaths[j].P_slipped_out()){

      cerr << "Error: Particle " << j
           << " slipped out of its sheath at the step "
           << i << "\n";

      return true;
    }

  return false;
}
#endif


