#include "common.h"
#include "Sheath.h"
#include "Particle.h"
#include "MersenneTwister.h" 

extern vector <Sheath> Sheaths;

extern MTRand * RandNumb;

extern double Density, A_S, Y_S, lx;

extern double mean_free_space, radius_S_out;

extern int number_of_grains;

//====================================================
//====================================================  make_gas
//====================================================

void make_gas(int _grains_num, MTRand * RandNumb){

  cout<<"======================make_gas()\n";

// MersenneTwister random number generator
//  long Grng_seed = (long) 2;

//  class MTRand *RandNumb = new MTRand (random_seed);


  lx = ((2.0 * radius_S_out) + mean_free_space) * _grains_num; 


  double grain_x [_grains_num];

#ifdef RandomInitialPosition

// ----------------------- Making Sheaths Positions
cout << "Making Sheaths Positions: If this part took more than a few seconds, "
     << "you may have to increase #mean_free_space... ";

  int grains_counter = 0;

  while (grains_counter < _grains_num) {

    double temp_x = lx * RandNumb -> randDblExc();


    bool flag_freeSpace = true;

    int i = 0;

    while (flag_freeSpace && i < grains_counter){


      if (   temp_x < grain_x[i] + 2.0 * radius_S_out + GSmallNumber
          && temp_x > grain_x[i] - 2.0 * radius_S_out - GSmallNumber)
        flag_freeSpace = false;



        i++;

    }

    if (flag_freeSpace){

      grain_x[grains_counter] = temp_x;


      grains_counter++;

    }

  }
// -----------------------



// ----------------------- sorting grain_x[]
// used for Linear neighbors


  bool flag_disorder = true;

  while (flag_disorder){

    flag_disorder = false;

    for (int i=0;i<_grains_num;i++){

      for (int j=0;j<_grains_num;j++){

        if (grain_x[i] > grain_x[j] && i < j){

          flag_disorder = true;
          double temp_x = grain_x[i];
          grain_x[i]    = grain_x[j];
          grain_x[j]    = temp_x;

        }

      }

    }

  }
#else

  double _inbetween_distance = lx / double(_grains_num);

  for (int i=0; i < _grains_num; i++){
    grain_x [i]= mean_free_space/2.0 + double(i) * _inbetween_distance;
  }

#endif
// -----------------------
  cout << "OK\n" << endl;
  cout << "lx = " << lx << endl;

#ifdef ParticlesExist
cout << "\nMaking Particles Positions: If this part took more than a few seconds, "
     << "you may have to decrease (#Alpha + #Beta)... ";
#endif
// ----------------------- making grains 
  for (int i=0; i<_grains_num ; i++){

    Sheath pp;

// ----------------------- radius, mass, rotational inertia

    pp.r()     = radius_S_out;

#ifdef ParticlesExist
    pp.r_mid() = radius_S_out * ( 1.0 - 2 * Beta);
    pp.P_r()   = pp.r() * Alpha;


    pp.m()     = Density * 2 * (pp.r() - pp.r_mid());
    pp.P_m()   = Density * 2 * pp.P_r();


#else
    pp.r_mid() = 0.0;


    pp.m()     = Density * 2 * (pp.r() - pp.r_mid());



#endif
// -----------------------



// ----------------------- positions
    pp.x()     = grain_x[i];



#ifdef ParticlesExist

 #ifdef RandomInitialPosition
find_new_rnd1:
    double temp_x = pp.x() 
                  + ( 0.5 - RandNumb -> randDblExc() ) * 2
                  * (pp.r_mid() - pp.P_r() - GSmallNumber) ; 


    if( pp.r_mid() 
        - (  sqrt((temp_x - pp.x()) * (temp_x - pp.x())) 
           + pp.P_r()) < 0) 
      goto find_new_rnd1;

    

    pp.P_x()  = temp_x; 

 #else
    pp.P_x()  = pp.x(); 
 #endif

#endif
// -----------------------



// ----------------------- random velocity
    pp.vx()   = (0.5 - RandNumb -> randDblExc()) * 2;

#ifdef ParticlesExist
 #ifdef RandomInitialVelocity
    pp.P_vx() = (0.5 - RandNumb -> randDblExc()) * 2;
 #else
    pp.P_vx() = pp.vx();
 #endif
#endif


// -----------------------



// ----------------------- material properties
    pp.A()     = A_S;
    pp.Y()     = Y_S;



#ifdef ParticlesExist
    pp.P_A()  = A_P;
    pp.P_Y()  = Y_P;


#endif
// -----------------------

    
    pp.ptype() = 0;
   
    Sheaths.push_back(pp);

  }
  cout << "OK\n" << endl;
  cout << number_of_grains << " grains are made\n" << flush;
  cout << "======================\n";

}

