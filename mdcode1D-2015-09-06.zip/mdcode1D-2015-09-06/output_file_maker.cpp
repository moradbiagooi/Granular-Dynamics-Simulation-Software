#include <sys/stat.h> // used for mkdir()

#include "common.h"
#include <fstream>
#include "Sheath.h"

#include "global_variables.h"

//====================================================
//====================================================  output_file_maker
//====================================================

void output_file_maker(int ensemble_index){

  string str_folder_output;

  char buffer[50]="";

  str_folder_output.append("outputs"); 

  sprintf(buffer,"_seed%lu/",random_seed);
  str_folder_output.append(buffer);



  const char* char_folder_output=str_folder_output.c_str();
  mkdir(char_folder_output,0777);

  time_t rawtime;

  struct tm * timeinfo;
  char char_buffer [40];
  time (&rawtime);
  timeinfo = localtime (&rawtime);
  

//  strftime (buffer,80,"Now it's %I:%M%p.",timeinfo);
//  strftime (buffer,80,"Now it's %F_%T",timeinfo);

  strftime (char_buffer,80,"  %F  %T",timeinfo);

  string str_fname;


#ifdef ParticlesExist //ON or OFF//
  str_fname.append("_PE");
#endif



  sprintf(buffer,"_nP:%lu",Sheaths.size());
  str_fname.append(buffer);

//  sprintf(buffer,"_dt:%g",timestep);
//  str_fname.append(buffer);
//  sprintf(buffer,"_nt:%u",nstep);

  sprintf(buffer,"_FT:%g",nstep*timestep);
  str_fname.append(buffer);

#ifdef ParticlesExist
  sprintf(buffer,"_AP:%g",A_P);
  str_fname.append(buffer);
#else
  sprintf(buffer,"_AS:%g",A_S);
  str_fname.append(buffer);
#endif

#ifdef ParticlesExist
  sprintf(buffer,"_Al:%g",Alpha);
  str_fname.append(buffer);
  sprintf(buffer,"_Be:%g",Beta);
  str_fname.append(buffer);
#endif

  sprintf(buffer,"_EI:%u",ensemble_index);
  str_fname.append(buffer);

//  sprintf(buffer,"_MFS:%g",mean_free_space);
//  str_fname.append(buffer);

  string str_fname_T=str_folder_output;
  str_fname_T.append("/T");
  str_fname_T.append(str_fname);
  str_fname_T.append(".dat");
  const char * char_ftemperature=str_fname_T.c_str();
  ftemperature.open(char_ftemperature);

  string str_fname_P=str_folder_output;
  str_fname_P.append("/P");
  str_fname_P.append(str_fname);
  str_fname_P.append(".dat");
  const char * char_fparameters_out=str_fname_P.c_str();
  fparameters_out.open(char_fparameters_out);

#ifdef XYZOutputMaker

  string str_xyzfile=str_folder_output;
  str_xyzfile.append("/XYZ");
  str_xyzfile.append(str_fname);
  str_xyzfile.append(".xyz");
  const char * char_xyzfile=str_xyzfile.c_str();
  xyzfile.open(char_xyzfile);

 #ifdef ParticlesExist
  string str_xyzfile2=str_folder_output;
  str_xyzfile2.append("/XYZ2");
  str_xyzfile2.append(str_fname);
  str_xyzfile2.append(".xyz");
  const char * char_xyzfile2=str_xyzfile2.c_str();
  xyzfile2.open(char_xyzfile2);
 #endif

#endif

#ifdef XTOutputMaker
  string str_xtfile=str_folder_output;
  str_xtfile.append("/xt");
  str_xtfile.append(str_fname);
  str_xtfile.append(".dat");
  const char * char_xtfile=str_xtfile.c_str();
  xtfile.open(char_xtfile);
#endif


  string str_fvelocity=str_folder_output;
  str_fvelocity.append("/v");
  str_fvelocity.append(str_fname);
  str_fvelocity.append(".dat");
  const char * char_fvelocity=str_fvelocity.c_str();
  fvelocity.open(char_fvelocity);




  cout            << "======================Date and time" << "\n";
  cout            << char_buffer                           << "\n";
  cout            << "======================"              << "\n";
  fparameters_out << "==================Date and time"     << "\n\n";
  fparameters_out << char_buffer                           << "\n\n";
  fparameters_out << "==================system properties" << "\n\n";


   
  fparameters_out << "Linear DashpotForce"    << "\n\n";

#ifdef ParticlesExist 
  fparameters_out << "Sheath - Particle grains"     << "\n";
#else
  fparameters_out << "Ordinary grains"     << "\n";
#endif


  fparameters_out << "\n==================\n\n";

  fparameters_out << "random_seed: "  << random_seed << "\n";

  fparameters_out << "radius_S_out: " << Sheaths[1].r() << "\n";

#ifdef ParticlesExist 
  fparameters_out << "radius_S_in: "  << Sheaths[1].r_mid() << "\n";
#endif

  fparameters_out << "Density: "  << Density  << "\n";
  fparameters_out << "mass_S: "   << Sheaths[1].m()   << "\n";
  fparameters_out << "A_S: "      << A_S      << "\n";
  fparameters_out << "Y_S: "      << Y_S      << "\n";

#ifdef ParticlesExist 
  fparameters_out << "Alpha: "     << Alpha             << "\n";
  fparameters_out << "Beta: "      << Beta              << "\n";

  fparameters_out << "radius_P: "  << Sheaths[1].P_r()  << "\n";
  fparameters_out << "mass_P: "    << Sheaths[1].P_m()  << "\n";
  fparameters_out << "A_P: "       << A_P       << "\n";
  fparameters_out << "Y_P: "       << Y_P       << "\n";

#endif

  fparameters_out << "\n==================\n\n";
  fparameters_out << "lx: "         << lx   << "\n";


  fparameters_out << "mean_free_space: "      
                  <<  mean_free_space    << "\n";
  fparameters_out << "init_gran_temp: "      
                  <<  init_gran_temp     << "\n";

  fparameters_out << "\n==================\n\n";
  fparameters_out << "timestep: "   << timestep   << "\n";
  fparameters_out << "nsteps: "     << nstep      << "\n";
  fparameters_out << "final_time: "  
                  << nstep*timestep               << "\n";

  fparameters_out << "\n==================\n\n";
  fparameters_out << "Number of grains: " 
                  << Sheaths.size()               << "\n";


}

