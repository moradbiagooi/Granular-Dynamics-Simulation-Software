
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _properties_h
#define _properties_h


//=============================== Sheaths's Particle existence
// If defined, each grain will have an inner radius and an inner Particle.
// 

//#define ParticlesExist     // ON or OFF //

//#define RandomInitialPosition

//#define RandomInitialVelocity

//===============================  output: xyz
// Make a output file in "xyz" format
// it can be used in VMD visualization
// "XYZ_***.xyz"  only Sheath's positions
// "XYZ2_***.xyz" Sheath's and particles positions which 
// would be constructed when ParticlesExist is defined
//

//#define XYZOutputMaker    // ON or OFF //


//===============================  output X(t)
// Make a output file in the format:
//     t1   x1   x2   ...   xn
//     t2   x1   x2   ...   xn
// it can be used to plot "phase vs time" graphs
//

//#define XTOutputMaker    // ON or OFF //


//===============================
//
#endif
