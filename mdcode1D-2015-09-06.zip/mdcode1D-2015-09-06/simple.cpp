
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include "common.h"
#include "Sheath.h"
#include "properties.h"
#include "global_variables.h"

using namespace std;

//====================================================


//void init_algorithm() 
//{
//}


//====================================================


void step()
{
  integrate();
}


//====================================================

void make_forces()
{

  for(unsigned int i=0;i<Sheaths.size();i++){



 #ifdef ParticlesExist
    Sheaths[i].internal_force(lx);
 #endif


    if (i+1 == Sheaths.size()){
      force(Sheaths[i],Sheaths[0], lx); // Periodic B.C
    }
    else
    {
      force(Sheaths[i],Sheaths[i+1], lx); // LINEAR NEIGHBORS
    }


  }

}


