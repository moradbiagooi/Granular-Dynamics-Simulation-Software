#include "common.h"
#include "global_variables.h"

//====================================================
//====================================================  total_kinetic_eneregy
//====================================================

double total_kinetic_energy()
{

  double sum=0;

  for( unsigned int i=0; i < Sheaths.size(); i++ ){

    if( Sheaths[i].ptype() == 0 )
      sum+=Sheaths[i].kinetic_energy();

  }

  return sum;

}

