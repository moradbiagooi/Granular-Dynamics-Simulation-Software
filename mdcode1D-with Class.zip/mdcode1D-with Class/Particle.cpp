
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include "Particle.h"
#include <assert.h>
#include "properties.h"



//====================================================
//==================================================== P::predict
//====================================================

void Particle::predict(double dt)
{

  double a1 = dt;
  double a2 = a1 * dt/2;
  double a3 = a2 * dt/3;
  double a4 = a3 * dt/4;

  rtd0 += a1*rtd1 + a2*rtd2 + a3*rtd3 + a4*rtd4;
  rtd1 += a1*rtd2 + a2*rtd3 + a3*rtd4;
  rtd2 += a1*rtd3 + a2*rtd4;
  rtd3 += a1*rtd4;

}

//====================================================
//==================================================== P::correct
//====================================================

void Particle::correct(double dt)
{


  static double accel,corr;


  double dtrez = 1/dt;
  const double coeff0 = double(19) / double(90) *(dt*dt/double(2));
  const double coeff1 = double(3)  / double(4)  *(dt/double(2));
  const double coeff3 = double(1)  / double(2)  *(double(3)*dtrez);
  const double coeff4 = double(1)  / double(12) *(double(12)*(dtrez*dtrez));


  accel = ((1/_m)*_force);

  corr  = accel-rtd2;

  rtd0 += coeff0*corr;
  rtd1 += coeff1*corr;
  rtd2  = accel;
  rtd3 += coeff3*corr;
  rtd4 += coeff4*corr;

}

//====================================================
//==================================================== P::kinetic_energy
//====================================================

double Particle::kinetic_energy() const
{

  return _m* ( rtd1 * rtd1 ) / 2;

}


