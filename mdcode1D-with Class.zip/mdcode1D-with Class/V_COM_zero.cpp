#include "common.h"
#include "Sheath.h"
#include <vector>

extern vector <Sheath> Sheaths;

//====================================================
//====================================================  v_COM_zero
//====================================================

void v_COM_zero ( bool make_zero_velocity ){

int number_of_grains = Sheaths.size();

restart_make_zero:

  double v_COM_x=0;


  for(unsigned int i=0;i<Sheaths.size();i++){

    if(Sheaths[i].ptype()==0){

      v_COM_x += Sheaths[i].vx();

#ifdef ParticlesExist
      v_COM_x += Sheaths[i].P_vx();
#endif


    }

  }


#ifdef ParticlesExist
  v_COM_x /= (2 * number_of_grains);
#else
  v_COM_x /= ( number_of_grains);
#endif




  if (make_zero_velocity) {  

    for(unsigned int i=0;i<Sheaths.size();i++){

      if(Sheaths[i].ptype()==0){

        Sheaths[i].vx()   -= v_COM_x;

#ifdef ParticlesExist
        Sheaths[i].P_vx() -= v_COM_x;
#endif


      }

    }

    make_zero_velocity = false;
    goto restart_make_zero;

  }

  cout << "center of mass velocity x: " << v_COM_x << "\n";
  cout<<"======================\n";

}


