#!/bin/sh
# BATCHPLOT - multiple file plotter script
# Ver. 0.1 (2009/01/28, test version)
# Copyright (c) 2010 Tianhe Yang [ http://tianheyang.com/ ]
# Licensed under the GNU General Public License [ http://tianheyang.com/documents/applications/license.txt ]
# Requires gnuplot

legend()
{
  cat << EOF
  legend: $0 options
  
  This script will plot all files in a directory with the specified file extension.
  
  OPTIONS:
  -h      Show this help document.
  -t      Type of plot. 'single' makes a new plot for each file, 'multi' plots all files on a single plot. The 'multi' option has not yet been implemented.
  -d      Directory of the files.
  -f      Extension of the data files to plot. Default value is 'txt'.
  -l      Delimiter symbol. Space: ' ' Comma: ',' Tab: '\t'
  -n      Name of the group. For example, if the files you wish to plot are named 'test01', 'test02', etc., the name of the group would be 'test'. Default behavior will plot all files with the specified file extension.
  -s      Some data files contain header information. Specify the line number to start reading from.
  -e      Some data files contain footer information. Specify the line number at which the data ends.
  -m      The output data type. Can be 'eps', 'pdf', or 'ps'.
  -x      x-axis label.
  -y      y-axis label.
EOF
}

TYPE="single"
DIR=""
EXT="dat"
DELIM=","
GROUP=""
START=""
END=""
OUT="png"
OFFSET=0
XLABEL="Wavelength (nm)"
YLABEL="Power (dBm)"
while getopts “h:t:d:f:l:n:s:e:m:x:y:o” OPTION
  do
    case $OPTION in
    h)
    legend
    exit 1
    ;;
  t)
  TYPE=$OPTARG
  ;;
d)
DIR=$OPTARG
;;
f)
EXT=$OPTARG
;;
l)
DELIM=$OPTARG
;;
n)
GROUP=$OPTARG
;;
s)
START=$OPTARG
;;
e)
END=$OPTARG
;;
m)
OUT=$OPTARG
;;
x)
XLABEL=$OPTARG
;;
y)
YLABEL=$OPTARG
;;
o)
OFFSET=$OPTARG
;;
?)
legend
exit
;;
esac
done

bashplotsingle()
{
  LIST="$(ls $DIR$GROUP*.$EXT)"
  for file in $LIST; do
    if [ -e $file ]; then
      echo "Processing $file..."
      gnuplot << EOF
      plot for [col=2:21] "$file" using col:1 w d notitle lt rgb "black"
      set term png
      set terminal png size 800,600 enhanced font "Helvetica,10"             
      set output "$file.$OUT"
      rep
EOF
      echo "Done!"
      else
	echo "The file \"$file\" is missing."
    fi
done
}

bashplotmulti()
{
  echo "Multi plots have not yet been implemented."
}

bashplot$TYPE -d $DIR -n $GROUP -f $EXT -l $DELIM -s $START -e $END -m $OUT -x $XLABEL -y $YLABEL -o $OFFSET

exit
