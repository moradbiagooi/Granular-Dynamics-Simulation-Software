
#include <fstream>

#include "class_system_parameters.h"

using namespace std;


bool system_parameters::check(){
#ifdef ParticlesExist
  if (Alpha < GSmallNumber || Alpha > 1.0 - GSmallNumber){
    cout << "Error: assign #Alpha between " << GSmallNumber << " and " << 1.0 - GSmallNumber << endl;
    return false;
  }
  if (Beta < GSmallNumber || Beta > 0.5 - GSmallNumber){
    cout << "Error: assign #Beta between " << GSmallNumber << " and " << 0.5 - GSmallNumber << endl;
    return false;
  }
  if (Alpha + Beta < 2.0*GSmallNumber || Alpha +Beta > 1.5 - 2.0*GSmallNumber){
    cout << "Error: assign #Alpha and #Beta so that (Alpha + Beta) would be between " << GSmallNumber << " and " << 1.5 - GSmallNumber << endl;
    return false;
  }
#endif
  return true;
}




//====================================================
//====================================================  init_parameters
//====================================================

void system_parameters::init_parameters(char * fname_ip)
{

  cout<<"======================init_parameters()\n";

  ifstream fparameters(fname_ip);

  while(fparameters.peek()=='#'){

    string type;

    fparameters >> type;

    if(type=="#random_seed:"){

      long ltemp;
      fparameters >> ltemp;
      _random_seed = ltemp;

      fparameters.ignore(100,'\n');
      cout << "random_seed: " << _random_seed << endl;


    } else if(type=="#number_of_grains:"){

      int itemp;
      fparameters >> itemp;
      _number_of_grains = itemp;

      fparameters.ignore(100,'\n');
      cout << "number_of_grains: " << _number_of_grains << endl;


    } else if(type=="#mean_free_space:"){

      double dtemp;
      fparameters >> dtemp;
      _mean_free_space = dtemp;

      fparameters.ignore(100,'\n');
      cout << "mean_free_space: " << _mean_free_space << endl;


    } else if(type=="#init_gran_temp:"){

      double dtemp;
      fparameters >> dtemp;
      _init_gran_temp = dtemp;

      fparameters.ignore(100,'\n');
      cout << "init_gran_temp: " << _init_gran_temp << endl;

    
    } else if(type=="#gravity:"){

      double dtemp;
      fparameters >> dtemp;
      _G = dtemp;

      fparameters.ignore(100,'\n');
      cout << "gravity: " << _G << endl;


    } else if(type=="#Time:"){

      double dtemp;
      fparameters >> dtemp;
      _Time = dtemp;

      fparameters.ignore(100,'\n');
      cout << "Time: " << _Time << endl;


    } else if(type=="#timestep:"){

      double dtemp;
      fparameters >> dtemp;
      _timestep = dtemp;

      fparameters.ignore(100,'\n');
      cout << "timestep: " << _timestep << endl;


    } else if(type=="#nstep:"){

      int itemp;
      fparameters >> itemp;
      _nstep = itemp;

      fparameters.ignore(100,'\n');
      cout << "nstep: " << _nstep << endl;


    } else if(type=="#nprint:"){

      int itemp;
      fparameters >> itemp;
      _nprint = itemp;

      fparameters.ignore(100,'\n');
      cout << "nprint: " << _nprint << endl;

    } else if(type=="#nenergy:"){

      int itemp;
      fparameters >> itemp;
      _nenergy = itemp;

      fparameters.ignore(100,'\n');
      cout << "nenergy: " << _nenergy << endl;


    } else if(type=="#Density:"){

      double dtemp;
      fparameters >> dtemp;
      _Density = dtemp;

      fparameters.ignore(100,'\n');
      cout << "Density: " << _Density << endl;

    } else if(type=="#radius_S_out:"){

      double dtemp;
      fparameters >> dtemp;
      _radius_S_out= dtemp;

      fparameters.ignore(100,'\n');
      cout << "radius_S_out: " << _radius_S_out << endl;

    }  else if(type=="#A_S:"){

      double dtemp;
      fparameters >> dtemp;
      _A_S = dtemp;

      fparameters.ignore(100,'\n');
      cout << "A_S: " << _A_S << endl;

    } else if(type=="#Y_S:"){

      double dtemp;
      fparameters >> dtemp;
      _Y_S = dtemp;

      fparameters.ignore(100,'\n');
      cout << "Y_S: " << _Y_S << endl;

    } else if(type=="#Alpha:"){

      double dtemp;
      fparameters >> dtemp;
      _Alpha = dtemp;

      cout << "Alpha: " << _Alpha << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#Beta:"){

      double dtemp;
      fparameters >> dtemp;
      _Beta = dtemp;

      cout << "Beta: " << _Beta << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#A_P:"){

      double dtemp;
      fparameters >> dtemp;
      _A_P = dtemp;

      cout << "A_P: " << _A_P << endl;
      fparameters.ignore(100,'\n');

    } else if(type=="#Y_P:"){

      double dtemp;
      fparameters >> dtemp;
      _Y_P = dtemp;

      cout << "Y_P: " << _Y_P << endl;
      fparameters.ignore(100,'\n');

    } else {

      cerr << "init_parameters(): unknown global property: " << type << endl;

    }

  }

}


