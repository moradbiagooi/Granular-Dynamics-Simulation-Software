#ifndef _CLASS_SYSTEM_PARAMETERS_H
#define _CLASS_SYSTEM_PARAMETERS_H

#include<iostream>
#include<fstream>

using namespace std;

class system_parameters{

public:
  system_parameters() {}


  void init_parameters(char * fname_ip);
 
  bool check();




  int  nstep ()  const {return _nstep;}
  int  nprint ()  const {return _nprint;}
  int  nenergy ()  const {return _nenergy;}
  int  number_of_grains ()  const {return _number_of_grains;}

  long  random_seed ()  const {return _random_seed;}

  double Time () const {return _Time;} //start time
  double  timestep ()  const {return _timestep;}
  double  mean_free_space ()  const {return _mean_free_space;}
  double  init_gran_temp ()  const {return _init_gran_temp;}
  double  lx ()  const {return _lx;}
  double  x0 ()  const {return _x0;}
  double  Density ()  const {return _Density;}
  double  Alpha ()  const {return _Alpha;} // Particle.r / Sheath.r_out
  double  Beta ()  const {return _Beta;}  // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 
  double  radius_S_out ()  const {return _radius_S_out;}     //Sheath:   radius_out
  double  A_S  () const {return _A_S;} // Sheath:Dissip. coef.
  double  Y_S  () const {return _Y_S;} // Sheath:Young modulus
  double  A_P  () const {return _A_P;} // Particle:Dissip. coef.
  double  Y_P () const {return _Y_P;} // Particle:Young modulus
  double  G () const {return _G;} // gravity 



private:


  int _nstep;
  int _nprint;
  int _nenergy;
  int _number_of_grains;

  long _random_seed;

  double _Time; // Start time
  double _timestep;
  double _mean_free_space;
  double _init_gran_temp;
  double _lx;
  double _x0;
  double _Density;
  double _Alpha; // Particle.r / Sheath.r_out
  double _Beta;  // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 
  double _radius_S_out;     //Sheath:   radius_out
  double _A_S;
  double _Y_S;
  double _A_P;
  double _Y_P;
  double _G; // gravity 

};

#endif
