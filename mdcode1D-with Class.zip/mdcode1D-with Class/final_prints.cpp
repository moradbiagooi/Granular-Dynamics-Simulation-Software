#include "common.h"
//#include "global_variables.h"
#include "class_system_parameters.h"
#include <fstream>
//====================================================
//====================================================  final_prints
//====================================================

extern ofstream fparameters_out;

void final_prints(clock_t t1, system_parameters * Parameters){

  int number_of_grains = Parameters -> number_of_grains();
  double init_gran_temp  = Parameters -> init_gran_temp();

  clock_t t2;
  t2 = clock();

  cout << "final granular temperature: " 
       << total_kinetic_energy()/(number_of_grains) << endl
       << "normalized final granular temperature: " 
       << total_kinetic_energy()/(number_of_grains*init_gran_temp)
       << endl;

  fparameters_out  
       << "final granular temperature: " 
       << total_kinetic_energy()/(number_of_grains) << endl
       << "normalized final granular temperature: " 
       << total_kinetic_energy()/(number_of_grains*init_gran_temp)
       << endl;

#ifdef XYZOutputMaker
  phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
  phase_plot_XT();
#endif

  cout            << "\n   Num. of active grains: " << number_of_grains;

  t2=clock();

  float diff ((float)t2-(float)t1);

  cout            << "\n\n  execution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n\n" ;
  fparameters_out << "\nexecution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n" ;

}


