/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>

#include <time.h>
#include <iomanip> 

#include "common.h"
#include "Sheath.h"   
#include "MersenneTwister.h"
#include "properties.h"


#include "class_system_parameters.h"

using namespace std;

#define PI 3.14159265
#define GSmallNumber 1e-4



ofstream ftemperature;
ofstream fvelocity;
ofstream fparameters_out;

#ifdef XYZOutputMaker
ofstream xyzfile;  // dump Sheaths positions
 #ifdef ParticlesExist
ofstream xyzfile2; // dump Sheaths and Particles positions
 #endif
#endif

#ifdef XTOutputMaker
ofstream xtfile;
#endif

vector <Sheath> Sheaths;

double Time;

//====================================================
//====================================================  main
//====================================================


int main ( int argc, char ** argv ){

  if (argc!=2){
    cerr << "Needs 1 input file, for example: \n\t \
             $ /a.out init_parameters.dat\n";
    exit(0);
    return 0; 
  }

  clock_t t0,t1;

  t0 = clock();

  ftemperature.precision( 10 ); 

  class system_parameters *Parameters = new system_parameters();

  Parameters -> init_parameters( argv[1] );

  if (!Parameters -> check()) return 0;

  class MTRand *RandNumb = new MTRand ( Parameters -> random_seed() );
  
  unsigned int  ensemble_number = 10;

  for ( unsigned int ensemble_index =1; ensemble_index <= ensemble_number; ensemble_index++ ){

    t1 = clock();

    Sheaths.clear();

    Time = Parameters -> Time(); // Start time

    double lx; // system size

    make_gas( lx, RandNumb, Parameters );  

    output_file_maker ( ensemble_index, Parameters );

#ifdef XYZOutputMaker
    phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
    phase_plot_XT();
#endif

    cal_rest_coef(); // coefficient of restitution.

    v_COM_zero(true);

    temperature_normalizer( Parameters -> init_gran_temp() ); 

    cout <<"======================";
    cout <<"time loop() for ensemble number " << ensemble_index << "\n";

//-------------------------------------------------------
    for ( int i=0; i < Parameters -> nstep(); i++ ){

      step( lx, Parameters -> timestep(), Time );      

#ifdef ParticlesExist
      if ( Particle_slipped_out( i ) ) return 0;
#endif

      if ( print_data_failed   ( i , Parameters )) return 0;

    }
//-------------------------------------------------------    

    velocity_distribution( 20 );    

    final_prints( t1 , Parameters);
 
    ftemperature.close();
    fparameters_out.close();
    fvelocity.close();

#ifdef XYZOutputMaker
    xyzfile.close();
 #ifdef ParticlesExist
    xyzfile2.close();
 #endif
#endif

#ifdef XTOutputMaker
    xtfile.close();
#endif

  }

  cout            << "\n\n  Total ensemble execution time: " 
                  << ((float)clock()-(float)t0) / CLOCKS_PER_SEC << " seconds\n\n" ;

  return 0;

}
//====================================================

bool print_data_failed ( int i, system_parameters * Parameters ) {

#ifdef XYZOutputMaker
  if ((i+1)%Parameters -> nprint () ==0)
    phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
  if ((i+1)%Parameters -> nprint () ==0)
    phase_plot_XT();
#endif


  if ((i+1)%Parameters -> nenergy () ==0){

    double temp_temp0 = total_kinetic_energy()
                      / (Parameters -> number_of_grains() * Parameters -> init_gran_temp() ); 

    ftemperature << Time << "\t" 
                 << temp_temp0
                 << endl;

    if (temp_temp0 > 3.0){

      cerr << "\n\nerror: increasing temperature\n"
           << "change your system parameters\n"
           << "Simulation stopped at the time step: "<< i <<"\n";

      return true;

    }
  }

  return false;
}


//====================================================

#ifdef ParticlesExist
bool Particle_slipped_out(int i){

  for (unsigned j=0; j<Sheaths.size(); j++)
    if (Sheaths[j].P_slipped_out()){

      cerr << "Error: Particle " << j
           << " slipped out of its sheath at the step "
           << i << "\n";

      return true;
    }

  return false;
}
#endif


