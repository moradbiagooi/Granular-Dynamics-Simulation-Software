#include "common.h"
#include "Sheath.h"
#include <vector>
//#include "global_variables.h"
extern vector <Sheath> Sheaths;

//====================================================
//====================================================  phase_plot
//====================================================

#ifdef XYZOutputMaker
void phase_plot_XYZ()
{
  double XYZscale=.5;

  xyzfile  << Sheaths.size() << "\nAtom\n";

 #ifdef ParticlesExist
  xyzfile2 << 2*Sheaths.size()
           << "\nAtom\n";
 #endif

  for(unsigned int i=0;i<Sheaths.size();i++){


    xyzfile  << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t0.0\t0.0\n";


  #ifdef ParticlesExist
    xyzfile2 << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t0.0\t0.0\n";

    if (Sheaths[i].ptype()==0)
      xyzfile2 << 3                        << "\t"
               << XYZscale*Sheaths[i].P_x()<< "\t0.0\t0.0\n";
  #endif



  }

}
#endif

//====================================================
//====================================================  phase_plot_XT
//====================================================

#ifdef XTOutputMaker
void phase_plot_XT()
{

  xtfile  << Time << " ";

  for(unsigned int i=0;i<Sheaths.size();i++)
    xtfile  << Sheaths[i].x() << " ";

  xtfile  << "\n";

}
#endif
