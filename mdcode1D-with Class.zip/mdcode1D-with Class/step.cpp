#include "common.h"
//#include "global_variables.h"
#include "Sheath.h"
extern vector <Sheath> Sheaths;
//====================================================
//====================================================  integrate
//====================================================

void step( double lx, double timestep, double & Time )
{

  for( unsigned int i = 0; i < Sheaths.size(); i++ ){

      Sheaths[i].set_force_to_zero(); 

      Sheaths[i].predict( timestep );

  }


    make_forces(lx);

  
  for( unsigned int i = 0; i < Sheaths.size(); i++ ){

      Sheaths[i].correct( timestep );

  }


  for( unsigned int i = 0; i < Sheaths.size(); i++ ){


//    Sheaths[i].periodic_bc ( x_0, lx );
    Sheaths[i].periodic_bc ( 0, lx );

  }

  Time += timestep;

}



