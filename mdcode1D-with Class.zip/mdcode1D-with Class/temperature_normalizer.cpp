#include "common.h"
#include "Sheath.h"
#include <vector>
//#include "global_variables.h"

extern vector <Sheath> Sheaths;
//====================================================
//====================================================  temperature_normalizer
//====================================================

void temperature_normalizer(double temp_0){

  int number_of_grains = Sheaths.size();
  double temp_1 = total_kinetic_energy();
  double temp_r = number_of_grains*temp_0/temp_1;
  double vel_r  = sqrt(temp_r);

  for(unsigned int i=0;i<Sheaths.size();i++){

    if(Sheaths[i].ptype()==0){


      Sheaths[i].vx()   = vel_r * Sheaths[i].vx() ;

 #ifdef ParticlesExist
      Sheaths[i].P_vx() = vel_r * Sheaths[i].P_vx();
 #endif



    }

  }

  cout << "initial kinetic energy : "
       <<  total_kinetic_energy() << "\n";
  cout << "initial granular temperature : "
       <<  total_kinetic_energy()/number_of_grains  << "\n";

}


