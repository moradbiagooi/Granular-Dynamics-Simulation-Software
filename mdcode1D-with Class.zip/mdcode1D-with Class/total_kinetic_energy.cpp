#include "common.h"
#include <vector>
#include "Sheath.h"
extern vector <Sheath> Sheaths;
//====================================================
//====================================================  total_kinetic_eneregy
//====================================================

double total_kinetic_energy()
{

  double sum=0;

  for( unsigned int i=0; i < Sheaths.size(); i++ ){

    if( Sheaths[i].ptype() == 0 )
      sum+=Sheaths[i].kinetic_energy();

  }

  return sum;

}

