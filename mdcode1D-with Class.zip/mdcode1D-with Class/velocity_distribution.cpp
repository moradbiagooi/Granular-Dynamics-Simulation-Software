#include <fstream>

#include "common.h"
#include "Sheath.h"
#include "properties.h"


using namespace std;

extern vector <Sheath> Sheaths;

extern ofstream fvelocity;

inline double abs( double _x ) {
  return _x < 0 ? -_x : _x;
}

void velocity_distribution( unsigned int _box_number ){


  double _max_velocity=0;

  for ( unsigned int i=0; i<Sheaths.size(); i++ ){
    double _abs_vx = abs (Sheaths[i].vx());
    if ( _abs_vx > _max_velocity ) _max_velocity = _abs_vx;
  }

  double dvx = 2*_max_velocity / double(_box_number);

 int velocity_function[_box_number] ;

  for ( unsigned int i=0; i < _box_number; i++ )
    velocity_function[i]=0 ;

  for ( unsigned int i=0; i<Sheaths.size(); i++ ){

    int _vel = int( ( _max_velocity + Sheaths[i].vx() ) / dvx );

    velocity_function [_vel]++;

  }

  for ( unsigned int i=0; i < _box_number; i++ )

    fvelocity << -_max_velocity + (i) * dvx - dvx << " "
              << double(velocity_function [i]) / Sheaths.size()
              << "\n";
}

