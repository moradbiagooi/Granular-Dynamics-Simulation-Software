rm simple_box
clear
g++ -o simple_box *.cpp
./simple_box input_parameters.dat
