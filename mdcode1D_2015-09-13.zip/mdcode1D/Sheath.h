
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#ifndef _Sheath_h
#define _Sheath_h

#include <iostream>
#include <math.h>


#include "properties.h"


#include "Particle.h"


using namespace std;


inline double normalize(double dx, double L){
  while(dx<-L/2) dx+=L;
  while(dx>=L/2) dx-=L;
  return dx;
}



class Sheath {



  friend void force(Sheath & p1, Sheath & p2, double lx);

//  friend bool sheath_slipped_through (Sheath & p1, Sheath & p2, double lx);

public:


  Sheath(): rtd0(0), rtd1(0), rtd2(0), rtd3(0), rtd4(0)
  {}



#ifdef ParticlesExist
  double & P_x() {return P.x();}
  double P_x() const {return P.x();}
 
  double & P_vx() {return P.vx();}
  double P_vx() const {return P.vx();}


  double & P_r() {return P.r();}
  double P_r() const {return P.r();}

  double P_m() const {return P.m();}
  double & P_m() {return P.m();}

  double & P_Y() {return P.Y();}
  double P_Y () const {return P.Y();}

  double & P_A() {return P.A();}
  double P_A() const {return P.A();}

  double P_kinetic_energy() const { return P.kinetic_energy();}
#endif



  double & x() {return rtd0;}
  double x() const {return rtd0;}

  double & vx() {return rtd1;}
  double vx() const {return rtd1;}




  double & r() {return _r;}
  double r() const {return _r;}

  double & r_mid() {return _r_mid;}
  double r_mid() const {return _r_mid;}

  double m() const {return _m;}
  double & m() {return _m;}

  double & Y() {return _Y;}
  double Y () const {return _Y;}

  double & A() {return _A;}
  double A() const {return _A;}

  int ptype() const {return _ptype;}
  int & ptype() {return _ptype;}
//Returns the type of the Sheath. 
//Sheaths of type 0 are subject to Newton’s equationof motion,
//Sheaths of other types belong to walls.



  void add_force(const double & f){_force+=f;} 
//Adds a value to the total force _force of the Sheath



  void predict(double dt);
//First step of the Gear algorithm


  void correct(double dt);
//Second step of the Gear algorithm


  double kinetic_energy() const;
//Computes the kinetic energy of the Sheath plus its Particle if existed.


#ifdef ParticlesExist
  bool P_slipped_out();
#endif


  void set_force_to_zero(){

    _force=0;

#ifdef ParticlesExist
    P.set_force_to_zero();
#endif

  }



  void periodic_bc(double x_0, double lx);
//Enforces the periodic boundary conditions




#ifdef ParticlesExist


  void internal_force(double lx);

#endif


private:

  int _ptype;

  double _r, _m, _r_mid;
  double _Y, _A;


  double rtd0,rtd1,rtd2,rtd3,rtd4;
  double _force;





#ifdef ParticlesExist
  Particle P;
#endif  

};

#endif
