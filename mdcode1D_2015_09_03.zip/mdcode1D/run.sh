rm simple_box
clear
g++ -o simple_box common.cpp Sheath.cpp Particle.cpp simple.cpp
./simple_box input_parameters.dat
