
/* //========================================//
   //
   // Developed by Morad Biagooi (2015-201X)
   // 
   // 
   // m.biagooi AT gmail.com
   // m.biagooi AT iasbs.ac.ir
   //
*/ //========================================//

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <sys/stat.h> // used for mkdir()
#include <time.h>
#include <iomanip> 

#include "common.h"
#include "Sheath.h"   
#include "MersenneTwister.h"
#include "properties.h"


#define PI 3.14159265
#define GSmallNumber 1e-4


using namespace std;


int XV_index;
int nstep;
int nprint_Tt;
int nprint_XV;
int nprint_Xt;
int nenergy;
int number_of_grains;
int number_of_ensembles;

long random_seed;

const double Density = 1.0;
const double radius_out = 0.5;       // Sheath.r_out
const double min_init_sep =  0.0005; // minimum initial seperation

double nprint_XVT = 1.0;
double Time;
double timestep;
double packing_factor;
double init_gran_temp;
double lx;
double Alpha;                        // Particle.r / Sheath.r_out
double Beta;                         // (Sheath.r_out - Sheath.r_in) / (2 * Sheath.r_out) 

double dissipative_coef;
double elastic_coef;
double mass_S;
double mass_P;
double restitution_coef;
double G;                            // gravity 


vector< Sheath > Sheaths;


ofstream FileTt;         // gas temperature
ofstream FileDataOut;    // system parameters and simulation data
#ifdef XYZOutputMaker
ofstream FileXYZ;        // positions of Sheaths 
#endif
#ifdef XTOutputMaker
ofstream FileXt;         // position vs time
#endif
#ifdef XVOutputMaker
ofstream FileXV;         // position vs velocity (snapshots with the same time difference)
ofstream FileXVbi; 
#endif
#ifdef XVTOutputMaker
ofstream FileXVT;         // position vs velocity (snapshots with the same temperature)
#endif
/*
X
X_tot
X_P
V
V_P
time
dimensionlesstime
*/
void output_file_maker( int );
void temperature_normalizer();
void P_COM_zero(bool);   // (true) : momentum_COM = zero. (false): print momentum_COM;
#ifdef XVTOutputMaker
void phase_plot_XVT();
#endif
#ifdef XVOutputMaker
void phase_plot_XV();
#endif
#ifdef XtOutputMaker
void phase_plot_Xt();
#endif
#ifdef XYZOutputMaker
void phase_plot_XYZ();
#endif
void make_gas( MTRand * RandNumb );
void init_parameters ( char * fname_ip );
void cal_rest_coef();
void final_prints( clock_t );

double phase_plot_Tt();
double total_kinetic_energy_S();
#ifdef ParticlesExist
double total_kinetic_energy_P();
#endif

bool init_parameters_check();
#ifdef ParticlesExist
bool Particle_slipped_out( int );
#endif
bool Particle_slipped_out( int );
bool print_data_failed( int );

inline double abs ( double _x ) { return _x < 0 ? -_x : _x ; }

int mkdir( const char *path, mode_t mode );

//====================================================
//====================================================  main
//====================================================


int main ( int argc, char ** argv ) {


  if ( argc != 2 ) {
    cerr << "Needs 1 input file, for example: \n\t \
             $ /a.out init_parameters.dat\n";
    exit(0);
    return 0; 
  }

  int simulation_fails; // numbers of system sliping out or temperature rising;

  clock_t t0,t1;

  t0 = clock();

  FileTt.precision(10); 

#ifdef XVOutputMaker
  FileXV.precision(10); 
#endif
#ifdef XVTOutputMaker
  FileXVT.precision(10); 
#endif


  init_parameters( argv[1] );

  class MTRand *RandNumb = new MTRand ( random_seed );
//--------------------------------------------------------

  for ( unsigned int ensemble_index =1; ensemble_index <= number_of_ensembles; ensemble_index++ ){

    XV_index=0;

    t1 = clock();

    Sheaths.clear();

    Time=0;


    if ( !init_parameters_check() )
      return 0;
    else
      cout << "\ninit_parameters_check() : OK \n";
// takes system parameters from the inputted file in the command line


    make_gas( RandNumb ); 

    cal_rest_coef(); // calculate coefficient of restitution

    output_file_maker ( ensemble_index );

    temperature_normalizer(); 

#ifdef XYZOutputMaker
    phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
    phase_plot_XT();
#endif

#ifdef XVOutputMaker
    phase_plot_XV();
#endif


#ifdef XVTOutputMaker
    phase_plot_XVT();
#endif

    phase_plot_Tt();


    P_COM_zero(false);
    P_COM_zero(true);

//---------------------------------------------------------------------
    cout <<"======================";
    cout <<"time loop() for ensemble number " << ensemble_index << "\n";



    for ( int i = 0; i < nstep; i++ ){


      step();      


#ifdef ParticlesExist
      if ( Particle_slipped_out(i) ) {
          ensemble_index--;
          i = nstep;
          simulation_fails++;
      }
#endif


      if ( print_data_failed(i)    ) {
          ensemble_index--;
          i = nstep;
          simulation_fails++;
      }    


    }
    

    P_COM_zero(false);

    final_prints(t1);
 

    FileTt.close();
    FileDataOut.close();
#ifdef XYZOutputMaker
    FileXYZ.close();
#endif
#ifdef XVOutputMaker
    FileXV.close();
    FileXVbi.close();
#endif
#ifdef XVTOutputMaker
    FileXVT.close();
#endif
#ifdef XtOutputMaker
    FileXt.close();
#endif
  }


  cout << "\n number of simulation fails: " << simulation_fails << "\n";
  cout << "\n\n  Total ensemble execution time: " 
       << ((float)clock()-(float)t0) / CLOCKS_PER_SEC 
       << " seconds\n\n" ;


  return 0;

}

//====================================================
//==================================================== phase_plot_Tt
//====================================================

double phase_plot_Tt(){

  double _temperature_S = total_kinetic_energy_S()
                        / ( number_of_grains * init_gran_temp ); 


#ifdef ParticlesExist

  double _temperature_P = total_kinetic_energy_P()
                        / ( number_of_grains * init_gran_temp ); 

  double _temperature = ( _temperature_S + _temperature_P ) / 2.0;

  FileTt  << Time           << " " 
          << _temperature   << " " 
          << _temperature_S << " "
          << _temperature_P << "\n";


#else
  double _temperature = _temperature_S;

  FileTt  << Time           << " " 
          << _temperature_S << "\n";

#endif

return _temperature;
}

//====================================================
//==================================================== print_data_failed
//====================================================

bool print_data_failed ( int i ) {

#ifdef XYZOutputMaker
  if ( (i+1) % nprint_Xt == 0 )
    phase_plot_XYZ();
#endif

#ifdef XTOutputMaker
  if ( (i+1) % nprint_Xt == 0 )
    phase_plot_XT();
#endif

#ifdef XVOutputMaker
  if ( (i+1) % nprint_XV ==0 )
    phase_plot_XV();
#endif

  if ( (i+1) % nprint_Tt == 0 ){

    double _temperature = phase_plot_Tt();

#ifdef XVTOutputMaker
    if ( _temperature < nprint_XVT )
      phase_plot_XVT();
#endif

    if ( _temperature > 1.1 ){

      cerr << "\n\nerror: increasing temperature\n"
           << "change your system parameters\n"
           << "Simulation stopped at the time step: "<< i <<"\n";

      return true;

    }
  }


  return false;
}

//====================================================
//==================================================== Particle_slipped_out
//====================================================

#ifdef ParticlesExist
bool Particle_slipped_out(int i){

  for ( unsigned j = 0; j < Sheaths.size(); j++ )
    if ( Sheaths[j].P_slipped_out() ){

      cerr << "Error: Particle " << j
           << " slipped out of its sheath at the step "
           << i << "\n";

      return true;
    }

  return false;
}
#endif

//====================================================
//====================================================  init_parameters_check
//====================================================

bool init_parameters_check(){
#ifdef ParticlesExist
  if ( Alpha < 0.0 || Alpha > 1.0 ){
    cout << "Error: assign #Alpha between " << 0.0 << " and " << 1.0 << endl;
    return false;
  }
  if ( Beta < 0.0 || Beta > 0.5 ){
    cout << "Error: assign #Beta between " << 0.0 << " and " << 0.5  << endl;
    return false;
  }
  if ( Alpha + Beta > 1.5 ){
    cout << "Error: assign #Alpha and #Beta so that (Alpha + Beta) would be between " << 0.0 << " and " << 1.5 << endl;
    return false;
  }
#endif
  return true;
}

//====================================================
//====================================================  final_prints
//====================================================

void final_prints(clock_t t1){

  clock_t t2;
  t2 = clock();


  t2=clock();

  float diff ((float)t2-(float)t1);

  cout            << "\n\n  execution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n\n" ;
  FileDataOut << "\nexecution time: " 
                  << diff / CLOCKS_PER_SEC << " seconds\n" ;

}

//====================================================
//====================================================  cal_rest_coef
//====================================================


void cal_rest_coef(){ 


  #ifdef ParticlesExist
  double _m_eff = mass_S * mass_P / ( mass_S + mass_P ); 
  #else
  double _m_eff = mass_S / 2.0;
  #endif

  double _Y     = elastic_coef;
  double _gamma = dissipative_coef;
  double _restitution_coef;



  double _m       = _m_eff; 
  double _beta    = _gamma / (2.0 * _m);
  double _omega_0 = sqrt ( _Y / _m );


  if (_beta < (_omega_0 / sqrt(2.0))){
    cout << "RC case 1 \n";
    double _omega   = sqrt (+_omega_0*_omega_0 - _beta*_beta);
    _restitution_coef = exp(-(_beta/_omega) *  (PI - atan ( (2.0 * _beta * _omega) / (_omega*_omega - _beta*_beta) )  ) ) ;
  }
  else if (_beta <= _omega_0) {
    cout << "RC case 2 \n";
    double _omega   = sqrt (+_omega_0*_omega_0 - _beta*_beta);
    _restitution_coef = exp(-(_beta/_omega) *  (atan ( (2.0 * _beta * _omega) / (_omega*_omega - _beta*_beta) )  ) ) ;
  }
  else {
    cout << "RC case 3 \n";
    double _OMEGA  = sqrt (-_omega_0*_omega_0 + _beta*_beta);
    _restitution_coef = exp(-(_beta/_OMEGA) * log ((_beta + _OMEGA) / (_beta - _OMEGA) ) ); 
  }

  restitution_coef = _restitution_coef;

  cout        << "restitution_coef : " << _restitution_coef << "\n";
  FileDataOut << "restitution_coef : " << _restitution_coef << "\n";

}


//====================================================
//====================================================  make_gas
//====================================================

void make_gas( MTRand * RandNumb ){

  cout<<"======================make_gas()\n";

  double mean_free_space = (1.0/packing_factor) - 1.0;

  lx = ((2.0 * radius_out) + mean_free_space) * number_of_grains; 


  double grain_x [number_of_grains];

#ifdef RandomInitialPosition

// ----------------------- Calculating Sheaths' Random Positions
cout << "Making Sheaths Positions: If this part took more than a few seconds, "
     << "you may have to increase #mean_free_space... ";

  int grains_counter = 0;

  while (grains_counter < number_of_grains) {

    double temp_x = lx * RandNumb -> randDblExc();


    bool flag_freeSpace = true;

    int i = 0;

    while (flag_freeSpace && i < grains_counter){

      if ( abs( temp_x - grain_x[i] ) < 2.0 * radius_out + min_init_sep)
        flag_freeSpace = false;

        i++;

    }

    if (flag_freeSpace){

      grain_x[grains_counter] = temp_x;


      grains_counter++;

    }

  }
// -----------------------



// ----------------------- sorting grain_x[]
// used for Linear neighbors


  bool flag_disorder = true;

  while (flag_disorder){

    flag_disorder = false;

    for (int i=0;i<number_of_grains;i++){

      for (int j=0;j<number_of_grains;j++){

        if (grain_x[i] > grain_x[j] && i < j){

          flag_disorder = true;
          double temp_x = grain_x[i];
          grain_x[i]    = grain_x[j];
          grain_x[j]    = temp_x;

        }

      }

    }

  }
#else

  double _inbetween_distance = lx / double( number_of_grains );

  for ( int i = 0; i < number_of_grains; i++ ){
    grain_x [i]= mean_free_space/2.0 + double(i) * _inbetween_distance;
  }

#endif
// -----------------------
  cout << "OK\n" << endl;
  cout << "lx = " << lx << endl;

#ifdef ParticlesExist
cout << "\nMaking Particles Positions: If this part took more than a few seconds, "
     << "you may have to decrease (#Alpha + #Beta)... ";
#endif
// ----------------------- making grains 


#ifdef ParticlesExist

  double _r_mid = radius_out * ( 1.0 - 2.0 * Beta );
  double _r_P   = radius_out * Alpha;

  mass_S = Density * 2.0 * ( radius_out - _r_mid );
  mass_P = Density * 2.0 * _r_P;

#else

  mass_S = 1.0;

#endif


  for ( int i = 0; i < number_of_grains; i++ ){

    Sheath pp;

// ----------------------- radius, mass, rotational inertia

    pp.r()     = radius_out;
    pp.m()     = mass_S;

#ifdef ParticlesExist

    pp.r_mid() = _r_mid;
    pp.P_r()   = _r_P;
    pp.P_m()   = mass_P;

#endif


// -----------------------



// ----------------------- positions
    pp.x()     = grain_x[i];

    pp.bc_zero();

#ifdef ParticlesExist

 #ifdef RandomInitialPosition

find_new_rnd1:
  double temp_x =  ( 0.5 - RandNumb -> randDblExc() ) * 2  * ( pp.r_mid() - pp.P_r() ); 

    if( abs( temp_x ) + pp.P_r() > pp.r_mid() - min_init_sep)
      goto find_new_rnd1;
    

    pp.P_x()  = pp.x() + temp_x; 
/*
find_new_rnd1:
    double temp_x = pp.x() 
                  + ( 0.5 - RandNumb -> randDblExc() ) * 2
                  * (pp.r_mid() - pp.P_r() - 0.01) ; 


    if( pp.r_mid() - ( abs( temp_x - pp.x() ) + pp.P_r() ) < 0) 
      goto find_new_rnd1;

    

    pp.P_x()  = temp_x; 
*/
 #else
    pp.P_x()  = pp.x(); 
 #endif

#endif
// -----------------------



// ----------------------- random velocity
    pp.vx()   = (0.5 - RandNumb -> randDblExc()) * 2;

#ifdef ParticlesExist
 #ifdef RandomInitialVelocity
    pp.P_vx() = (0.5 - RandNumb -> randDblExc()) * 2;
 #else
    pp.P_vx() = pp.vx();
 #endif
#endif


// -----------------------



// ----------------------- material properties

#ifdef ParticlesExist

    pp.A()     = 0.0;
    pp.Y()     = elastic_coef;

    pp.P_A()  = dissipative_coef;
    pp.P_Y()  = elastic_coef;

#else

    pp.A()     = dissipative_coef;
    pp.Y()     = elastic_coef;

#endif
// -----------------------

    
    pp.ptype() = 0;
   
    Sheaths.push_back(pp);

  }
  cout << "OK\n" << endl;
  cout << number_of_grains << " grains are made\n" << flush;
  cout << "======================\n";

}

//====================================================
//====================================================  P_COM_zero
//====================================================

void P_COM_zero(bool make_zero_momentum){

  if (make_zero_momentum) 
  cout << "corrected " ;  
  else
  cout << "not-corrected " ;


restart_make_zero:

  double P_COM_x = 0;


  for ( unsigned int i = 0; i < Sheaths.size(); i++ ){

      P_COM_x += mass_S * Sheaths[i].vx();

#ifdef ParticlesExist
      P_COM_x += mass_P * Sheaths[i].P_vx();
#endif

  }


#ifdef ParticlesExist
  double vx_correct = P_COM_x / ( number_of_grains * ( mass_S + mass_P ) );
#else
  double vx_correct = P_COM_x / ( number_of_grains * mass_S );
#endif



  if (make_zero_momentum) {  

    for( unsigned int i = 0; i < Sheaths.size(); i++ ){


        Sheaths[i].vx()   -= vx_correct;

#ifdef ParticlesExist
        Sheaths[i].P_vx() -= vx_correct;
#endif


    }

    make_zero_momentum = false;
    goto restart_make_zero;

  }


  cout << "center of mass momentum_x: " << P_COM_x << "\n";
  cout << "======================\n";

}

//====================================================
//====================================================  temperature_normalizer
//====================================================

void temperature_normalizer(){


  double _temperature_S = total_kinetic_energy_S() / ( number_of_grains ); 

#ifdef ParticlesExist

  double _temperature_P = total_kinetic_energy_P() / ( number_of_grains ); 

  double _temperature   = ( _temperature_S + _temperature_P ) / 2.0;

#else

  double _temperature   = _temperature_S;

#endif




  double _vel_r  = sqrt( init_gran_temp / _temperature );

  for( unsigned int i = 0; i < Sheaths.size(); i++ ){


      Sheaths[i].vx()   = _vel_r * Sheaths[i].vx() ;

 #ifdef ParticlesExist
      Sheaths[i].P_vx() = _vel_r * Sheaths[i].P_vx();
 #endif


  }

 _temperature_S = total_kinetic_energy_S()
                  / ( number_of_grains ); 

#ifdef ParticlesExist

  _temperature_P = total_kinetic_energy_P()
                   / ( number_of_grains ); 

  _temperature = ( _temperature_S + _temperature_P ) / 2.0;

#else

  _temperature = _temperature_S;

#endif

  cout << "initial granular temperature : "
       <<  _temperature  << "\n";


}

//====================================================
//====================================================  output_file_maker
//====================================================

void output_file_maker(int ensemble_index){

  string str_folder_output;

  char buffer[50]="";

  str_folder_output.append("outputs"); 

  sprintf(buffer,"_seed%lu/",random_seed);
  str_folder_output.append(buffer);



  const char* char_folder_output=str_folder_output.c_str();
  mkdir(char_folder_output,0777);

  time_t rawtime;

  struct tm * timeinfo;
  char char_buffer [40];
  time (&rawtime);
  timeinfo = localtime (&rawtime);
  

  strftime (char_buffer,80,"  %F  %T",timeinfo);

  string str_fname;


#ifdef ParticlesExist //ON or OFF//
  str_fname.append("_PE");
#endif



  sprintf(buffer,"_nP:%lu",Sheaths.size());
  str_fname.append(buffer);


  sprintf(buffer,"_FT:%g",nstep*timestep);
  str_fname.append(buffer);


  sprintf(buffer,"_RC:%g",restitution_coef);
  str_fname.append(buffer);


#ifdef ParticlesExist
  sprintf(buffer,"_Al:%g",Alpha);
  str_fname.append(buffer);
  sprintf(buffer,"_Be:%g",Beta);
  str_fname.append(buffer);
#endif

  sprintf(buffer,"_EI:%u",ensemble_index);
  str_fname.append(buffer);


  string str_fname_T=str_folder_output;
  str_fname_T.append("/T");
  str_fname_T.append(str_fname);
  str_fname_T.append(".dat");
  const char * char_FileTt=str_fname_T.c_str();
  FileTt.open(char_FileTt);

  string str_fname_P=str_folder_output;
  str_fname_P.append("/P");
  str_fname_P.append(str_fname);
  str_fname_P.append(".dat");
  const char * char_FileDataOut=str_fname_P.c_str();
  FileDataOut.open(char_FileDataOut);

#ifdef XYZOutputMaker
  string str_FileXYZ=str_folder_output;
  str_FileXYZ.append("/XYZ");
  str_FileXYZ.append(str_fname);
  str_FileXYZ.append(".xyz");
  const char * char_FileXYZ=str_FileXYZ.c_str();
  FileXYZ.open(char_FileXYZ);
#endif

#ifdef XTOutputMaker
  string str_FileXt=str_folder_output;
  str_FileXt.append("/xt");
  str_FileXt.append(str_fname);
  str_FileXt.append(".dat");
  const char * char_FileXt=str_FileXt.c_str();
  FileXt.open(char_FileXt);
#endif

#ifdef XVOutputMaker
  string str_FileXV=str_folder_output;
  str_FileXV.append("/xv");
  str_FileXV.append(str_fname);
  str_FileXV.append(".dat");
  const char * char_FileXV=str_FileXV.c_str();
  FileXV.open(char_FileXV);

  string str_FileXVbi=str_folder_output;
  str_FileXVbi.append("/xv");
  str_FileXVbi.append(str_fname);
  str_FileXVbi.append(".bin");
  const char * char_FileXVbi=str_FileXVbi.c_str();
  FileXVbi.open(char_FileXVbi, ios::binary | ios::out);
#endif

#ifdef XVTOutputMaker
  string str_FileXVT=str_folder_output;
  str_FileXVT.append("/xvT");
  str_FileXVT.append(str_fname);
  str_FileXVT.append(".dat");
  const char * char_FileXVT=str_FileXVT.c_str();
  FileXVT.open(char_FileXVT);
#endif



  cout        << "======================Date and time" << "\n";
  cout        << char_buffer                           << "\n";
  cout        << "======================"              << "\n";
  FileDataOut << "==================Date and time"     << "\n\n";
  FileDataOut << char_buffer                           << "\n\n";
  FileDataOut << "==================system properties" << "\n\n";


   
  FileDataOut << "Linear DashpotForce"    << "\n\n";

#ifdef ParticlesExist 
  FileDataOut << "Sheath - Particle grains"     << "\n";
#else
  FileDataOut << "Ordinary grains"     << "\n";
#endif


  FileDataOut << "\n==================\n\n";

  FileDataOut << "random_seed: "  << random_seed << "\n";

  FileDataOut << "radius_out: "   << Sheaths[1].r() << "\n";

#ifdef ParticlesExist 
  FileDataOut << "radius_S_in: "  << Sheaths[1].r_mid() << "\n";
#endif

  FileDataOut << "Density: "           << Density  << "\n";
  FileDataOut << "mass_S: "            << Sheaths[1].m()   << "\n";
  FileDataOut << "dissipative_coef: "  << dissipative_coef      << "\n";
  FileDataOut << "elastic_coef: "      << elastic_coef      << "\n";

#ifdef ParticlesExist 
  FileDataOut << "Alpha: "     << Alpha             << "\n";
  FileDataOut << "Beta: "      << Beta              << "\n";

  FileDataOut << "radius_P: "  << Sheaths[1].P_r()  << "\n";
  FileDataOut << "mass_P: "    << Sheaths[1].P_m()  << "\n";
#endif

  FileDataOut << "\n==================\n\n";
  FileDataOut << "lx: "         << lx   << "\n";


  FileDataOut << "packing_factor: "      
                  <<  packing_factor    << "\n";
  FileDataOut << "init_gran_temp: "      
                  <<  init_gran_temp    << "\n";

  FileDataOut << "\n==================\n\n";
  FileDataOut << "timestep: "   << timestep   << "\n";
  FileDataOut << "nsteps: "     << nstep      << "\n";
  FileDataOut << "final_time: "  
                  << nstep*timestep               << "\n";

  FileDataOut << "\n==================\n\n";
  FileDataOut << "Number of grains: " 
                  << Sheaths.size()               << "\n";


}

//====================================================
//====================================================  integrate
//====================================================

void integrate()
{

  for( unsigned int i = 0; i < Sheaths.size(); i++ ){

      Sheaths[i].set_force_to_zero(); 

      Sheaths[i].predict( timestep );

  }


    make_forces();

  
  for( unsigned int i = 0; i < Sheaths.size(); i++ ){

      Sheaths[i].correct( timestep );

  }


  for( unsigned int i = 0; i < Sheaths.size(); i++ ){


    Sheaths[i].periodic_bc ( 0.0, lx );

  }

  Time += timestep;

}

//====================================================
//====================================================  init_parameters
//====================================================

void init_parameters( char * fname_ip )
{

  cout<<"======================init_parameters()\n";

  ifstream FileDataIn( fname_ip );

  while( FileDataIn.peek() == '#' ){

    string type;

    FileDataIn >> type;

    if(type=="#random_seed:"){

      FileDataIn >> random_seed;
      FileDataIn.ignore(100,'\n');
      cout        << "random_seed: " << random_seed << endl;
      FileDataOut << "random_seed: " << random_seed << endl;

    } else if(type=="#number_of_ensembles:"){

      FileDataIn >> number_of_ensembles;
      FileDataIn.ignore(100,'\n');
      cout        << "number_of_ensembles: " << number_of_ensembles << endl;
      FileDataOut << "number_of_ensembles: " << number_of_ensembles << endl;

    } else if(type=="#number_of_grains:"){

      FileDataIn >> number_of_grains;
      FileDataIn.ignore(100,'\n');
      cout        << "number_of_grains: " << number_of_grains << endl;
      FileDataOut << "number_of_grains: " << number_of_grains << endl;

    } else if(type=="#packing_factor:"){

      FileDataIn >> packing_factor;
      FileDataIn.ignore(100,'\n');
      cout        << "packing_factor: " << packing_factor << endl;
      FileDataOut << "packing_factor: " << packing_factor << endl;

    } else if(type=="#init_gran_temp:"){

      FileDataIn >> init_gran_temp;
      FileDataIn.ignore(100,'\n');
      cout        << "init_gran_temp: " << init_gran_temp << endl;
      FileDataOut << "init_gran_temp: " << init_gran_temp << endl;

    } else if(type=="#gravity:"){

      FileDataIn >> G;
      FileDataIn.ignore(100,'\n');
      cout        << "gravity: " << G << endl;
      FileDataOut << "gravity: " << G << endl;

    } else if(type=="#Time:"){

      FileDataIn >> Time;
      FileDataIn.ignore(100,'\n');
      cout        << "Time: " << Time << endl;
      FileDataOut << "Time: " << Time << endl;

    } else if(type=="#timestep:"){

      FileDataIn >> timestep;
      FileDataIn.ignore(100,'\n');
      cout        << "timestep: " << timestep << endl;
      FileDataOut << "timestep: " << timestep << endl;

    } else if(type=="#nstep:"){

      FileDataIn >> nstep;
      FileDataIn.ignore(100,'\n');
      cout        << "nstep: " << nstep << endl;
      FileDataOut << "nstep: " << nstep << endl;

    } else if(type=="#nprint_Tt:"){

      FileDataIn >> nprint_Tt;
      FileDataIn.ignore(100,'\n');
      cout << "nprint_Tt: " << nprint_Tt << endl;

    } else if(type=="#nprint_XV:"){

      FileDataIn >> nprint_XV;
      FileDataIn.ignore(100,'\n');
      cout << "nprint_XV: " << nprint_XV << endl;

    } else if(type=="#nprint_Xt:"){

      FileDataIn >> nprint_Xt;
      FileDataIn.ignore(100,'\n');
      cout << "nprint_Xt: " << nprint_Xt << endl;

    }/*else if(type=="#Density:"){

      FileDataIn >> Density;
      FileDataIn.ignore(100,'\n');
      cout << "Density: " << Density << endl;

    } else if(type=="#radius_out:"){

      FileDataIn >> radius_out;
      FileDataIn.ignore(100,'\n');
      cout << "radius_out: " << radius_out << endl;

    }*/else if(type=="#dissipative_coef:"){

      FileDataIn >> dissipative_coef;
      FileDataIn.ignore(100,'\n');
      cout << "dissipative_coef: " << dissipative_coef << endl;

    } else if(type=="#elastic_coef:"){

      FileDataIn >> elastic_coef;
      FileDataIn.ignore(100,'\n');
      cout << "elastic_coef: " << elastic_coef << endl;

    } else if(type=="#Alpha:"){

      FileDataIn >> Alpha;
      FileDataIn.ignore(100,'\n');
      cout << "Alpha: " << Alpha << endl;
 
    } else if(type=="#Beta:"){

      FileDataIn >> Beta;
      FileDataIn.ignore(100,'\n');
      cout << "Beta: " << Beta << endl;

    } else {

      cerr << "init_parameters(): unknown global property: " << type << endl;

    }

  }

}


//====================================================
//====================================================  total_kinetic_eneregy
//====================================================

double total_kinetic_energy_S()
{

  double sum=0;

  for( unsigned int i = 0; i < Sheaths.size(); i++ ){

    sum += Sheaths[i].kinetic_energy();

  }

  return sum;

}

#ifdef ParticlesExist
double total_kinetic_energy_P()
{

  double sum=0;

  for( unsigned int i = 0 ; i < Sheaths.size(); i++ ){

      sum += Sheaths[i].P_kinetic_energy();

  }

  return sum;

}
#endif

//====================================================
//====================================================  phase_plot_XYZ
//====================================================

#ifdef XYZOutputMaker
void phase_plot_XYZ()
{

  double XYZscale=.5;

 #ifdef ParticlesExist
  FileXYZ  << 2*Sheaths.size()
           << "\nAtom\n";
 #else
  FileXYZ  << Sheaths.size() << "\nAtom\n";
 #endif

  for( unsigned int i = 0; i < Sheaths.size(); i++ ){


    FileXYZ  << Sheaths[i].ptype()+1    << "\t"
             << XYZscale*Sheaths[i].x() << "\t0\t0\n";


  #ifdef ParticlesExist
    if (Sheaths[i].ptype()==0)
      FileXYZ  << 3                        << "\t"
               << XYZscale*Sheaths[i].P_x()<< "\t0\t0\n";
  #endif



  }

}
#endif

//====================================================
//====================================================  phase_plot_XT
//====================================================

#ifdef XTOutputMaker
void phase_plot_XT()
{

  FileXt  << Time << " ";

  for( unsigned int i = 0; i < Sheaths.size(); i++ )
    FileXt  << Sheaths[i].x() << " ";

  FileXt  << "\n";

}
#endif

//====================================================
//====================================================  phase_plot_XV
//====================================================


#ifdef XVOutputMaker
void phase_plot_XV()
{

FileXVbi.write( reinterpret_cast<char*>( &Time ), sizeof( double ) );

  for( unsigned int i = 0; i < Sheaths.size(); i++ ){

#ifdef ParticlesExist
    FileXV << XV_index         << " " 
           << Sheaths[i].x()   << " " << Sheaths[i].vx()   << " "
           << Sheaths[i].P_x() << " " << Sheaths[i].P_vx() << " "
           << ( mass_S * Sheaths[i].x()  + mass_P * Sheaths[i].P_x()  ) / ( mass_S + mass_P ) << " "
           << ( mass_S * Sheaths[i].vx() + mass_P * Sheaths[i].P_vx() ) / ( mass_S + mass_P ) << "\n";
#else
    FileXV << XV_index << " " << Sheaths[i].x() << " " << Sheaths[i].vx() << "\n";
#endif

#ifdef ParticlesExist

    double _x_com  =  ( mass_S * Sheaths[i].x()  + mass_P * Sheaths[i].P_x()  ) / ( mass_S + mass_P ); 
    double _vx_com =  ( mass_S * Sheaths[i].vx() + mass_P * Sheaths[i].P_vx() ) / ( mass_S + mass_P ); 

    FileXVbi.write( reinterpret_cast<char*>( &Sheaths[i].x()    ) , sizeof( double ) );
    FileXVbi.write( reinterpret_cast<char*>( &Sheaths[i].vx()   ) , sizeof( double ) );
    FileXVbi.write( reinterpret_cast<char*>( &Sheaths[i].P_x()  ) , sizeof( double ) );
    FileXVbi.write( reinterpret_cast<char*>( &Sheaths[i].P_vx() ) , sizeof( double ) );
    FileXVbi.write( reinterpret_cast<char*>( &_x_com            ) , sizeof( double ) );
    FileXVbi.write( reinterpret_cast<char*>( &_vx_com           ) , sizeof( double ) );
 
/*
    FileXVbi << XV_index         << " " 
           << Sheaths[i].x()   << " " << Sheaths[i].vx()   << " "
           << Sheaths[i].P_x() << " " << Sheaths[i].P_vx() << " "
           << ( mass_S * Sheaths[i].x()  + mass_P * Sheaths[i].P_x()  ) / ( mass_S + mass_P ) << " "
           << ( mass_S * Sheaths[i].vx() + mass_P * Sheaths[i].P_vx() ) / ( mass_S + mass_P ) << "\n";
           */
#else
    FileXVbi.write( reinterpret_cast<char*>( &Sheaths[i].x()    ) , sizeof( double ) );
    FileXVbi.write( reinterpret_cast<char*>( &Sheaths[i].vx()   ) , sizeof( double ) );
//    FileXVbi << XV_index << " " << Sheaths[i].x() << " " << Sheaths[i].vx() << "\n";
#endif

  }

  XV_index++;
}
#endif
//====================================================
//====================================================  phase_plot_XVT
//====================================================


#ifdef XVTOutputMaker
void phase_plot_XVT()
{

  for( unsigned int i = 0; i < Sheaths.size(); i++ ){

#ifdef ParticlesExist
    FileXVT << nprint_XVT       << " " 
            << Sheaths[i].x()   << " " << Sheaths[i].vx()   << " "
            << Sheaths[i].P_x() << " " << Sheaths[i].P_vx() << " "
            << ( mass_S * Sheaths[i].x()  + mass_P * Sheaths[i].P_x()  ) / ( mass_S + mass_P ) << " "
            << ( mass_S * Sheaths[i].vx() + mass_P * Sheaths[i].P_vx() ) / ( mass_S + mass_P ) << "\n";
#else
    FileXVT << nprint_XVT << " " << Sheaths[i].x() << " " << Sheaths[i].vx() << "\n";
#endif

  }

  nprint_XVT /= 10.0;
}
#endif

