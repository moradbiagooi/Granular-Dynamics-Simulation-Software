#clear
#reset
g++ -std=gnu++11 -o box_maker.out box_maker.cc Random_Gasdev.cpp Random_Ran2.cpp
./box_maker.out
#vmd CheckVMD.xyz
