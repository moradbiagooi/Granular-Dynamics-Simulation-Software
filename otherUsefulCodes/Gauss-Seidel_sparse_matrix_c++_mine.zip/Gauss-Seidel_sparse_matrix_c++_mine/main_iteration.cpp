#include <iostream>
#include <fstream>
#include <vector>
#include <complex>
#include <cmath>
//#include <iomanip>

#define FILENAME_IN_I  "I.txt"
#define FILENAME_IN_J  "J.txt"
#define FILENAME_IN_SR "SR.txt"
#define FILENAME_IN_SI "SI.txt"
#define FILENAME_IN_bR  "bR.txt"
#define FILENAME_IN_bI  "bI.txt"

#define FILENAME_OUT_x "x.txt"


#define NO_ITERATIONS 20


using namespace std;

void data_print ( vector < int > &b );

void data_print ( vector < double > &b );

void data_print ( vector < vector < int > > S_col );

void data_print ( vector < complex<double> > &b );

void data_print ( vector < int > &I,
                  vector < int > &J,
                  vector < complex<double> > &S );
 


void data_input ( vector < int > &I,
                  vector < int > &J, 
                  vector < double > &SR,
                  vector < double > &SI, 
                  vector < double > &bR,
                  vector < double > &bI);


void iteration ( vector < int > &I,
                 vector < int > &J,
                 vector < complex<double> > &S, 
                 vector < complex<double> > &x, 
                 vector < complex<double> > &b );


void data_output ( vector < complex<double> > &x );


/*  note that
 *  S is sparse
 *  b is complete
 *
 */


//===========================================
//=========================================== main()
//===========================================



int main(){
  
    cout << "loalaolaoa" << endl;

 
    vector < int > I;
    vector < int > J;
  
    vector < double > SR;
    vector < double > SI;
    vector < double > bR;
    vector < double > bI;

 
    vector < complex<double> > S;
    vector < complex<double> > x;
    vector < complex<double> > b;



    data_input ( I, J, SR, SI, bR, bI );

    cout <<"\nI:\n";
    data_print ( I );
    cout <<"\nJ:\n";
    data_print ( J );
    cout <<"\nSR:\n";
    data_print ( SR );
    cout <<"\nSI:\n";
    data_print ( SI );
    cout <<"\nbR:\n";
    data_print ( bR );
    cout <<"\nbI:\n";
    data_print ( bI );






    for ( unsigned int i = 0; i < I.size(); i++ ) {


        complex<double> dcompx;

        dcompx.real ( SR[i]);

        dcompx.imag ( SI[i]);

        S.push_back ( dcompx );

    }

    for ( unsigned int i = 0; i < bI.size(); i++ ) {


        complex<double> dcompx;

        dcompx.real ( bR[i]);

        dcompx.imag ( bI[i]);

        b.push_back ( dcompx );

    }

    cout << "\nS:\n";

    data_print ( I, J, S );


    iteration    ( I, J, S, x, b );


    data_output ( x ); 
//============================================  
  
  
 
 
    return 0;
  
}

///*

//===========================================
//=========================================== iteration()
//===========================================

void iteration ( vector < int > &I,
                 vector < int > &J,
                 vector < complex<double> > &S, 
                 vector < complex<double> > &x0, 
                 vector < complex<double> > &b ){


    vector < vector < int > > S_col;
    vector < vector < int > > S_num;


    vector < complex<double> > a_inv;
    vector < complex<double> > x1;


    const unsigned int n_b = b.size();
    const unsigned int n_S = S.size();


    for ( unsigned int i = 0; i < n_b; i++ ) {

        complex<double> dcompx1;

        dcompx1.real( 0.0 );
        dcompx1.imag( 0.0  );

        complex<double> dcompx2;

        dcompx2.real( 1.0 );
        dcompx2.imag( 0.0  );



        x0.push_back( dcompx1 );
        x1.push_back( dcompx2 );
        
    }
cout << "\nx0_init:\n";
    data_print ( x0 );
cout << "\nx1_init:\n";
    data_print ( x1 );




    S_col.resize( n_b );
    S_num.resize( n_b );

    for ( unsigned int i = 0; i < n_S; i++ ) {

        S_num [ I [i] ].push_back(    i  );
        S_col [ I [i] ].push_back(    J [i]  );

    }


cout << "\nS_col:\n";
    data_print ( S_col );
cout << "\nS_num:\n";
    data_print ( S_num );



    for ( unsigned int i = 0; i < n_S; i++ ) {


        unsigned int icheck = I[i];



        if ( I[i] == J[i] ) {

            complex<double> dcompx;

            dcompx.real( 1.0 );
            dcompx.imag( 0.0 );

            dcompx /= S[i];

            a_inv.push_back ( dcompx );

        }
        

    }

cout << "\na_inv:\n";
    data_print ( a_inv );



    for ( unsigned int itr = 0; itr < NO_ITERATIONS; itr++ ) {

//       cout << "-------------\n";

        for ( unsigned int i = 0; i < n_b; i++ ) {
//        cout << "\n" << "itr: " <<  itr+1 << ", i: "<< i+1 <<"\n";

            complex<double> sum;
            sum.real(0.0);
            sum.imag(0.0);


            for ( unsigned int jj = 0; jj < S_col[ i ].size(); jj++ ) {
                
//cout << "S_col[ i ].size(): " << S_col[ i ].size( ) << "\n";
                unsigned int j     = S_col [ i ][ jj ];
                unsigned int j_num = S_num [ i ][ jj ];


                if ( j < i ) {
//cout << "1  i: "<< i << ",j: " << j << ",j_num:" << j_num << "\n";
                    sum += S[ j_num ] * x1 [ j ];
  //                  cout << "sum+= " << S[ j_num ] << " * " << x1 [ j ] << " \n ";


                } else if ( j > i ) {
//cout << "2  i: "<< i << ",j: " << j << ",j_num:" << j_num << "\n";
                    sum += S[ j_num ] * x0 [ j ];
//                    cout << "sum+= " << S[ j_num ] << " * " << x0 [ j ] << " \n ";
                }


            }

  //          cout <<"\n";
//cout << "-sum1 "<< -sum << "+B(i) " <<  b[i] << "1/A(i,i)"  << a_inv[i] << "\n";
            x1[i] = a_inv[i] * ( b[i] - sum );
//cout << "x1(i) " << x1[i] << "  x0(i) " << x0[i] << "\n";
            x0[i]= x1[i];


        }
    
    }

// --- check
//

    vector < complex<double> > b2;

    b2.resize ( n_b );

    for ( unsigned int i = 0; i < n_b; i++ ) {
        b2 [i] = (0.0,0.0);
    }

    for ( unsigned int i = 0; i < n_b; i++ ) {
      

        complex<double> sum (0,0);


        for ( unsigned int jj = 0; jj < S_col[ i ].size(); jj++ ) {
                

            unsigned int j     = S_col [ i ][ jj ];
            unsigned int j_num = S_num [ i ][ jj ];



            sum += S[ j_num ] * x0 [j];


        }


        b2[i] = sum;

//        cout << b2[i] << "\t" << b[i] << "\n";

   }
       
cout << "\nb:\n";
    data_print ( b );
cout << "\nb2:\n";
    data_print ( b2 );
cout << "\nx0:\n";
    data_print ( x0 );

}




//===========================================
//=========================================== data_input()
//===========================================

void data_input ( vector < int > &I,
                  vector < int > &J, 
                  vector < double > &SR,
                  vector < double > &SI, 
                  vector < double > &bR, 
                  vector < double > &bI ){


    ifstream fileIn_I,  fileIn_J;
    ifstream fileIn_SI, fileIn_SR;
    ifstream fileIn_bR, fileIn_bI;


    fileIn_I.open  ( FILENAME_IN_I  );
    fileIn_J.open  ( FILENAME_IN_J  );
    fileIn_SR.open ( FILENAME_IN_SR );
    fileIn_SI.open ( FILENAME_IN_SI );
    fileIn_bR.open ( FILENAME_IN_bR );
    fileIn_bI.open ( FILENAME_IN_bI );

    while ( !fileIn_I.eof() ){
    
    
        double dtemp;

        int    itemp;
    

        fileIn_I >> itemp;
        I.push_back ( itemp );
    
        fileIn_J >> itemp;
        J.push_back ( itemp );

        fileIn_SR >> dtemp;
        SR.push_back ( dtemp );

        fileIn_SI >> dtemp;
        SI.push_back ( dtemp );
    
    }



    while ( !fileIn_bR.eof() ){
        cout << "l";
    
        double dtemp;

        fileIn_bR >> dtemp;
        bR.push_back ( dtemp );

        fileIn_bI >> dtemp;
        bI.push_back ( dtemp );
    
    }

    I.pop_back();
    J.pop_back();
    SR.pop_back();
    SI.pop_back();
    bR.pop_back();    
    bI.pop_back();

    fileIn_I.close();
    fileIn_J.close();
    fileIn_SR.close();
    fileIn_SI.close();
    fileIn_bR.close();
    fileIn_bI.close();
} 




//===========================================
//=========================================== data_output()
//===========================================

void data_output ( vector < complex<double> > &x ) {


    ofstream fileOut_x;


    fileOut_x.open ( FILENAME_OUT_x  );


    for ( unsigned int i = 0; i < x.size(); i++ ) {

        fileOut_x << x[i] << "\n";

    }


    fileOut_x.close();

} 

//===========================================
//=========================================== data_print()
//===========================================

void data_print ( vector < vector < int > > col ) {
    int tot_size = 0;
    for ( unsigned int i = 0; i < col.size(); i++ ) {
        for ( unsigned int j = 0; j < col[i].size(); j++ ) {
            cout << col[i][j] << "  ";
            tot_size++;
        }
        cout << "\n";
    }

    cout << "size : " << tot_size << "\n";

}

void data_print ( vector < int > &b ){

    for ( unsigned int i = 0; i < b.size(); i++ ) {

        cout << b[i] << "\n";

    }

    cout << "size : " << b.size() << "\n";

}
void data_print ( vector < double > &b ){

    for ( unsigned int i = 0; i < b.size(); i++ ) {

        cout << b[i] << "\n";

    }
    cout << "size : " << b.size() << "\n";
}

void data_print ( vector < complex<double> > &b ){

    for ( unsigned int i = 0; i < b.size(); i++ ) {

        cout << b[i] << "\n";

    }
    cout << "size : " << b.size() << "\n";
}


void data_print ( vector < int > &I,
                  vector < int > &J,
                  vector < complex<double> > &S ){


    const int n_max = 4;

    int n_c = -1;

    for ( unsigned int i = 0; i < n_max; i++ ) {

        for ( unsigned int j = 0; j < n_max; j++ ) {

            bool fprinted = false;

            for ( unsigned int k = 0; k < S.size(); k++ ) {

                if ( I[k] == i && J[k] == j ) {

                    cout << S[k] << " " << k;
                    k = S.size() + 1;
                    fprinted = true;

                }  
       
            }

            if ( !fprinted ) {
                cout << "(0.0,0.0)";               
            }

            cout << " " ;

        }

        cout << "\n";
    }
    cout << "size : " << S.size() << "\n";
}
 
