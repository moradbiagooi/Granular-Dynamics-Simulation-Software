// page 49
#include <fstream>
#include <stdlib.h>

using namespace std;
void dump_particle(ostream & os,
                   double x, double y, double vx, double vy,
                   double radius, double mass, int type)
{ 
/*  
  os << x << "\t" << y << "\t0\t" << vx << "\t" << vy << "\t0\t"
     << radius << "\t" << mass << "\t"<< type 
     << "\t0\t0\t0\t0"
     << "\t0\t0\t0"
     << "\t0\t0\t0" << "\t0\t0\t0" << "\t0\t0\t0\n";
*/
double Young=1e9,friction=0.5,damping=0.01,tang_damp=10.0,density=8.0;
  os << x << "\t" << y << "\t0\t" << vx << "\t" << vy << "\t0\t"
     << radius << "\t" << mass << "\t"<< type 
     << "\t"<<Young<<"\t"<<damping<<"\t"<<friction<<"\t"<<tang_damp
     << "\t"<<0<<"\t"<<0<<"\t"<<0
     << "\t0\t0\t0" << "\t0\t0\t0" << "\t0\t0\t0\n";

}

int main()
{
  ofstream fout("input_hopper.dat");
  ofstream fout2("input.dat");
  fout << "#gravity: 0 -9.81 0\n";
  fout << "#timestep: 1e-6\n";
  fout << "#nstep: 5000000\n";
  fout << "#nprint: 1000\n";
  fout << "#nenergy: 1000\n";
  fout << "#Time: 0\n";
  fout << "#lx: 2\n";
  fout << "#ly: 2\n";
  //for(int i=0;i<11;i++)
 //   dump_particle(fout,0.45+i*0.01,0.19,0,0,0.005,1,1);
  for(int i=0;i<10;i++){
    dump_particle(fout,0.45+(i+0.5)*0.005,i*0.01+0.2,0,0,0.005,1,1);
    dump_particle(fout,0.45-(i+0.5)*0.005,i*0.01+0.2,0,0,0.005,1,1);

    dump_particle(fout2,0.45+(i+0.5)*0.005,i*0.01+0.2,0,0,0.005,1,1);
    dump_particle(fout2,0.45-(i+0.5)*0.005,i*0.01+0.2,0,0,0.005,1,1);

  }
  const double Rmax=0.006, Rmin=0.004;
  for(int i=0;i<5;i++){
    for(int k=0;k<5;k++){
      double centerx=0.4115+0.013*i;
      double centery=0.6+0.013*k;
      double z=drand48();
      double r=Rmin*Rmax/(Rmax-z*(Rmax-Rmin));
      dump_particle(fout,centerx,centery,0,0,r,r*r/(Rmax*Rmax),0);
      dump_particle(fout2,centerx,centery,0,0,r,r*r/(Rmax*Rmax),0);
    }
  }
}
