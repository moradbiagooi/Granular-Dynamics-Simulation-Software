#ifndef __NEWTON_RAPHSON_H
#define __NEWTON_RAPHSON_H

float rtsafe( void (*funcd)( float, float *, float * ), float x1, float x2, float xacc );

#endif
