#include <iostream>

#include "Newton_Raphson.h"


using namespace std;


void f      ( float, float *, float *);

void (*pf)  ( float, float *, float *);


int main () {

    
    float t, f_t, df_t;

    t = -1.0;

    float *pf_t;
    float *pdf_t;

    pf_t = & f_t;
    pdf_t = & df_t;

    pf = & f;

    f ( t, pf_t, pdf_t);

    cout << "t = " << t << " f_t = " << f_t << " df_t = " << df_t << "\n";

    float result = rtsafe ( pf, 5.0, 8.0, 0.1 );
    cout << "result = " << result << "\n";


    return 0;
}


void f ( float t, float * f_t, float * df_t ){
/*
    *f_t  = t*t - 1.0;

    *df_t = 2 * t;
*/

    *f_t  = (t-5) * (t-5) - 1.0;
    *df_t = 2 * ( t-5) - 1.0;



}
