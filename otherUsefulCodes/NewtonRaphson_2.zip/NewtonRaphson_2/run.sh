rm a.out *~
icpc *.cpp
./a.out
