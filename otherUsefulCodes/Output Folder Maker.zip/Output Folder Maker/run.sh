g++ main.cc
./a.out
