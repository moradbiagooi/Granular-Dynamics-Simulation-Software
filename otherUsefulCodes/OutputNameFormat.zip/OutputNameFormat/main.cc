#include<iostream>
#include<fstream>
#include<string>
#include<stdio.h>
using namespace std;

int main (){

double a=1e-08,b=1231.13000;
int c=331231;
string ss="";

ss.append("AA_");
char buffer[20];
sprintf(buffer,"aa_%g_%g_%u",a,b,c);
ss.append(buffer);

ofstream ff;
const char * cc=ss.c_str();
ff.open (cc);
ff<<"aa";
}

