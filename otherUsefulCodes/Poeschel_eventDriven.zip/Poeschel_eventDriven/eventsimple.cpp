#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <cstdlib>
#include <cmath>


using namespace std;

const int N=3000, nstep=2000000000, nps=50000, nprint=1000, noverlap=10000;
const double R=1, eps=0.95, Lbox=150, pssize=500;
const double infty=1e20, null=1e-10;

vector<double> x(N),y(N),vx(N),vy(N);
vector<double> clist[N];

double Time=0;

map <double,pair<int,int> > cseq;

ofstream fps("event.ps"), fenergy("kinenergy");

void init(double);
void propagation(double);
void collision(const pair<int,int> &);
void wcollision(int);
void update(int);
void psplot(int, ofstream &);

bool checkoverlap();

double ppcoll(int,int,double);
double pwcoll(int,double);
double ranf(double x){ return (2*double(rand())/(1+double(RAND_MAX))-1)*x;}
double kinenergy();



int main()
{
    double tnext, tn=0;

    pair <int,int> ijnext;

        init(null);

        for (int it=0; it<nstep; it++) {

            if ( it % noverlap == 0 ) checkoverlap ();

            if ( it % nprint   == 0 ) fenergy << it << " " << kinenergy () << endl;

            tnext = cseq.begin() -> first;

            if ( !(it%nprint) ) cout << "IT: " << it << " time= " << Time << endl;

            ijnext = cseq.begin() -> second;

            if ( ijnext.second == -1 ){

                tn   = pwcoll (ijnext.first,null);
                propagation   (tn-Time);
                Time = tnext;
                wcollision    (ijnext.first);
                update        (ijnext.first);

            } else{

                tn   = ppcoll (ijnext.first,ijnext.second,null);
                propagation   (tn-Time);
                Time = tnext;
                collision     (ijnext);
                update        (ijnext.first);
                update        (ijnext.second);

            }

            if ( it % nps == 0 ) psplot ( it / nps, fps );
        }

}






void propagation(double tprop)
{
    for(int i=0; i<N; i++){
        x[i]+=tprop*vx[i];
        y[i]+=tprop*vy[i];
    }
}

void collision(const pair<int,int> & ij)
{
    int i = ij.first;
    int j = ij.second;
    double dx = x[i]-x[j];
    double dy = y[i]-y[j];
    double dist = sqrt(dx*dx+dy*dy);
    double ndx = dx/dist;
    double ndy = dy/dist;
    double h = (1+eps)*((vx[i]-vx[j])*ndx+(vy[i]-vy[j])*ndy)/2;
    vx[i] -=± h*ndx;
    vy[i] -= h*ndy;
    vx[j] += h*ndx;
    vy[j] += h*ndy;
}



double ppcoll (int i, int j, double tol)
{
    double dx,dy,dvx,dvy,xci,xcj,yci,ycj,scalar,h,p,q,w,ct;
    double dist2,RR,vv2;

    dx=x[i]-x[j];
    dy=y[i]-y[j];
    dvx=vx[i]-vx[j];
    dvy=vy[i]-vy[j];
    scalar=dx*dvx+dy*dvy;
    if(scalar>0){
        return infty;
    } else{
        dist2 = dx*dx+dy*dy;
        RR = (dist2>=R*R ? R : R-tol);
        vv2 = dvx*dvx+dvy*dvy;
        q = dist2-4*RR*RR;
        w = scalar*scalar - q*vv2;  // ???????? vv or vv2

        if(w<0){
            return infty;
        } else {
            ct=Time+q/(-scalar + sqrt(w));
            xci=x[i]+(ct-Time)*vx[i]; xcj=x[j]+(ct-Time)*vx[j];
            if((xci>Lbox-R)||(xci<-Lbox+R)||(xcj>Lbox-R)||(xcj<-Lbox+R)){
                return infty;
            } else {
                yci=y[i]+(ct-Time)*vy[i]; ycj=y[j]+(ct-Time)*vy[j];
                if((yci>Lbox-R)||(yci<-Lbox+R)||(ycj>Lbox-R)||(ycj<-Lbox+R)){
                    return infty;
                } else {
                    return ct;
                }
            }
        }
    }
}

void wcollision(int i)
{
    if( y[i]<0){
        if((y[i] > x[i]) || (y[i] > -x[i])){
            vx[i]=-vx[i];
        } else{
            vy[i]=-vy[i];
        }
    } else {
        if((y[i] < -x[i]) || (y[i] < x[i])){
            vx[i]=-vx[i];
        } else{
            vy[i]=-vy[i];
        }
    }
}


double pwcoll(int i,double tol)
{
    double tx, ty;
    double RR = R;

        if((Lbox+x[i]>R) || (Lbox-x[i]<R) || (Lbox+y[i]>R) || (Lbox-y[i]<R)) {
            RR=R-tol;
        }
    if(vx[i]==0){
        tx=infty;
    } else {
        if(vx[i] >0) {
            tx=(Lbox-x[i]-RR)/vx[i];
        } else {
            tx=(-Lbox-x[i]+RR)/vx[i];
        }
    }
    if(vy[i]==0){
        ty=infty;
    } else {
        if(vy[i] >0){
            ty=(Lbox-y[i]-RR)/vy[i];
        } else {
            ty=(-Lbox-y[i]+RR)/vy[i];
        }
    }
    return Time+min(tx,ty);

}



void init(double tol)
{
    bool overlap;
    int j;

        x[0]=ranf(Lbox-R-tol);
    y[0]=ranf(Lbox-R-tol);
    vx[0]=ranf(1);
    vy[0]=ranf(1);
    for(int i=1; i<N; i++){
        if(!(i % 100 )) cout << "Init "<< i << endl;
        do{
            overlap=false;
            x[i]=ranf(Lbox-R-tol); y[i]=ranf(Lbox-R-tol);
            j=0;
            do{
                overlap=((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j])<
                        4*(R+tol)*(R+tol));
            } while((++j<i) && !overlap);
        } while(overlap);
        vx[i]=ranf(1);
        vy[i]=ranf(1);
    }
    for(int i=0; i<N; i++) update(i);

}

void update(int i)
{
    double ct;

        for(unsigned int ii=0; ii!=clist[i].size(); ii++) cseq.erase(clist[i][ii]);
    clist[i].clear();
    for(int j=0; j<N; j++){
        if(i!=j){
            ct=ppcoll(i,j,null);
            if(ct < infty){
                cseq[ct]=pair <int, int> (i,j);
                clist[i].push_back(ct);
                clist[j].push_back(ct);
            }
        }
    }
    ct=pwcoll(i,null);
    if(ct < infty){
        cseq[ct]=pair<int, int>(i,-1);
        clist[i].push_back(ct);
    }

}




void psplot(int page, ofstream & psout)
{
    if(!page){
        psout << "%!PS-Adobe-2.0" << endl;


            psout<< "%%BoundingBox: 0 0 "<<pssize+20<<" "<< pssize+20<< endl;
        psout<< "%%EndComments" << endl;
        psout<< "/frame {10 10 translate " <<Lbox/pssize<<" setlinewidth ";
        psout<< pssize/(2*Lbox) <<" "<< pssize/(2*Lbox) <<" scale ";
        psout<< Lbox<<" "<<Lbox<<" translate newpath ";
        psout<< -Lbox<<" "<<-Lbox<<" moveto ";
        psout<< 2*Lbox;
        psout <<" 0 rlineto 0 "<<2*Lbox<<" rlineto "<<-2*Lbox;
        psout<<" 0 rlineto closepath stroke}def" << endl;
        psout << "/c { 1 0 360 arc stroke} def" << endl;

    }
    psout << "%%Page: " << page << " " << page << endl;
    psout << "frame " <<endl;
    for(int i=0; i<N; i++) psout << x[i]<<" "<<y[i]<<" c" << endl;
    psout << "stroke showpage " << endl;

}


double kinenergy() {
    double ekin=0;

    for(int i=0; i<N; i++) ekin+=vx[i]*vx[i]+vy[i]*vy[i];
    return ekin;
}


bool checkoverlap()
{
    double dist;

        for(int i=1; i<N; i++){
            for(int j=0; j<i; j++){
                dist=(x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j])-4*R*R;
                if(dist<0){
                    cout <<" OVERLAP "<<i<<" "<<j<< " " << dist << endl;
                    return true;
                }
            }
        }

    for(int i=0; i<N; i++){
        if((x[i]-R<-Lbox)||(y[i]-R<-Lbox)||(x[i]+R>Lbox)||(y[i]+R>Lbox)){
            cout<<"OVERLAP WALL"<<i<< " "<<y[i]+R-Lbox << endl;
            return true;
        }
    }
    return false;

}
