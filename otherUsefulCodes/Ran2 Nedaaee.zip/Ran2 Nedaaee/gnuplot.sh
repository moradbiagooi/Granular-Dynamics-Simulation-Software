set term png
set terminal png size 800,600 enhanced font "Helvetica,10"             
set output "output.png"
plot [:][0:]"output.dat" u 1:2 w l lw 2


