/*
A code to check ran2 algorithm

Written by Morad Biagooi

use "run.sh"
*/

#include <iostream>
#include <fstream>
#include <time.h>
#include "random.h"


using namespace std;

Random R;

int main(){

  time_t utime;
  time(&utime);
  long seed = (long)utime;

  cout<<"hoho \n";
  const int bins=1001;
  int numm[bins]={0};

  long  l=131; // seed
  long *ll;
//  ll=&l;
  ll=&seed;



  int i_end=10000000; // number of generation

  for (int i=0;i<i_end;i++){

    double ran=R.ran2(ll);

//    double ran= (R.ran2(ll)+R.ran2(ll)+R.ran2(ll)
//                +R.ran2(ll)+R.ran2(ll))/5; // a method to make a gaussian distribution

    ran*=double(bins-1);
    int b=int(ran);

    numm[b]+=1;

}


  ofstream ofile("output.dat");

 
  for (int i=0;i<bins-1;i++)

    ofile << i << " " 
          << double(numm[i])/double(100)
          << "\n";

}
