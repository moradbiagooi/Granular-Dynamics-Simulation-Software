clear
g++ -o ran.out main.cc Random_Gasdev.cpp Random_Ran2.cpp
./ran.out
rm output.png
gnuplot gnuplot.sh
comix output.png
