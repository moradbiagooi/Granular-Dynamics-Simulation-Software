#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <cmath>

#include"macros.h"

using namespace std;




typedef struct { double x, y; } VecR;

typedef struct { int x, y;} VecI;

typedef struct { VecR r, rv, ra; } Mol;

typedef struct { double val, sum, sum2; } Prop;

Mol *mol;
VecR region, vSum;
VecI initUcell;
Prop kinEnergy, pressure, totEnergy;
double deltaT, density, rCut, temperature, timeNow, uSum, velMag,
virSum, vvSum;
int moreCycles, nMol, stepAvg, stepCount, stepEquil, stepLimit;
//======
#define IADD 453806245
#define IMUL 314159269
#define MASK 2147483647
#define SCALE 0.4656612873e-9

int randSeedP = 17;
double RandR ()
{
    randSeedP = (randSeedP * IMUL + IADD) & MASK;
    return (randSeedP * SCALE);
}

//=====
void VRand (VecR *p)
{
    double s;
    s = 2. * M_PI * RandR ();
    p->x = cos (s);
    p->y = sin (s);
}

void GetNameList (int, char**);
void SingleStep ();
void SetupJob ();

void ComputeForces ();

void LeapfrogStep (int part);
void ApplyBoundaryCond ();
void InitCoords ();
void InitVels ();
void InitAccels ();
void AllocArrays ();
void SetParams ();
void AccumProps (int icode);
void EvalProps ();

//void PrintSummary (FILE *fp);
void EvalVelDist ();






int main (int argc, char **argv)
{
	GetNameList (argc, argv);
//	PrintNameList (stdout);
	SetParams ();
	SetupJob ();
	moreCycles = 1;

	while (moreCycles) {
		SingleStep ();
		if (stepCount >= stepLimit) moreCycles = 0;
	}
}


void SingleStep ()
{
	++ stepCount;
	timeNow = stepCount * deltaT;
	LeapfrogStep (1);
	ApplyBoundaryCond ();
	ComputeForces ();
	LeapfrogStep (2);
	EvalProps ();
	AccumProps (1);
	if (stepCount % stepAvg == 0) {
		AccumProps (2);
//		PrintSummary (stdout);
		AccumProps (0);
	}
}


void SetupJob ()
{
	AllocArrays ();
	stepCount = 0;
	InitCoords ();
	InitVels ();
	InitAccels ();
	AccumProps (0);
}

/*
void ComputeForces ()
{
	VecR dr;
	double fcVal, rr, rrCut, rri, rri3;
	int j1, j2, n;
	rrCut = Sqr (rCut);
	for (n = 0; n < nMol; n ++) {
		mol[n].ra.x = 0.;
		mol[n].ra.y = 0.;
	}
	uSum = 0.;

	for (j1 = 0; j1 < nMol - 1; j1 ++) {
		for (j2 = j1 + 1; j2 < nMol; j2 ++) {
			dr.x = mol[j1].r.x - mol[j2].r.x;
			dr.y = mol[j1].r.y - mol[j2].r.y;
			if (dr.x >= 0.5 * region.x) dr.x -= region.x;
			else if (dr.x < -0.5 * region.x) dr.x += region.x;
			if (dr.y >= 0.5 * region.y) dr.y -= region.y;
			else if (dr.y < -0.5 * region.y) dr.y += region.y;
			rr = dr.x * dr.x + dr.y * dr.y;
			if (rr < rrCut) {
				rri = 1. / rr;
				rri3 = rri * rri * rri;
				fcVal = 48. * rri3 * (rri3 - 0.5) * rri;
				mol[j1].ra.x += fcVal * dr.x;
				mol[j1].ra.y += fcVal * dr.y;
				mol[j2].ra.x -= fcVal * dr.x;
				mol[j2].ra.y -= fcVal * dr.y;
				uSum += 4. * rri3 * (rri3 - 1.) + 1.;
			}
		}
	}
}
*/

void ComputeForces ()
{
	VecR dr;
	double fcVal, rr, rrCut, rri, rri3;
	int j1, j2, n;
	rrCut = Sqr (rCut);
	DO_MOL VZero (mol[n].ra);
	uSum = 0.;
	virSum = 0.;
	for (j1 = 0; j1 < nMol - 1; j1 ++) {
		for (j2 = j1 + 1; j2 < nMol; j2 ++) {
			VSub (dr, mol[j1].r, mol[j2].r);
			VWrapAll (dr);
			rr = VLenSq (dr);
			if (rr < rrCut) {
				rri = 1. / rr;
				rri3 = Cube (rri);
				fcVal = 48. * rri3 * (rri3 - 0.5) * rri;
				VVSAdd (mol[j1].ra, fcVal, dr);
				VVSAdd (mol[j2].ra, - fcVal, dr);
				uSum += 4. * rri3 * (rri3 - 1.) + 1.;
				virSum += fcVal * rr;
			}
		}
	}
}


void LeapfrogStep (int part)
{
	int n;
	if (part == 1) {
		DO_MOL {
			VVSAdd (mol[n].rv, 0.5 * deltaT, mol[n].ra);
			VVSAdd (mol[n].r, deltaT, mol[n].rv);
		}
	} else {
		DO_MOL VVSAdd (mol[n].rv, 0.5 * deltaT, mol[n].ra);
	}
}


void ApplyBoundaryCond ()
{
	int n;
	DO_MOL VWrapAll (mol[n].r);
}



void InitCoords ()
{
	VecR c, gap;
	int n, nx, ny;
	VDiv (gap, region, initUcell);
	n = 0;
	for (ny = 0; ny < initUcell.y; ny ++) {
		for (nx = 0; nx < initUcell.x; nx ++) {
			VSet (c, nx + 0.5, ny + 0.5);
			VMul (c, c, gap);
			VVSAdd (c, -0.5, region);
			mol[n].r = c;
			++ n;
		}
	}
}




void InitVels ()
{
	int n;
	VZero (vSum);
	DO_MOL {
		VRand (&mol[n].rv);
		VScale (mol[n].rv, velMag);
		VVAdd (vSum, mol[n].rv);
	}

	DO_MOL VVSAdd (mol[n].rv, - 1. / nMol, vSum);

}


void InitAccels ()
{
	int n;
	DO_MOL VZero (mol[n].ra);
}








void AllocArrays ()
{
	AllocMem (mol, nMol, Mol);
}


void SetParams ()
{
	rCut = pow (2., 1./6.);
	VSCopy (region, 1. / sqrt (density), initUcell);
	nMol = VProd (initUcell);
	velMag = sqrt (NDIM * (1. - 1. / nMol) * temperature);
}



void EvalProps ()
{
	double vv;
	int n;
	VZero (vSum);
	vvSum = 0.;
	DO_MOL {
		VVAdd (vSum, mol[n].rv);
		vv = VLenSq (mol[n].rv);
		vvSum += vv;
	}

	kinEnergy.val = 0.5 * vvSum / nMol;
	totEnergy.val = kinEnergy.val + uSum / nMol;
	pressure.val = density * (vvSum + virSum) / (nMol * NDIM);
}


void AccumProps (int icode)
{
	if (icode == 0) {
		PropZero (totEnergy);
		PropZero (kinEnergy);
		PropZero (pressure);
	} else if (icode == 1) {
		PropAccum (totEnergy);
		PropAccum (kinEnergy);
		PropAccum (pressure);
	} else if (icode == 2) {
		PropAvg (totEnergy, stepAvg);
		PropAvg (kinEnergy, stepAvg);
		PropAvg (pressure, stepAvg);
	}
}

void GetNameList(int argc , char ** argv)
{
NameList nameList[] = {
	NameR (deltaT),
	NameR (density),
	NameI (initUcell),
	NameI (stepAvg),
	NameI (stepEquil),
	NameI (stepLimit),
	NameR (temperature),
};
}
/*
void PrintSummary (FILE *fp)
{
	fprintf (fp,
	"%5d %8.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n",
	stepCount, timeNow, VCSum (vSum) / nMol, PropEst (totEnergy),
	PropEst (kinEnergy), PropEst (pressure));
}
*/

void EvalVelDist ()
{
	double deltaV, histSum;
	int j, n;

	if (countVel == 0) {
	for (j = 0; j < sizeHistVel; j++) histVel[j] = 0.;
	}

	deltaV = rangeVel / sizeHistVel;
	DO_MOL {
		j = VLen (mol[n].rv) / deltaV;
		++ histVel[Min (j, sizeHistVel	- 1)];
	}
	++ countVel;
	if (countVel == limitVel) {
		histSum = 0.;
		for (j = 0; j < sizeHistVel; j++) histSum += histVel[j];
		for (j = 0; j < sizeHistVel; j++) histVel[j] /= histSum;
		PrintVelDist (stdout);
		countVel = 0;
	}

}
