rm mdrun
icpc mdrun *.cpp
./mdrun
