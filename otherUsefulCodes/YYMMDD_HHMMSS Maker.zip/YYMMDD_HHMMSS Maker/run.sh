g++ -o a.out main.cc
./a.out
