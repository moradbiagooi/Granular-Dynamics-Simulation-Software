#include<iostream>
#include<fstream>
#include<string>
#include <sys/stat.h> // used for mkdir()

using namespace std;


const int no_of_files=10;
const int nstep=10000;
const int no_of_col=4;

double av_var[nstep][no_of_col]={0};//maybe [4][nstep] for a faster scheme
double temp[no_of_col];

ofstream ofs_f;
ifstream ifs_f[no_of_files];

void open_files();
void input_average_output();
//===============================main
//===============================main
//===============================main

int main(){
  open_files();
  input_average_output();
  ofs_f.close();
}
//===============================input_average_output
//===============================input_average_output
//===============================input_average_output
void input_average_output(){
  for(int j=0;j<no_of_files;j++){
    for(int i=0;i<nstep;i++){
      ifs_f[j] >> temp[0];
      av_var[i][0] = temp[0]; // faster for [k][i] ??
      for(int k=1;k<no_of_col;k++){
	ifs_f[j] >> temp[k];
	av_var[i][k] += temp[k]; // faster for [k][i] ??
      }
    }
  }

  for(int i=0;i<nstep;i++){
    ofs_f << av_var[i][0]; //time
    for(int k=1;k<no_of_col;k++){
      ofs_f << "\t";
      ofs_f << av_var[i][k] / double(no_of_files); // faster for [k][i] ??
    }
    ofs_f << "\n";
  }
}

//===============================open_files
//===============================open_files
//===============================open_files
void open_files(){

  char buffer[10]="";

  string str_folder_;
  string str_folder_in[no_of_files];
  string str_folder_out;
  string str_infilename;
  string str_outfilename;

  str_infilename.append("T_1D_i:On_i:Hook_o:Hook_nP:11_dt:1e-06_nt:100000000_Ai:500_Ao:0_Mi:7.5_Mo:2.5.dat");

  str_folder_.append("box"); 


  for (int i=0;i<no_of_files;i++){

    str_folder_in[i].append(str_folder_); 

    sprintf(buffer,"%u",i+1);
    str_folder_in[i].append(buffer);

    str_folder_in[i].append("/outputs/");
    str_folder_in[i].append(str_infilename);

    const char * char_f_in=str_folder_in[i].c_str();
    ifs_f[i].open (char_f_in);
  }




  str_folder_out.append("output_averaged/");
  const char* char_folder_out=str_folder_out.c_str();
  mkdir(char_folder_out,0777);

  str_outfilename.append(str_folder_out);
  str_outfilename.append(str_infilename);

  const char * char_f_out=str_outfilename.c_str();
  ofs_f.open(char_f_out);
  ofs_f.precision(10);

}

