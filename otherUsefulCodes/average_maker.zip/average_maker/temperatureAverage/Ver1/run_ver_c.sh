g++ -o main_average_maker_ver_c main_average_maker_ver_c.cc
./main_average_maker_ver_c
