#include <iostream>
#include <fstream>
#include <string>
#include <sys/stat.h> // used for mkdir()
#include <vector>
#include <cmath>

#define ManyFolderS 1

#define FILENAME "o_e_ng100_Ysp0.01_Asp0.1_s"

#define FOLDERNAME "o_33_"

#define FILEEXTENSION ".txt"

int FolderNumberStart = 1; // It's disabled when there's only one folder
int FileNumberStart = 1; // It's disabled when there's only one file in each folder.

using namespace std;


const int no_files=1; // number of files in each folder
#ifdef ManyFolderS
const int no_folders=10; // change this
#else
const int no_folders=1; // don't change this
#endif

const int no_FilesFolders = no_files*no_folders;

const int no_steps=10000;
const int no_columns=9;

double av_var[no_steps][no_columns]={0};
double err_var[no_steps][no_columns]={0};
double temp[no_columns];

vector <vector<vector<double> > > all_data;

ofstream ofs_f;

ifstream ifs_f[no_FilesFolders];

bool open_files();
void input_average_output();

//===============================main
//===============================main
//===============================main

int main () {

	all_data.resize (no_steps);
	for (int i=0;i<no_steps;++i)
		all_data[i].resize (no_columns);

  if  (!open_files()){
    cout<<"The process has been ended because of the problem above.\n";
    return 0;
  }

  input_average_output ();
  ofs_f.close ();
}

//===============================input_average_output
//===============================input_average_output
//===============================input_average_output
void input_average_output(){

  cout<<"reading data...\n";

  for (int l=0;l<no_folders;++l){
  	for(int m=0;m<no_files;++m){
      int j= m + l*no_files;
    	for(int i=0;i<no_steps;++i){
      	ifs_f[j] >> temp[0];
				all_data[i][0].push_back(temp[0]);
      	av_var[i][0] = temp[0];
      	for(int k=1;k<no_columns;++k){
					ifs_f[j] >> temp[k];
					all_data[i][k].push_back(temp[k]);
					av_var[i][k] += temp[k]; 
      	}
    	}
  	}
  }


  cout<<"calculating averages...\n";
  for(int i=0;i<no_steps;++i){
    for(int j=1;j<no_columns;++j){
      av_var[i][j] /= double(no_FilesFolders); 
    }
  }

	cout<<"calculating errorbars...\n";
  for(int i=0;i<no_steps;++i){
    for(int j=1;j<no_columns;++j){
			double temp = 0.0;
    	for(int k=0;k<no_FilesFolders;k++){
				temp += (all_data[i][j][k]-av_var[i][j])*(all_data[i][j][k]-av_var[i][j]);
			}
			err_var[i][j] = sqrt (temp/(no_FilesFolders));
    }
  }


  cout<<"outputing data...\n";
  for(int i=0;i<no_steps;++i){
    ofs_f << av_var[i][0]; //time
    for(int k=1;k<no_columns;++k){
      ofs_f << "\t";
      ofs_f << av_var[i][k]; 
      ofs_f << "\t" << err_var[i][k];
    }
    ofs_f << "\n";
  }
}

//===============================open_files
//===============================open_files
//===============================open_files

bool open_files(){

  cout<<"reading file names...\n";

  char buffer[10]="";

  string str_folder_;

  string str_folder_in[no_FilesFolders];

  string str_folder_out;
  string str_infilename;
  string str_outfilename;

  str_infilename.append(FILENAME);

  for (int l=0;l<no_folders;++l){
    for (int k=0;k<no_files;++k){
      int i= k + l*no_files; 
      str_folder_in[i].append (FOLDERNAME);

#ifdef ManyFolderS
			if (no_folders>1) {
      	sprintf (buffer,"%u",l+FolderNumberStart);
      	str_folder_in[i].append (buffer);
			}
#endif

      str_folder_in[i].append ("/");

      str_folder_in[i].append (str_infilename);
			if (no_files>1) {
      	sprintf (buffer,"%u",k+1); // ** note the k istead of i
      	str_folder_in[i].append (buffer);
			}

	   	sprintf (buffer,"%u",l+FolderNumberStart); // folder number in file name
     	str_folder_in[i].append (buffer);//
	
      str_folder_in[i].append (FILEEXTENSION);

      const char * char_f_in=str_folder_in[i].c_str ();
      ifs_f[i].open (char_f_in);
      if (!ifs_f[i].good()){
        cout <<"\nA problem occured in reading the file:\n\n "<<char_f_in<<"\n";
        cout <<"\nCheck the address and try again.\n";    
				return false;
      }

    }
  }


  str_folder_out.append ("output_averaged/");
  const char* char_folder_out=str_folder_out.c_str ();
  mkdir (char_folder_out,0777);

  str_outfilename.append (str_folder_out);
  str_outfilename.append (str_infilename);
  str_outfilename.append (".dat");

  const char * char_f_out=str_outfilename.c_str ();
  ofs_f.open (char_f_out);
  ofs_f.precision (10);
  return true;
}

