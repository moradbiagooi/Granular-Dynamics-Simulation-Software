#include <iostream>
#include <fstream>
#include <string>
#include <sys/stat.h> // used for mkdir()
#include <math.h>

//#define ManyFolderS

#define FILENAME "T_nP:1000_FT:10000_AS:0.1_EI:"

#define FOLDERNAME "outputs_seed2"

int FolderNumberStart = 1;

using namespace std;


const int no_of_files=10; // number of files in each folder
#ifdef ManyFolderS
const int no_of_folders=4;
#endif

const int nstep=100000;
const int no_of_col=2;

double av_var[nstep][no_of_col]={0};
double av_varvar[nstep][no_of_col]={0};

double temp[no_of_col];

ofstream ofs_f;

#ifdef ManyFolderS
ifstream ifs_f[no_of_files*no_of_folders];
#else
ifstream ifs_f[no_of_files];
#endif

bool open_files();
void input_average_output();

//===============================main
//===============================main
//===============================main

int main(){

  if (!open_files()){
    cout<<"The process has been ended because of the problem above.\n";
    return 0;
  }

  input_average_output();
  ofs_f.close();
}

//===============================input_average_output
//===============================input_average_output
//===============================input_average_output
void input_average_output(){

  cout<<"reading data...\n";
#ifdef ManyFolderS
  for (int l=0;l<no_of_folders;l++){
#endif
  for(int m=0;m<no_of_files;m++){
#ifdef ManyFolderS
      int j= m + l*no_of_files;
#else
      int j= m;
#endif
    for(int i=0;i<nstep;i++){
      ifs_f[j] >> temp[0];
      av_var[i][0] = temp[0]; 
      for(int k=1;k<no_of_col;k++){
	ifs_f[j] >> temp[k];
	av_var[i][k] += temp[k]; 
	av_varvar[i][k] += temp[k]*temp[k]; 
      }
    }
  }
#ifdef ManyFolderS
  }
#endif

  cout<<"outputing data...\n";
  for(int i=0;i<nstep;i++){
    ofs_f << av_var[i][0]; //time
    for(int k=1;k<no_of_col;k++){
      ofs_f << "\t";
#ifdef ManyFolderS
      double mean = av_var[i][k] / double(no_of_files*no_of_folders); 
      double meanmean = av_varvar[i][k] / double(no_of_files*no_of_folders); 
#else
      double mean = av_var[i][k] / double(no_of_files); 
      double meanmean = av_varvar[i][k] / double(no_of_files); 
#endif

      double error_bar = sqrt (meanmean - mean*mean);

      ofs_f << mean << " " << error_bar;

    }
    ofs_f << "\n";
  }
}

//===============================open_files
//===============================open_files
//===============================open_files

bool open_files(){

  cout<<"reading file names...\n";

  char buffer[10]="";

  string str_folder_;
#ifdef ManyFolderS
  string str_folder_in[no_of_files*no_of_folders];
#else
  string str_folder_in[no_of_files];
#endif
  string str_folder_out;
  string str_infilename;
  string str_outfilename;

  str_infilename.append(FILENAME);

#ifdef ManyFolderS
  for (int l=0;l<no_of_folders;l++){
#endif
    for (int k=0;k<no_of_files;k++){
  



#ifdef ManyFolderS
      int i= k + l*no_of_files;
      str_folder_in[i].append(FOLDERNAME);
      sprintf(buffer,"%u",l+FolderNumberStart);
      str_folder_in[i].append(buffer);

#else
      int i=k;
      str_folder_in[i].append(FOLDERNAME);
#endif

      str_folder_in[i].append("/");

      str_folder_in[i].append(str_infilename);
      sprintf(buffer,"%u",k+1); // ** note the k istead of i
      str_folder_in[i].append(buffer);
      str_folder_in[i].append(".dat");

      const char * char_f_in=str_folder_in[i].c_str();
      ifs_f[i].open (char_f_in);
      if (!ifs_f[i].good()){
        cout <<"\nA problem occured in reading the file:\n\n "<<char_f_in<<"\n";
        cout <<"\nCheck the address and try again.\n";    
	return false;
      }

    }
#ifdef ManyFolderS
  }
#endif


  str_folder_out.append("output_averaged/");
  const char* char_folder_out=str_folder_out.c_str();
  mkdir(char_folder_out,0777);

  str_outfilename.append(str_folder_out);
  str_outfilename.append(str_infilename);
  str_outfilename.append(".dat");

  const char * char_f_out=str_outfilename.c_str();
  ofs_f.open(char_f_out);
  ofs_f.precision(10);
  return true;
}

