#include <iostream>
#include <fstream>

int main() {

  using namespace std;

  ofstream ofs( "atest.txt", ios::binary );

  if ( ofs ) {

    double pi = 3.14;
    
    ofs.write( reinterpret_cast<char*>( &pi ), sizeof pi );

    ofs.close();

    ifstream ifs( "atest.txt", ios::binary );

    double read;

    if ( ifs ) { 

      ifs.read( reinterpret_cast<char*>( &read ), sizeof read );
      cout << read << '\n';
    }

  }

  return 0;
}
