
#include <iostream>
#include <fstream>

using namespace std;


#define INPUT_FILE_NAME "xP_nP:100_FT:100_RC:1_Al:0.7_Be:0.1_EI:1.bin"


const int no_grains = 100;
const int no_snapshots = 1001;     


//#######################################

int main() {

  ifstream ifs( INPUT_FILE_NAME, ios::binary | ios::in  );



  ofstream ofs( "output.dat" );

  ofs.precision (10);

  for ( unsigned int i = 0; i < no_snapshots; i++){


      double time;

      ifs.read( reinterpret_cast<char*>( &time ), sizeof (double) );

      ofs << time ;


    for ( unsigned int j = 0; j < no_grains; j++){


        double data;

        ifs.read( reinterpret_cast<char*>( &data ), sizeof (double) );

        ofs << " " << data;


    }


    ofs << "\n";


  }


/*
  ofstream ofs( "atest.txt", ios::binary );

  if ( ofs ) {

    double pi = 3.14;
    
    ofs.write( reinterpret_cast<char*>( &pi ), sizeof pi );

    ofs.close();

    ifstream ifs( "atest.txt", ios::binary );

    double read;

    if ( ifs ) { 

      ifs.read( reinterpret_cast<char*>( &read ), sizeof read );
      cout << read << '\n';
    }

  }
*/


  return 0;
}
