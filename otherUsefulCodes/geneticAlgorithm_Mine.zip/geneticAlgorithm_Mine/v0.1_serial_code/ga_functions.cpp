#include "ga_functions.h"

void genetic_algorithm_run ()
{
    class Genetic_Algorithm * ga = new Genetic_Algorithm ( );

    ga -> initiate ( ); // make a random generation and call it old_people;

    ga_fitness_function ( ga, 0 ); // check the fitness of old_people;

    ga -> output_generation_stat ( ); // output old_people statistic; 

    for ( int i = 0; i < GA_NO_GENERATIONS; i++ )
    {
        cout << "\n generation: " << i << " ,\t" << flush;;

        ga -> make_new_people  ( ); // cross-over old_people by their fitness to make new_people with the same number.

        ga_fitness_function ( ga, 1 ); // check the fitness of new_people

        ga -> similar_people_check ();

        ga_fitness_function ( ga, 2 ); // check the fitness of random people replaced on similar ones;

        ga -> find_best_people ( );  // compare old_people and new_people. find best_people of them. then old_people = best_people.

        ga -> output_generation_stat ( ); // output old_people statistics;

//      here can be a function which stops the generation if a good answer has been found.


    }

    ga -> output_generation_people ( ) ; // output old_people chromosomes;

    delete ga;

}





void ga_fitness_function ( class Genetic_Algorithm * ga , int ktype )
{
    double gene [ NO_GENES ];

    if ( ktype == 2 )
    {
        for ( unsigned int l = 0 ; l < ga -> re_cal_list[0].size(); l++ )
        {
						int i = ga -> re_cal_list[0][l];
            for ( int j = 0; j < NO_GENES; j++ )
            {
                gene [j] = ga -> gene_people ( i , j, 0 );
            }

            double fitness_value;
        
            ga_run_code ( gene , fitness_value );

            ga -> assign_fitness ( i, fitness_value, 0 );
        }

        for ( unsigned int l = 0 ; l < ga -> re_cal_list[1].size(); l++ )
        {
						int i = ga -> re_cal_list[1][l];
            for ( int j = 0; j < NO_GENES; j++ )
            {
                gene [j] = ga -> gene_people ( i , j, 1 );
            }

            double fitness_value;
        
            ga_run_code ( gene , fitness_value );

            ga -> assign_fitness ( i, fitness_value, 1 );
        }


    } 
    else
    {
        for ( int i = 0; i < NO_PEOPLE; i++ )
        {
            for ( int j = 0; j < NO_GENES; j++ )
            {
                gene [j] = ga -> gene_people ( i , j, ktype );
            }

            double fitness_value;
        
            ga_run_code ( gene , fitness_value );

            ga -> assign_fitness ( i, fitness_value, ktype );
//        cout << fitness_value << " " ;
        }
    }

}

//  a prototype for ga_run_code

/*
void ga_run_code ( double * gene, double & fitness_value )
{

    double sum = 0.0;

    for ( int i = 0; i < NO_GENES; i++)
    {
        double f =  ( double (i) - (double (NO_GENES)/2))/double (NO_GENES) ; //??

        sum += abs ( (f * f) - gene[i] ); 
    }

    fitness_value = sum; // all of fitness values has to be positive, and a better fitness is a smaller value. the best fitness has to be zero;

}
*/
