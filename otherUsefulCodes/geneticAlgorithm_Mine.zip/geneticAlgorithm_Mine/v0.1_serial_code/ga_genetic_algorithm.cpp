#include "ga_genetic_algorithm.h"
void Genetic_Algorithm :: similar_people_check ( ) 
{
		new_people -> calc_tot_fitness ();
    re_cal_list[0].clear();
    re_cal_list[1].clear();
    for ( int i = 0; i < NO_PEOPLE; ++i )
    {
        for ( int j = i + 1; j < NO_PEOPLE; ++j )
        {
            
            if ( old_people -> fitness (i) == old_people -> fitness (j) ) 
            {

                int similar_genes = 0;

                for ( int k = 0; k < NO_GENES; ++k ) 
                {
                    if (old_people -> gene_of_chrom ( i,k) ==  old_people -> gene_of_chrom ( j,k))
                      similar_genes += 1;

                }
                if ( similar_genes == NO_GENES )
                {
                //    cout <<" ("<< i << "," << j << ") ";
                    old_people -> make_ran_child ( randnumb, j );                  
                    re_cal_list[0].push_back (j);
                }

            }

        }
        for ( int j = i + 1; j < NO_PEOPLE; ++j )
        {
            
            if ( old_people -> fitness (i) == new_people -> fitness (j) ) 
            {

                int similar_genes = 0;

                for ( int k = 0; k < NO_GENES; ++k ) 
                {
                    if (old_people -> gene_of_chrom ( i,k) ==  new_people -> gene_of_chrom ( j,k))
                      similar_genes += 1;

                }
                if ( similar_genes == NO_GENES )
                {
                //    cout <<" ("<< i << "," << j << ") ";
                    new_people -> make_ran_child ( randnumb, j );
                    re_cal_list[1].push_back (j);
                }

            }

        }
        for ( int j = i + 1; j < NO_PEOPLE; ++j )
        {
            
            if ( new_people -> fitness (i) == new_people -> fitness (j) ) 
            {

                int similar_genes = 0;

                for ( int k = 0; k < NO_GENES; ++k ) 
                {
                    if (new_people -> gene_of_chrom ( i,k) ==  new_people -> gene_of_chrom ( j,k))
                      similar_genes += 1;

                }
                if ( similar_genes == NO_GENES )
                {
                //    cout <<" ("<< i << "," << j << ") ";
                    new_people -> make_ran_child ( randnumb, j );
                    re_cal_list[1].push_back (j);
                }

            }

        }


    }
}//


void Genetic_Algorithm :: find_best_people ( ) 
{
    rank_all_people();
 /*
    cout << "\n after ranking\n";
    for (int i = 0; i < 2*NO_PEOPLE; i++ )
        cout << i<< " " <<  _ranking_m_index[i] <<" "<< _ranking_m_is_old [i]<< " " <<  _ranking_m_fitness [i] << "\n";
    cout << endl;
 */
    change_best_to_old_people();
//    similar_people_check();

}


void Genetic_Algorithm :: change_best_to_old_people()
{

    for ( int i = 0; i < NO_PEOPLE; i++ )
    {

//        cout << "\ncopied: ";
        if ( _ranking_m_is_old[i] )
        {
///            cout << "(old," << _ranking_m_index [i] << ") to (temp,"<<i << "). " ;
            GA_Chromosome_Copy ( temp_people, i, old_people, _ranking_m_index [i]) ;
            temp_people -> fitness ( i ) = old_people -> fitness (  _ranking_m_index [i] );
        }
        else
        {
//            cout << "(new," << _ranking_m_index [i] << ") to (temp,"<<i << "). " ;
            GA_Chromosome_Copy ( temp_people, i, new_people, _ranking_m_index [i] );
            temp_people -> fitness ( i ) = new_people -> fitness (  _ranking_m_index [i] );
        }
    }
 /*
    cout << "\n===========old_people_before:\n";
    for (int i=0; i < NO_PEOPLE;i++){
        cout << "cr_no: " << i << "\n";
        for (int j=0; j < NO_GENES;j++)
        {
            cout << old_people -> gene_of_chrom (i, j ) << " ";
        }
        cout << " f: "<<old_people -> fitness ( i)<<endl;
    }
    */
    /*
    cout << "\n===========temp_people_before:\n";
    for (int i=0; i < NO_PEOPLE;i++){
        cout << "cr_no: " << i << "\n";
        for (int j=0; j < NO_GENES;j++)
        {
            cout << temp_people -> gene_of_chrom (i, j ) << " ";
        }
        cout << endl;
    }
 */
    for ( int i = 0; i < NO_PEOPLE; i++ )
    {
        GA_Chromosome_Copy ( old_people, i, temp_people, i );
        old_people -> fitness ( i ) = temp_people -> fitness ( i );
    }
 /*
    cout << "\n***********old_people_after:\n";
    for (int i=0; i < NO_PEOPLE;i++){
        cout << "cr_no: " << i << "\n";
        for (int j=0; j < NO_GENES;j++)
        {
            cout << old_people -> gene_of_chrom (i, j ) << " ";
        }
        cout << " f: "<<old_people -> fitness ( i)<<endl;
    }
    */
    /*
    cout << "\n&&&&&&&&&temp_people_after:\n";
    for (int i=0; i < NO_PEOPLE;i++){
        cout << "cr_no: " << i << "\n";
        for (int j=0; j < NO_GENES;j++)
        {
            cout << temp_people -> gene_of_chrom (i, j ) << " ";
        }
        cout << endl;
    }

*/
}

void Genetic_Algorithm :: rank_all_people ( )
{
    for ( int i = 0; i < NO_PEOPLE; i++ )
    {
        int j = i + NO_PEOPLE;
        _ranking_m_is_old  [ i ] = true;
        _ranking_m_is_old  [ j ] = false;
        _ranking_m_index   [ i ] = i;
        _ranking_m_index   [ j ] = i;
        _ranking_m_fitness [ i ] = old_people -> fitness (i);
        _ranking_m_fitness [ j ] = new_people -> fitness (i);       
    }

    bool correct_ranking = false;

    while ( !correct_ranking )
    {
        correct_ranking = true;

        for ( int i = 0; i < 2*NO_PEOPLE; i ++ )
        {
            int j = i + 1;
            if ( _ranking_m_fitness [ i ] > _ranking_m_fitness [ j ] )
            {
                
                correct_ranking = false;
                // swap them
                bool   temp_m_is_old     = _ranking_m_is_old  [ i ];
                int    temp_m_index      = _ranking_m_index   [ i ];
                double temp_m_fitness    = _ranking_m_fitness [ i ];

                _ranking_m_is_old  [ i ] = _ranking_m_is_old  [ j ];
                _ranking_m_index   [ i ] = _ranking_m_index   [ j ];
                _ranking_m_fitness [ i ] = _ranking_m_fitness [ j ];               

                _ranking_m_is_old  [ j ] = temp_m_is_old  ;
                _ranking_m_index   [ j ] = temp_m_index   ;
                _ranking_m_fitness [ j ] = temp_m_fitness ;               


            }

        }

    }


}

bool Genetic_Algorithm :: cross_over ( int child_index )
{

    int parent_1 = old_people -> ran_select_by_fitness ( randnumb );
    int parent_2 = old_people -> ran_select_by_fitness ( randnumb );

//    cout << "parents " << parent_1 << " , " << parent_2 << " \n";

    GA_Chromosome child_1, child_2;


        int co_site = int ( randnumb -> randDblExc() * double (NO_GENES) ); //cross_over site//

        int no_mutation_1 = 0 , no_mutation_2 = 0;

        for ( int i = 0; i < NO_GENES; i++ )
        {
            if ( i < co_site )
            {
                child_1.gene(i) = old_people -> gene_of_chrom ( parent_1, i );
                child_2.gene(i) = old_people -> gene_of_chrom ( parent_2, i );
            }
            else
            {
                child_2.gene(i) = old_people -> gene_of_chrom ( parent_1, i );
                child_1.gene(i) = old_people -> gene_of_chrom ( parent_2, i );
            }

            no_mutation_1 += mutate ( child_1.gene(i) );
            no_mutation_2 += mutate ( child_2.gene(i) );
        }
        if ( parent_1 == parent_2 )
        {
          if ( no_mutation_1 == 0 || no_mutation_2 == 0 )
            return false;
        }
        child_1.parents ( parent_1, parent_2 );
        child_2.parents ( parent_1, parent_2 );

        new_people -> add_child ( child_1, child_index     );
        new_people -> add_child ( child_2, child_index + 1 );
/*
        cout << "\np1:";
        for (int k=0; k<NO_GENES; ++k)
          cout << old_people -> gene_of_chrom ( parent_1, k ) << " "; 
        cout << "\np2:";
        for (int k=0; k<NO_GENES; ++k)
          cout << old_people -> gene_of_chrom ( parent_2, k ) << " "; 
        cout << "\n\nc1:";
        for (int k=0; k<NO_GENES; ++k)
          cout << new_people -> gene_of_chrom ( child_index, k ) << " "; 
        cout << "\nc2:";
        for (int k=0; k<NO_GENES; ++k)
          cout << new_people -> gene_of_chrom ( child_index+1, k ) << " "; 
        cout <<endl;
*/


        return true;
        

}

inline int Genetic_Algorithm :: mutate ( double & a_gene  )
{
    double rand_mut = randnumb -> rand ();

    if ( rand_mut < PROB_MUTATION )
    {
        double rand_new_value = randnumb -> rand();

        a_gene = rand_new_value;

        return 1;
    }
    return 0;
}

void Genetic_Algorithm :: initiate ( )
{
    old_people  -> make_ran_people ( randnumb ); //    make_old_people();
    new_people  -> make_ran_people ( randnumb ); //    make_old_people();
    temp_people -> make_ran_people ( randnumb ); //    make_old_people();

    _ranking_m_is_old.resize ( 2*NO_PEOPLE );
    _ranking_m_index.resize ( 2*NO_PEOPLE );
    _ranking_m_fitness.resize ( 2*NO_PEOPLE );

    re_cal_list.resize (2);

    for (int i = 0; i < 2*NO_PEOPLE; ++i)
    {
      _ranking_m_is_old  [i] = true ; 
      _ranking_m_index   [i] =  i ;
      _ranking_m_fitness [i] = 0.1 ;
    }
}

void Genetic_Algorithm :: make_new_people (  )
{

    old_people -> calc_tot_fitness  ();
    old_people -> normalize_fitness ();

    for ( int i = 0; i < NO_PEOPLE; i += 2 )
    {
        if ( ! cross_over ( i ) )
            i -= 2;
    }

}


double Genetic_Algorithm :: gene_people (int i , int j, int k ) const 
{ 
    if ( k == 0 )
        return old_people -> gene_of_chrom (i,j);
    else if ( k == 1 )
        return new_people -> gene_of_chrom (i,j);
    else 
    { 
        cout << "\n error : unknown input " << k << " at Genetic_Algorithm::gene_people \n";
        return 0.0;;
    }
}


void Genetic_Algorithm :: assign_fitness ( int i, double fitness, int k ) 
{ 
    if ( k == 0 )
        old_people -> fitness ( i ) = fitness; 
    else if ( k == 1 )
        new_people -> fitness ( i ) = fitness;
    else 
        cout << "\n error : unknown input " << k << " at Genetic_Algorithm::assign_fitness \n";
}

void Genetic_Algorithm :: normalize_fitness ( int k )
{
    if ( k == 0 )
        old_people -> normalize_fitness (); 
    else if ( k == 1 )
        new_people -> normalize_fitness ();
    else 
        cout << "\n error : unknown input " << k << " at Genetic_Algorithm::normalize_fitness \n";
}


void Genetic_Algorithm :: output_generation_stat ()
{
    old_people -> calc_tot_fitness();
    cout << "mean_fitness = " << old_people -> tot_fitness() / double(NO_PEOPLE);
}
void Genetic_Algorithm :: output_generation_people ()
{

    ofstream out_file_p;
    out_file_p.open ( "output_ga_people.txt" );

    for ( int i = 0; i < NO_PEOPLE; i++ )
    {
        for ( int j = 0; j < NO_GENES; j++ )
        {
            out_file_p << old_people -> gene_of_chrom ( i, j) << " ";
        }
        out_file_p << "\n" << flush;
    }
    out_file_p.close();


    ofstream out_file_f;
    out_file_f.open ( "output_ga_final.txt" );
    out_file_f  << "GA_NO_GENERATIONS " << GA_NO_GENERATIONS << "\n"
                << "GA_RAND_SEED      " << GA_RAND_SEED  << "\n"
                << "NO_PEOPLE         " << NO_PEOPLE  << "\n"
                << "NO_GENES          " << NO_GENES  << "\n"
                << "PROB_MUTATION     " << PROB_MUTATION   << "\n"
                << "PR_FITNESS_LIMIT  " << PR_FITNESS_LIMIT  << "\n";
    out_file_f  << "\nfitness of people:\n";

    for ( int i = 0; i < NO_PEOPLE; i++ )
    {
        out_file_f << i << " " << old_people -> fitness ( i) << "\n";
    }
    out_file_f.close();

}
