#ifndef _GENETIC_ALGORITHM_H
#define _GENETIC_ALGORITHM_H

#include "MersenneTwister.h"
#include "ga_people.h"
#include "ga_macros.h"


class Genetic_Algorithm
{
    public:


    Genetic_Algorithm ( )
    {
        new_people  = new GA_People;
        old_people  = new GA_People;
        temp_people = new GA_People;
        randnumb    = new MTRand ( GA_RAND_SEED );
    };

    ~Genetic_Algorithm() 
    {
        delete old_people;delete new_people;delete temp_people;delete randnumb;
    };

    class MTRand    *randnumb;

    double gene_people (int i , int j, int ) const ;

    void find_best_people () ;

    void assign_fitness ( int i, double fitness, int ); 

    void normalize_fitness ( int );

    bool cross_over ( int );

    void make_new_people  ( );

    void similar_people_check ();

    inline int mutate     ( double &a_gene );

    void initiate ( );

    void make_next_generation ( );

    void output_generation_stat (); // output statistic //
    void output_generation_people (); // output the data of the best people //
    void rank_all_people ();
    void change_best_to_old_people();   

    vector < vector < int > > re_cal_list;

    private:
    class GA_People *new_people;
    class GA_People *old_people;
    class GA_People *temp_people;

    vector < bool > _ranking_m_is_old; 
    vector < int  >  _ranking_m_index;
    vector < double >  _ranking_m_fitness;

 
};

#endif

