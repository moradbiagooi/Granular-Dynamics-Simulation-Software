#ifndef _GA_HEADERS_H
#define _GA_HEADERS_H


#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <time.h>
#include <sys/stat.h>
#include <string>

using namespace std;

#endif

