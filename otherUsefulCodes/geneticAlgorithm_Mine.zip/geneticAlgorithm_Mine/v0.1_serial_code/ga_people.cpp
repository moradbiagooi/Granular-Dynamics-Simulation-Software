#include "ga_people.h"

void GA_Chromosome_Copy ( class GA_People * best_people, int i, class GA_People * other_people, int j )
{
//     (best_people -> _chromosomes [i])  = (other_people -> _chromosomes [j])  ;
     for ( int k = 0; k<NO_GENES; k++ )
         best_people -> _chromosomes [i].gene (k)  = other_people -> _chromosomes [j].gene (k);
}

void GA_People :: add_child ( GA_Chromosome &c, int i )
{
     for ( int k = 0; k<NO_GENES; k++ )
         _chromosomes [i].gene (k)  = c.gene (k);
}

void GA_People::normalize_fitness  ( )
{

    double fitness_max = 0.0;


    for ( int i = 0; i < NO_PEOPLE; i++ )
    {
        if ( fitness_max < _fitness [i] )
            fitness_max  = _fitness [i];

        if ( _fitness [i] < 0.0 )
            cout << " \n error: negative fitness value \n";
    }

    double pr_fitness_sum = 0.0;
    for ( int i = 0; i < NO_PEOPLE; i++ )
    {
        _pr_fitness [i] = (  fitness_max - _fitness[i] );
        pr_fitness_sum    += _pr_fitness [i];
    }

    if ( pr_fitness_sum < PR_FITNESS_LIMIT )
    {
      cout << "PR_FITNESS_LIMIT is reached:";
      for ( int i = 0; i < NO_PEOPLE; i++ )
      {   
          _fitness [i]   = PR_FITNESS_LIMIT;
          _pr_fitness [i] = PR_FITNESS_LIMIT/NO_PEOPLE;
          pr_fitness_sum += _pr_fitness [i];
      }

    }
    _tot_pr_fitness = 0.0;
    for ( int i = 0; i < NO_PEOPLE; i++ )
    {
        _pr_fitness [i] = _pr_fitness [i] /  pr_fitness_sum;
        _tot_pr_fitness +=  _pr_fitness [i]; 
//        cout << _pr_fitness [i] << " ";
    }
//      cout << "tot_or_fitness :" << _tot_pr_fitness << endl;

}

void GA_People::make_ran_people  ( class MTRand * randnumb )
{


    for ( int i = 0; i < NO_PEOPLE; i++)
    {
//cout <<                _chromosomes[i] -> gene (i);

        _chromosomes[i].new_rand_chrom ( randnumb );
        _chromosomes[i].parents ( i, i);
        _fitness[i] = 1.0;
        _pr_fitness[i] = 1/double(NO_PEOPLE);
    }
}


void GA_People::make_ran_child  ( class MTRand * randnumb, int i )
{
        _chromosomes[i].new_rand_chrom ( randnumb );
        _chromosomes[i].parents ( i, i);
        _fitness[i] = _tot_fitness;
        _pr_fitness[i] = 1/double(NO_PEOPLE);
}

void GA_People::calc_tot_fitness ( )
{
    _tot_fitness = 0.0;

    for ( int i = 0; i < NO_PEOPLE; i++ )
    {

        _tot_fitness += _fitness [i] ;
//      cout << "f["<<i <<"] " << _fitness [i] << " . " ;
    }
//      cout << "r" << _fitness [i] << " " ;
//        cout << "tot fitness" << _tot_fitness << " . " ;

}

int GA_People::ran_select_by_fitness ( class MTRand * randnumb )
{

    double rand_pr_fitness = randnumb -> randDblExc () * _tot_pr_fitness;
    
    double sum_pr_fitness = 0.0;

    int i = 0;


    while ( i < NO_PEOPLE && sum_pr_fitness < rand_pr_fitness )
    {
        sum_pr_fitness += _pr_fitness [i];
        i++;
    }

    return i-1;
}
