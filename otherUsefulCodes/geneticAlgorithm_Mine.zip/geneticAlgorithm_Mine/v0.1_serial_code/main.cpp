#include "headers.h"
#include "ga_headers.h"
#include "ga_macros.h"
#include "ga_functions.h"



int main()
{

    clock_t time_start, time_end;
    time_start = clock ();
    
    genetic_algorithm_run ();

    time_end = clock ();
    double total_time =  ( (float)time_end - (float)time_start ) / CLOCKS_PER_SEC; 
    cout << "\n\n  Total execution time: "  << total_time << " seconds\n\n" ;


    return 0;
      
}

void ga_run_code ( double * gene, double & fitness_value )
{

//    ofstream file_test_function;
//    file_test_function.open ( "output_ga_test_function.txt" );

    double sum = 0.0;

    for ( int i = 0; i < NO_GENES; i++)
    {
//v        double f =  ( double (i) - (double (NO_GENES)/2))/double (NO_GENES) ; //??
        double f = abs ( double (i) - (double (NO_GENES)/2))/double (NO_GENES) ; //??

//      file_test_function << i << " " << f << "\n";
        sum += abs ( (f * f) - gene[i] ); 
    }

    fitness_value = sum; // all of fitness values has to be positive, and a better fitness is a smaller value. the best fitness has to be zero;
//    file_test_function.close();
}
