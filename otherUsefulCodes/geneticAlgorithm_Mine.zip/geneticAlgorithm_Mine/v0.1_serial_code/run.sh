reset
rm a.out *~
#c++ -g -Wall *.cpp *.h
c++ -Wall *.cpp
./a.out
