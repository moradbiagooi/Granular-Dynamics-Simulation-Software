
#include<iostream>

#include"MersenneTwister.h"

using namespace std;

int main(){

    int N=1000;

    long seed = 2;

    class MTRand *RandMaker = new MTRand (seed);

    
    double sum=0.0;

    for ( unsigned int i=0; i<N; i++){
//        double rand = RandMaker -> randDblExc();
        double rand = 2. * (RandMaker -> randDblExc() - 0.5);
        cout << " " << rand ;
        sum+= rand * rand;
    }
    cout << "\n" << sum / double(N) <<"\n";
    

    return 0;
}
