

/***************************/

class Sheath{
  
 private:
  
  class Particle p;
  
 public:
  
  
};


/***************************/


class Particle{
  
 private:
  
 public:


};


/***************************/
