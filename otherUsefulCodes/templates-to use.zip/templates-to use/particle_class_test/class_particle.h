

class Particle{
  
 private:
  double _x;

 public:
  Particle()
    {_x=0.13;};

  Particle(double x)
    {_x=x+0.1;};

  double & x() {return _x;}
  double x() const {return _x;}

};



/***************************/

class Sheath{
  
 private:
  double _x;
//    class Particle p(double _x);  
//    class Particle P();      
//    class Particle;      
// Particle* P;      
//Particle P(2.2);
Particle P();

 public:

  Sheath();
  Sheath(double x){
    _x=x;
//    P = new Particle(double (2));
 //    Particle P(double (2));
//     std::cout<<"\nParticle.x = " << P.x() << "\n";
P.x();
     hh();
  };

  void hh(){std::cout<<"\n"<<_x<<"\n";};

  void gg(){
//     Particle P(double (2.2));
//     std::cout<<"\nParticle.x = " << P.x() << "\n";
//P.x();
}

// void gg(){std::cout<<"Particle.x = " << Particle P.x() << "\n";};

};


/***************************/



/***************************/
