#include<iostream>
#include"class_particle.h"

using namespace std;

int main(){
    
    Sheath VV(0.5);
    VV.gg();
    return 0;
}
