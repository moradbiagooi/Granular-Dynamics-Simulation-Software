reset
g++ -o main main.cc
./main
