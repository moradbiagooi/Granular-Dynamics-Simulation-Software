#include <stdlib.h>
#include <stdio.h>

#include "MersenneTwister.h"


#define Grng_seed (int)2

int main(){

  
  class MTRand   *RandNumb = new MTRand( Grng_seed );

  double rnd = RandNumb -> randDblExc();
  
  printf("rnd = %f\n", rnd);
  
  
  /** End **/
  
  return 0;
  
  
}
